.class Lcom/fakeninjalite/MainActivity$ExpiryResultRunnable;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/fakeninjalite/MainActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x22
    name = "ExpiryResultRunnable"
.end annotation


# instance fields
.field private final exMsg:Ljava/lang/String;

.field private final exState:Ljava/lang/String;

.field private final this$0:Lcom/fakeninjalite/MainActivity;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const/16 v0, 0x7b

    invoke-static {v0}, LBeykix/protect/NativeUtil;->classesInit0(I)V

    return-void
.end method

.method constructor <init>(Lcom/fakeninjalite/MainActivity;Ljava/lang/String;Ljava/lang/String;)V
    .registers 4

    .line 787
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/fakeninjalite/MainActivity$ExpiryResultRunnable;->this$0:Lcom/fakeninjalite/MainActivity;

    .line 788
    iput-object p2, p0, Lcom/fakeninjalite/MainActivity$ExpiryResultRunnable;->exState:Ljava/lang/String;

    iput-object p3, p0, Lcom/fakeninjalite/MainActivity$ExpiryResultRunnable;->exMsg:Ljava/lang/String;

    return-void
.end method

.method static native access$0(Lcom/fakeninjalite/MainActivity$ExpiryResultRunnable;)Lcom/fakeninjalite/MainActivity;
.end method


# virtual methods
.method public native run()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation
.end method
