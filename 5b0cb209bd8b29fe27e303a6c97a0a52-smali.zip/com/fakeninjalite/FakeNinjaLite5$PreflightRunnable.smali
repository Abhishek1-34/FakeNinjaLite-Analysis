.class Lcom/fakeninjalite/FakeNinjaLite5$PreflightRunnable;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/fakeninjalite/FakeNinjaLite5;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2a
    name = "PreflightRunnable"
.end annotation


# instance fields
.field private final cb:Lcom/fakeninjalite/FakeNinjaLite5$PreflightCallback;

.field private final ctx:Landroid/content/Context;

.field private final hours:I


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const/16 v0, 0x4f

    invoke-static {v0}, LBeykix/protect/NativeUtil;->classesInit0(I)V

    return-void
.end method

.method constructor <init>(Landroid/content/Context;ILcom/fakeninjalite/FakeNinjaLite5$PreflightCallback;)V
    .registers 4

    .line 187
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 188
    iput-object p1, p0, Lcom/fakeninjalite/FakeNinjaLite5$PreflightRunnable;->ctx:Landroid/content/Context;

    .line 189
    iput p2, p0, Lcom/fakeninjalite/FakeNinjaLite5$PreflightRunnable;->hours:I

    .line 190
    iput-object p3, p0, Lcom/fakeninjalite/FakeNinjaLite5$PreflightRunnable;->cb:Lcom/fakeninjalite/FakeNinjaLite5$PreflightCallback;

    return-void
.end method


# virtual methods
.method public native run()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation
.end method
