.class Lcom/fakeninjalite/FakeNinjaLite9$RetryClickListener;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/fakeninjalite/FakeNinjaLite9;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x22
    name = "RetryClickListener"
.end annotation


# instance fields
.field private final this$0:Lcom/fakeninjalite/FakeNinjaLite9;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const/16 v0, 0x23

    invoke-static {v0}, LBeykix/protect/NativeUtil;->classesInit0(I)V

    return-void
.end method

.method public constructor <init>(Lcom/fakeninjalite/FakeNinjaLite9;)V
    .registers 2

    .line 236
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/fakeninjalite/FakeNinjaLite9$RetryClickListener;->this$0:Lcom/fakeninjalite/FakeNinjaLite9;

    return-void
.end method

.method static native access$0(Lcom/fakeninjalite/FakeNinjaLite9$RetryClickListener;)Lcom/fakeninjalite/FakeNinjaLite9;
.end method


# virtual methods
.method public native onClick(Landroid/content/DialogInterface;I)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/DialogInterface;",
            "I)V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation
.end method
