.class Lcom/fakeninjalite/FakeNinjaLite8$TeleportPkt;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/fakeninjalite/FakeNinjaLite8;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x28
    name = "TeleportPkt"
.end annotation


# instance fields
.field final data:[B

.field final dataLen:I

.field final dstIp:I

.field final dstPort:I

.field final sock:Ljava/net/DatagramSocket;


# direct methods
.method constructor <init>([BIIILjava/net/DatagramSocket;)V
    .registers 6

    .line 812
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 813
    iput-object p1, p0, Lcom/fakeninjalite/FakeNinjaLite8$TeleportPkt;->data:[B

    iput p2, p0, Lcom/fakeninjalite/FakeNinjaLite8$TeleportPkt;->dataLen:I

    iput p3, p0, Lcom/fakeninjalite/FakeNinjaLite8$TeleportPkt;->dstIp:I

    iput p4, p0, Lcom/fakeninjalite/FakeNinjaLite8$TeleportPkt;->dstPort:I

    iput-object p5, p0, Lcom/fakeninjalite/FakeNinjaLite8$TeleportPkt;->sock:Ljava/net/DatagramSocket;

    return-void
.end method
