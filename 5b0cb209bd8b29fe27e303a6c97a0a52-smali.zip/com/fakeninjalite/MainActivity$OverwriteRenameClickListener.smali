.class Lcom/fakeninjalite/MainActivity$OverwriteRenameClickListener;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/fakeninjalite/MainActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x22
    name = "OverwriteRenameClickListener"
.end annotation


# instance fields
.field private final newName:Ljava/lang/String;

.field private final oldName:Ljava/lang/String;

.field private final this$0:Lcom/fakeninjalite/MainActivity;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const/4 v0, 0x5

    invoke-static {v0}, LBeykix/protect/NativeUtil;->classesInit0(I)V

    return-void
.end method

.method constructor <init>(Lcom/fakeninjalite/MainActivity;Ljava/lang/String;Ljava/lang/String;)V
    .registers 4

    .line 933
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/fakeninjalite/MainActivity$OverwriteRenameClickListener;->this$0:Lcom/fakeninjalite/MainActivity;

    .line 934
    iput-object p2, p0, Lcom/fakeninjalite/MainActivity$OverwriteRenameClickListener;->oldName:Ljava/lang/String;

    iput-object p3, p0, Lcom/fakeninjalite/MainActivity$OverwriteRenameClickListener;->newName:Ljava/lang/String;

    return-void
.end method

.method static native access$0(Lcom/fakeninjalite/MainActivity$OverwriteRenameClickListener;)Lcom/fakeninjalite/MainActivity;
.end method


# virtual methods
.method public native onClick(Landroid/content/DialogInterface;I)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/DialogInterface;",
            "I)V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation
.end method
