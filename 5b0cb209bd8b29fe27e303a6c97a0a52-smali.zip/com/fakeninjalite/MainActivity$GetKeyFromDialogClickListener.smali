.class Lcom/fakeninjalite/MainActivity$GetKeyFromDialogClickListener;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/fakeninjalite/MainActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x22
    name = "GetKeyFromDialogClickListener"
.end annotation


# instance fields
.field private final dlg:Landroid/app/AlertDialog;

.field private final this$0:Lcom/fakeninjalite/MainActivity;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const/16 v0, 0x66

    invoke-static {v0}, LBeykix/protect/NativeUtil;->classesInit0(I)V

    return-void
.end method

.method constructor <init>(Lcom/fakeninjalite/MainActivity;Landroid/app/AlertDialog;)V
    .registers 3

    .line 653
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/fakeninjalite/MainActivity$GetKeyFromDialogClickListener;->this$0:Lcom/fakeninjalite/MainActivity;

    iput-object p2, p0, Lcom/fakeninjalite/MainActivity$GetKeyFromDialogClickListener;->dlg:Landroid/app/AlertDialog;

    return-void
.end method

.method static native access$0(Lcom/fakeninjalite/MainActivity$GetKeyFromDialogClickListener;)Lcom/fakeninjalite/MainActivity;
.end method


# virtual methods
.method public native onClick(Landroid/view/View;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation
.end method
