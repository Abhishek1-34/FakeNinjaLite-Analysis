.class public Lcom/fakeninjalite/FakeNinjaLite6$Config;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/fakeninjalite/FakeNinjaLite6;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x29
    name = "Config"
.end annotation


# instance fields
.field public posXFreezeV2:I

.field public posXGhostV2:I

.field public posXTeleV2:I

.field public posXVpn:I

.field public posYFreezeV2:I

.field public posYGhostV2:I

.field public posYTeleV2:I

.field public posYVpn:I

.field public stepMsTele:J

.field public szFreezeV2:I

.field public szGhostV2:I

.field public szTeleV2:I

.field public szVpn:I

.field public visFreezeV2:Z

.field public visGhostV2:Z

.field public visTeleV2:Z

.field public visVpn:Z


# direct methods
.method public constructor <init>()V
    .registers 4

    .line 42
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/fakeninjalite/FakeNinjaLite6$Config;->visVpn:Z

    iput-boolean v0, p0, Lcom/fakeninjalite/FakeNinjaLite6$Config;->visGhostV2:Z

    iput-boolean v0, p0, Lcom/fakeninjalite/FakeNinjaLite6$Config;->visFreezeV2:Z

    iput-boolean v0, p0, Lcom/fakeninjalite/FakeNinjaLite6$Config;->visTeleV2:Z

    const/16 v0, 0x10

    iput v0, p0, Lcom/fakeninjalite/FakeNinjaLite6$Config;->posXVpn:I

    const/16 v1, 0x64

    iput v1, p0, Lcom/fakeninjalite/FakeNinjaLite6$Config;->posYVpn:I

    const/16 v1, 0x46

    iput v1, p0, Lcom/fakeninjalite/FakeNinjaLite6$Config;->szVpn:I

    iput v0, p0, Lcom/fakeninjalite/FakeNinjaLite6$Config;->posXGhostV2:I

    const/16 v2, 0x140

    iput v2, p0, Lcom/fakeninjalite/FakeNinjaLite6$Config;->posYGhostV2:I

    iput v1, p0, Lcom/fakeninjalite/FakeNinjaLite6$Config;->szGhostV2:I

    iput v0, p0, Lcom/fakeninjalite/FakeNinjaLite6$Config;->posXFreezeV2:I

    const/16 v2, 0xd2

    iput v2, p0, Lcom/fakeninjalite/FakeNinjaLite6$Config;->posYFreezeV2:I

    iput v1, p0, Lcom/fakeninjalite/FakeNinjaLite6$Config;->szFreezeV2:I

    iput v0, p0, Lcom/fakeninjalite/FakeNinjaLite6$Config;->posXTeleV2:I

    const/16 v0, 0x1ae

    iput v0, p0, Lcom/fakeninjalite/FakeNinjaLite6$Config;->posYTeleV2:I

    iput v1, p0, Lcom/fakeninjalite/FakeNinjaLite6$Config;->szTeleV2:I

    const-wide/16 v0, 0x8

    iput-wide v0, p0, Lcom/fakeninjalite/FakeNinjaLite6$Config;->stepMsTele:J

    return-void
.end method
