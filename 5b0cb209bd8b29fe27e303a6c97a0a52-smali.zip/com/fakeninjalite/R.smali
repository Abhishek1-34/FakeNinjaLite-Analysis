.class public final Lcom/fakeninjalite/R;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/fakeninjalite/R$attr;,
        Lcom/fakeninjalite/R$drawable;,
        Lcom/fakeninjalite/R$id;,
        Lcom/fakeninjalite/R$layout;,
        Lcom/fakeninjalite/R$string;,
        Lcom/fakeninjalite/R$style;
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 89
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
