.class Lcom/fakeninjalite/FakeNinjaLite5$VerifyRunnable;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/fakeninjalite/FakeNinjaLite5;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2a
    name = "VerifyRunnable"
.end annotation


# instance fields
.field private final cb:Lcom/fakeninjalite/FakeNinjaLite5$VerifyCallback;

.field private final ctx:Landroid/content/Context;

.field private final hmac:Ljava/lang/String;

.field private final hours:I

.field private final token:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const/16 v0, 0x3f

    invoke-static {v0}, LBeykix/protect/NativeUtil;->classesInit0(I)V

    return-void
.end method

.method constructor <init>(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;ILcom/fakeninjalite/FakeNinjaLite5$VerifyCallback;)V
    .registers 6

    .line 236
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 237
    iput-object p1, p0, Lcom/fakeninjalite/FakeNinjaLite5$VerifyRunnable;->ctx:Landroid/content/Context;

    .line 238
    iput-object p2, p0, Lcom/fakeninjalite/FakeNinjaLite5$VerifyRunnable;->token:Ljava/lang/String;

    .line 239
    iput-object p3, p0, Lcom/fakeninjalite/FakeNinjaLite5$VerifyRunnable;->hmac:Ljava/lang/String;

    .line 240
    iput p4, p0, Lcom/fakeninjalite/FakeNinjaLite5$VerifyRunnable;->hours:I

    .line 241
    iput-object p5, p0, Lcom/fakeninjalite/FakeNinjaLite5$VerifyRunnable;->cb:Lcom/fakeninjalite/FakeNinjaLite5$VerifyCallback;

    return-void
.end method


# virtual methods
.method public native run()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation
.end method
