.class public interface abstract Lcom/fakeninjalite/FakeNinjaLite5$VerifyCallback;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/fakeninjalite/FakeNinjaLite5;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x209
    name = "VerifyCallback"
.end annotation


# virtual methods
.method public abstract onResult(Ljava/lang/String;JLjava/lang/String;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "J",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation
.end method
