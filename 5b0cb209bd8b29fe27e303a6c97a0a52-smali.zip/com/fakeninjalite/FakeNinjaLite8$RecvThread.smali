.class Lcom/fakeninjalite/FakeNinjaLite8$RecvThread;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/fakeninjalite/FakeNinjaLite8;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x22
    name = "RecvThread"
.end annotation


# instance fields
.field private final dstPort:I

.field private final key:Lcom/fakeninjalite/FakeNinjaLite8$ConnKey;

.field private final out:Ljava/io/FileOutputStream;

.field private final sock:Ljava/net/DatagramSocket;

.field private final srcIp:I

.field private final srcPort:I

.field private final this$0:Lcom/fakeninjalite/FakeNinjaLite8;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const/16 v0, 0x6b

    invoke-static {v0}, LBeykix/protect/NativeUtil;->classesInit0(I)V

    return-void
.end method

.method constructor <init>(Lcom/fakeninjalite/FakeNinjaLite8;Ljava/net/DatagramSocket;IIILjava/io/FileOutputStream;Lcom/fakeninjalite/FakeNinjaLite8$ConnKey;)V
    .registers 8

    .line 411
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/fakeninjalite/FakeNinjaLite8$RecvThread;->this$0:Lcom/fakeninjalite/FakeNinjaLite8;

    .line 412
    iput-object p2, p0, Lcom/fakeninjalite/FakeNinjaLite8$RecvThread;->sock:Ljava/net/DatagramSocket;

    .line 413
    iput p3, p0, Lcom/fakeninjalite/FakeNinjaLite8$RecvThread;->srcIp:I

    .line 414
    iput p4, p0, Lcom/fakeninjalite/FakeNinjaLite8$RecvThread;->srcPort:I

    .line 415
    iput p5, p0, Lcom/fakeninjalite/FakeNinjaLite8$RecvThread;->dstPort:I

    .line 416
    iput-object p6, p0, Lcom/fakeninjalite/FakeNinjaLite8$RecvThread;->out:Ljava/io/FileOutputStream;

    .line 417
    iput-object p7, p0, Lcom/fakeninjalite/FakeNinjaLite8$RecvThread;->key:Lcom/fakeninjalite/FakeNinjaLite8$ConnKey;

    return-void
.end method

.method static native access$0(Lcom/fakeninjalite/FakeNinjaLite8$RecvThread;)Lcom/fakeninjalite/FakeNinjaLite8;
.end method


# virtual methods
.method public native run()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation
.end method
