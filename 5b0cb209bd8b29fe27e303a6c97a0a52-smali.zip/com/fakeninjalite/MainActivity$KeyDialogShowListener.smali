.class Lcom/fakeninjalite/MainActivity$KeyDialogShowListener;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/content/DialogInterface$OnShowListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/fakeninjalite/MainActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x22
    name = "KeyDialogShowListener"
.end annotation


# instance fields
.field private final dlg:Landroid/app/AlertDialog;

.field private final et:Landroid/widget/EditText;

.field private final this$0:Lcom/fakeninjalite/MainActivity;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const/16 v0, 0x7c

    invoke-static {v0}, LBeykix/protect/NativeUtil;->classesInit0(I)V

    return-void
.end method

.method constructor <init>(Lcom/fakeninjalite/MainActivity;Landroid/widget/EditText;Landroid/app/AlertDialog;)V
    .registers 4

    .line 635
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/fakeninjalite/MainActivity$KeyDialogShowListener;->this$0:Lcom/fakeninjalite/MainActivity;

    .line 636
    iput-object p2, p0, Lcom/fakeninjalite/MainActivity$KeyDialogShowListener;->et:Landroid/widget/EditText;

    iput-object p3, p0, Lcom/fakeninjalite/MainActivity$KeyDialogShowListener;->dlg:Landroid/app/AlertDialog;

    return-void
.end method

.method static native access$0(Lcom/fakeninjalite/MainActivity$KeyDialogShowListener;)Lcom/fakeninjalite/MainActivity;
.end method


# virtual methods
.method public native onShow(Landroid/content/DialogInterface;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/DialogInterface;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation
.end method
