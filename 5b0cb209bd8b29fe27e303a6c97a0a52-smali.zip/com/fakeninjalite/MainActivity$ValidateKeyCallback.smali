.class Lcom/fakeninjalite/MainActivity$ValidateKeyCallback;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/fakeninjalite/FakeNinjaLite5$ValidateCallback;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/fakeninjalite/MainActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x22
    name = "ValidateKeyCallback"
.end annotation


# instance fields
.field private final bA:Landroid/widget/Button;

.field private final bE:Landroid/widget/Button;

.field private final bG:Landroid/widget/Button;

.field private final dlg:Landroid/app/AlertDialog;

.field private final et:Landroid/widget/EditText;

.field private final this$0:Lcom/fakeninjalite/MainActivity;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const/4 v0, 0x7

    invoke-static {v0}, LBeykix/protect/NativeUtil;->classesInit0(I)V

    return-void
.end method

.method constructor <init>(Lcom/fakeninjalite/MainActivity;Landroid/widget/EditText;Landroid/app/AlertDialog;Landroid/widget/Button;Landroid/widget/Button;Landroid/widget/Button;)V
    .registers 7

    .line 591
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/fakeninjalite/MainActivity$ValidateKeyCallback;->this$0:Lcom/fakeninjalite/MainActivity;

    .line 592
    iput-object p2, p0, Lcom/fakeninjalite/MainActivity$ValidateKeyCallback;->et:Landroid/widget/EditText;

    iput-object p3, p0, Lcom/fakeninjalite/MainActivity$ValidateKeyCallback;->dlg:Landroid/app/AlertDialog;

    .line 593
    iput-object p4, p0, Lcom/fakeninjalite/MainActivity$ValidateKeyCallback;->bA:Landroid/widget/Button;

    iput-object p5, p0, Lcom/fakeninjalite/MainActivity$ValidateKeyCallback;->bG:Landroid/widget/Button;

    iput-object p6, p0, Lcom/fakeninjalite/MainActivity$ValidateKeyCallback;->bE:Landroid/widget/Button;

    return-void
.end method

.method static native access$0(Lcom/fakeninjalite/MainActivity$ValidateKeyCallback;)Lcom/fakeninjalite/MainActivity;
.end method


# virtual methods
.method public native onResult(IJ)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(IJ)V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation
.end method
