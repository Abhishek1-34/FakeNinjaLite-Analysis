.class Lcom/fakeninjalite/FakeNinjaLite8$100000000;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/fakeninjalite/FakeNinjaLite8;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000000"
.end annotation


# instance fields
.field private final this$0:Lcom/fakeninjalite/FakeNinjaLite8;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const/16 v0, 0x61

    invoke-static {v0}, LBeykix/protect/NativeUtil;->classesInit0(I)V

    return-void
.end method

.method constructor <init>(Lcom/fakeninjalite/FakeNinjaLite8;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/fakeninjalite/FakeNinjaLite8$100000000;->this$0:Lcom/fakeninjalite/FakeNinjaLite8;

    return-void
.end method

.method static native access$0(Lcom/fakeninjalite/FakeNinjaLite8$100000000;)Lcom/fakeninjalite/FakeNinjaLite8;
.end method


# virtual methods
.method public native run()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation
.end method
