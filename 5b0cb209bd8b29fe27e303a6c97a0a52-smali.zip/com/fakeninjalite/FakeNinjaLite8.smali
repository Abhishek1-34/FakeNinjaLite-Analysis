.class public Lcom/fakeninjalite/FakeNinjaLite8;
.super Landroid/net/VpnService;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/fakeninjalite/FakeNinjaLite8$RestartVpnRunnable;,
        Lcom/fakeninjalite/FakeNinjaLite8$Pkt;,
        Lcom/fakeninjalite/FakeNinjaLite8$ConnKey;,
        Lcom/fakeninjalite/FakeNinjaLite8$RxWorker;,
        Lcom/fakeninjalite/FakeNinjaLite8$QueuedPkt;,
        Lcom/fakeninjalite/FakeNinjaLite8$QueueFlushTask;,
        Lcom/fakeninjalite/FakeNinjaLite8$100000000;,
        Lcom/fakeninjalite/FakeNinjaLite8$100000001;,
        Lcom/fakeninjalite/FakeNinjaLite8$100000002;,
        Lcom/fakeninjalite/FakeNinjaLite8$100000003;
    }
.end annotation


# static fields
.field public static final ACT_FREEZE:Ljava/lang/String; = "com.fakeninjalite.ACT_FREEZE"

.field public static final ACT_FREEZE_V2:Ljava/lang/String; = "com.fakeninjalite.ACT_FREEZE_V2"

.field public static final ACT_FREEZE_V2_CANCEL:Ljava/lang/String; = "com.fakeninjalite.ACT_FREEZE_V2_CANCEL"

.field public static final ACT_GHOST_V2:Ljava/lang/String; = "com.fakeninjalite.ACT_GHOST_V2"

.field public static final ACT_GHOST_V2_CANCEL:Ljava/lang/String; = "com.fakeninjalite.ACT_GHOST_V2_CANCEL"

.field public static final ACT_INTERCEPT:Ljava/lang/String; = "com.fakeninjalite.ACT_INTERCEPT"

.field public static final ACT_SET:Ljava/lang/String; = "com.fakeninjalite.ACT_SET"

.field public static final ACT_STAT:Ljava/lang/String; = "com.fakeninjalite.ACT_STAT"

.field public static final ACT_STOP:Ljava/lang/String; = "com.fakeninjalite.ACT_STOP"

.field public static final ACT_TELEPORT_V2_CANCEL:Ljava/lang/String; = "com.fakeninjalite.ACT_TELEPORT_V2_CANCEL"

.field public static final ACT_TELEPORT_V2_EXEC:Ljava/lang/String; = "com.fakeninjalite.ACT_TELEPORT_V2_EXEC"

.field public static final ACT_TELEPORT_V2_MARK:Ljava/lang/String; = "com.fakeninjalite.ACT_TELEPORT_V2_MARK"

.field public static final ACT_VPN_OFF:Ljava/lang/String; = "com.fakeninjalite.ACT_VPN_OFF"

.field public static final ACT_VPN_ON:Ljava/lang/String; = "com.fakeninjalite.ACT_VPN_ON"

.field public static volatile FREEZE_V2_DELAY_MS:J = 0x0L

.field public static volatile FREEZE_V2_ON_MS:J = 0x0L

.field public static volatile GHOST_V2_INTERVAL_MS:J = 0x0L

.field private static final JOURNEY_MAX:I = 0x7d0

.field public static volatile TELE_STEP_MS:J = 0x0L

.field private static final TELE_V2_LOCK_BURST:I = 0xa

.field private static final TELE_V2_LOCK_MS:J = 0x3cL

.field public static volatile TELE_V2_STEP_MS:J

.field private static final rnd:Ljava/util/Random;


# instance fields
.field private volatile active:Z

.field private volatile isFreeze:Z

.field private volatile isIntercept:Z

.field private volatile isRunning:Z

.field private localIp:I

.field private volatile mFlushLatch:Z

.field private volatile mFlushWorker:Ljava/lang/Thread;

.field private volatile mPeerAddr:I

.field private volatile mPeerBuf:[B

.field private volatile mPeerLen:I

.field private volatile mPeerPort:I

.field private volatile mPeerSock:Ljava/net/DatagramSocket;

.field private volatile mPeerSync:Z

.field private volatile mPeerWorker:Ljava/lang/Thread;

.field private final mPktQueue:Ljava/util/concurrent/ConcurrentLinkedDeque;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/ConcurrentLinkedDeque<",
            "Lcom/fakeninjalite/FakeNinjaLite8$QueuedPkt;",
            ">;"
        }
    .end annotation
.end field

.field private volatile mPulseActive:Z

.field private volatile mPulseWorker:Ljava/lang/Thread;

.field private volatile mQueueLatch:Z

.field private volatile mSnapAddr:I

.field private volatile mSnapBuf:[B

.field private volatile mSnapLen:I

.field private volatile mSnapPort:I

.field private volatile mSnapSock:Ljava/net/DatagramSocket;

.field private volatile mSnapWorker:Ljava/lang/Thread;

.field private pool:Ljava/util/concurrent/ExecutorService;

.field private volatile statBIn:J

.field private volatile statBOut:J

.field private volatile statDrop:J

.field private volatile statSent:J

.field private volatile statThread:Ljava/lang/Thread;

.field private targetPkg:Ljava/lang/String;

.field private final udpSockets:Ljava/util/concurrent/ConcurrentHashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/ConcurrentHashMap<",
            "Lcom/fakeninjalite/FakeNinjaLite8$ConnKey;",
            "Ljava/net/DatagramSocket;",
            ">;"
        }
    .end annotation
.end field

.field private vpnIface:Landroid/os/ParcelFileDescriptor;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    const/16 v0, 0x40

    invoke-static {v0}, LBeykix/protect/NativeUtil;->classesInit0(I)V

    const-wide/16 v0, 0x4b0

    sput-wide v0, Lcom/fakeninjalite/FakeNinjaLite8;->FREEZE_V2_ON_MS:J

    const-wide/16 v0, 0x320

    sput-wide v0, Lcom/fakeninjalite/FakeNinjaLite8;->FREEZE_V2_DELAY_MS:J

    const-wide/16 v0, 0x32

    sput-wide v0, Lcom/fakeninjalite/FakeNinjaLite8;->GHOST_V2_INTERVAL_MS:J

    const-wide/16 v0, 0x8

    sput-wide v0, Lcom/fakeninjalite/FakeNinjaLite8;->TELE_STEP_MS:J

    sput-wide v0, Lcom/fakeninjalite/FakeNinjaLite8;->TELE_V2_STEP_MS:J

    new-instance v0, Ljava/util/Random;

    invoke-direct {v0}, Ljava/util/Random;-><init>()V

    sput-object v0, Lcom/fakeninjalite/FakeNinjaLite8;->rnd:Ljava/util/Random;

    return-void
.end method

.method public constructor <init>()V
    .registers 5

    .line 779
    invoke-direct {p0}, Landroid/net/VpnService;-><init>()V

    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/fakeninjalite/FakeNinjaLite8;->isRunning:Z

    iput-boolean v0, p0, Lcom/fakeninjalite/FakeNinjaLite8;->active:Z

    iput-boolean v0, p0, Lcom/fakeninjalite/FakeNinjaLite8;->isFreeze:Z

    const/4 v1, 0x0

    move-object v2, v1

    check-cast v2, [B

    iput-object v1, p0, Lcom/fakeninjalite/FakeNinjaLite8;->mSnapBuf:[B

    iput v0, p0, Lcom/fakeninjalite/FakeNinjaLite8;->mSnapLen:I

    iput v0, p0, Lcom/fakeninjalite/FakeNinjaLite8;->mSnapAddr:I

    iput v0, p0, Lcom/fakeninjalite/FakeNinjaLite8;->mSnapPort:I

    move-object v2, v1

    check-cast v2, Ljava/net/DatagramSocket;

    iput-object v1, p0, Lcom/fakeninjalite/FakeNinjaLite8;->mSnapSock:Ljava/net/DatagramSocket;

    move-object v2, v1

    check-cast v2, Ljava/lang/Thread;

    iput-object v1, p0, Lcom/fakeninjalite/FakeNinjaLite8;->mSnapWorker:Ljava/lang/Thread;

    iput-boolean v0, p0, Lcom/fakeninjalite/FakeNinjaLite8;->mPulseActive:Z

    iput-object v1, p0, Lcom/fakeninjalite/FakeNinjaLite8;->mPulseWorker:Ljava/lang/Thread;

    iput-boolean v0, p0, Lcom/fakeninjalite/FakeNinjaLite8;->mPeerSync:Z

    iput-object v1, p0, Lcom/fakeninjalite/FakeNinjaLite8;->mPeerBuf:[B

    iput v0, p0, Lcom/fakeninjalite/FakeNinjaLite8;->mPeerLen:I

    iput v0, p0, Lcom/fakeninjalite/FakeNinjaLite8;->mPeerAddr:I

    iput v0, p0, Lcom/fakeninjalite/FakeNinjaLite8;->mPeerPort:I

    iput-object v1, p0, Lcom/fakeninjalite/FakeNinjaLite8;->mPeerSock:Ljava/net/DatagramSocket;

    iput-object v1, p0, Lcom/fakeninjalite/FakeNinjaLite8;->mPeerWorker:Ljava/lang/Thread;

    iput-boolean v0, p0, Lcom/fakeninjalite/FakeNinjaLite8;->mQueueLatch:Z

    iput-boolean v0, p0, Lcom/fakeninjalite/FakeNinjaLite8;->mFlushLatch:Z

    new-instance v2, Ljava/util/concurrent/ConcurrentLinkedDeque;

    invoke-direct {v2}, Ljava/util/concurrent/ConcurrentLinkedDeque;-><init>()V

    iput-object v2, p0, Lcom/fakeninjalite/FakeNinjaLite8;->mPktQueue:Ljava/util/concurrent/ConcurrentLinkedDeque;

    iput-object v1, p0, Lcom/fakeninjalite/FakeNinjaLite8;->mFlushWorker:Ljava/lang/Thread;

    iput-boolean v0, p0, Lcom/fakeninjalite/FakeNinjaLite8;->isIntercept:Z

    const-string v2, ""

    invoke-static {v2}, Lobfuse/NPStringFog;->decode(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    iput-object v2, p0, Lcom/fakeninjalite/FakeNinjaLite8;->targetPkg:Ljava/lang/String;

    const v2, 0xa000002

    iput v2, p0, Lcom/fakeninjalite/FakeNinjaLite8;->localIp:I

    new-instance v2, Ljava/util/concurrent/ConcurrentHashMap;

    invoke-direct {v2}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    iput-object v2, p0, Lcom/fakeninjalite/FakeNinjaLite8;->udpSockets:Ljava/util/concurrent/ConcurrentHashMap;

    int-to-long v2, v0

    iput-wide v2, p0, Lcom/fakeninjalite/FakeNinjaLite8;->statSent:J

    iput-wide v2, p0, Lcom/fakeninjalite/FakeNinjaLite8;->statDrop:J

    iput-wide v2, p0, Lcom/fakeninjalite/FakeNinjaLite8;->statBIn:J

    iput-wide v2, p0, Lcom/fakeninjalite/FakeNinjaLite8;->statBOut:J

    iput-object v1, p0, Lcom/fakeninjalite/FakeNinjaLite8;->statThread:Ljava/lang/Thread;

    return-void
.end method

.method static synthetic access$1000056(Lcom/fakeninjalite/FakeNinjaLite8;)V
    .registers 1

    invoke-direct {p0}, Lcom/fakeninjalite/FakeNinjaLite8;->snapOn()V

    return-void
.end method

.method static synthetic access$1000057(Lcom/fakeninjalite/FakeNinjaLite8;)V
    .registers 1

    invoke-direct {p0}, Lcom/fakeninjalite/FakeNinjaLite8;->snapOff()V

    return-void
.end method

.method static synthetic access$1000063(Lcom/fakeninjalite/FakeNinjaLite8;Ljava/net/DatagramPacket;III)[B
    .registers 5

    invoke-direct {p0, p1, p2, p3, p4}, Lcom/fakeninjalite/FakeNinjaLite8;->buildReply(Ljava/net/DatagramPacket;III)[B

    move-result-object p0

    return-object p0
.end method

.method static synthetic access$1000065(I)[B
    .registers 1

    invoke-static {p0}, Lcom/fakeninjalite/FakeNinjaLite8;->ipBytes(I)[B

    move-result-object p0

    return-object p0
.end method

.method static synthetic access$1000066(Lcom/fakeninjalite/FakeNinjaLite8;I)Ljava/net/DatagramSocket;
    .registers 2

    invoke-direct {p0, p1}, Lcom/fakeninjalite/FakeNinjaLite8;->findActiveSock(I)Ljava/net/DatagramSocket;

    move-result-object p0

    return-object p0
.end method

.method static synthetic access$L1000001()I
    .registers 1

    sget v0, Lcom/fakeninjalite/FakeNinjaLite8;->TELE_V2_LOCK_BURST:I

    return v0
.end method

.method static synthetic access$L1000002()J
    .registers 2

    sget-wide v0, Lcom/fakeninjalite/FakeNinjaLite8;->TELE_V2_LOCK_MS:J

    return-wide v0
.end method

.method static synthetic access$L1000003(Lcom/fakeninjalite/FakeNinjaLite8;)Z
    .registers 1

    iget-boolean p0, p0, Lcom/fakeninjalite/FakeNinjaLite8;->isRunning:Z

    return p0
.end method

.method static synthetic access$L1000004(Lcom/fakeninjalite/FakeNinjaLite8;)Z
    .registers 1

    iget-boolean p0, p0, Lcom/fakeninjalite/FakeNinjaLite8;->active:Z

    return p0
.end method

.method static synthetic access$L1000005(Lcom/fakeninjalite/FakeNinjaLite8;)Z
    .registers 1

    iget-boolean p0, p0, Lcom/fakeninjalite/FakeNinjaLite8;->isFreeze:Z

    return p0
.end method

.method static synthetic access$L1000006(Lcom/fakeninjalite/FakeNinjaLite8;)[B
    .registers 1

    iget-object p0, p0, Lcom/fakeninjalite/FakeNinjaLite8;->mSnapBuf:[B

    return-object p0
.end method

.method static synthetic access$L1000007(Lcom/fakeninjalite/FakeNinjaLite8;)I
    .registers 1

    iget p0, p0, Lcom/fakeninjalite/FakeNinjaLite8;->mSnapLen:I

    return p0
.end method

.method static synthetic access$L1000008(Lcom/fakeninjalite/FakeNinjaLite8;)I
    .registers 1

    iget p0, p0, Lcom/fakeninjalite/FakeNinjaLite8;->mSnapAddr:I

    return p0
.end method

.method static synthetic access$L1000009(Lcom/fakeninjalite/FakeNinjaLite8;)I
    .registers 1

    iget p0, p0, Lcom/fakeninjalite/FakeNinjaLite8;->mSnapPort:I

    return p0
.end method

.method static synthetic access$L1000010(Lcom/fakeninjalite/FakeNinjaLite8;)Ljava/net/DatagramSocket;
    .registers 1

    iget-object p0, p0, Lcom/fakeninjalite/FakeNinjaLite8;->mSnapSock:Ljava/net/DatagramSocket;

    return-object p0
.end method

.method static synthetic access$L1000012(Lcom/fakeninjalite/FakeNinjaLite8;)Z
    .registers 1

    iget-boolean p0, p0, Lcom/fakeninjalite/FakeNinjaLite8;->mPulseActive:Z

    return p0
.end method

.method static synthetic access$L1000014(Lcom/fakeninjalite/FakeNinjaLite8;)Z
    .registers 1

    iget-boolean p0, p0, Lcom/fakeninjalite/FakeNinjaLite8;->mPeerSync:Z

    return p0
.end method

.method static synthetic access$L1000015(Lcom/fakeninjalite/FakeNinjaLite8;)[B
    .registers 1

    iget-object p0, p0, Lcom/fakeninjalite/FakeNinjaLite8;->mPeerBuf:[B

    return-object p0
.end method

.method static synthetic access$L1000016(Lcom/fakeninjalite/FakeNinjaLite8;)I
    .registers 1

    iget p0, p0, Lcom/fakeninjalite/FakeNinjaLite8;->mPeerLen:I

    return p0
.end method

.method static synthetic access$L1000017(Lcom/fakeninjalite/FakeNinjaLite8;)I
    .registers 1

    iget p0, p0, Lcom/fakeninjalite/FakeNinjaLite8;->mPeerAddr:I

    return p0
.end method

.method static synthetic access$L1000018(Lcom/fakeninjalite/FakeNinjaLite8;)I
    .registers 1

    iget p0, p0, Lcom/fakeninjalite/FakeNinjaLite8;->mPeerPort:I

    return p0
.end method

.method static synthetic access$L1000019(Lcom/fakeninjalite/FakeNinjaLite8;)Ljava/net/DatagramSocket;
    .registers 1

    iget-object p0, p0, Lcom/fakeninjalite/FakeNinjaLite8;->mPeerSock:Ljava/net/DatagramSocket;

    return-object p0
.end method

.method static synthetic access$L1000022(Lcom/fakeninjalite/FakeNinjaLite8;)Z
    .registers 1

    iget-boolean p0, p0, Lcom/fakeninjalite/FakeNinjaLite8;->mFlushLatch:Z

    return p0
.end method

.method static synthetic access$L1000031(Lcom/fakeninjalite/FakeNinjaLite8;)Ljava/util/concurrent/ConcurrentHashMap;
    .registers 1

    iget-object p0, p0, Lcom/fakeninjalite/FakeNinjaLite8;->udpSockets:Ljava/util/concurrent/ConcurrentHashMap;

    return-object p0
.end method

.method static synthetic access$L1000032(Lcom/fakeninjalite/FakeNinjaLite8;)J
    .registers 3

    iget-wide v0, p0, Lcom/fakeninjalite/FakeNinjaLite8;->statSent:J

    return-wide v0
.end method

.method static synthetic access$L1000033(Lcom/fakeninjalite/FakeNinjaLite8;)J
    .registers 3

    iget-wide v0, p0, Lcom/fakeninjalite/FakeNinjaLite8;->statDrop:J

    return-wide v0
.end method

.method static synthetic access$L1000034(Lcom/fakeninjalite/FakeNinjaLite8;)J
    .registers 3

    iget-wide v0, p0, Lcom/fakeninjalite/FakeNinjaLite8;->statBIn:J

    return-wide v0
.end method

.method static synthetic access$L1000035(Lcom/fakeninjalite/FakeNinjaLite8;)J
    .registers 3

    iget-wide v0, p0, Lcom/fakeninjalite/FakeNinjaLite8;->statBOut:J

    return-wide v0
.end method

.method static synthetic access$S1000001(I)V
    .registers 1

    sput p0, Lcom/fakeninjalite/FakeNinjaLite8;->TELE_V2_LOCK_BURST:I

    return-void
.end method

.method static synthetic access$S1000002(J)V
    .registers 2

    sput-wide p0, Lcom/fakeninjalite/FakeNinjaLite8;->TELE_V2_LOCK_MS:J

    return-void
.end method

.method static synthetic access$S1000003(Lcom/fakeninjalite/FakeNinjaLite8;Z)V
    .registers 2

    iput-boolean p1, p0, Lcom/fakeninjalite/FakeNinjaLite8;->isRunning:Z

    return-void
.end method

.method static synthetic access$S1000004(Lcom/fakeninjalite/FakeNinjaLite8;Z)V
    .registers 2

    iput-boolean p1, p0, Lcom/fakeninjalite/FakeNinjaLite8;->active:Z

    return-void
.end method

.method static synthetic access$S1000005(Lcom/fakeninjalite/FakeNinjaLite8;Z)V
    .registers 2

    iput-boolean p1, p0, Lcom/fakeninjalite/FakeNinjaLite8;->isFreeze:Z

    return-void
.end method

.method static synthetic access$S1000006(Lcom/fakeninjalite/FakeNinjaLite8;[B)V
    .registers 2

    iput-object p1, p0, Lcom/fakeninjalite/FakeNinjaLite8;->mSnapBuf:[B

    return-void
.end method

.method static synthetic access$S1000007(Lcom/fakeninjalite/FakeNinjaLite8;I)V
    .registers 2

    iput p1, p0, Lcom/fakeninjalite/FakeNinjaLite8;->mSnapLen:I

    return-void
.end method

.method static synthetic access$S1000008(Lcom/fakeninjalite/FakeNinjaLite8;I)V
    .registers 2

    iput p1, p0, Lcom/fakeninjalite/FakeNinjaLite8;->mSnapAddr:I

    return-void
.end method

.method static synthetic access$S1000009(Lcom/fakeninjalite/FakeNinjaLite8;I)V
    .registers 2

    iput p1, p0, Lcom/fakeninjalite/FakeNinjaLite8;->mSnapPort:I

    return-void
.end method

.method static synthetic access$S1000010(Lcom/fakeninjalite/FakeNinjaLite8;Ljava/net/DatagramSocket;)V
    .registers 2

    iput-object p1, p0, Lcom/fakeninjalite/FakeNinjaLite8;->mSnapSock:Ljava/net/DatagramSocket;

    return-void
.end method

.method static synthetic access$S1000012(Lcom/fakeninjalite/FakeNinjaLite8;Z)V
    .registers 2

    iput-boolean p1, p0, Lcom/fakeninjalite/FakeNinjaLite8;->mPulseActive:Z

    return-void
.end method

.method static synthetic access$S1000014(Lcom/fakeninjalite/FakeNinjaLite8;Z)V
    .registers 2

    iput-boolean p1, p0, Lcom/fakeninjalite/FakeNinjaLite8;->mPeerSync:Z

    return-void
.end method

.method static synthetic access$S1000015(Lcom/fakeninjalite/FakeNinjaLite8;[B)V
    .registers 2

    iput-object p1, p0, Lcom/fakeninjalite/FakeNinjaLite8;->mPeerBuf:[B

    return-void
.end method

.method static synthetic access$S1000016(Lcom/fakeninjalite/FakeNinjaLite8;I)V
    .registers 2

    iput p1, p0, Lcom/fakeninjalite/FakeNinjaLite8;->mPeerLen:I

    return-void
.end method

.method static synthetic access$S1000017(Lcom/fakeninjalite/FakeNinjaLite8;I)V
    .registers 2

    iput p1, p0, Lcom/fakeninjalite/FakeNinjaLite8;->mPeerAddr:I

    return-void
.end method

.method static synthetic access$S1000018(Lcom/fakeninjalite/FakeNinjaLite8;I)V
    .registers 2

    iput p1, p0, Lcom/fakeninjalite/FakeNinjaLite8;->mPeerPort:I

    return-void
.end method

.method static synthetic access$S1000019(Lcom/fakeninjalite/FakeNinjaLite8;Ljava/net/DatagramSocket;)V
    .registers 2

    iput-object p1, p0, Lcom/fakeninjalite/FakeNinjaLite8;->mPeerSock:Ljava/net/DatagramSocket;

    return-void
.end method

.method static synthetic access$S1000022(Lcom/fakeninjalite/FakeNinjaLite8;Z)V
    .registers 2

    iput-boolean p1, p0, Lcom/fakeninjalite/FakeNinjaLite8;->mFlushLatch:Z

    return-void
.end method

.method static synthetic access$S1000031(Lcom/fakeninjalite/FakeNinjaLite8;Ljava/util/concurrent/ConcurrentHashMap;)V
    .registers 2

    iput-object p1, p0, Lcom/fakeninjalite/FakeNinjaLite8;->udpSockets:Ljava/util/concurrent/ConcurrentHashMap;

    return-void
.end method

.method static synthetic access$S1000032(Lcom/fakeninjalite/FakeNinjaLite8;J)V
    .registers 3

    iput-wide p1, p0, Lcom/fakeninjalite/FakeNinjaLite8;->statSent:J

    return-void
.end method

.method static synthetic access$S1000033(Lcom/fakeninjalite/FakeNinjaLite8;J)V
    .registers 3

    iput-wide p1, p0, Lcom/fakeninjalite/FakeNinjaLite8;->statDrop:J

    return-void
.end method

.method static synthetic access$S1000034(Lcom/fakeninjalite/FakeNinjaLite8;J)V
    .registers 3

    iput-wide p1, p0, Lcom/fakeninjalite/FakeNinjaLite8;->statBIn:J

    return-void
.end method

.method static synthetic access$S1000035(Lcom/fakeninjalite/FakeNinjaLite8;J)V
    .registers 3

    iput-wide p1, p0, Lcom/fakeninjalite/FakeNinjaLite8;->statBOut:J

    return-void
.end method

.method private native buildReply(Ljava/net/DatagramPacket;III)[B
.end method

.method private native buildTunnel(III)Landroid/os/ParcelFileDescriptor;
.end method

.method private native closeAllSockets()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation
.end method

.method private native closeIface()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation
.end method

.method private native drainQueue()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation
.end method

.method private native findActiveSock(I)Ljava/net/DatagramSocket;
.end method

.method private native haltFlush()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation
.end method

.method private native handleAction(Ljava/lang/String;Landroid/content/Intent;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Landroid/content/Intent;",
            ")V"
        }
    .end annotation
.end method

.method private static native ipBytes(I)[B
.end method

.method private static native ipChecksum(Ljava/nio/ByteBuffer;I)S
.end method

.method private native processUdp(Lcom/fakeninjalite/FakeNinjaLite8$Pkt;Ljava/io/FileOutputStream;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/fakeninjalite/FakeNinjaLite8$Pkt;",
            "Ljava/io/FileOutputStream;",
            ")V"
        }
    .end annotation
.end method

.method private native pulseOff()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation
.end method

.method private native pulseOn()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation
.end method

.method private native restartVpn()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation
.end method

.method private native shutDown()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation
.end method

.method private native shutDownVpn()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation
.end method

.method private native snapOff()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation
.end method

.method private native snapOn()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation
.end method

.method private native startFg()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation
.end method

.method private native startStatThread()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation
.end method

.method private native syncPeerOff()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation
.end method

.method private native syncPeerOn()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation
.end method


# virtual methods
.method public native onBind(Landroid/content/Intent;)Landroid/os/IBinder;
    .annotation runtime Ljava/lang/Override;
    .end annotation
.end method

.method public native onCreate()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation
.end method

.method public native onDestroy()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation
.end method

.method public native onStartCommand(Landroid/content/Intent;II)I
    .annotation runtime Ljava/lang/Override;
    .end annotation
.end method

.method public native onTaskRemoved(Landroid/content/Intent;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Intent;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation
.end method

.method public native run()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation
.end method
