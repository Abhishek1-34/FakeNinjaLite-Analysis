.class public Lcom/fakeninjalite/FakeNinjaLite9;
.super Landroid/app/Activity;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/fakeninjalite/FakeNinjaLite9$CloseBtnClickListener;,
        Lcom/fakeninjalite/FakeNinjaLite9$WebProgressClient;,
        Lcom/fakeninjalite/FakeNinjaLite9$GetKeyWebViewClient;,
        Lcom/fakeninjalite/FakeNinjaLite9$JsBridge;,
        Lcom/fakeninjalite/FakeNinjaLite9$JsSuccessRunnable;,
        Lcom/fakeninjalite/FakeNinjaLite9$DoVerifyRunnable;,
        Lcom/fakeninjalite/FakeNinjaLite9$SetStatusRunnable;,
        Lcom/fakeninjalite/FakeNinjaLite9$PreflightResultCallback;,
        Lcom/fakeninjalite/FakeNinjaLite9$PreflightResultRunnable;,
        Lcom/fakeninjalite/FakeNinjaLite9$VerifyResultCallback;,
        Lcom/fakeninjalite/FakeNinjaLite9$VerifyResultRunnable;,
        Lcom/fakeninjalite/FakeNinjaLite9$RetryClickListener;,
        Lcom/fakeninjalite/FakeNinjaLite9$CancelResultClickListener;,
        Lcom/fakeninjalite/FakeNinjaLite9$ConfirmCancelYesClickListener;,
        Lcom/fakeninjalite/FakeNinjaLite9$100000000;
    }
.end annotation


# static fields
.field public static final EXTRA_HOURS:Ljava/lang/String; = "hours"

.field public static final RESULT_EXPIRY_MS:Ljava/lang/String; = "expiryMs"

.field public static final RESULT_KEY:Ljava/lang/String; = "key"

.field private static final SUCCESS_HOST:Ljava/lang/String; = "zoxu4k.github.io"

.field private static final SUCCESS_PATH:Ljava/lang/String; = "/fngetkey"


# instance fields
.field private hours:I

.field private loadingOverlay:Landroid/view/View;

.field private final mainHandler:Landroid/os/Handler;

.field private pendingHmac:Ljava/lang/String;

.field private pendingToken:Ljava/lang/String;

.field private progressBar:Landroid/widget/ProgressBar;

.field private taskDone:Z

.field private tvStatus:Landroid/widget/TextView;

.field private verifyInProgress:Z

.field private webView:Landroid/webkit/WebView;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const/16 v0, 0x4d

    invoke-static {v0}, LBeykix/protect/NativeUtil;->classesInit0(I)V

    return-void
.end method

.method public constructor <init>()V
    .registers 3

    .line 486
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/fakeninjalite/FakeNinjaLite9;->verifyInProgress:Z

    iput-boolean v0, p0, Lcom/fakeninjalite/FakeNinjaLite9;->taskDone:Z

    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v0, p0, Lcom/fakeninjalite/FakeNinjaLite9;->mainHandler:Landroid/os/Handler;

    return-void
.end method

.method static synthetic access$1000022(Lcom/fakeninjalite/FakeNinjaLite9;)V
    .registers 1

    invoke-direct {p0}, Lcom/fakeninjalite/FakeNinjaLite9;->hideOverlay()V

    return-void
.end method

.method static synthetic access$1000025(Lcom/fakeninjalite/FakeNinjaLite9;)V
    .registers 1

    invoke-direct {p0}, Lcom/fakeninjalite/FakeNinjaLite9;->startPreflightThenLoad()V

    return-void
.end method

.method static synthetic access$1000026(Lcom/fakeninjalite/FakeNinjaLite9;)V
    .registers 1

    invoke-direct {p0}, Lcom/fakeninjalite/FakeNinjaLite9;->doVerify()V

    return-void
.end method

.method static synthetic access$1000027(Lcom/fakeninjalite/FakeNinjaLite9;Ljava/lang/String;)Z
    .registers 2

    invoke-direct {p0, p1}, Lcom/fakeninjalite/FakeNinjaLite9;->isSuccessUrl(Ljava/lang/String;)Z

    move-result p0

    return p0
.end method

.method static synthetic access$1000029(Lcom/fakeninjalite/FakeNinjaLite9;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/fakeninjalite/FakeNinjaLite9;->setStatus(Ljava/lang/String;)V

    return-void
.end method

.method static synthetic access$1000030(Lcom/fakeninjalite/FakeNinjaLite9;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/fakeninjalite/FakeNinjaLite9;->showFatalError(Ljava/lang/String;)V

    return-void
.end method

.method static synthetic access$1000031(Lcom/fakeninjalite/FakeNinjaLite9;)V
    .registers 1

    invoke-direct {p0}, Lcom/fakeninjalite/FakeNinjaLite9;->confirmCancel()V

    return-void
.end method

.method static synthetic access$L1000000()Ljava/lang/String;
    .registers 1

    sget-object v0, Lcom/fakeninjalite/FakeNinjaLite9;->SUCCESS_HOST:Ljava/lang/String;

    return-object v0
.end method

.method static synthetic access$L1000001()Ljava/lang/String;
    .registers 1

    sget-object v0, Lcom/fakeninjalite/FakeNinjaLite9;->SUCCESS_PATH:Ljava/lang/String;

    return-object v0
.end method

.method static synthetic access$L1000002(Lcom/fakeninjalite/FakeNinjaLite9;)Landroid/webkit/WebView;
    .registers 1

    iget-object p0, p0, Lcom/fakeninjalite/FakeNinjaLite9;->webView:Landroid/webkit/WebView;

    return-object p0
.end method

.method static synthetic access$L1000003(Lcom/fakeninjalite/FakeNinjaLite9;)Landroid/widget/ProgressBar;
    .registers 1

    iget-object p0, p0, Lcom/fakeninjalite/FakeNinjaLite9;->progressBar:Landroid/widget/ProgressBar;

    return-object p0
.end method

.method static synthetic access$L1000004(Lcom/fakeninjalite/FakeNinjaLite9;)Landroid/widget/TextView;
    .registers 1

    iget-object p0, p0, Lcom/fakeninjalite/FakeNinjaLite9;->tvStatus:Landroid/widget/TextView;

    return-object p0
.end method

.method static synthetic access$L1000006(Lcom/fakeninjalite/FakeNinjaLite9;)Ljava/lang/String;
    .registers 1

    iget-object p0, p0, Lcom/fakeninjalite/FakeNinjaLite9;->pendingToken:Ljava/lang/String;

    return-object p0
.end method

.method static synthetic access$L1000007(Lcom/fakeninjalite/FakeNinjaLite9;)Ljava/lang/String;
    .registers 1

    iget-object p0, p0, Lcom/fakeninjalite/FakeNinjaLite9;->pendingHmac:Ljava/lang/String;

    return-object p0
.end method

.method static synthetic access$L1000008(Lcom/fakeninjalite/FakeNinjaLite9;)I
    .registers 1

    iget p0, p0, Lcom/fakeninjalite/FakeNinjaLite9;->hours:I

    return p0
.end method

.method static synthetic access$L1000009(Lcom/fakeninjalite/FakeNinjaLite9;)Z
    .registers 1

    iget-boolean p0, p0, Lcom/fakeninjalite/FakeNinjaLite9;->verifyInProgress:Z

    return p0
.end method

.method static synthetic access$L1000010(Lcom/fakeninjalite/FakeNinjaLite9;)Z
    .registers 1

    iget-boolean p0, p0, Lcom/fakeninjalite/FakeNinjaLite9;->taskDone:Z

    return p0
.end method

.method static synthetic access$L1000011(Lcom/fakeninjalite/FakeNinjaLite9;)Landroid/os/Handler;
    .registers 1

    iget-object p0, p0, Lcom/fakeninjalite/FakeNinjaLite9;->mainHandler:Landroid/os/Handler;

    return-object p0
.end method

.method static synthetic access$S1000000(Ljava/lang/String;)V
    .registers 1

    sput-object p0, Lcom/fakeninjalite/FakeNinjaLite9;->SUCCESS_HOST:Ljava/lang/String;

    return-void
.end method

.method static synthetic access$S1000001(Ljava/lang/String;)V
    .registers 1

    sput-object p0, Lcom/fakeninjalite/FakeNinjaLite9;->SUCCESS_PATH:Ljava/lang/String;

    return-void
.end method

.method static synthetic access$S1000002(Lcom/fakeninjalite/FakeNinjaLite9;Landroid/webkit/WebView;)V
    .registers 2

    iput-object p1, p0, Lcom/fakeninjalite/FakeNinjaLite9;->webView:Landroid/webkit/WebView;

    return-void
.end method

.method static synthetic access$S1000003(Lcom/fakeninjalite/FakeNinjaLite9;Landroid/widget/ProgressBar;)V
    .registers 2

    iput-object p1, p0, Lcom/fakeninjalite/FakeNinjaLite9;->progressBar:Landroid/widget/ProgressBar;

    return-void
.end method

.method static synthetic access$S1000004(Lcom/fakeninjalite/FakeNinjaLite9;Landroid/widget/TextView;)V
    .registers 2

    iput-object p1, p0, Lcom/fakeninjalite/FakeNinjaLite9;->tvStatus:Landroid/widget/TextView;

    return-void
.end method

.method static synthetic access$S1000006(Lcom/fakeninjalite/FakeNinjaLite9;Ljava/lang/String;)V
    .registers 2

    iput-object p1, p0, Lcom/fakeninjalite/FakeNinjaLite9;->pendingToken:Ljava/lang/String;

    return-void
.end method

.method static synthetic access$S1000007(Lcom/fakeninjalite/FakeNinjaLite9;Ljava/lang/String;)V
    .registers 2

    iput-object p1, p0, Lcom/fakeninjalite/FakeNinjaLite9;->pendingHmac:Ljava/lang/String;

    return-void
.end method

.method static synthetic access$S1000008(Lcom/fakeninjalite/FakeNinjaLite9;I)V
    .registers 2

    iput p1, p0, Lcom/fakeninjalite/FakeNinjaLite9;->hours:I

    return-void
.end method

.method static synthetic access$S1000009(Lcom/fakeninjalite/FakeNinjaLite9;Z)V
    .registers 2

    iput-boolean p1, p0, Lcom/fakeninjalite/FakeNinjaLite9;->verifyInProgress:Z

    return-void
.end method

.method static synthetic access$S1000010(Lcom/fakeninjalite/FakeNinjaLite9;Z)V
    .registers 2

    iput-boolean p1, p0, Lcom/fakeninjalite/FakeNinjaLite9;->taskDone:Z

    return-void
.end method

.method static synthetic access$S1000011(Lcom/fakeninjalite/FakeNinjaLite9;Landroid/os/Handler;)V
    .registers 2

    iput-object p1, p0, Lcom/fakeninjalite/FakeNinjaLite9;->mainHandler:Landroid/os/Handler;

    return-void
.end method

.method private native buildLayout()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation
.end method

.method private native buildLoadingOverlay()Landroid/view/View;
.end method

.method private native confirmCancel()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation
.end method

.method private native doVerify()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation
.end method

.method private native dp(I)I
.end method

.method private native extractHost(Ljava/lang/String;)Ljava/lang/String;
.end method

.method private native hideOverlay()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation
.end method

.method private native isSuccessUrl(Ljava/lang/String;)Z
.end method

.method private native setStatus(Ljava/lang/String;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation
.end method

.method private native setupWebView()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation
.end method

.method private native showFatalError(Ljava/lang/String;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation
.end method

.method private native showOverlay(Ljava/lang/String;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation
.end method

.method private native startPreflightThenLoad()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation
.end method


# virtual methods
.method public native onBackPressed()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation
.end method

.method protected native onCreate(Landroid/os/Bundle;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/os/Bundle;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation
.end method

.method protected native onDestroy()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation
.end method
