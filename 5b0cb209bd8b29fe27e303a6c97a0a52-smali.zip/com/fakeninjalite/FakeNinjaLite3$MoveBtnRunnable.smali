.class Lcom/fakeninjalite/FakeNinjaLite3$MoveBtnRunnable;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/fakeninjalite/FakeNinjaLite3;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x22
    name = "MoveBtnRunnable"
.end annotation


# instance fields
.field private final label:Ljava/lang/String;

.field private final size:I

.field private final this$0:Lcom/fakeninjalite/FakeNinjaLite3;

.field private final x:I

.field private final y:I


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const/16 v0, 0x7a

    invoke-static {v0}, LBeykix/protect/NativeUtil;->classesInit0(I)V

    return-void
.end method

.method constructor <init>(Lcom/fakeninjalite/FakeNinjaLite3;Ljava/lang/String;III)V
    .registers 6

    .line 680
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/fakeninjalite/FakeNinjaLite3$MoveBtnRunnable;->this$0:Lcom/fakeninjalite/FakeNinjaLite3;

    .line 681
    iput-object p2, p0, Lcom/fakeninjalite/FakeNinjaLite3$MoveBtnRunnable;->label:Ljava/lang/String;

    iput p3, p0, Lcom/fakeninjalite/FakeNinjaLite3$MoveBtnRunnable;->x:I

    iput p4, p0, Lcom/fakeninjalite/FakeNinjaLite3$MoveBtnRunnable;->y:I

    iput p5, p0, Lcom/fakeninjalite/FakeNinjaLite3$MoveBtnRunnable;->size:I

    return-void
.end method

.method static native access$0(Lcom/fakeninjalite/FakeNinjaLite3$MoveBtnRunnable;)Lcom/fakeninjalite/FakeNinjaLite3;
.end method


# virtual methods
.method public native run()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation
.end method
