.class Lcom/fakeninjalite/FakeNinjaLite1$CheckExpiryRunnable;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/fakeninjalite/FakeNinjaLite1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2a
    name = "CheckExpiryRunnable"
.end annotation


# instance fields
.field private final cb:Lcom/fakeninjalite/FakeNinjaLite1$ExpiryCallback;

.field private final serverExpiry:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const/16 v0, 0x52

    invoke-static {v0}, LBeykix/protect/NativeUtil;->classesInit0(I)V

    return-void
.end method

.method constructor <init>(Ljava/lang/String;Lcom/fakeninjalite/FakeNinjaLite1$ExpiryCallback;)V
    .registers 3

    .line 167
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 168
    iput-object p1, p0, Lcom/fakeninjalite/FakeNinjaLite1$CheckExpiryRunnable;->serverExpiry:Ljava/lang/String;

    .line 169
    iput-object p2, p0, Lcom/fakeninjalite/FakeNinjaLite1$CheckExpiryRunnable;->cb:Lcom/fakeninjalite/FakeNinjaLite1$ExpiryCallback;

    return-void
.end method


# virtual methods
.method public native run()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation
.end method
