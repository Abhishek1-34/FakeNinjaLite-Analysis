.class Lcom/fakeninjalite/MainActivity$WireCheckboxListener;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/widget/CompoundButton$OnCheckedChangeListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/fakeninjalite/MainActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x22
    name = "WireCheckboxListener"
.end annotation


# instance fields
.field private final btn:Ljava/lang/String;

.field private final pref:Ljava/lang/String;

.field private final this$0:Lcom/fakeninjalite/MainActivity;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const/16 v0, 0x6d

    invoke-static {v0}, LBeykix/protect/NativeUtil;->classesInit0(I)V

    return-void
.end method

.method constructor <init>(Lcom/fakeninjalite/MainActivity;Ljava/lang/String;Ljava/lang/String;)V
    .registers 4

    .line 430
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/fakeninjalite/MainActivity$WireCheckboxListener;->this$0:Lcom/fakeninjalite/MainActivity;

    iput-object p2, p0, Lcom/fakeninjalite/MainActivity$WireCheckboxListener;->pref:Ljava/lang/String;

    iput-object p3, p0, Lcom/fakeninjalite/MainActivity$WireCheckboxListener;->btn:Ljava/lang/String;

    return-void
.end method

.method static native access$0(Lcom/fakeninjalite/MainActivity$WireCheckboxListener;)Lcom/fakeninjalite/MainActivity;
.end method


# virtual methods
.method public native onCheckedChanged(Landroid/widget/CompoundButton;Z)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/CompoundButton;",
            "Z)V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation
.end method
