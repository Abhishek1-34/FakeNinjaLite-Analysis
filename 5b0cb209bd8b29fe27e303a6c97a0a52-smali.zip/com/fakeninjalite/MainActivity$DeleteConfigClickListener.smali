.class Lcom/fakeninjalite/MainActivity$DeleteConfigClickListener;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/fakeninjalite/MainActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x22
    name = "DeleteConfigClickListener"
.end annotation


# instance fields
.field private final name:Ljava/lang/String;

.field private final this$0:Lcom/fakeninjalite/MainActivity;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const/16 v0, 0x10

    invoke-static {v0}, LBeykix/protect/NativeUtil;->classesInit0(I)V

    return-void
.end method

.method constructor <init>(Lcom/fakeninjalite/MainActivity;Ljava/lang/String;)V
    .registers 3

    .line 887
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/fakeninjalite/MainActivity$DeleteConfigClickListener;->this$0:Lcom/fakeninjalite/MainActivity;

    iput-object p2, p0, Lcom/fakeninjalite/MainActivity$DeleteConfigClickListener;->name:Ljava/lang/String;

    return-void
.end method

.method static native access$0(Lcom/fakeninjalite/MainActivity$DeleteConfigClickListener;)Lcom/fakeninjalite/MainActivity;
.end method


# virtual methods
.method public native onClick(Landroid/view/View;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation
.end method
