.class public Lcom/fakeninjalite/MainActivity;
.super Landroid/app/Activity;

# interfaces
.implements Lcom/fakeninjalite/FakeNinjaLite2$Callbacks;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/fakeninjalite/MainActivity$KeyCountdownRunnable;,
        Lcom/fakeninjalite/MainActivity$ConfirmEngineDeadRunnable;,
        Lcom/fakeninjalite/MainActivity$RetryServerClickListener;,
        Lcom/fakeninjalite/MainActivity$ChangeKeyClickListener;,
        Lcom/fakeninjalite/MainActivity$EngineToggleClickListener;,
        Lcom/fakeninjalite/MainActivity$BtnFfNormalClickListener;,
        Lcom/fakeninjalite/MainActivity$BtnFfMaxClickListener;,
        Lcom/fakeninjalite/MainActivity$FreezeV2OnWatcher;,
        Lcom/fakeninjalite/MainActivity$FreezeV2DelayWatcher;,
        Lcom/fakeninjalite/MainActivity$StepTeleTextWatcher;,
        Lcom/fakeninjalite/MainActivity$StepTeleV2TextWatcher;,
        Lcom/fakeninjalite/MainActivity$PermVpnCheckedChangeListener;,
        Lcom/fakeninjalite/MainActivity$PermOverlayCheckedChangeListener;,
        Lcom/fakeninjalite/MainActivity$PermNotifCheckedChangeListener;,
        Lcom/fakeninjalite/MainActivity$PermStorageCheckedChangeListener;,
        Lcom/fakeninjalite/MainActivity$WireCheckboxListener;,
        Lcom/fakeninjalite/MainActivity$RefreshVpnPermListener;,
        Lcom/fakeninjalite/MainActivity$RefreshOverlayPermListener;,
        Lcom/fakeninjalite/MainActivity$RefreshNotifPermListener;,
        Lcom/fakeninjalite/MainActivity$RefreshStoragePermListener;,
        Lcom/fakeninjalite/MainActivity$StatsReceiver;,
        Lcom/fakeninjalite/MainActivity$UpdateEngineStatRunnable;,
        Lcom/fakeninjalite/MainActivity$StartEngineDelayRunnable;,
        Lcom/fakeninjalite/MainActivity$ServerRetryRunnable;,
        Lcom/fakeninjalite/MainActivity$ToastRunnable;,
        Lcom/fakeninjalite/MainActivity$NoInternetRestartClickListener;,
        Lcom/fakeninjalite/MainActivity$NoInternetExitClickListener;,
        Lcom/fakeninjalite/MainActivity$ExitClickListener;,
        Lcom/fakeninjalite/MainActivity$DismissClickListener;,
        Lcom/fakeninjalite/MainActivity$UpdateNegativeClickListener;,
        Lcom/fakeninjalite/MainActivity$GetKeyClickListener;,
        Lcom/fakeninjalite/MainActivity$ActivateKeyClickListener;,
        Lcom/fakeninjalite/MainActivity$ValidateKeyCallback;,
        Lcom/fakeninjalite/MainActivity$ValidateKeyResultRunnable;,
        Lcom/fakeninjalite/MainActivity$KeyDialogShowListener;,
        Lcom/fakeninjalite/MainActivity$GetKeyFromDialogClickListener;,
        Lcom/fakeninjalite/MainActivity$ConfigFetchCallback;,
        Lcom/fakeninjalite/MainActivity$ConfigFetchResultRunnable;,
        Lcom/fakeninjalite/MainActivity$ExpiryCheckCallback;,
        Lcom/fakeninjalite/MainActivity$ExpiryResultRunnable;,
        Lcom/fakeninjalite/MainActivity$RevalidateKeyCallback;,
        Lcom/fakeninjalite/MainActivity$RevalidateKeyResultRunnable;,
        Lcom/fakeninjalite/MainActivity$ConfigSaveClickListener;,
        Lcom/fakeninjalite/MainActivity$OverwriteConfigClickListener;,
        Lcom/fakeninjalite/MainActivity$RenameConfigClickListener;,
        Lcom/fakeninjalite/MainActivity$DeleteConfigClickListener;,
        Lcom/fakeninjalite/MainActivity$LoadConfigClickListener;,
        Lcom/fakeninjalite/MainActivity$DeleteConfigConfirmClickListener;,
        Lcom/fakeninjalite/MainActivity$RenameConfigConfirmClickListener;,
        Lcom/fakeninjalite/MainActivity$OverwriteRenameClickListener;,
        Lcom/fakeninjalite/MainActivity$NotifBlockedOpenSettingsClickListener;,
        Lcom/fakeninjalite/MainActivity$StorageSettingsClickListener;,
        Lcom/fakeninjalite/MainActivity$FileSortComparator;,
        Lcom/fakeninjalite/MainActivity$StartupRevalidateCallback;,
        Lcom/fakeninjalite/MainActivity$IntegrityCheckRunnable;,
        Lcom/fakeninjalite/MainActivity$StartupRevalidateResultRunnable;,
        Lcom/fakeninjalite/MainActivity$GetEngineTokenThenStartCallback;,
        Lcom/fakeninjalite/MainActivity$EngineTokenVerifyCallback;,
        Lcom/fakeninjalite/MainActivity$GetEngineTokenThenStartRunnable;,
        Lcom/fakeninjalite/MainActivity$EngineTokenVerifyResultRunnable;
    }
.end annotation


# static fields
.field private static final BORDER2:Ljava/lang/String; = "#FF3A3A3A"

.field private static final CFG_DIR:Ljava/lang/String; = "FakeNinjaLite"

.field private static final DOT_ERR:Ljava/lang/String; = "#FF888888"

.field private static final DOT_OFF:Ljava/lang/String; = "#FF555555"

.field private static final DOT_ON:Ljava/lang/String; = "#FFCCCCCC"

.field private static final DOT_WARN:Ljava/lang/String; = "#FF999999"

.field private static final KEY_NOTIF_ASKED:Ljava/lang/String; = "perm_notif_asked"

.field private static final KEY_NOTIF_OK:Ljava/lang/String; = "perm_notif"

.field private static final KEY_VPN_OK:Ljava/lang/String; = "perm_vpn"

.field private static final PKG_FF:Ljava/lang/String; = "com.dts.freefireth"

.field private static final PKG_FF_MAX:Ljava/lang/String; = "com.dts.freefiremax"

.field private static final PREFS:Ljava/lang/String; = "prefs_fnl"

.field private static final REQ_GETKEY:I = 0x3ed

.field private static final REQ_NOTIF:I = 0x3eb

.field private static final REQ_OVERLAY:I = 0x3ea

.field private static final REQ_STORAGE:I = 0x3ec

.field private static final REQ_VPN:I = 0x3e9

.field private static final SERVER_MAX_RETRY:I = 0x3

.field private static final SERVER_RETRY_DELAY_MS:J = 0x1388L

.field private static final SURFACE2:Ljava/lang/String; = "#FF1A1A1A"

.field private static final TXT_MUT:Ljava/lang/String; = "#FF444444"

.field private static final TXT_PRI:Ljava/lang/String; = "#FFCCCCCC"

.field private static final TXT_SEC:Ljava/lang/String; = "#FF555555"

.field private static final _TOKEN_PREFIX:Ljava/lang/String; = "FNL_OVT_"


# instance fields
.field private volatile _onlineValidationToken:Ljava/lang/String;

.field private activeKeyDialog:Landroid/app/AlertDialog;

.field private btnConfigSave:Landroid/widget/Button;

.field private btnEngine:Landroid/widget/Button;

.field private btnFfMax:Landroid/widget/Button;

.field private btnFfNormal:Landroid/widget/Button;

.field private cbFreeze:Landroid/widget/CheckBox;

.field private cbFreezeV2:Landroid/widget/CheckBox;

.field private cbGhostV2:Landroid/widget/CheckBox;

.field private cbPermNotif:Landroid/widget/CheckBox;

.field private cbPermOverlay:Landroid/widget/CheckBox;

.field private cbPermStorage:Landroid/widget/CheckBox;

.field private cbPermVpn:Landroid/widget/CheckBox;

.field private cbTeleV2:Landroid/widget/CheckBox;

.field private cbVpn:Landroid/widget/CheckBox;

.field private dotEngine:Landroid/view/View;

.field private dotKey:Landroid/view/View;

.field private dotPermNotif:Landroid/view/View;

.field private dotPermOverlay:Landroid/view/View;

.field private dotPermStorage:Landroid/view/View;

.field private dotPermVpn:Landroid/view/View;

.field private dotServer:Landroid/view/View;

.field private engineOn:Z

.field private etConfigName:Landroid/widget/EditText;

.field private etFreezeV2Delay:Landroid/widget/EditText;

.field private etFreezeV2On:Landroid/widget/EditText;

.field private etStepTele:Landroid/widget/EditText;

.field private etStepTeleV2:Landroid/widget/EditText;

.field private final integrityHandler:Landroid/os/Handler;

.field private final integrityRunnable:Ljava/lang/Runnable;

.field private final keyHandler:Landroid/os/Handler;

.field private final keyRunnable:Ljava/lang/Runnable;

.field private volatile keyUnlocked:Z

.field private llConfigList:Landroid/widget/LinearLayout;

.field private selPkg:Ljava/lang/String;

.field private serverOk:Z

.field private serverRetryCount:I

.field private statsRcv:Landroid/content/BroadcastReceiver;

.field private tvConfigEmpty:Landroid/widget/TextView;

.field private tvEngineHint:Landroid/widget/TextView;

.field private tvEngineStatus:Landroid/widget/TextView;

.field private tvKeyExpiry:Landroid/widget/TextView;

.field private tvKeyValue:Landroid/widget/TextView;

.field private tvPermNotif:Landroid/widget/TextView;

.field private tvPermOverlay:Landroid/widget/TextView;

.field private tvPermStorage:Landroid/widget/TextView;

.field private tvPermVpn:Landroid/widget/TextView;

.field private tvServerStatus:Landroid/widget/TextView;

.field private waiting:Z


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const/16 v0, 0x25

    invoke-static {v0}, LBeykix/protect/NativeUtil;->classesInit0(I)V

    return-void
.end method

.method public constructor <init>()V
    .registers 4

    .line 2097
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    const/4 v0, 0x0

    move-object v1, v0

    check-cast v1, Landroid/app/AlertDialog;

    iput-object v0, p0, Lcom/fakeninjalite/MainActivity;->activeKeyDialog:Landroid/app/AlertDialog;

    const-string v1, "30003D7C201539480B1D21223C1840131A1C"

    invoke-static {v1}, Lobfuse/NPStringFog;->decode(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    iput-object v1, p0, Lcom/fakeninjalite/MainActivity;->selPkg:Ljava/lang/String;

    const/4 v1, 0x0

    iput-boolean v1, p0, Lcom/fakeninjalite/MainActivity;->engineOn:Z

    iput-boolean v1, p0, Lcom/fakeninjalite/MainActivity;->waiting:Z

    iput-boolean v1, p0, Lcom/fakeninjalite/MainActivity;->keyUnlocked:Z

    move-object v2, v0

    check-cast v2, Ljava/lang/String;

    iput-object v0, p0, Lcom/fakeninjalite/MainActivity;->_onlineValidationToken:Ljava/lang/String;

    iput v1, p0, Lcom/fakeninjalite/MainActivity;->serverRetryCount:I

    iput-boolean v1, p0, Lcom/fakeninjalite/MainActivity;->serverOk:Z

    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v0, p0, Lcom/fakeninjalite/MainActivity;->keyHandler:Landroid/os/Handler;

    new-instance v0, Lcom/fakeninjalite/MainActivity$KeyCountdownRunnable;

    invoke-direct {v0, p0}, Lcom/fakeninjalite/MainActivity$KeyCountdownRunnable;-><init>(Lcom/fakeninjalite/MainActivity;)V

    iput-object v0, p0, Lcom/fakeninjalite/MainActivity;->keyRunnable:Ljava/lang/Runnable;

    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v0, p0, Lcom/fakeninjalite/MainActivity;->integrityHandler:Landroid/os/Handler;

    new-instance v0, Lcom/fakeninjalite/MainActivity$IntegrityCheckRunnable;

    invoke-direct {v0, p0}, Lcom/fakeninjalite/MainActivity$IntegrityCheckRunnable;-><init>(Lcom/fakeninjalite/MainActivity;)V

    iput-object v0, p0, Lcom/fakeninjalite/MainActivity;->integrityRunnable:Ljava/lang/Runnable;

    return-void
.end method

.method static synthetic access$1000026(Lcom/fakeninjalite/MainActivity;Z)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/fakeninjalite/MainActivity;->setKeyUnlocked(Z)V

    return-void
.end method

.method static synthetic access$1000119(Lcom/fakeninjalite/MainActivity;)V
    .registers 1

    invoke-direct {p0}, Lcom/fakeninjalite/MainActivity;->refreshPerms()V

    return-void
.end method

.method static synthetic access$1000121(Lcom/fakeninjalite/MainActivity;Landroid/widget/CompoundButton;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/fakeninjalite/MainActivity;->lockBox(Landroid/widget/CompoundButton;)V

    return-void
.end method

.method static synthetic access$1000122(Lcom/fakeninjalite/MainActivity;Landroid/widget/CompoundButton;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/fakeninjalite/MainActivity;->resetBox(Landroid/widget/CompoundButton;)V

    return-void
.end method

.method static synthetic access$1000123(Lcom/fakeninjalite/MainActivity;)Z
    .registers 1

    invoke-direct {p0}, Lcom/fakeninjalite/MainActivity;->allPermsGranted()Z

    move-result p0

    return p0
.end method

.method static synthetic access$1000124(Lcom/fakeninjalite/MainActivity;)Z
    .registers 1

    invoke-direct {p0}, Lcom/fakeninjalite/MainActivity;->isStorageGranted()Z

    move-result p0

    return p0
.end method

.method static synthetic access$1000125(Lcom/fakeninjalite/MainActivity;)V
    .registers 1

    invoke-direct {p0}, Lcom/fakeninjalite/MainActivity;->doFetchConfig()V

    return-void
.end method

.method static synthetic access$1000128(Lcom/fakeninjalite/MainActivity;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/fakeninjalite/MainActivity;->showExpiredDlg(Ljava/lang/String;)V

    return-void
.end method

.method static synthetic access$1000129(Lcom/fakeninjalite/MainActivity;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V
    .registers 5

    invoke-direct {p0, p1, p2, p3, p4}, Lcom/fakeninjalite/MainActivity;->showUpdateDlg(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V

    return-void
.end method

.method static synthetic access$1000135(Lcom/fakeninjalite/MainActivity;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/fakeninjalite/MainActivity;->showKeyDialog(Ljava/lang/String;)V

    return-void
.end method

.method static synthetic access$1000136(Lcom/fakeninjalite/MainActivity;I)Ljava/lang/String;
    .registers 2

    invoke-direct {p0, p1}, Lcom/fakeninjalite/MainActivity;->keyMsg(I)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method static synthetic access$1000137(Lcom/fakeninjalite/MainActivity;Z)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/fakeninjalite/MainActivity;->refreshKeyCard(Z)V

    return-void
.end method

.method static synthetic access$1000139(Lcom/fakeninjalite/MainActivity;Z)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/fakeninjalite/MainActivity;->setEngineEnabled(Z)V

    return-void
.end method

.method static synthetic access$1000142(Lcom/fakeninjalite/MainActivity;)V
    .registers 1

    invoke-direct {p0}, Lcom/fakeninjalite/MainActivity;->activateKeyMode()V

    return-void
.end method

.method static synthetic access$1000144(Lcom/fakeninjalite/MainActivity;Z)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/fakeninjalite/MainActivity;->updateEngineUI(Z)V

    return-void
.end method

.method static synthetic access$1000145(Lcom/fakeninjalite/MainActivity;)V
    .registers 1

    invoke-direct {p0}, Lcom/fakeninjalite/MainActivity;->refreshGameButtons()V

    return-void
.end method

.method static synthetic access$1000148(Lcom/fakeninjalite/MainActivity;)V
    .registers 1

    invoke-direct {p0}, Lcom/fakeninjalite/MainActivity;->checkOverlay()V

    return-void
.end method

.method static synthetic access$1000154(Lcom/fakeninjalite/MainActivity;)V
    .registers 1

    invoke-direct {p0}, Lcom/fakeninjalite/MainActivity;->startEngine()V

    return-void
.end method

.method static synthetic access$1000155(Lcom/fakeninjalite/MainActivity;)V
    .registers 1

    invoke-direct {p0}, Lcom/fakeninjalite/MainActivity;->stopEngine()V

    return-void
.end method

.method static synthetic access$1000156(Lcom/fakeninjalite/MainActivity;)V
    .registers 1

    invoke-direct {p0}, Lcom/fakeninjalite/MainActivity;->sendTargetToEngine()V

    return-void
.end method

.method static synthetic access$1000157(Lcom/fakeninjalite/MainActivity;)V
    .registers 1

    invoke-direct {p0}, Lcom/fakeninjalite/MainActivity;->requestNotifPerm()V

    return-void
.end method

.method static synthetic access$1000158(Lcom/fakeninjalite/MainActivity;)V
    .registers 1

    invoke-direct {p0}, Lcom/fakeninjalite/MainActivity;->requestStoragePerm()V

    return-void
.end method

.method static synthetic access$1000159(Lcom/fakeninjalite/MainActivity;Ljava/lang/String;Z)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/fakeninjalite/MainActivity;->showBcast(Ljava/lang/String;Z)V

    return-void
.end method

.method static synthetic access$1000163(Lcom/fakeninjalite/MainActivity;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/fakeninjalite/MainActivity;->launchPkg(Ljava/lang/String;)V

    return-void
.end method

.method static synthetic access$1000164(Lcom/fakeninjalite/MainActivity;Landroid/content/Intent;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/fakeninjalite/MainActivity;->startServiceCompat(Landroid/content/Intent;)V

    return-void
.end method

.method static synthetic access$1000165(Lcom/fakeninjalite/MainActivity;)Landroid/content/SharedPreferences;
    .registers 1

    invoke-direct {p0}, Lcom/fakeninjalite/MainActivity;->sp()Landroid/content/SharedPreferences;

    move-result-object p0

    return-object p0
.end method

.method static synthetic access$1000167(Lcom/fakeninjalite/MainActivity;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/fakeninjalite/MainActivity;->doSaveConfig(Ljava/lang/String;)V

    return-void
.end method

.method static synthetic access$1000168(Lcom/fakeninjalite/MainActivity;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/fakeninjalite/MainActivity;->doLoadConfig(Ljava/lang/String;)V

    return-void
.end method

.method static synthetic access$1000169(Lcom/fakeninjalite/MainActivity;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/fakeninjalite/MainActivity;->doDeleteConfig(Ljava/lang/String;)V

    return-void
.end method

.method static synthetic access$1000170(Lcom/fakeninjalite/MainActivity;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/fakeninjalite/MainActivity;->doRenameConfig(Ljava/lang/String;)V

    return-void
.end method

.method static synthetic access$1000171(Lcom/fakeninjalite/MainActivity;Ljava/lang/String;Ljava/lang/String;)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/fakeninjalite/MainActivity;->performRename(Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method static synthetic access$1000172(Lcom/fakeninjalite/MainActivity;)V
    .registers 1

    invoke-direct {p0}, Lcom/fakeninjalite/MainActivity;->renderConfigList()V

    return-void
.end method

.method static synthetic access$1000174(Lcom/fakeninjalite/MainActivity;Ljava/lang/String;)Ljava/io/File;
    .registers 2

    invoke-direct {p0, p1}, Lcom/fakeninjalite/MainActivity;->getCfgFile(Ljava/lang/String;)Ljava/io/File;

    move-result-object p0

    return-object p0
.end method

.method static synthetic access$1000178(Lcom/fakeninjalite/MainActivity;)Ljava/lang/String;
    .registers 1

    invoke-direct {p0}, Lcom/fakeninjalite/MainActivity;->autoName()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method static synthetic access$1000180(Lcom/fakeninjalite/MainActivity;Landroid/view/View;Ljava/lang/String;)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/fakeninjalite/MainActivity;->dotColor(Landroid/view/View;Ljava/lang/String;)V

    return-void
.end method

.method static synthetic access$1000182(Lcom/fakeninjalite/MainActivity;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/fakeninjalite/MainActivity;->toast(Ljava/lang/String;)V

    return-void
.end method

.method static synthetic access$L1000000()I
    .registers 1

    sget v0, Lcom/fakeninjalite/MainActivity;->REQ_VPN:I

    return v0
.end method

.method static synthetic access$L1000001()I
    .registers 1

    sget v0, Lcom/fakeninjalite/MainActivity;->REQ_OVERLAY:I

    return v0
.end method

.method static synthetic access$L1000003()I
    .registers 1

    sget v0, Lcom/fakeninjalite/MainActivity;->REQ_STORAGE:I

    return v0
.end method

.method static synthetic access$L1000005()Ljava/lang/String;
    .registers 1

    sget-object v0, Lcom/fakeninjalite/MainActivity;->PKG_FF:Ljava/lang/String;

    return-object v0
.end method

.method static synthetic access$L1000006()Ljava/lang/String;
    .registers 1

    sget-object v0, Lcom/fakeninjalite/MainActivity;->PKG_FF_MAX:Ljava/lang/String;

    return-object v0
.end method

.method static synthetic access$L1000009()Ljava/lang/String;
    .registers 1

    sget-object v0, Lcom/fakeninjalite/MainActivity;->KEY_VPN_OK:Ljava/lang/String;

    return-object v0
.end method

.method static synthetic access$L1000010()Ljava/lang/String;
    .registers 1

    sget-object v0, Lcom/fakeninjalite/MainActivity;->KEY_NOTIF_OK:Ljava/lang/String;

    return-object v0
.end method

.method static synthetic access$L1000013()Ljava/lang/String;
    .registers 1

    sget-object v0, Lcom/fakeninjalite/MainActivity;->TXT_PRI:Ljava/lang/String;

    return-object v0
.end method

.method static synthetic access$L1000016()Ljava/lang/String;
    .registers 1

    sget-object v0, Lcom/fakeninjalite/MainActivity;->DOT_ON:Ljava/lang/String;

    return-object v0
.end method

.method static synthetic access$L1000018()Ljava/lang/String;
    .registers 1

    sget-object v0, Lcom/fakeninjalite/MainActivity;->DOT_WARN:Ljava/lang/String;

    return-object v0
.end method

.method static synthetic access$L1000019()Ljava/lang/String;
    .registers 1

    sget-object v0, Lcom/fakeninjalite/MainActivity;->DOT_ERR:Ljava/lang/String;

    return-object v0
.end method

.method static synthetic access$L1000022(Lcom/fakeninjalite/MainActivity;)Ljava/lang/String;
    .registers 1

    iget-object p0, p0, Lcom/fakeninjalite/MainActivity;->selPkg:Ljava/lang/String;

    return-object p0
.end method

.method static synthetic access$L1000023(Lcom/fakeninjalite/MainActivity;)Z
    .registers 1

    iget-boolean p0, p0, Lcom/fakeninjalite/MainActivity;->engineOn:Z

    return p0
.end method

.method static synthetic access$L1000024(Lcom/fakeninjalite/MainActivity;)Z
    .registers 1

    iget-boolean p0, p0, Lcom/fakeninjalite/MainActivity;->waiting:Z

    return p0
.end method

.method static synthetic access$L1000025(Lcom/fakeninjalite/MainActivity;)Z
    .registers 1

    iget-boolean p0, p0, Lcom/fakeninjalite/MainActivity;->keyUnlocked:Z

    return p0
.end method

.method static synthetic access$L1000027(Lcom/fakeninjalite/MainActivity;)Ljava/lang/String;
    .registers 1

    iget-object p0, p0, Lcom/fakeninjalite/MainActivity;->_onlineValidationToken:Ljava/lang/String;

    return-object p0
.end method

.method static synthetic access$L1000028()Ljava/lang/String;
    .registers 1

    sget-object v0, Lcom/fakeninjalite/MainActivity;->_TOKEN_PREFIX:Ljava/lang/String;

    return-object v0
.end method

.method static synthetic access$L1000029(Lcom/fakeninjalite/MainActivity;)I
    .registers 1

    iget p0, p0, Lcom/fakeninjalite/MainActivity;->serverRetryCount:I

    return p0
.end method

.method static synthetic access$L1000030()I
    .registers 1

    sget v0, Lcom/fakeninjalite/MainActivity;->SERVER_MAX_RETRY:I

    return v0
.end method

.method static synthetic access$L1000031()J
    .registers 2

    sget-wide v0, Lcom/fakeninjalite/MainActivity;->SERVER_RETRY_DELAY_MS:J

    return-wide v0
.end method

.method static synthetic access$L1000032(Lcom/fakeninjalite/MainActivity;)Z
    .registers 1

    iget-boolean p0, p0, Lcom/fakeninjalite/MainActivity;->serverOk:Z

    return p0
.end method

.method static synthetic access$L1000033(Lcom/fakeninjalite/MainActivity;)Landroid/view/View;
    .registers 1

    iget-object p0, p0, Lcom/fakeninjalite/MainActivity;->dotKey:Landroid/view/View;

    return-object p0
.end method

.method static synthetic access$L1000035(Lcom/fakeninjalite/MainActivity;)Landroid/widget/TextView;
    .registers 1

    iget-object p0, p0, Lcom/fakeninjalite/MainActivity;->tvKeyExpiry:Landroid/widget/TextView;

    return-object p0
.end method

.method static synthetic access$L1000036(Lcom/fakeninjalite/MainActivity;)Landroid/view/View;
    .registers 1

    iget-object p0, p0, Lcom/fakeninjalite/MainActivity;->dotServer:Landroid/view/View;

    return-object p0
.end method

.method static synthetic access$L1000037(Lcom/fakeninjalite/MainActivity;)Landroid/widget/TextView;
    .registers 1

    iget-object p0, p0, Lcom/fakeninjalite/MainActivity;->tvServerStatus:Landroid/widget/TextView;

    return-object p0
.end method

.method static synthetic access$L1000038(Lcom/fakeninjalite/MainActivity;)Landroid/view/View;
    .registers 1

    iget-object p0, p0, Lcom/fakeninjalite/MainActivity;->dotEngine:Landroid/view/View;

    return-object p0
.end method

.method static synthetic access$L1000039(Lcom/fakeninjalite/MainActivity;)Landroid/widget/TextView;
    .registers 1

    iget-object p0, p0, Lcom/fakeninjalite/MainActivity;->tvEngineStatus:Landroid/widget/TextView;

    return-object p0
.end method

.method static synthetic access$L1000065(Lcom/fakeninjalite/MainActivity;)Landroid/widget/EditText;
    .registers 1

    iget-object p0, p0, Lcom/fakeninjalite/MainActivity;->etConfigName:Landroid/widget/EditText;

    return-object p0
.end method

.method static synthetic access$L1000069(Lcom/fakeninjalite/MainActivity;)Landroid/os/Handler;
    .registers 1

    iget-object p0, p0, Lcom/fakeninjalite/MainActivity;->keyHandler:Landroid/os/Handler;

    return-object p0
.end method

.method static synthetic access$L1000131(Lcom/fakeninjalite/MainActivity;)Landroid/os/Handler;
    .registers 1

    iget-object p0, p0, Lcom/fakeninjalite/MainActivity;->integrityHandler:Landroid/os/Handler;

    return-object p0
.end method

.method static synthetic access$S1000000(I)V
    .registers 1

    sput p0, Lcom/fakeninjalite/MainActivity;->REQ_VPN:I

    return-void
.end method

.method static synthetic access$S1000001(I)V
    .registers 1

    sput p0, Lcom/fakeninjalite/MainActivity;->REQ_OVERLAY:I

    return-void
.end method

.method static synthetic access$S1000003(I)V
    .registers 1

    sput p0, Lcom/fakeninjalite/MainActivity;->REQ_STORAGE:I

    return-void
.end method

.method static synthetic access$S1000005(Ljava/lang/String;)V
    .registers 1

    sput-object p0, Lcom/fakeninjalite/MainActivity;->PKG_FF:Ljava/lang/String;

    return-void
.end method

.method static synthetic access$S1000006(Ljava/lang/String;)V
    .registers 1

    sput-object p0, Lcom/fakeninjalite/MainActivity;->PKG_FF_MAX:Ljava/lang/String;

    return-void
.end method

.method static synthetic access$S1000009(Ljava/lang/String;)V
    .registers 1

    sput-object p0, Lcom/fakeninjalite/MainActivity;->KEY_VPN_OK:Ljava/lang/String;

    return-void
.end method

.method static synthetic access$S1000010(Ljava/lang/String;)V
    .registers 1

    sput-object p0, Lcom/fakeninjalite/MainActivity;->KEY_NOTIF_OK:Ljava/lang/String;

    return-void
.end method

.method static synthetic access$S1000013(Ljava/lang/String;)V
    .registers 1

    sput-object p0, Lcom/fakeninjalite/MainActivity;->TXT_PRI:Ljava/lang/String;

    return-void
.end method

.method static synthetic access$S1000016(Ljava/lang/String;)V
    .registers 1

    sput-object p0, Lcom/fakeninjalite/MainActivity;->DOT_ON:Ljava/lang/String;

    return-void
.end method

.method static synthetic access$S1000018(Ljava/lang/String;)V
    .registers 1

    sput-object p0, Lcom/fakeninjalite/MainActivity;->DOT_WARN:Ljava/lang/String;

    return-void
.end method

.method static synthetic access$S1000019(Ljava/lang/String;)V
    .registers 1

    sput-object p0, Lcom/fakeninjalite/MainActivity;->DOT_ERR:Ljava/lang/String;

    return-void
.end method

.method static synthetic access$S1000022(Lcom/fakeninjalite/MainActivity;Ljava/lang/String;)V
    .registers 2

    iput-object p1, p0, Lcom/fakeninjalite/MainActivity;->selPkg:Ljava/lang/String;

    return-void
.end method

.method static synthetic access$S1000023(Lcom/fakeninjalite/MainActivity;Z)V
    .registers 2

    iput-boolean p1, p0, Lcom/fakeninjalite/MainActivity;->engineOn:Z

    return-void
.end method

.method static synthetic access$S1000024(Lcom/fakeninjalite/MainActivity;Z)V
    .registers 2

    iput-boolean p1, p0, Lcom/fakeninjalite/MainActivity;->waiting:Z

    return-void
.end method

.method static synthetic access$S1000025(Lcom/fakeninjalite/MainActivity;Z)V
    .registers 2

    iput-boolean p1, p0, Lcom/fakeninjalite/MainActivity;->keyUnlocked:Z

    return-void
.end method

.method static synthetic access$S1000027(Lcom/fakeninjalite/MainActivity;Ljava/lang/String;)V
    .registers 2

    iput-object p1, p0, Lcom/fakeninjalite/MainActivity;->_onlineValidationToken:Ljava/lang/String;

    return-void
.end method

.method static synthetic access$S1000028(Ljava/lang/String;)V
    .registers 1

    sput-object p0, Lcom/fakeninjalite/MainActivity;->_TOKEN_PREFIX:Ljava/lang/String;

    return-void
.end method

.method static synthetic access$S1000029(Lcom/fakeninjalite/MainActivity;I)V
    .registers 2

    iput p1, p0, Lcom/fakeninjalite/MainActivity;->serverRetryCount:I

    return-void
.end method

.method static synthetic access$S1000030(I)V
    .registers 1

    sput p0, Lcom/fakeninjalite/MainActivity;->SERVER_MAX_RETRY:I

    return-void
.end method

.method static synthetic access$S1000031(J)V
    .registers 2

    sput-wide p0, Lcom/fakeninjalite/MainActivity;->SERVER_RETRY_DELAY_MS:J

    return-void
.end method

.method static synthetic access$S1000032(Lcom/fakeninjalite/MainActivity;Z)V
    .registers 2

    iput-boolean p1, p0, Lcom/fakeninjalite/MainActivity;->serverOk:Z

    return-void
.end method

.method static synthetic access$S1000033(Lcom/fakeninjalite/MainActivity;Landroid/view/View;)V
    .registers 2

    iput-object p1, p0, Lcom/fakeninjalite/MainActivity;->dotKey:Landroid/view/View;

    return-void
.end method

.method static synthetic access$S1000035(Lcom/fakeninjalite/MainActivity;Landroid/widget/TextView;)V
    .registers 2

    iput-object p1, p0, Lcom/fakeninjalite/MainActivity;->tvKeyExpiry:Landroid/widget/TextView;

    return-void
.end method

.method static synthetic access$S1000036(Lcom/fakeninjalite/MainActivity;Landroid/view/View;)V
    .registers 2

    iput-object p1, p0, Lcom/fakeninjalite/MainActivity;->dotServer:Landroid/view/View;

    return-void
.end method

.method static synthetic access$S1000037(Lcom/fakeninjalite/MainActivity;Landroid/widget/TextView;)V
    .registers 2

    iput-object p1, p0, Lcom/fakeninjalite/MainActivity;->tvServerStatus:Landroid/widget/TextView;

    return-void
.end method

.method static synthetic access$S1000038(Lcom/fakeninjalite/MainActivity;Landroid/view/View;)V
    .registers 2

    iput-object p1, p0, Lcom/fakeninjalite/MainActivity;->dotEngine:Landroid/view/View;

    return-void
.end method

.method static synthetic access$S1000039(Lcom/fakeninjalite/MainActivity;Landroid/widget/TextView;)V
    .registers 2

    iput-object p1, p0, Lcom/fakeninjalite/MainActivity;->tvEngineStatus:Landroid/widget/TextView;

    return-void
.end method

.method static synthetic access$S1000065(Lcom/fakeninjalite/MainActivity;Landroid/widget/EditText;)V
    .registers 2

    iput-object p1, p0, Lcom/fakeninjalite/MainActivity;->etConfigName:Landroid/widget/EditText;

    return-void
.end method

.method static synthetic access$S1000069(Lcom/fakeninjalite/MainActivity;Landroid/os/Handler;)V
    .registers 2

    iput-object p1, p0, Lcom/fakeninjalite/MainActivity;->keyHandler:Landroid/os/Handler;

    return-void
.end method

.method static synthetic access$S1000131(Lcom/fakeninjalite/MainActivity;Landroid/os/Handler;)V
    .registers 2

    iput-object p1, p0, Lcom/fakeninjalite/MainActivity;->integrityHandler:Landroid/os/Handler;

    return-void
.end method

.method private native activateKeyMode()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation
.end method

.method private native allPermsGranted()Z
.end method

.method private native autoName()Ljava/lang/String;
.end method

.method private native bindViews(ZZ)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(ZZ)V"
        }
    .end annotation
.end method

.method private native cancelEngine(Ljava/lang/String;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation
.end method

.method private native checkKeyOnStart()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation
.end method

.method private native checkOverlay()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation
.end method

.method private native checkVpn()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation
.end method

.method private native doDeleteConfig(Ljava/lang/String;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation
.end method

.method private native doFetchConfig()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation
.end method

.method private native doLoadConfig(Ljava/lang/String;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation
.end method

.method private native doRenameConfig(Ljava/lang/String;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation
.end method

.method private native doSaveConfig(Ljava/lang/String;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation
.end method

.method private native dotColor(Landroid/view/View;Ljava/lang/String;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation
.end method

.method private native dp(I)I
.end method

.method private native getCfgDir()Ljava/io/File;
.end method

.method private native getCfgFile(Ljava/lang/String;)Ljava/io/File;
.end method

.method private native installed(Landroid/content/pm/PackageManager;Ljava/lang/String;)Z
.end method

.method private native isNetworkAvailable()Z
.end method

.method private native isStorageGranted()Z
.end method

.method private native keyMsg(I)Ljava/lang/String;
.end method

.method private native launchPkg(Ljava/lang/String;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation
.end method

.method private native listConfigs()Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end method

.method private native lockBox(Landroid/widget/CompoundButton;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/CompoundButton;",
            ")V"
        }
    .end annotation
.end method

.method private native moveLockBcast(Ljava/lang/String;Z)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Z)V"
        }
    .end annotation
.end method

.method private native movePosBcast(Ljava/lang/String;III)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "III)V"
        }
    .end annotation
.end method

.method private native paintGameBtn(Landroid/widget/Button;Z)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/Button;",
            "Z)V"
        }
    .end annotation
.end method

.method private native parseCfgInt(Ljava/util/Properties;Ljava/lang/String;I)I
.end method

.method private native performRename(Ljava/lang/String;Ljava/lang/String;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation
.end method

.method private native readCfg(Ljava/lang/String;)Ljava/util/Properties;
.end method

.method private native refreshGameButtons()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation
.end method

.method private native refreshKeyCard(Z)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(Z)V"
        }
    .end annotation
.end method

.method private native refreshPerms()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation
.end method

.method private native regStats()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation
.end method

.method private native renderConfigList()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation
.end method

.method private native requestNotifPerm()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation
.end method

.method private native requestStoragePerm()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation
.end method

.method private native resetBox(Landroid/widget/CompoundButton;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/CompoundButton;",
            ")V"
        }
    .end annotation
.end method

.method private native scheduleIntegrityCheck()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation
.end method

.method private native sendTargetToEngine()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation
.end method

.method private native setEngineEnabled(Z)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(Z)V"
        }
    .end annotation
.end method

.method private native setExpiry(Ljava/lang/String;Ljava/lang/String;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation
.end method

.method private native setKeyUnlocked(Z)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(Z)V"
        }
    .end annotation
.end method

.method private native setupConfigManager()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation
.end method

.method private native setupPermCheckboxes()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation
.end method

.method private native showBcast(Ljava/lang/String;Z)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Z)V"
        }
    .end annotation
.end method

.method private native showExpiredDlg(Ljava/lang/String;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation
.end method

.method private native showKeyDialog(Ljava/lang/String;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation
.end method

.method private native showNoInternetDialog()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation
.end method

.method private native showUpdateDlg(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Z)V"
        }
    .end annotation
.end method

.method private native sp()Landroid/content/SharedPreferences;
.end method

.method private native startCountdown()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation
.end method

.method private native startEngine()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation
.end method

.method private native startServiceCompat(Landroid/content/Intent;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Intent;",
            ")V"
        }
    .end annotation
.end method

.method private native stopCountdown()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation
.end method

.method private native stopEngine()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation
.end method

.method private native toast(Ljava/lang/String;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation
.end method

.method private native updateCheckbox(Landroid/widget/CheckBox;ZLandroid/widget/CompoundButton$OnCheckedChangeListener;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/CheckBox;",
            "Z",
            "Landroid/widget/CompoundButton$OnCheckedChangeListener;",
            ")V"
        }
    .end annotation
.end method

.method private native updateEngineUI(Z)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(Z)V"
        }
    .end annotation
.end method

.method private native verifyEngineTokenThenStart()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation
.end method

.method private native wireCheckbox(Landroid/widget/CheckBox;Ljava/lang/String;Ljava/lang/String;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/CheckBox;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation
.end method

.method private native writeCfg(Ljava/lang/String;Ljava/util/Properties;)Z
.end method


# virtual methods
.method protected native onActivityResult(IILandroid/content/Intent;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(II",
            "Landroid/content/Intent;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation
.end method

.method public native onCreate(Landroid/os/Bundle;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/os/Bundle;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation
.end method

.method protected native onDestroy()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation
.end method

.method public native onKeyDialogNeeded(Ljava/lang/String;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation
.end method

.method public native onKillDialogNeeded(Ljava/lang/String;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation
.end method

.method public native onNoInternetDialogNeeded()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation
.end method

.method protected native onPause()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation
.end method

.method public native onRequestPermissionsResult(I[Ljava/lang/String;[I)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I[",
            "Ljava/lang/String;",
            "[I)V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation
.end method

.method protected native onResume()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation
.end method

.method public native onUpdateDialogNeeded(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Z)V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation
.end method
