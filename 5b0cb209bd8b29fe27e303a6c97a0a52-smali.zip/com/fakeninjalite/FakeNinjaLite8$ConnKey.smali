.class Lcom/fakeninjalite/FakeNinjaLite8$ConnKey;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/fakeninjalite/FakeNinjaLite8;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x28
    name = "ConnKey"
.end annotation


# instance fields
.field final dst:I

.field final ip:I

.field final src:I


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const/16 v0, 0x48

    invoke-static {v0}, LBeykix/protect/NativeUtil;->classesInit0(I)V

    return-void
.end method

.method constructor <init>(III)V
    .registers 4

    .line 730
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lcom/fakeninjalite/FakeNinjaLite8$ConnKey;->src:I

    iput p2, p0, Lcom/fakeninjalite/FakeNinjaLite8$ConnKey;->dst:I

    iput p3, p0, Lcom/fakeninjalite/FakeNinjaLite8$ConnKey;->ip:I

    return-void
.end method


# virtual methods
.method public native equals(Ljava/lang/Object;)Z
    .annotation runtime Ljava/lang/Override;
    .end annotation
.end method

.method public native hashCode()I
    .annotation runtime Ljava/lang/Override;
    .end annotation
.end method
