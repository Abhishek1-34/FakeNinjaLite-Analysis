.class Lcom/fakeninjalite/FakeNinjaLite2$100000002$100000001;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/fakeninjalite/FakeNinjaLite2$100000002;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000001"
.end annotation


# instance fields
.field private final this$0:Lcom/fakeninjalite/FakeNinjaLite2$100000002;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const/4 v0, 0x6

    invoke-static {v0}, LBeykix/protect/NativeUtil;->classesInit0(I)V

    return-void
.end method

.method constructor <init>(Lcom/fakeninjalite/FakeNinjaLite2$100000002;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/fakeninjalite/FakeNinjaLite2$100000002$100000001;->this$0:Lcom/fakeninjalite/FakeNinjaLite2$100000002;

    return-void
.end method

.method static native access$0(Lcom/fakeninjalite/FakeNinjaLite2$100000002$100000001;)Lcom/fakeninjalite/FakeNinjaLite2$100000002;
.end method


# virtual methods
.method public native run()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation
.end method
