.class public Lcom/fakeninjalite/FakeNinjaLite6;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/fakeninjalite/FakeNinjaLite6$Config;
    }
.end annotation


# static fields
.field private static final CFG_DIR:Ljava/lang/String; = "FakeNinjaLite"


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const/16 v0, 0x3d

    invoke-static {v0}, LBeykix/protect/NativeUtil;->classesInit0(I)V

    return-void
.end method

.method public constructor <init>()V
    .registers 1

    .line 179
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static native autoName()Ljava/lang/String;
.end method

.method private static native bool(Ljava/util/Properties;Ljava/lang/String;Z)Z
.end method

.method public static native deleteConfig(Ljava/lang/String;)Z
.end method

.method public static native getCfgDir()Ljava/io/File;
.end method

.method public static native getCfgFile(Ljava/lang/String;)Ljava/io/File;
.end method

.method private static native intv(Ljava/util/Properties;Ljava/lang/String;I)I
.end method

.method public static native listConfigs()Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end method

.method public static native loadConfig(Ljava/lang/String;)Lcom/fakeninjalite/FakeNinjaLite6$Config;
.end method

.method private static native longv(Ljava/util/Properties;Ljava/lang/String;J)J
.end method

.method public static native renameConfig(Ljava/lang/String;Ljava/lang/String;)Z
.end method

.method public static native saveConfig(Ljava/lang/String;)Z
.end method
