.class Lcom/fakeninjalite/FakeNinjaLite9$JsBridge;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/fakeninjalite/FakeNinjaLite9;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x22
    name = "JsBridge"
.end annotation


# instance fields
.field private final this$0:Lcom/fakeninjalite/FakeNinjaLite9;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const/16 v0, 0x1b

    invoke-static {v0}, LBeykix/protect/NativeUtil;->classesInit0(I)V

    return-void
.end method

.method public constructor <init>(Lcom/fakeninjalite/FakeNinjaLite9;)V
    .registers 2

    .line 151
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/fakeninjalite/FakeNinjaLite9$JsBridge;->this$0:Lcom/fakeninjalite/FakeNinjaLite9;

    return-void
.end method

.method static native access$0(Lcom/fakeninjalite/FakeNinjaLite9$JsBridge;)Lcom/fakeninjalite/FakeNinjaLite9;
.end method


# virtual methods
.method public native onSuccess()V
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation
.end method
