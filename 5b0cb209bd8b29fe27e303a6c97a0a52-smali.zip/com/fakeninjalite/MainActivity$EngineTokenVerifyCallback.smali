.class Lcom/fakeninjalite/MainActivity$EngineTokenVerifyCallback;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/fakeninjalite/FakeNinjaLite5$EngineVerifyCallback;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/fakeninjalite/MainActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x22
    name = "EngineTokenVerifyCallback"
.end annotation


# instance fields
.field private final this$0:Lcom/fakeninjalite/MainActivity;

.field private final token:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const/16 v0, 0x85

    invoke-static {v0}, LBeykix/protect/NativeUtil;->classesInit0(I)V

    return-void
.end method

.method constructor <init>(Lcom/fakeninjalite/MainActivity;Ljava/lang/String;)V
    .registers 3

    .line 1558
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/fakeninjalite/MainActivity$EngineTokenVerifyCallback;->this$0:Lcom/fakeninjalite/MainActivity;

    iput-object p2, p0, Lcom/fakeninjalite/MainActivity$EngineTokenVerifyCallback;->token:Ljava/lang/String;

    return-void
.end method

.method static native access$0(Lcom/fakeninjalite/MainActivity$EngineTokenVerifyCallback;)Lcom/fakeninjalite/MainActivity;
.end method


# virtual methods
.method public native onResult(Z)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(Z)V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation
.end method
