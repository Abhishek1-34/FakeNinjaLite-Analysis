.class public Lcom/fakeninjalite/FakeNinjaLite5;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/fakeninjalite/FakeNinjaLite5$ValidateCallback;,
        Lcom/fakeninjalite/FakeNinjaLite5$PreflightCallback;,
        Lcom/fakeninjalite/FakeNinjaLite5$VerifyCallback;,
        Lcom/fakeninjalite/FakeNinjaLite5$PreflightRunnable;,
        Lcom/fakeninjalite/FakeNinjaLite5$VerifyRunnable;,
        Lcom/fakeninjalite/FakeNinjaLite5$EngineVerifyCallback;,
        Lcom/fakeninjalite/FakeNinjaLite5$EngineVerifyRunnable;,
        Lcom/fakeninjalite/FakeNinjaLite5$ValidateAsyncRunnable;
    }
.end annotation


# static fields
.field public static final GRACE_PERIOD_MS:J = 0x6ddd00L

.field private static final KEY_EXPIRY_MS:Ljava/lang/String;

.field private static final KEY_INTEGRITY:Ljava/lang/String; = "k_itg"

.field private static final KEY_LAST_ONLINE:Ljava/lang/String; = "last_online_ms"

.field private static final KEY_SAVED:Ljava/lang/String;

.field private static final KEY_VALID:Ljava/lang/String;

.field private static final PINNED_FINGERPRINTS:[Ljava/lang/String;

.field private static final PREFS:Ljava/lang/String;

.field private static final SESSION_FILENAME:Ljava/lang/String; = "fnl_s.dat"

.field private static final UA_POOL:[Ljava/lang/String;

.field public static final VR_KEY_DEVICE_MISMATCH:I = 0x4

.field public static final VR_KEY_DISABLED:I = 0x3

.field public static final VR_KEY_EXPIRED:I = 0x2

.field public static final VR_KEY_NOT_FOUND:I = 0x1

.field public static final VR_MAX_DEVICE_REACHED:I = 0x5

.field public static final VR_NETWORK_ERROR:I = 0x6

.field public static final VR_OK:I = 0x0

.field private static final _GU:[I

.field private static final _GU_B:[I

.field private static final _GU_C:[I

.field private static final _GU_D:[I

.field private static final _GU_E:[I

.field private static final _GU_F:[I

.field private static final _GU_G:[I

.field private static final _K1:[I

.field private static final _K2:[I

.field private static final _LV3H:[I

.field private static final _LV3H_B:[I

.field private static final _LV3H_C:[I

.field private static final _LV3H_D:[I

.field private static final _LV3H_E:[I

.field private static final _LV3H_F:[I

.field private static final _LV3H_G:[I

.field private static final _LV6H:[I

.field private static final _LV6H_B:[I

.field private static final _LV6H_C:[I

.field private static final _LV6H_D:[I

.field private static final _LV6H_E:[I

.field private static final _LV6H_F:[I

.field private static final _LV6H_G:[I

.field private static final _SU:[I

.field private static final _SU_B:[I

.field private static final _SU_C:[I

.field private static final _SU_D:[I

.field private static final _SU_E:[I

.field private static final _SU_F:[I

.field private static final _SU_G:[I

.field private static final _S_KEY_EXPIRY:[I

.field private static final _S_KEY_SAVED:[I

.field private static final _S_KEY_VALID:[I

.field private static final _S_PREFS:[I

.field private static final _S_err_ca:[I

.field private static final _S_err_dlr:[I

.field private static final _S_err_dm:[I

.field private static final _S_err_kd:[I

.field private static final _S_err_ke:[I

.field private static final _S_err_knf:[I

.field private static final _S_err_mdr:[I

.field private static final _S_ev_action:[I

.field private static final _S_ev_error:[I

.field private static final _S_ev_token:[I

.field private static final _S_ev_valid:[I

.field private static final _S_f_devId:[I

.field private static final _S_f_error:[I

.field private static final _S_f_expiryMs:[I

.field private static final _S_f_key:[I

.field private static final _S_f_ok:[I

.field private static final _S_f_remainingMs:[I

.field private static final _S_f_sig:[I

.field private static final _S_fallback:[I

.field private static final _S_resp_salt:[I

.field private static final _VR_MAGIC:I = 0x4e2a7c1f

.field private static volatile _engineToken:Ljava/lang/String;

.field private static volatile _engineTokenExpiry:J

.field private static final _engineTokenLock:Ljava/lang/Object;


# direct methods
.method static constructor <clinit>()V
    .registers 12

    const/16 v0, 0x3e

    invoke-static {v0}, LBeykix/protect/NativeUtil;->classesInit0(I)V

    const/16 v0, 0x40

    new-array v1, v0, [I

    fill-array-data v1, :array_204

    sput-object v1, Lcom/fakeninjalite/FakeNinjaLite5;->_K1:[I

    new-array v0, v0, [I

    fill-array-data v0, :array_288

    sput-object v0, Lcom/fakeninjalite/FakeNinjaLite5;->_K2:[I

    const/16 v0, 0x2e

    new-array v1, v0, [I

    fill-array-data v1, :array_30c

    sput-object v1, Lcom/fakeninjalite/FakeNinjaLite5;->_SU:[I

    new-array v1, v0, [I

    fill-array-data v1, :array_36c

    sput-object v1, Lcom/fakeninjalite/FakeNinjaLite5;->_SU_B:[I

    new-array v1, v0, [I

    fill-array-data v1, :array_3cc

    sput-object v1, Lcom/fakeninjalite/FakeNinjaLite5;->_SU_C:[I

    new-array v1, v0, [I

    fill-array-data v1, :array_42c

    sput-object v1, Lcom/fakeninjalite/FakeNinjaLite5;->_SU_D:[I

    new-array v1, v0, [I

    fill-array-data v1, :array_48c

    sput-object v1, Lcom/fakeninjalite/FakeNinjaLite5;->_SU_E:[I

    new-array v1, v0, [I

    fill-array-data v1, :array_4ec

    sput-object v1, Lcom/fakeninjalite/FakeNinjaLite5;->_SU_F:[I

    new-array v0, v0, [I

    fill-array-data v0, :array_54c

    sput-object v0, Lcom/fakeninjalite/FakeNinjaLite5;->_SU_G:[I

    const/16 v0, 0x21

    new-array v1, v0, [I

    fill-array-data v1, :array_5ac

    sput-object v1, Lcom/fakeninjalite/FakeNinjaLite5;->_GU:[I

    new-array v1, v0, [I

    fill-array-data v1, :array_5f2

    sput-object v1, Lcom/fakeninjalite/FakeNinjaLite5;->_GU_B:[I

    new-array v1, v0, [I

    fill-array-data v1, :array_638

    sput-object v1, Lcom/fakeninjalite/FakeNinjaLite5;->_GU_C:[I

    new-array v1, v0, [I

    fill-array-data v1, :array_67e

    sput-object v1, Lcom/fakeninjalite/FakeNinjaLite5;->_GU_D:[I

    new-array v1, v0, [I

    fill-array-data v1, :array_6c4

    sput-object v1, Lcom/fakeninjalite/FakeNinjaLite5;->_GU_E:[I

    new-array v1, v0, [I

    fill-array-data v1, :array_70a

    sput-object v1, Lcom/fakeninjalite/FakeNinjaLite5;->_GU_F:[I

    new-array v0, v0, [I

    fill-array-data v0, :array_750

    sput-object v0, Lcom/fakeninjalite/FakeNinjaLite5;->_GU_G:[I

    const/16 v0, 0xe

    new-array v0, v0, [I

    fill-array-data v0, :array_796

    sput-object v0, Lcom/fakeninjalite/FakeNinjaLite5;->_S_PREFS:[I

    const/16 v1, 0x9

    new-array v1, v1, [I

    fill-array-data v1, :array_7b6

    sput-object v1, Lcom/fakeninjalite/FakeNinjaLite5;->_S_KEY_SAVED:[I

    const/16 v2, 0xf

    new-array v3, v2, [I

    fill-array-data v3, :array_7cc

    sput-object v3, Lcom/fakeninjalite/FakeNinjaLite5;->_S_KEY_EXPIRY:[I

    const/16 v4, 0xc

    new-array v5, v4, [I

    fill-array-data v5, :array_7ee

    sput-object v5, Lcom/fakeninjalite/FakeNinjaLite5;->_S_KEY_VALID:[I

    const/16 v6, 0x8

    new-array v7, v6, [I

    fill-array-data v7, :array_80a

    sput-object v7, Lcom/fakeninjalite/FakeNinjaLite5;->_S_fallback:[I

    const/16 v7, 0xd

    new-array v7, v7, [I

    fill-array-data v7, :array_81e

    sput-object v7, Lcom/fakeninjalite/FakeNinjaLite5;->_S_err_knf:[I

    const/16 v7, 0xb

    new-array v8, v7, [I

    fill-array-data v8, :array_83c

    sput-object v8, Lcom/fakeninjalite/FakeNinjaLite5;->_S_err_ke:[I

    new-array v8, v4, [I

    fill-array-data v8, :array_856

    sput-object v8, Lcom/fakeninjalite/FakeNinjaLite5;->_S_err_kd:[I

    new-array v8, v2, [I

    fill-array-data v8, :array_872

    sput-object v8, Lcom/fakeninjalite/FakeNinjaLite5;->_S_err_dm:[I

    new-array v2, v2, [I

    fill-array-data v2, :array_894

    sput-object v2, Lcom/fakeninjalite/FakeNinjaLite5;->_S_err_ca:[I

    const/16 v2, 0x14

    new-array v2, v2, [I

    fill-array-data v2, :array_8b6

    sput-object v2, Lcom/fakeninjalite/FakeNinjaLite5;->_S_err_dlr:[I

    const/16 v2, 0x12

    new-array v2, v2, [I

    fill-array-data v2, :array_8e2

    sput-object v2, Lcom/fakeninjalite/FakeNinjaLite5;->_S_err_mdr:[I

    const/16 v2, 0xfe

    const/16 v8, 0x8e

    const/16 v9, 0xb7

    filled-new-array {v8, v9, v2}, [I

    move-result-object v2

    sput-object v2, Lcom/fakeninjalite/FakeNinjaLite5;->_S_f_key:[I

    const/16 v2, 0x42

    const/16 v8, 0x1e

    const/16 v10, 0x81

    const/16 v11, 0xf1

    filled-new-array {v10, v9, v11, v2, v8}, [I

    move-result-object v2

    sput-object v2, Lcom/fakeninjalite/FakeNinjaLite5;->_S_f_devId:[I

    const/16 v2, 0x8a

    const/16 v8, 0xb9

    filled-new-array {v2, v8}, [I

    move-result-object v2

    sput-object v2, Lcom/fakeninjalite/FakeNinjaLite5;->_S_f_ok:[I

    const/16 v2, 0xf5

    const/16 v8, 0x64

    const/16 v9, 0x80

    const/16 v10, 0xa0

    filled-new-array {v9, v10, v2, v8, v6}, [I

    move-result-object v2

    sput-object v2, Lcom/fakeninjalite/FakeNinjaLite5;->_S_f_error:[I

    new-array v2, v6, [I

    fill-array-data v2, :array_90a

    sput-object v2, Lcom/fakeninjalite/FakeNinjaLite5;->_S_f_expiryMs:[I

    new-array v2, v7, [I

    fill-array-data v2, :array_91e

    sput-object v2, Lcom/fakeninjalite/FakeNinjaLite5;->_S_f_remainingMs:[I

    const/16 v2, 0xbb

    const/16 v7, 0xe0

    const/16 v8, 0x96

    filled-new-array {v8, v2, v7}, [I

    move-result-object v2

    sput-object v2, Lcom/fakeninjalite/FakeNinjaLite5;->_S_f_sig:[I

    const/16 v2, 0x15

    new-array v2, v2, [I

    fill-array-data v2, :array_938

    sput-object v2, Lcom/fakeninjalite/FakeNinjaLite5;->_S_ev_action:[I

    new-array v2, v4, [I

    fill-array-data v2, :array_966

    sput-object v2, Lcom/fakeninjalite/FakeNinjaLite5;->_S_ev_token:[I

    new-array v2, v6, [I

    fill-array-data v2, :array_982

    sput-object v2, Lcom/fakeninjalite/FakeNinjaLite5;->_S_ev_valid:[I

    new-array v2, v6, [I

    fill-array-data v2, :array_996

    sput-object v2, Lcom/fakeninjalite/FakeNinjaLite5;->_S_ev_error:[I

    invoke-static {v0}, Lcom/fakeninjalite/FakeNinjaLite5;->_d([I)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/fakeninjalite/FakeNinjaLite5;->PREFS:Ljava/lang/String;

    invoke-static {v1}, Lcom/fakeninjalite/FakeNinjaLite5;->_d([I)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/fakeninjalite/FakeNinjaLite5;->KEY_SAVED:Ljava/lang/String;

    invoke-static {v3}, Lcom/fakeninjalite/FakeNinjaLite5;->_d([I)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/fakeninjalite/FakeNinjaLite5;->KEY_EXPIRY_MS:Ljava/lang/String;

    invoke-static {v5}, Lcom/fakeninjalite/FakeNinjaLite5;->_d([I)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/fakeninjalite/FakeNinjaLite5;->KEY_VALID:Ljava/lang/String;

    const/16 v0, 0x2c

    new-array v1, v0, [I

    fill-array-data v1, :array_9aa

    sput-object v1, Lcom/fakeninjalite/FakeNinjaLite5;->_LV3H:[I

    new-array v1, v0, [I

    fill-array-data v1, :array_a06

    sput-object v1, Lcom/fakeninjalite/FakeNinjaLite5;->_LV3H_B:[I

    new-array v1, v0, [I

    fill-array-data v1, :array_a62

    sput-object v1, Lcom/fakeninjalite/FakeNinjaLite5;->_LV3H_C:[I

    new-array v1, v0, [I

    fill-array-data v1, :array_abe

    sput-object v1, Lcom/fakeninjalite/FakeNinjaLite5;->_LV3H_D:[I

    new-array v1, v0, [I

    fill-array-data v1, :array_b1a

    sput-object v1, Lcom/fakeninjalite/FakeNinjaLite5;->_LV3H_E:[I

    new-array v1, v0, [I

    fill-array-data v1, :array_b76

    sput-object v1, Lcom/fakeninjalite/FakeNinjaLite5;->_LV3H_F:[I

    new-array v0, v0, [I

    fill-array-data v0, :array_bd2

    sput-object v0, Lcom/fakeninjalite/FakeNinjaLite5;->_LV3H_G:[I

    const/16 v0, 0x26

    new-array v1, v0, [I

    fill-array-data v1, :array_c2e

    sput-object v1, Lcom/fakeninjalite/FakeNinjaLite5;->_LV6H:[I

    new-array v1, v0, [I

    fill-array-data v1, :array_c7e

    sput-object v1, Lcom/fakeninjalite/FakeNinjaLite5;->_LV6H_B:[I

    new-array v1, v0, [I

    fill-array-data v1, :array_cce

    sput-object v1, Lcom/fakeninjalite/FakeNinjaLite5;->_LV6H_C:[I

    new-array v1, v0, [I

    fill-array-data v1, :array_d1e

    sput-object v1, Lcom/fakeninjalite/FakeNinjaLite5;->_LV6H_D:[I

    new-array v1, v0, [I

    fill-array-data v1, :array_d6e

    sput-object v1, Lcom/fakeninjalite/FakeNinjaLite5;->_LV6H_E:[I

    new-array v1, v0, [I

    fill-array-data v1, :array_dbe

    sput-object v1, Lcom/fakeninjalite/FakeNinjaLite5;->_LV6H_F:[I

    new-array v0, v0, [I

    fill-array-data v0, :array_e0e

    sput-object v0, Lcom/fakeninjalite/FakeNinjaLite5;->_LV6H_G:[I

    const/4 v0, 0x0

    move-object v1, v0

    check-cast v1, Ljava/lang/String;

    sput-object v0, Lcom/fakeninjalite/FakeNinjaLite5;->_engineToken:Ljava/lang/String;

    const-wide/16 v0, 0x0

    sput-wide v0, Lcom/fakeninjalite/FakeNinjaLite5;->_engineTokenExpiry:J

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Lcom/fakeninjalite/FakeNinjaLite5;->_engineTokenLock:Ljava/lang/Object;

    const/16 v0, 0x13

    new-array v0, v0, [I

    fill-array-data v0, :array_e5e

    sput-object v0, Lcom/fakeninjalite/FakeNinjaLite5;->_S_resp_salt:[I

    const-string v0, "142E1E060D3E0E232328050905227A375C415A07301F260E2322213E7C1D196B6721613072611C0873171C"

    invoke-static {v0}, Lobfuse/NPStringFog;->decode(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    filled-new-array {v0}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/fakeninjalite/FakeNinjaLite5;->PINNED_FINGERPRINTS:[Ljava/lang/String;

    const-string v0, "1E002A3B280D2B4958417467723D5B181B0C577837380C3B0919154C0461761467291E210E0A72011B7A0807191E353E262A0D38314800585D7F6175137B3E09270A791952582A241D702153205A236B1833061C0D2802430577021C7D4A6864714F3B3C523E39096910160E13101E6E47625D405655"

    invoke-static {v0}, Lobfuse/NPStringFog;->decode(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Mobile Safari/537.36"

    const-string v2, "1E002A3B280D2B4958417467723D5B181B0C577837380C3B0919154C04627614640D4B035B13766A121B39070517070C21032F256A52065C446264631B183D153E0B19151E5D282A58170355285E65627B181C010F20485D06711F026354767A61221931593B304C1A221109000B58744166445D53"

    invoke-static {v2}, Lobfuse/NPStringFog;->decode(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    filled-new-array {v2, v0, v1}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/fakeninjalite/FakeNinjaLite5;->UA_POOL:[Ljava/lang/String;

    return-void

    :array_204
    .array-data 4
        0xbd
        0x92
        0xea
        0x82
        0x9c
        0x69
        0x2e
        0x85
        0x1f
        0xc4
        0x75
        0x3
        0xdb
        0x8f
        0xd2
        0xaf
        0xe
        0x40
        0xe4
        0x4c
        0x59
        0xf9
        0xcd
        0xab
        0xc0
        0x74
        0xf3
        0x9f
        0x60
        0x27
        0xff
        0x37
        0x57
        0xbc
        0x2b
        0x32
        0xfc
        0x4f
        0x3a
        0x62
        0x58
        0x8a
        0xc6
        0x76
        0xa4
        0x56
        0xe1
        0x22
        0xf4
        0x12
        0x63
        0x30
        0xb7
        0xfe
        0xbd
        0x31
        0x3c
        0x0
        0x7e
        0x2
        0x3
        0x5d
        0xf5
        0x7f
    .end array-data

    :array_288
    .array-data 4
        0x58
        0x41
        0x6f
        0x8a
        0xe2
        0x11
        0xd3
        0x94
        0xbe
        0x98
        0x69
        0xcb
        0x1e
        0x3c
        0x58
        0xb
        0x11
        0xe5
        0x2e
        0x16
        0x43
        0x20
        0x12
        0x5d
        0x5e
        0x58
        0x85
        0x7d
        0x3
        0x9b
        0x17
        0xa1
        0x89
        0xd9
        0x43
        0x4f
        0xb4
        0x90
        0x5
        0xbc
        0x3a
        0xef
        0x3c
        0x9f
        0x95
        0x7c
        0x8f
        0xb8
        0xdf
        0xf4
        0xb4
        0xed
        0x23
        0xd9
        0xa1
        0xba
        0x25
        0xfb
        0xd6
        0x7b
        0x92
        0xe4
        0xbb
        0xd0
    .end array-data

    :array_30c
    .array-data 4
        0x8d
        0xa6
        0xf3
        0x7b
        0x9
        0x47
        0xd4
        0x39
        0xcf
        0x3b
        0x3b
        0xa8
        0xac
        0xc7
        0xa9
        0xd8
        0x6a
        0xc6
        0xae
        0x2c
        0x7c
        0xe1
        0xba
        0x8e
        0xe9
        0x41
        0x15
        0xd7
        0x9
        0xc4
        0x84
        0xea
        0x9b
        0x28
        0x64
        0x3f
        0x1c
        0x8a
        0x36
        0x98
        0x3a
        0x25
        0xff
        0xa9
        0x78
        0x7e
    .end array-data

    :array_36c
    .array-data 4
        0x8d
        0xa6
        0xf3
        0x7b
        0x9
        0x47
        0xd4
        0x39
        0xcf
        0x3b
        0x3b
        0xa8
        0xac
        0xc7
        0xa9
        0xd8
        0x6a
        0xc6
        0xae
        0x2c
        0x7c
        0xe1
        0xba
        0x8e
        0xe9
        0x41
        0x15
        0xd7
        0x9
        0xc4
        0x84
        0xea
        0x9b
        0x28
        0x64
        0x3f
        0x1c
        0x8a
        0x36
        0x98
        0x3a
        0x25
        0xff
        0xa9
        0x78
        0x7e
    .end array-data

    :array_3cc
    .array-data 4
        0x8d
        0xa6
        0xf3
        0x7b
        0x9
        0x47
        0xd4
        0x39
        0xcf
        0x3b
        0x3b
        0xa8
        0xac
        0xc7
        0xa9
        0xd8
        0x6a
        0xc6
        0xae
        0x2c
        0x7c
        0xe1
        0xba
        0x8e
        0xe9
        0x41
        0x15
        0xd7
        0x9
        0xc4
        0x84
        0xea
        0x9b
        0x28
        0x64
        0x3f
        0x1c
        0x8a
        0x36
        0x98
        0x3a
        0x25
        0xff
        0xa9
        0x78
        0x7e
    .end array-data

    :array_42c
    .array-data 4
        0x8d
        0xa6
        0xf3
        0x7b
        0x9
        0x47
        0xd4
        0x39
        0xcf
        0x3b
        0x3b
        0xa8
        0xac
        0xc7
        0xa9
        0xd8
        0x6a
        0xc6
        0xae
        0x2c
        0x7c
        0xe1
        0xba
        0x8e
        0xe9
        0x41
        0x15
        0xd7
        0x9
        0xc4
        0x84
        0xea
        0x9b
        0x28
        0x64
        0x3f
        0x1c
        0x8a
        0x36
        0x98
        0x3a
        0x25
        0xff
        0xa9
        0x78
        0x7e
    .end array-data

    :array_48c
    .array-data 4
        0x8d
        0xa6
        0xf3
        0x7b
        0x9
        0x47
        0xd4
        0x39
        0xcf
        0x3b
        0x3b
        0xa8
        0xac
        0xc7
        0xa9
        0xd8
        0x6a
        0xc6
        0xae
        0x2c
        0x7c
        0xe1
        0xba
        0x8e
        0xe9
        0x41
        0x15
        0xd7
        0x9
        0xc4
        0x84
        0xea
        0x9b
        0x28
        0x64
        0x3f
        0x1c
        0x8a
        0x36
        0x98
        0x3a
        0x25
        0xff
        0xa9
        0x78
        0x7e
    .end array-data

    :array_4ec
    .array-data 4
        0x8d
        0xa6
        0xf3
        0x7b
        0x9
        0x47
        0xd4
        0x39
        0xcf
        0x3b
        0x3b
        0xa8
        0xac
        0xc7
        0xa9
        0xd8
        0x6a
        0xc6
        0xae
        0x2c
        0x7c
        0xe1
        0xba
        0x8e
        0xe9
        0x41
        0x15
        0xd7
        0x9
        0xc4
        0x84
        0xea
        0x9b
        0x28
        0x64
        0x3f
        0x1c
        0x8a
        0x36
        0x98
        0x3a
        0x25
        0xff
        0xa9
        0x78
        0x7e
    .end array-data

    :array_54c
    .array-data 4
        0x8d
        0xa6
        0xf3
        0x7b
        0x9
        0x47
        0xd4
        0x39
        0xcf
        0x3b
        0x3b
        0xa8
        0xac
        0xc7
        0xa9
        0xd8
        0x6a
        0xc6
        0xae
        0x2c
        0x7c
        0xe1
        0xba
        0x8e
        0xe9
        0x41
        0x15
        0xd7
        0x9
        0xc4
        0x84
        0xea
        0x9b
        0x28
        0x64
        0x3f
        0x1c
        0x8a
        0x36
        0x98
        0x3a
        0x25
        0xff
        0xa9
        0x78
        0x7e
    .end array-data

    :array_5ac
    .array-data 4
        0x8d
        0xa6
        0xf3
        0x7b
        0x9
        0x47
        0xd4
        0x39
        0xf3
        0x3a
        0x6e
        0xb6
        0xfd
        0xf5
        0xaa
        0xcc
        0x66
        0xc0
        0xb0
        0x3c
        0x6c
        0xe2
        0xa0
        0x8e
        0xa9
        0x73
        0x22
        0xbe
        0x1a
        0xd5
        0xbd
        0xec
        0x87
    .end array-data

    :array_5f2
    .array-data 4
        0x8d
        0xa6
        0xf3
        0x7b
        0x9
        0x47
        0xd4
        0x39
        0xf3
        0x3a
        0x6e
        0xb6
        0xfd
        0xf5
        0xaa
        0xcc
        0x66
        0xc0
        0xb0
        0x3c
        0x6c
        0xe2
        0xa0
        0x8e
        0xa9
        0x73
        0x22
        0xbe
        0x1a
        0xd5
        0xbd
        0xec
        0x87
    .end array-data

    :array_638
    .array-data 4
        0x8d
        0xa6
        0xf3
        0x7b
        0x9
        0x47
        0xd4
        0x39
        0xf3
        0x3a
        0x6e
        0xb6
        0xfd
        0xf5
        0xaa
        0xcc
        0x66
        0xc0
        0xb0
        0x3c
        0x6c
        0xe2
        0xa0
        0x8e
        0xa9
        0x73
        0x22
        0xbe
        0x1a
        0xd5
        0xbd
        0xec
        0x87
    .end array-data

    :array_67e
    .array-data 4
        0x8d
        0xa6
        0xf3
        0x7b
        0x9
        0x47
        0xd4
        0x39
        0xf3
        0x3a
        0x6e
        0xb6
        0xfd
        0xf5
        0xaa
        0xcc
        0x66
        0xc0
        0xb0
        0x3c
        0x6c
        0xe2
        0xa0
        0x8e
        0xa9
        0x73
        0x22
        0xbe
        0x1a
        0xd5
        0xbd
        0xec
        0x87
    .end array-data

    :array_6c4
    .array-data 4
        0x8d
        0xa6
        0xf3
        0x7b
        0x9
        0x47
        0xd4
        0x39
        0xf3
        0x3a
        0x6e
        0xb6
        0xfd
        0xf5
        0xaa
        0xcc
        0x66
        0xc0
        0xb0
        0x3c
        0x6c
        0xe2
        0xa0
        0x8e
        0xa9
        0x73
        0x22
        0xbe
        0x1a
        0xd5
        0xbd
        0xec
        0x87
    .end array-data

    :array_70a
    .array-data 4
        0x8d
        0xa6
        0xf3
        0x7b
        0x9
        0x47
        0xd4
        0x39
        0xf3
        0x3a
        0x6e
        0xb6
        0xfd
        0xf5
        0xaa
        0xcc
        0x66
        0xc0
        0xb0
        0x3c
        0x6c
        0xe2
        0xa0
        0x8e
        0xa9
        0x73
        0x22
        0xbe
        0x1a
        0xd5
        0xbd
        0xec
        0x87
    .end array-data

    :array_750
    .array-data 4
        0x8d
        0xa6
        0xf3
        0x7b
        0x9
        0x47
        0xd4
        0x39
        0xf3
        0x3a
        0x6e
        0xb6
        0xfd
        0xf5
        0xaa
        0xcc
        0x66
        0xc0
        0xb0
        0x3c
        0x6c
        0xe2
        0xa0
        0x8e
        0xa9
        0x73
        0x22
        0xbe
        0x1a
        0xd5
        0xbd
        0xec
        0x87
    .end array-data

    :array_796
    .array-data 4
        0xa3
        0x9c
        0xcb
        0x62
        0xe
        0x18
        0xb0
        0x73
        0xd0
        0x5
        0x64
        0xa6
        0xaf
        0xcd
    .end array-data

    :array_7b6
    .array-data 4
        0x96
        0xb3
        0xf1
        0x6e
        0x1e
        0x22
        0x90
        0x73
        0xd0
    .end array-data

    :array_7cc
    .array-data 4
        0x96
        0xb3
        0xf1
        0x6e
        0x1e
        0x22
        0x9e
        0x6e
        0xd9
        0x3c
        0x64
        0xba
        0x96
        0xd3
        0xf7
    .end array-data

    :array_7ee
    .array-data 4
        0x8e
        0xb7
        0xfe
        0x54
        0x13
        0xe
        0xa4
        0x60
        0xc8
        0x39
        0x7f
        0xa7
    .end array-data

    :array_80a
    .array-data 4
        0x83
        0xb3
        0xeb
        0x67
        0x18
        0x1c
        0x98
        0x7d
    .end array-data

    :array_81e
    .array-data 4
        0x8e
        0xb7
        0xfe
        0x54
        0x14
        0x12
        0x8f
        0x49
        0xcf
        0x3a
        0x63
        0xad
        0xad
    .end array-data

    :array_83c
    .array-data 4
        0x8e
        0xb7
        0xfe
        0x54
        0x1f
        0x5
        0x8b
        0x7f
        0xdb
        0x30
        0x72
    .end array-data

    :array_856
    .array-data 4
        0x8e
        0xb7
        0xfe
        0x54
        0x1e
        0x14
        0x88
        0x77
        0xcb
        0x39
        0x73
        0xa7
    .end array-data

    :array_872
    .array-data 4
        0x81
        0xb7
        0xf1
        0x62
        0x19
        0x18
        0xa4
        0x7b
        0xc0
        0x26
        0x7b
        0xa2
        0xbd
        0xdd
        0xec
    .end array-data

    :array_894
    .array-data 4
        0x86
        0xbd
        0xe8
        0x67
        0x1e
        0x12
        0x8c
        0x78
        0xf6
        0x34
        0x75
        0xb7
        0xa0
        0xc8
        0xe1
    .end array-data

    :array_8b6
    .array-data 4
        0x81
        0xb7
        0xf1
        0x62
        0x19
        0x18
        0xa4
        0x7a
        0xc0
        0x38
        0x7f
        0xb7
        0x96
        0xcc
        0xe1
        0xca
        0x6c
        0xdc
        0xbd
        0x2d
    .end array-data

    :array_8e2
    .array-data 4
        0x88
        0xb3
        0xff
        0x54
        0x1e
        0x18
        0x8d
        0x7f
        0xca
        0x30
        0x49
        0xb1
        0xac
        0xdf
        0xe7
        0xc3
        0x6a
        0xd0
    .end array-data

    :array_90a
    .array-data 4
        0x80
        0xaa
        0xf7
        0x62
        0x8
        0x4
        0xb6
        0x65
    .end array-data

    :array_91e
    .array-data 4
        0x97
        0xb7
        0xea
        0x6a
        0x13
        0x13
        0x92
        0x78
        0xce
        0x18
        0x65
    .end array-data

    :array_938
    .array-data 4
        0xda
        0xb3
        0xe4
        0x7f
        0x13
        0x12
        0x95
        0x2b
        0xcc
        0x3b
        0x71
        0xaa
        0xa7
        0xdb
        0xdb
        0xdd
        0x6a
        0xc6
        0xb1
        0x2f
        0x77
    .end array-data

    :array_966
    .array-data 4
        0x80
        0xbc
        0xe0
        0x62
        0x14
        0x18
        0xa4
        0x62
        0xc6
        0x3e
        0x73
        0xad
    .end array-data

    :array_982
    .array-data 4
        0x80
        0xa6
        0xd8
        0x7d
        0x1b
        0x11
        0x92
        0x72
    .end array-data

    :array_996
    .array-data 4
        0x80
        0xa6
        0xd8
        0x6e
        0x8
        0xf
        0x94
        0x64
    .end array-data

    :array_9aa
    .array-data 4
        0x8d
        0xa6
        0xf3
        0x7b
        0x9
        0x47
        0xd4
        0x39
        0xc5
        0x3c
        0x78
        0xa8
        0xe4
        0xca
        0xe5
        0xd9
        0x68
        0xd1
        0xac
        0x67
        0x60
        0xa9
        0xbd
        0xce
        0xb2
        0x6
        0x59
        0xcf
        0x4b
        0x91
        0xc7
        0xa6
        0xc6
        0x3e
        0x3d
        0x9
        0x3a
        0xac
        0x6c
        0x95
        0x22
        0x9
        0x95
        0x8d
    .end array-data

    :array_a06
    .array-data 4
        0x8d
        0xa6
        0xf3
        0x7b
        0x9
        0x47
        0xd4
        0x39
        0xc5
        0x3c
        0x78
        0xa8
        0xe4
        0xca
        0xe5
        0xd9
        0x68
        0xd1
        0xac
        0x67
        0x60
        0xa9
        0xbd
        0xce
        0xb2
        0x6
        0x59
        0xcf
        0x4b
        0x91
        0xc7
        0xa6
        0xc6
        0x3e
        0x3d
        0x9
        0x3a
        0xac
        0x6c
        0x95
        0x22
        0x9
        0x95
        0x8d
    .end array-data

    :array_a62
    .array-data 4
        0x8d
        0xa6
        0xf3
        0x7b
        0x9
        0x47
        0xd4
        0x39
        0xc5
        0x3c
        0x78
        0xa8
        0xe4
        0xca
        0xe5
        0xd9
        0x68
        0xd1
        0xac
        0x67
        0x60
        0xa9
        0xbd
        0xce
        0xb2
        0x6
        0x59
        0xcf
        0x4b
        0x91
        0xc7
        0xa6
        0xc6
        0x3e
        0x3d
        0x9
        0x3a
        0xac
        0x6c
        0x95
        0x22
        0x9
        0x95
        0x8d
    .end array-data

    :array_abe
    .array-data 4
        0x8d
        0xa6
        0xf3
        0x7b
        0x9
        0x47
        0xd4
        0x39
        0xc5
        0x3c
        0x78
        0xa8
        0xe4
        0xca
        0xe5
        0xd9
        0x68
        0xd1
        0xac
        0x67
        0x60
        0xa9
        0xbd
        0xce
        0xb2
        0x6
        0x59
        0xcf
        0x4b
        0x91
        0xc7
        0xa6
        0xc6
        0x3e
        0x3d
        0x9
        0x3a
        0xac
        0x6c
        0x95
        0x22
        0x9
        0x95
        0x8d
    .end array-data

    :array_b1a
    .array-data 4
        0x8d
        0xa6
        0xf3
        0x7b
        0x9
        0x47
        0xd4
        0x39
        0xc5
        0x3c
        0x78
        0xa8
        0xe4
        0xca
        0xe5
        0xd9
        0x68
        0xd1
        0xac
        0x67
        0x60
        0xa9
        0xbd
        0xce
        0xb2
        0x6
        0x59
        0xcf
        0x4b
        0x91
        0xc7
        0xa6
        0xc6
        0x3e
        0x3d
        0x9
        0x3a
        0xac
        0x6c
        0x95
        0x22
        0x9
        0x95
        0x8d
    .end array-data

    :array_b76
    .array-data 4
        0x8d
        0xa6
        0xf3
        0x7b
        0x9
        0x47
        0xd4
        0x39
        0xc5
        0x3c
        0x78
        0xa8
        0xe4
        0xca
        0xe5
        0xd9
        0x68
        0xd1
        0xac
        0x67
        0x60
        0xa9
        0xbd
        0xce
        0xb2
        0x6
        0x59
        0xcf
        0x4b
        0x91
        0xc7
        0xa6
        0xc6
        0x3e
        0x3d
        0x9
        0x3a
        0xac
        0x6c
        0x95
        0x22
        0x9
        0x95
        0x8d
    .end array-data

    :array_bd2
    .array-data 4
        0x8d
        0xa6
        0xf3
        0x7b
        0x9
        0x47
        0xd4
        0x39
        0xc5
        0x3c
        0x78
        0xa8
        0xe4
        0xca
        0xe5
        0xd9
        0x68
        0xd1
        0xac
        0x67
        0x60
        0xa9
        0xbd
        0xce
        0xb2
        0x6
        0x59
        0xcf
        0x4b
        0x91
        0xc7
        0xa6
        0xc6
        0x3e
        0x3d
        0x9
        0x3a
        0xac
        0x6c
        0x95
        0x22
        0x9
        0x95
        0x8d
    .end array-data

    :array_c2e
    .array-data 4
        0x8d
        0xa6
        0xf3
        0x7b
        0x9
        0x47
        0xd4
        0x39
        0xf3
        0x3a
        0x6e
        0xb6
        0xfd
        0xf5
        0xaa
        0xcc
        0x66
        0xc0
        0xb0
        0x3c
        0x6c
        0xe2
        0xa0
        0x8e
        0xa9
        0x73
        0x22
        0xb5
        0x16
        0xcf
        0x9d
        0xa6
        0x8d
        0x30
        0x2f
        0x2e
        0x5d
        0xd5
    .end array-data

    :array_c7e
    .array-data 4
        0x8d
        0xa6
        0xf3
        0x7b
        0x9
        0x47
        0xd4
        0x39
        0xf3
        0x3a
        0x6e
        0xb6
        0xfd
        0xf5
        0xaa
        0xcc
        0x66
        0xc0
        0xb0
        0x3c
        0x6c
        0xe2
        0xa0
        0x8e
        0xa9
        0x73
        0x22
        0xb5
        0x16
        0xcf
        0x9d
        0xa6
        0x8d
        0x30
        0x2f
        0x2e
        0x5d
        0xd5
    .end array-data

    :array_cce
    .array-data 4
        0x8d
        0xa6
        0xf3
        0x7b
        0x9
        0x47
        0xd4
        0x39
        0xf3
        0x3a
        0x6e
        0xb6
        0xfd
        0xf5
        0xaa
        0xcc
        0x66
        0xc0
        0xb0
        0x3c
        0x6c
        0xe2
        0xa0
        0x8e
        0xa9
        0x73
        0x22
        0xb5
        0x16
        0xcf
        0x9d
        0xa6
        0x8d
        0x30
        0x2f
        0x2e
        0x5d
        0xd5
    .end array-data

    :array_d1e
    .array-data 4
        0x8d
        0xa6
        0xf3
        0x7b
        0x9
        0x47
        0xd4
        0x39
        0xf3
        0x3a
        0x6e
        0xb6
        0xfd
        0xf5
        0xaa
        0xcc
        0x66
        0xc0
        0xb0
        0x3c
        0x6c
        0xe2
        0xa0
        0x8e
        0xa9
        0x73
        0x22
        0xb5
        0x16
        0xcf
        0x9d
        0xa6
        0x8d
        0x30
        0x2f
        0x2e
        0x5d
        0xd5
    .end array-data

    :array_d6e
    .array-data 4
        0x8d
        0xa6
        0xf3
        0x7b
        0x9
        0x47
        0xd4
        0x39
        0xf3
        0x3a
        0x6e
        0xb6
        0xfd
        0xf5
        0xaa
        0xcc
        0x66
        0xc0
        0xb0
        0x3c
        0x6c
        0xe2
        0xa0
        0x8e
        0xa9
        0x73
        0x22
        0xb5
        0x16
        0xcf
        0x9d
        0xa6
        0x8d
        0x30
        0x2f
        0x2e
        0x5d
        0xd5
    .end array-data

    :array_dbe
    .array-data 4
        0x8d
        0xa6
        0xf3
        0x7b
        0x9
        0x47
        0xd4
        0x39
        0xf3
        0x3a
        0x6e
        0xb6
        0xfd
        0xf5
        0xaa
        0xcc
        0x66
        0xc0
        0xb0
        0x3c
        0x6c
        0xe2
        0xa0
        0x8e
        0xa9
        0x73
        0x22
        0xb5
        0x16
        0xcf
        0x9d
        0xa6
        0x8d
        0x30
        0x2f
        0x2e
        0x5d
        0xd5
    .end array-data

    :array_e0e
    .array-data 4
        0x8d
        0xa6
        0xf3
        0x7b
        0x9
        0x47
        0xd4
        0x39
        0xf3
        0x3a
        0x6e
        0xb6
        0xfd
        0xf5
        0xaa
        0xcc
        0x66
        0xc0
        0xb0
        0x3c
        0x6c
        0xe2
        0xa0
        0x8e
        0xa9
        0x73
        0x22
        0xb5
        0x16
        0xcf
        0x9d
        0xa6
        0x8d
        0x30
        0x2f
        0x2e
        0x5d
        0xd5
    .end array-data

    :array_e5e
    .array-data 4
        0xa7
        0x97
        0xde
        0x40
        0x33
        0x25
        0xbc
        0x57
        0xe7
        0x1
        0x53
        0x8d
        0x8e
        0xfc
        0xc5
        0xe5
        0x48
        0xf1
        0x8c
    .end array-data
.end method

.method public constructor <init>()V
    .registers 1

    .line 832
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static native GET_KEY_URL()Ljava/lang/String;
.end method

.method private static native _d([I)Ljava/lang/String;
.end method

.method static synthetic access$1000042([I)Ljava/lang/String;
    .registers 1

    invoke-static {p0}, Lcom/fakeninjalite/FakeNinjaLite5;->_d([I)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method static synthetic access$1000043()Ljava/lang/String;
    .registers 1

    invoke-static {}, Lcom/fakeninjalite/FakeNinjaLite5;->getServerUrl()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method static synthetic access$1000078(Ljava/lang/String;JJLjava/lang/String;)Z
    .registers 6

    invoke-static/range {p0 .. p5}, Lcom/fakeninjalite/FakeNinjaLite5;->verifyResponseSig(Ljava/lang/String;JJLjava/lang/String;)Z

    move-result p0

    return p0
.end method

.method static synthetic access$1000091(Landroid/content/Context;)Ljava/lang/String;
    .registers 1

    invoke-static {p0}, Lcom/fakeninjalite/FakeNinjaLite5;->getRawDeviceId(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method static synthetic access$1000096(Landroid/content/Context;Ljava/lang/String;J)V
    .registers 4

    invoke-static {p0, p1, p2, p3}, Lcom/fakeninjalite/FakeNinjaLite5;->saveKeyLocal(Landroid/content/Context;Ljava/lang/String;J)V

    return-void
.end method

.method static synthetic access$1000100(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    invoke-static {p0, p1}, Lcom/fakeninjalite/FakeNinjaLite5;->httpPost(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method static synthetic access$L1000021()[I
    .registers 1

    sget-object v0, Lcom/fakeninjalite/FakeNinjaLite5;->_S_err_knf:[I

    return-object v0
.end method

.method static synthetic access$L1000022()[I
    .registers 1

    sget-object v0, Lcom/fakeninjalite/FakeNinjaLite5;->_S_err_ke:[I

    return-object v0
.end method

.method static synthetic access$L1000023()[I
    .registers 1

    sget-object v0, Lcom/fakeninjalite/FakeNinjaLite5;->_S_err_kd:[I

    return-object v0
.end method

.method static synthetic access$L1000024()[I
    .registers 1

    sget-object v0, Lcom/fakeninjalite/FakeNinjaLite5;->_S_err_dm:[I

    return-object v0
.end method

.method static synthetic access$L1000025()[I
    .registers 1

    sget-object v0, Lcom/fakeninjalite/FakeNinjaLite5;->_S_err_ca:[I

    return-object v0
.end method

.method static synthetic access$L1000026()[I
    .registers 1

    sget-object v0, Lcom/fakeninjalite/FakeNinjaLite5;->_S_err_dlr:[I

    return-object v0
.end method

.method static synthetic access$L1000027()[I
    .registers 1

    sget-object v0, Lcom/fakeninjalite/FakeNinjaLite5;->_S_err_mdr:[I

    return-object v0
.end method

.method static synthetic access$L1000028()[I
    .registers 1

    sget-object v0, Lcom/fakeninjalite/FakeNinjaLite5;->_S_f_key:[I

    return-object v0
.end method

.method static synthetic access$L1000029()[I
    .registers 1

    sget-object v0, Lcom/fakeninjalite/FakeNinjaLite5;->_S_f_devId:[I

    return-object v0
.end method

.method static synthetic access$L1000030()[I
    .registers 1

    sget-object v0, Lcom/fakeninjalite/FakeNinjaLite5;->_S_f_ok:[I

    return-object v0
.end method

.method static synthetic access$L1000031()[I
    .registers 1

    sget-object v0, Lcom/fakeninjalite/FakeNinjaLite5;->_S_f_error:[I

    return-object v0
.end method

.method static synthetic access$L1000032()[I
    .registers 1

    sget-object v0, Lcom/fakeninjalite/FakeNinjaLite5;->_S_f_expiryMs:[I

    return-object v0
.end method

.method static synthetic access$L1000033()[I
    .registers 1

    sget-object v0, Lcom/fakeninjalite/FakeNinjaLite5;->_S_f_remainingMs:[I

    return-object v0
.end method

.method static synthetic access$L1000034()[I
    .registers 1

    sget-object v0, Lcom/fakeninjalite/FakeNinjaLite5;->_S_f_sig:[I

    return-object v0
.end method

.method static synthetic access$L1000035()[I
    .registers 1

    sget-object v0, Lcom/fakeninjalite/FakeNinjaLite5;->_S_ev_action:[I

    return-object v0
.end method

.method static synthetic access$L1000036()[I
    .registers 1

    sget-object v0, Lcom/fakeninjalite/FakeNinjaLite5;->_S_ev_token:[I

    return-object v0
.end method

.method static synthetic access$L1000037()[I
    .registers 1

    sget-object v0, Lcom/fakeninjalite/FakeNinjaLite5;->_S_ev_valid:[I

    return-object v0
.end method

.method static synthetic access$S1000021([I)V
    .registers 1

    sput-object p0, Lcom/fakeninjalite/FakeNinjaLite5;->_S_err_knf:[I

    return-void
.end method

.method static synthetic access$S1000022([I)V
    .registers 1

    sput-object p0, Lcom/fakeninjalite/FakeNinjaLite5;->_S_err_ke:[I

    return-void
.end method

.method static synthetic access$S1000023([I)V
    .registers 1

    sput-object p0, Lcom/fakeninjalite/FakeNinjaLite5;->_S_err_kd:[I

    return-void
.end method

.method static synthetic access$S1000024([I)V
    .registers 1

    sput-object p0, Lcom/fakeninjalite/FakeNinjaLite5;->_S_err_dm:[I

    return-void
.end method

.method static synthetic access$S1000025([I)V
    .registers 1

    sput-object p0, Lcom/fakeninjalite/FakeNinjaLite5;->_S_err_ca:[I

    return-void
.end method

.method static synthetic access$S1000026([I)V
    .registers 1

    sput-object p0, Lcom/fakeninjalite/FakeNinjaLite5;->_S_err_dlr:[I

    return-void
.end method

.method static synthetic access$S1000027([I)V
    .registers 1

    sput-object p0, Lcom/fakeninjalite/FakeNinjaLite5;->_S_err_mdr:[I

    return-void
.end method

.method static synthetic access$S1000028([I)V
    .registers 1

    sput-object p0, Lcom/fakeninjalite/FakeNinjaLite5;->_S_f_key:[I

    return-void
.end method

.method static synthetic access$S1000029([I)V
    .registers 1

    sput-object p0, Lcom/fakeninjalite/FakeNinjaLite5;->_S_f_devId:[I

    return-void
.end method

.method static synthetic access$S1000030([I)V
    .registers 1

    sput-object p0, Lcom/fakeninjalite/FakeNinjaLite5;->_S_f_ok:[I

    return-void
.end method

.method static synthetic access$S1000031([I)V
    .registers 1

    sput-object p0, Lcom/fakeninjalite/FakeNinjaLite5;->_S_f_error:[I

    return-void
.end method

.method static synthetic access$S1000032([I)V
    .registers 1

    sput-object p0, Lcom/fakeninjalite/FakeNinjaLite5;->_S_f_expiryMs:[I

    return-void
.end method

.method static synthetic access$S1000033([I)V
    .registers 1

    sput-object p0, Lcom/fakeninjalite/FakeNinjaLite5;->_S_f_remainingMs:[I

    return-void
.end method

.method static synthetic access$S1000034([I)V
    .registers 1

    sput-object p0, Lcom/fakeninjalite/FakeNinjaLite5;->_S_f_sig:[I

    return-void
.end method

.method static synthetic access$S1000035([I)V
    .registers 1

    sput-object p0, Lcom/fakeninjalite/FakeNinjaLite5;->_S_ev_action:[I

    return-void
.end method

.method static synthetic access$S1000036([I)V
    .registers 1

    sput-object p0, Lcom/fakeninjalite/FakeNinjaLite5;->_S_ev_token:[I

    return-void
.end method

.method static synthetic access$S1000037([I)V
    .registers 1

    sput-object p0, Lcom/fakeninjalite/FakeNinjaLite5;->_S_ev_valid:[I

    return-void
.end method

.method public static native clearKey(Landroid/content/Context;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            ")V"
        }
    .end annotation
.end method

.method private static native computeIntegrity(Landroid/content/Context;Ljava/lang/String;J)Ljava/lang/String;
.end method

.method private static native computeIntegrity(Landroid/content/Context;Ljava/lang/String;JJ)Ljava/lang/String;
.end method

.method public static native consumeEngineToken(Ljava/lang/String;)Z
.end method

.method private static native decLong(Landroid/content/Context;J)J
.end method

.method private static native decStr(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;
.end method

.method private static native deleteSessionFile(Landroid/content/Context;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            ")V"
        }
    .end annotation
.end method

.method private static native encLong(Landroid/content/Context;J)J
.end method

.method private static native encStr(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;
.end method

.method public static native formatRemaining(J)Ljava/lang/String;
.end method

.method public static native getAndClearEngineToken()Ljava/lang/String;
.end method

.method public static native getLinkvertiseUrl(I)Ljava/lang/String;
.end method

.method private static native getRawDeviceId(Landroid/content/Context;)Ljava/lang/String;
.end method

.method public static native getRemainingMs(Landroid/content/Context;)J
.end method

.method public static native getSavedKey(Landroid/content/Context;)Ljava/lang/String;
.end method

.method private static native getServerUrl()Ljava/lang/String;
.end method

.method private static native getSessionFile(Landroid/content/Context;)Ljava/io/File;
.end method

.method public static native graceRemainingMs(Landroid/content/Context;)J
.end method

.method private static native hmacSha256(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
.end method

.method private static native httpPost(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation
.end method

.method public static native isGracePeriodExpired(Landroid/content/Context;)Z
.end method

.method private static native isPinnedCert(Ljavax/net/ssl/HttpsURLConnection;)Z
.end method

.method public static native isSavedKeyValidLocal(Landroid/content/Context;)Z
.end method

.method private static native isValidKeyFormat(Ljava/lang/String;)Z
.end method

.method public static native preflight(Landroid/content/Context;ILcom/fakeninjalite/FakeNinjaLite5$PreflightCallback;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "I",
            "Lcom/fakeninjalite/FakeNinjaLite5$PreflightCallback;",
            ")V"
        }
    .end annotation
.end method

.method private static native readKeyFromFile(Landroid/content/Context;)[Ljava/lang/String;
.end method

.method public static native revalidateSavedKey(Landroid/content/Context;Lcom/fakeninjalite/FakeNinjaLite5$ValidateCallback;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Lcom/fakeninjalite/FakeNinjaLite5$ValidateCallback;",
            ")V"
        }
    .end annotation
.end method

.method private static native saveKeyLocal(Landroid/content/Context;Ljava/lang/String;J)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/lang/String;",
            "J)V"
        }
    .end annotation
.end method

.method private static native saveKeyToFile(Landroid/content/Context;Ljava/lang/String;J)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/lang/String;",
            "J)V"
        }
    .end annotation
.end method

.method public static native setEngineToken(Ljava/lang/String;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation
.end method

.method public static native validateAsync(Landroid/content/Context;Ljava/lang/String;Lcom/fakeninjalite/FakeNinjaLite5$ValidateCallback;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/lang/String;",
            "Lcom/fakeninjalite/FakeNinjaLite5$ValidateCallback;",
            ")V"
        }
    .end annotation
.end method

.method public static native verifyEngineTokenOnline(Landroid/content/Context;Ljava/lang/String;Lcom/fakeninjalite/FakeNinjaLite5$EngineVerifyCallback;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/lang/String;",
            "Lcom/fakeninjalite/FakeNinjaLite5$EngineVerifyCallback;",
            ")V"
        }
    .end annotation
.end method

.method private static native verifyResponseSig(Ljava/lang/String;JJLjava/lang/String;)Z
.end method

.method public static native verifyToken(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;ILcom/fakeninjalite/FakeNinjaLite5$VerifyCallback;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "I",
            "Lcom/fakeninjalite/FakeNinjaLite5$VerifyCallback;",
            ")V"
        }
    .end annotation
.end method
