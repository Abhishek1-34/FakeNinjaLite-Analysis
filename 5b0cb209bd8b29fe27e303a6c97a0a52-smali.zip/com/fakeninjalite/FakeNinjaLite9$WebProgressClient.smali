.class Lcom/fakeninjalite/FakeNinjaLite9$WebProgressClient;
.super Landroid/webkit/WebChromeClient;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/fakeninjalite/FakeNinjaLite9;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x22
    name = "WebProgressClient"
.end annotation


# instance fields
.field private final this$0:Lcom/fakeninjalite/FakeNinjaLite9;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const/16 v0, 0x83

    invoke-static {v0}, LBeykix/protect/NativeUtil;->classesInit0(I)V

    return-void
.end method

.method public constructor <init>(Lcom/fakeninjalite/FakeNinjaLite9;)V
    .registers 2

    .line 83
    invoke-direct {p0}, Landroid/webkit/WebChromeClient;-><init>()V

    iput-object p1, p0, Lcom/fakeninjalite/FakeNinjaLite9$WebProgressClient;->this$0:Lcom/fakeninjalite/FakeNinjaLite9;

    return-void
.end method

.method static native access$0(Lcom/fakeninjalite/FakeNinjaLite9$WebProgressClient;)Lcom/fakeninjalite/FakeNinjaLite9;
.end method


# virtual methods
.method public native onCreateWindow(Landroid/webkit/WebView;ZZLandroid/os/Message;)Z
    .annotation runtime Ljava/lang/Override;
    .end annotation
.end method

.method public native onProgressChanged(Landroid/webkit/WebView;I)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/webkit/WebView;",
            "I)V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation
.end method

.method public native onReceivedTitle(Landroid/webkit/WebView;Ljava/lang/String;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/webkit/WebView;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation
.end method
