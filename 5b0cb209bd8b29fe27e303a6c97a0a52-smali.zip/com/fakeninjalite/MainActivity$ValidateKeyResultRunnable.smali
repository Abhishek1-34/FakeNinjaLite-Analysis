.class Lcom/fakeninjalite/MainActivity$ValidateKeyResultRunnable;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/fakeninjalite/MainActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x22
    name = "ValidateKeyResultRunnable"
.end annotation


# instance fields
.field private final bA:Landroid/widget/Button;

.field private final bE:Landroid/widget/Button;

.field private final bG:Landroid/widget/Button;

.field private final dlg:Landroid/app/AlertDialog;

.field private final et:Landroid/widget/EditText;

.field private final r:I

.field private final this$0:Lcom/fakeninjalite/MainActivity;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const/16 v0, 0x7f

    invoke-static {v0}, LBeykix/protect/NativeUtil;->classesInit0(I)V

    return-void
.end method

.method constructor <init>(Lcom/fakeninjalite/MainActivity;Landroid/widget/EditText;Landroid/app/AlertDialog;Landroid/widget/Button;Landroid/widget/Button;Landroid/widget/Button;I)V
    .registers 8

    .line 605
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/fakeninjalite/MainActivity$ValidateKeyResultRunnable;->this$0:Lcom/fakeninjalite/MainActivity;

    .line 606
    iput-object p2, p0, Lcom/fakeninjalite/MainActivity$ValidateKeyResultRunnable;->et:Landroid/widget/EditText;

    iput-object p3, p0, Lcom/fakeninjalite/MainActivity$ValidateKeyResultRunnable;->dlg:Landroid/app/AlertDialog;

    .line 607
    iput-object p4, p0, Lcom/fakeninjalite/MainActivity$ValidateKeyResultRunnable;->bA:Landroid/widget/Button;

    iput-object p5, p0, Lcom/fakeninjalite/MainActivity$ValidateKeyResultRunnable;->bG:Landroid/widget/Button;

    iput-object p6, p0, Lcom/fakeninjalite/MainActivity$ValidateKeyResultRunnable;->bE:Landroid/widget/Button;

    iput p7, p0, Lcom/fakeninjalite/MainActivity$ValidateKeyResultRunnable;->r:I

    return-void
.end method

.method static native access$0(Lcom/fakeninjalite/MainActivity$ValidateKeyResultRunnable;)Lcom/fakeninjalite/MainActivity;
.end method


# virtual methods
.method public native run()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation
.end method
