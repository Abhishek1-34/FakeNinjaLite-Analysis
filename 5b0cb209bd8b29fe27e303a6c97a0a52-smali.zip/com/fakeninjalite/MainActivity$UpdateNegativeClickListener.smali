.class Lcom/fakeninjalite/MainActivity$UpdateNegativeClickListener;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/fakeninjalite/MainActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x22
    name = "UpdateNegativeClickListener"
.end annotation


# instance fields
.field private final mandatory:Z

.field private final this$0:Lcom/fakeninjalite/MainActivity;

.field private final url:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const/16 v0, 0x49

    invoke-static {v0}, LBeykix/protect/NativeUtil;->classesInit0(I)V

    return-void
.end method

.method constructor <init>(Lcom/fakeninjalite/MainActivity;Ljava/lang/String;Z)V
    .registers 4

    .line 547
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/fakeninjalite/MainActivity$UpdateNegativeClickListener;->this$0:Lcom/fakeninjalite/MainActivity;

    .line 548
    iput-object p2, p0, Lcom/fakeninjalite/MainActivity$UpdateNegativeClickListener;->url:Ljava/lang/String;

    iput-boolean p3, p0, Lcom/fakeninjalite/MainActivity$UpdateNegativeClickListener;->mandatory:Z

    return-void
.end method

.method static native access$0(Lcom/fakeninjalite/MainActivity$UpdateNegativeClickListener;)Lcom/fakeninjalite/MainActivity;
.end method


# virtual methods
.method public native onClick(Landroid/content/DialogInterface;I)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/DialogInterface;",
            "I)V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation
.end method
