.class Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener$TickRunnable;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x22
    name = "TickRunnable"
.end annotation


# instance fields
.field private final this$0:Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const/16 v0, 0x4b

    invoke-static {v0}, LBeykix/protect/NativeUtil;->classesInit0(I)V

    return-void
.end method

.method public constructor <init>(Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener;)V
    .registers 2

    .line 841
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener$TickRunnable;->this$0:Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener;

    return-void
.end method

.method static native access$0(Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener$TickRunnable;)Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener;
.end method


# virtual methods
.method public native run()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation
.end method
