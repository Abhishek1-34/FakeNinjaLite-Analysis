.class Lcom/fakeninjalite/FakeNinjaLite8$QueueFlushTask;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/fakeninjalite/FakeNinjaLite8;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x22
    name = "QueueFlushTask"
.end annotation


# instance fields
.field private final journey:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/fakeninjalite/FakeNinjaLite8$QueuedPkt;",
            ">;"
        }
    .end annotation
.end field

.field private final this$0:Lcom/fakeninjalite/FakeNinjaLite8;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const/16 v0, 0x54

    invoke-static {v0}, LBeykix/protect/NativeUtil;->classesInit0(I)V

    return-void
.end method

.method constructor <init>(Lcom/fakeninjalite/FakeNinjaLite8;Ljava/util/List;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/fakeninjalite/FakeNinjaLite8;",
            "Ljava/util/List<",
            "Lcom/fakeninjalite/FakeNinjaLite8$QueuedPkt;",
            ">;)V"
        }
    .end annotation

    .line 453
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/fakeninjalite/FakeNinjaLite8$QueueFlushTask;->this$0:Lcom/fakeninjalite/FakeNinjaLite8;

    iput-object p2, p0, Lcom/fakeninjalite/FakeNinjaLite8$QueueFlushTask;->journey:Ljava/util/List;

    return-void
.end method

.method static native access$0(Lcom/fakeninjalite/FakeNinjaLite8$QueueFlushTask;)Lcom/fakeninjalite/FakeNinjaLite8;
.end method


# virtual methods
.method public native run()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation
.end method
