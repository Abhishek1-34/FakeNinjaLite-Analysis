.class Lcom/fakeninjalite/FakeNinjaLite9$SetStatusRunnable;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/fakeninjalite/FakeNinjaLite9;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x22
    name = "SetStatusRunnable"
.end annotation


# instance fields
.field private final msg:Ljava/lang/String;

.field private final this$0:Lcom/fakeninjalite/FakeNinjaLite9;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const/16 v0, 0x36

    invoke-static {v0}, LBeykix/protect/NativeUtil;->classesInit0(I)V

    return-void
.end method

.method constructor <init>(Lcom/fakeninjalite/FakeNinjaLite9;Ljava/lang/String;)V
    .registers 3

    .line 170
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/fakeninjalite/FakeNinjaLite9$SetStatusRunnable;->this$0:Lcom/fakeninjalite/FakeNinjaLite9;

    iput-object p2, p0, Lcom/fakeninjalite/FakeNinjaLite9$SetStatusRunnable;->msg:Ljava/lang/String;

    return-void
.end method

.method static native access$0(Lcom/fakeninjalite/FakeNinjaLite9$SetStatusRunnable;)Lcom/fakeninjalite/FakeNinjaLite9;
.end method


# virtual methods
.method public native run()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation
.end method
