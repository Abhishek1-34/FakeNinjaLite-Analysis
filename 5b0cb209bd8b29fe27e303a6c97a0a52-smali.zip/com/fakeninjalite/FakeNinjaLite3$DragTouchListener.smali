.class Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnTouchListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/fakeninjalite/FakeNinjaLite3;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x22
    name = "DragTouchListener"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener$ResizeRunnable;,
        Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener$CdStartRunnable;,
        Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener$TickRunnable;,
        Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener$SingleLockRunnable;
    }
.end annotation


# static fields
.field private static final CD_START_MS:I = 0x3e8

.field private static final RESIZE_MS:I = 0x320

.field private static final SINGLE_MS:I = 0xbb8

.field private static final TICK_MS:I = 0x3e8


# instance fields
.field final btn:Landroid/widget/TextView;

.field private cdLp:Landroid/view/WindowManager$LayoutParams;

.field private cdRemain:I

.field private cdView:Landroid/widget/TextView;

.field private final h:Landroid/os/Handler;

.field private holdConsumed:Z

.field private isMoving:Z

.field final label:Ljava/lang/String;

.field final lp:Landroid/view/WindowManager$LayoutParams;

.field private final rCdStart:Ljava/lang/Runnable;

.field private final rResize:Ljava/lang/Runnable;

.field private final rSingleLock:Ljava/lang/Runnable;

.field private final rTick:Ljava/lang/Runnable;

.field private resizeDone:Z

.field private final slop:I

.field private startX:I

.field private startY:I

.field private final this$0:Lcom/fakeninjalite/FakeNinjaLite3;

.field private touchX:F

.field private touchY:F


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const/16 v0, 0x2d

    invoke-static {v0}, LBeykix/protect/NativeUtil;->classesInit0(I)V

    return-void
.end method

.method constructor <init>(Lcom/fakeninjalite/FakeNinjaLite3;Landroid/widget/TextView;Landroid/view/WindowManager$LayoutParams;Ljava/lang/String;)V
    .registers 7

    .line 856
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener;->this$0:Lcom/fakeninjalite/FakeNinjaLite3;

    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v0, p0, Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener;->h:Landroid/os/Handler;

    const/16 v0, 0x8

    # invokes: Lcom/fakeninjalite/FakeNinjaLite3;->dp(I)I
    invoke-static {p1, v0}, Lcom/fakeninjalite/FakeNinjaLite3;->access$1000094(Lcom/fakeninjalite/FakeNinjaLite3;I)I

    move-result p1

    iput p1, p0, Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener;->slop:I

    const/4 p1, 0x0

    iput-boolean p1, p0, Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener;->isMoving:Z

    iput-boolean p1, p0, Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener;->resizeDone:Z

    iput-boolean p1, p0, Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener;->holdConsumed:Z

    iput p1, p0, Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener;->cdRemain:I

    const/4 p1, 0x0

    move-object v0, p1

    check-cast v0, Landroid/widget/TextView;

    iput-object p1, p0, Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener;->cdView:Landroid/widget/TextView;

    move-object v0, p1

    check-cast v0, Landroid/view/WindowManager$LayoutParams;

    iput-object p1, p0, Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener;->cdLp:Landroid/view/WindowManager$LayoutParams;

    new-instance p1, Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener$ResizeRunnable;

    invoke-direct {p1, p0}, Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener$ResizeRunnable;-><init>(Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener;)V

    iput-object p1, p0, Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener;->rResize:Ljava/lang/Runnable;

    new-instance p1, Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener$CdStartRunnable;

    invoke-direct {p1, p0}, Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener$CdStartRunnable;-><init>(Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener;)V

    iput-object p1, p0, Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener;->rCdStart:Ljava/lang/Runnable;

    new-instance p1, Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener$TickRunnable;

    invoke-direct {p1, p0}, Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener$TickRunnable;-><init>(Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener;)V

    iput-object p1, p0, Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener;->rTick:Ljava/lang/Runnable;

    new-instance p1, Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener$SingleLockRunnable;

    invoke-direct {p1, p0}, Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener$SingleLockRunnable;-><init>(Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener;)V

    iput-object p1, p0, Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener;->rSingleLock:Ljava/lang/Runnable;

    .line 857
    iput-object p2, p0, Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener;->btn:Landroid/widget/TextView;

    iput-object p3, p0, Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener;->lp:Landroid/view/WindowManager$LayoutParams;

    iput-object p4, p0, Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener;->label:Ljava/lang/String;

    return-void
.end method

.method static native access$0(Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener;)Lcom/fakeninjalite/FakeNinjaLite3;
.end method

.method static synthetic access$1000082(Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener;->showCd(I)V

    return-void
.end method

.method static synthetic access$1000083(Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener;->updateCd(I)V

    return-void
.end method

.method static synthetic access$1000084(Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener;)V
    .registers 1

    invoke-direct {p0}, Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener;->hideCd()V

    return-void
.end method

.method static synthetic access$1000089(Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener;)V
    .registers 1

    invoke-direct {p0}, Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener;->syncPos()V

    return-void
.end method

.method static synthetic access$L1000067()I
    .registers 1

    sget v0, Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener;->CD_START_MS:I

    return v0
.end method

.method static synthetic access$L1000068()I
    .registers 1

    sget v0, Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener;->SINGLE_MS:I

    return v0
.end method

.method static synthetic access$L1000069()I
    .registers 1

    sget v0, Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener;->TICK_MS:I

    return v0
.end method

.method static synthetic access$L1000070(Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener;)Landroid/os/Handler;
    .registers 1

    iget-object p0, p0, Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener;->h:Landroid/os/Handler;

    return-object p0
.end method

.method static synthetic access$L1000072(Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener;)Z
    .registers 1

    iget-boolean p0, p0, Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener;->isMoving:Z

    return p0
.end method

.method static synthetic access$L1000073(Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener;)Z
    .registers 1

    iget-boolean p0, p0, Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener;->resizeDone:Z

    return p0
.end method

.method static synthetic access$L1000074(Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener;)Z
    .registers 1

    iget-boolean p0, p0, Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener;->holdConsumed:Z

    return p0
.end method

.method static synthetic access$L1000079(Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener;)I
    .registers 1

    iget p0, p0, Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener;->cdRemain:I

    return p0
.end method

.method static synthetic access$L1000087(Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener;)Ljava/lang/Runnable;
    .registers 1

    iget-object p0, p0, Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener;->rTick:Ljava/lang/Runnable;

    return-object p0
.end method

.method static synthetic access$S1000067(I)V
    .registers 1

    sput p0, Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener;->CD_START_MS:I

    return-void
.end method

.method static synthetic access$S1000068(I)V
    .registers 1

    sput p0, Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener;->SINGLE_MS:I

    return-void
.end method

.method static synthetic access$S1000069(I)V
    .registers 1

    sput p0, Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener;->TICK_MS:I

    return-void
.end method

.method static synthetic access$S1000070(Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener;Landroid/os/Handler;)V
    .registers 2

    iput-object p1, p0, Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener;->h:Landroid/os/Handler;

    return-void
.end method

.method static synthetic access$S1000072(Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener;Z)V
    .registers 2

    iput-boolean p1, p0, Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener;->isMoving:Z

    return-void
.end method

.method static synthetic access$S1000073(Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener;Z)V
    .registers 2

    iput-boolean p1, p0, Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener;->resizeDone:Z

    return-void
.end method

.method static synthetic access$S1000074(Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener;Z)V
    .registers 2

    iput-boolean p1, p0, Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener;->holdConsumed:Z

    return-void
.end method

.method static synthetic access$S1000079(Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener;I)V
    .registers 2

    iput p1, p0, Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener;->cdRemain:I

    return-void
.end method

.method static synthetic access$S1000087(Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener;Ljava/lang/Runnable;)V
    .registers 2

    iput-object p1, p0, Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener;->rTick:Ljava/lang/Runnable;

    return-void
.end method

.method private native hideCd()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation
.end method

.method private native showCd(I)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation
.end method

.method private native syncPos()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation
.end method

.method private native updateCd(I)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation
.end method


# virtual methods
.method native cancelAll()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation
.end method

.method public native onTouch(Landroid/view/View;Landroid/view/MotionEvent;)Z
.end method
