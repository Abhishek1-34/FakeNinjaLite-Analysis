.class Lcom/fakeninjalite/MainActivity$ConfigFetchResultRunnable;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/fakeninjalite/MainActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x22
    name = "ConfigFetchResultRunnable"
.end annotation


# instance fields
.field private final autoClose:Z

.field private final autoCloseMessage:Ljava/lang/String;

.field private final expDate:Ljava/lang/String;

.field private final msg:Ljava/lang/String;

.field private final state:Ljava/lang/String;

.field private final this$0:Lcom/fakeninjalite/MainActivity;

.field private final updateMandatory:Z

.field private final updateMsg:Ljava/lang/String;

.field private final updateTitle:Ljava/lang/String;

.field private final updateUrl:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const/16 v0, 0x51

    invoke-static {v0}, LBeykix/protect/NativeUtil;->classesInit0(I)V

    return-void
.end method

.method constructor <init>(Lcom/fakeninjalite/MainActivity;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZZLjava/lang/String;)V
    .registers 11

    .line 683
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/fakeninjalite/MainActivity$ConfigFetchResultRunnable;->this$0:Lcom/fakeninjalite/MainActivity;

    .line 684
    iput-object p2, p0, Lcom/fakeninjalite/MainActivity$ConfigFetchResultRunnable;->state:Ljava/lang/String;

    iput-object p3, p0, Lcom/fakeninjalite/MainActivity$ConfigFetchResultRunnable;->msg:Ljava/lang/String;

    iput-object p4, p0, Lcom/fakeninjalite/MainActivity$ConfigFetchResultRunnable;->expDate:Ljava/lang/String;

    .line 685
    iput-object p5, p0, Lcom/fakeninjalite/MainActivity$ConfigFetchResultRunnable;->updateTitle:Ljava/lang/String;

    iput-object p6, p0, Lcom/fakeninjalite/MainActivity$ConfigFetchResultRunnable;->updateMsg:Ljava/lang/String;

    .line 686
    iput-object p7, p0, Lcom/fakeninjalite/MainActivity$ConfigFetchResultRunnable;->updateUrl:Ljava/lang/String;

    iput-boolean p8, p0, Lcom/fakeninjalite/MainActivity$ConfigFetchResultRunnable;->updateMandatory:Z

    .line 687
    iput-boolean p9, p0, Lcom/fakeninjalite/MainActivity$ConfigFetchResultRunnable;->autoClose:Z

    iput-object p10, p0, Lcom/fakeninjalite/MainActivity$ConfigFetchResultRunnable;->autoCloseMessage:Ljava/lang/String;

    return-void
.end method

.method static native access$0(Lcom/fakeninjalite/MainActivity$ConfigFetchResultRunnable;)Lcom/fakeninjalite/MainActivity;
.end method


# virtual methods
.method public native run()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation
.end method
