.class Lcom/fakeninjalite/FakeNinjaLite9$100000000;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnLongClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/fakeninjalite/FakeNinjaLite9;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000000"
.end annotation


# instance fields
.field private final this$0:Lcom/fakeninjalite/FakeNinjaLite9;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const/16 v0, 0x6c

    invoke-static {v0}, LBeykix/protect/NativeUtil;->classesInit0(I)V

    return-void
.end method

.method constructor <init>(Lcom/fakeninjalite/FakeNinjaLite9;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/fakeninjalite/FakeNinjaLite9$100000000;->this$0:Lcom/fakeninjalite/FakeNinjaLite9;

    return-void
.end method

.method static native access$0(Lcom/fakeninjalite/FakeNinjaLite9$100000000;)Lcom/fakeninjalite/FakeNinjaLite9;
.end method


# virtual methods
.method public native onLongClick(Landroid/view/View;)Z
    .annotation runtime Ljava/lang/Override;
    .end annotation
.end method
