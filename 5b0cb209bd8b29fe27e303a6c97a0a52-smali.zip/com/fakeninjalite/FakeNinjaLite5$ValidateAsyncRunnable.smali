.class Lcom/fakeninjalite/FakeNinjaLite5$ValidateAsyncRunnable;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/fakeninjalite/FakeNinjaLite5;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2a
    name = "ValidateAsyncRunnable"
.end annotation


# instance fields
.field private final cb:Lcom/fakeninjalite/FakeNinjaLite5$ValidateCallback;

.field private final ctx:Landroid/content/Context;

.field private final devId:Ljava/lang/String;

.field private final key:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const/16 v0, 0x55

    invoke-static {v0}, LBeykix/protect/NativeUtil;->classesInit0(I)V

    return-void
.end method

.method constructor <init>(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Lcom/fakeninjalite/FakeNinjaLite5$ValidateCallback;)V
    .registers 5

    .line 489
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 490
    iput-object p1, p0, Lcom/fakeninjalite/FakeNinjaLite5$ValidateAsyncRunnable;->ctx:Landroid/content/Context;

    .line 491
    iput-object p2, p0, Lcom/fakeninjalite/FakeNinjaLite5$ValidateAsyncRunnable;->key:Ljava/lang/String;

    .line 492
    iput-object p3, p0, Lcom/fakeninjalite/FakeNinjaLite5$ValidateAsyncRunnable;->devId:Ljava/lang/String;

    .line 493
    iput-object p4, p0, Lcom/fakeninjalite/FakeNinjaLite5$ValidateAsyncRunnable;->cb:Lcom/fakeninjalite/FakeNinjaLite5$ValidateCallback;

    return-void
.end method


# virtual methods
.method public native run()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation
.end method
