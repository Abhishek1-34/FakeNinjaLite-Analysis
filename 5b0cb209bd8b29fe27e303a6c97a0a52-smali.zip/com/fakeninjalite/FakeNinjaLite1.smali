.class public Lcom/fakeninjalite/FakeNinjaLite1;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/fakeninjalite/FakeNinjaLite1$ConfigCallback;,
        Lcom/fakeninjalite/FakeNinjaLite1$ExpiryCallback;,
        Lcom/fakeninjalite/FakeNinjaLite1$FetchConfigRunnable;,
        Lcom/fakeninjalite/FakeNinjaLite1$CheckExpiryRunnable;
    }
.end annotation


# static fields
.field private static final CONFIG_URLS:[Ljava/lang/String;

.field private static final TIME_HOSTS:[Ljava/lang/String;

.field private static final _K1:[I

.field private static final _K2:[I

.field private static final _U0:[I

.field private static final _U1:[I

.field private static final _U2:[I


# direct methods
.method static constructor <clinit>()V
    .registers 3

    const/16 v0, 0x43

    invoke-static {v0}, LBeykix/protect/NativeUtil;->classesInit0(I)V

    const/16 v0, 0x40

    new-array v1, v0, [I

    fill-array-data v1, :array_54

    sput-object v1, Lcom/fakeninjalite/FakeNinjaLite1;->_K1:[I

    new-array v0, v0, [I

    fill-array-data v0, :array_d8

    sput-object v0, Lcom/fakeninjalite/FakeNinjaLite1;->_K2:[I

    const/16 v0, 0x1b

    new-array v0, v0, [I

    fill-array-data v0, :array_15c

    sput-object v0, Lcom/fakeninjalite/FakeNinjaLite1;->_U0:[I

    const/16 v0, 0x25

    new-array v0, v0, [I

    fill-array-data v0, :array_196

    sput-object v0, Lcom/fakeninjalite/FakeNinjaLite1;->_U1:[I

    const/16 v1, 0x56

    new-array v1, v1, [I

    fill-array-data v1, :array_1e4

    sput-object v1, Lcom/fakeninjalite/FakeNinjaLite1;->_U2:[I

    invoke-static {v0}, Lcom/fakeninjalite/FakeNinjaLite1;->_du([I)Ljava/lang/String;

    move-result-object v0

    invoke-static {v1}, Lcom/fakeninjalite/FakeNinjaLite1;->_du([I)Ljava/lang/String;

    move-result-object v1

    filled-new-array {v0, v1}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/fakeninjalite/FakeNinjaLite1;->CONFIG_URLS:[Ljava/lang/String;

    const-string v0, "3B1B2422375B65490E032B323E175E171C11423B193B"

    invoke-static {v0}, Lobfuse/NPStringFog;->decode(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "https://microsoft.com"

    const-string v2, "3B1B2422375B65490A002B2036141C150119"

    invoke-static {v2}, Lobfuse/NPStringFog;->decode(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    filled-new-array {v2, v0, v1}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/fakeninjalite/FakeNinjaLite1;->TIME_HOSTS:[Ljava/lang/String;

    return-void

    nop

    :array_54
    .array-data 4
        0xbd
        0x92
        0xea
        0x82
        0x9c
        0x69
        0x2e
        0x85
        0x1f
        0xc4
        0x75
        0x3
        0xdb
        0x8f
        0xd2
        0xaf
        0xe
        0x40
        0xe4
        0x4c
        0x59
        0xf9
        0xcd
        0xab
        0xc0
        0x74
        0xf3
        0x9f
        0x60
        0x27
        0xff
        0x37
        0x57
        0xbc
        0x2b
        0x32
        0xfc
        0x4f
        0x3a
        0x62
        0x58
        0x8a
        0xc6
        0x76
        0xa4
        0x56
        0xe1
        0x22
        0xf4
        0x12
        0x63
        0x30
        0xb7
        0xfe
        0xbd
        0x31
        0x3c
        0x0
        0x7e
        0x2
        0x3
        0x5d
        0xf5
        0x7f
    .end array-data

    :array_d8
    .array-data 4
        0x58
        0x41
        0x6f
        0x8a
        0xe2
        0x11
        0xd3
        0x94
        0xbe
        0x98
        0x69
        0xcb
        0x1e
        0x3c
        0x58
        0xb
        0x11
        0xe5
        0x2e
        0x16
        0x43
        0x20
        0x12
        0x5d
        0x5e
        0x58
        0x85
        0x7d
        0x3
        0x9b
        0x17
        0xa1
        0x89
        0xd9
        0x43
        0x4f
        0xb4
        0x90
        0x5
        0xbc
        0x3a
        0xef
        0x3c
        0x9f
        0x95
        0x7c
        0x8f
        0xb8
        0xdf
        0xf4
        0xb4
        0xed
        0x23
        0xd9
        0xa1
        0xba
        0x25
        0xfb
        0xd6
        0x7b
        0x92
        0xe4
        0xbb
        0xd0
    .end array-data

    :array_15c
    .array-data 4
        0x8d
        0xa6
        0xf3
        0x7b
        0x9
        0x47
        0xd4
        0x39
        0xcf
        0x34
        0x7d
        0xa6
        0xa5
        0xdf
        0xe3
        0x85
        0x61
        0xd1
        0xb3
        0x26
        0x79
        0xa9
        0xab
        0xcf
        0xe9
        0x47
        0xb
    .end array-data

    :array_196
    .array-data 4
        0x8d
        0xa6
        0xf3
        0x7b
        0x9
        0x47
        0xd4
        0x39
        0xcf
        0x34
        0x7d
        0xa6
        0xa5
        0xdf
        0xe3
        0x85
        0x61
        0xd1
        0xb3
        0x26
        0x79
        0xa9
        0xab
        0xcf
        0xe9
        0x47
        0xb
        0xd6
        0x39
        0xef
        0xba
        0xbf
        0xd0
        0x2e
        0x39
        0x31
        0x2
    .end array-data

    :array_1e4
    .array-data 4
        0x8d
        0xa6
        0xf3
        0x7b
        0x9
        0x47
        0xd4
        0x39
        0xdb
        0x34
        0x61
        0xed
        0xae
        0xd7
        0xf0
        0xc3
        0x7a
        0xd6
        0xad
        0x3a
        0x6b
        0xbe
        0xaa
        0x8e
        0xe8
        0x41
        0x9
        0x97
        0xb
        0x8f
        0x95
        0xe6
        0x93
        0x6b
        0x2c
        0x3f
        0x7
        0x9f
        0x75
        0x98
        0x2d
        0x3e
        0xb5
        0xa0
        0x72
        0x75
        0x2e
        0x9a
        0x7d
        0xb6
        0x8e
        0x8b
        0xcc
        0x73
        0x4d
        0xce
        0x44
        0xa0
        0xfd
        0x30
        0xc3
        0xaa
        0x17
        0xf9
        0xd1
        0xfa
        0xb2
        0x29
        0x14
        0x54
        0xd4
        0x79
        0x84
        0x74
        0x3f
        0xed
        0xa6
        0xb8
        0x8a
        0xa7
        0x79
        0xda
        0xf2
        0x7a
        0x21
        0xe2
    .end array-data
.end method

.method public constructor <init>()V
    .registers 1

    .line 228
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static native _du([I)Ljava/lang/String;
.end method

.method static synthetic access$1000005([I)Ljava/lang/String;
    .registers 1

    invoke-static {p0}, Lcom/fakeninjalite/FakeNinjaLite1;->_du([I)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method static synthetic access$L1000002()[I
    .registers 1

    sget-object v0, Lcom/fakeninjalite/FakeNinjaLite1;->_U0:[I

    return-object v0
.end method

.method static synthetic access$L1000006()[Ljava/lang/String;
    .registers 1

    sget-object v0, Lcom/fakeninjalite/FakeNinjaLite1;->CONFIG_URLS:[Ljava/lang/String;

    return-object v0
.end method

.method static synthetic access$L1000007()[Ljava/lang/String;
    .registers 1

    sget-object v0, Lcom/fakeninjalite/FakeNinjaLite1;->TIME_HOSTS:[Ljava/lang/String;

    return-object v0
.end method

.method static synthetic access$S1000002([I)V
    .registers 1

    sput-object p0, Lcom/fakeninjalite/FakeNinjaLite1;->_U0:[I

    return-void
.end method

.method static synthetic access$S1000006([Ljava/lang/String;)V
    .registers 1

    sput-object p0, Lcom/fakeninjalite/FakeNinjaLite1;->CONFIG_URLS:[Ljava/lang/String;

    return-void
.end method

.method static synthetic access$S1000007([Ljava/lang/String;)V
    .registers 1

    sput-object p0, Lcom/fakeninjalite/FakeNinjaLite1;->TIME_HOSTS:[Ljava/lang/String;

    return-void
.end method

.method public static native checkExpiry(Ljava/lang/String;Lcom/fakeninjalite/FakeNinjaLite1$ExpiryCallback;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Lcom/fakeninjalite/FakeNinjaLite1$ExpiryCallback;",
            ")V"
        }
    .end annotation
.end method

.method public static native fetchConfig(Landroid/content/Context;Lcom/fakeninjalite/FakeNinjaLite1$ConfigCallback;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Lcom/fakeninjalite/FakeNinjaLite1$ConfigCallback;",
            ")V"
        }
    .end annotation
.end method

.method public static native formatDate(Ljava/lang/String;)Ljava/lang/String;
.end method
