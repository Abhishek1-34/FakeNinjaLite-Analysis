.class public interface abstract Lcom/fakeninjalite/FakeNinjaLite5$ValidateCallback;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/fakeninjalite/FakeNinjaLite5;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x209
    name = "ValidateCallback"
.end annotation


# virtual methods
.method public abstract onResult(IJ)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(IJ)V"
        }
    .end annotation
.end method
