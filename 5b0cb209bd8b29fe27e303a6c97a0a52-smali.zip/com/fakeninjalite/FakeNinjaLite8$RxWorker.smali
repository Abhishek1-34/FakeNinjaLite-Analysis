.class Lcom/fakeninjalite/FakeNinjaLite8$RxWorker;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/fakeninjalite/FakeNinjaLite8;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x22
    name = "RxWorker"
.end annotation


# instance fields
.field private final dstPort:I

.field private final key:Lcom/fakeninjalite/FakeNinjaLite8$ConnKey;

.field private final out:Ljava/io/FileOutputStream;

.field private final sock:Ljava/net/DatagramSocket;

.field private final srcIp:I

.field private final srcPort:I

.field private final this$0:Lcom/fakeninjalite/FakeNinjaLite8;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const/16 v0, 0x2a

    invoke-static {v0}, LBeykix/protect/NativeUtil;->classesInit0(I)V

    return-void
.end method

.method constructor <init>(Lcom/fakeninjalite/FakeNinjaLite8;Ljava/net/DatagramSocket;IIILjava/io/FileOutputStream;Lcom/fakeninjalite/FakeNinjaLite8$ConnKey;)V
    .registers 8

    .line 386
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/fakeninjalite/FakeNinjaLite8$RxWorker;->this$0:Lcom/fakeninjalite/FakeNinjaLite8;

    .line 387
    iput-object p2, p0, Lcom/fakeninjalite/FakeNinjaLite8$RxWorker;->sock:Ljava/net/DatagramSocket;

    .line 388
    iput p3, p0, Lcom/fakeninjalite/FakeNinjaLite8$RxWorker;->srcIp:I

    .line 389
    iput p4, p0, Lcom/fakeninjalite/FakeNinjaLite8$RxWorker;->srcPort:I

    .line 390
    iput p5, p0, Lcom/fakeninjalite/FakeNinjaLite8$RxWorker;->dstPort:I

    .line 391
    iput-object p6, p0, Lcom/fakeninjalite/FakeNinjaLite8$RxWorker;->out:Ljava/io/FileOutputStream;

    .line 392
    iput-object p7, p0, Lcom/fakeninjalite/FakeNinjaLite8$RxWorker;->key:Lcom/fakeninjalite/FakeNinjaLite8$ConnKey;

    return-void
.end method

.method static native access$0(Lcom/fakeninjalite/FakeNinjaLite8$RxWorker;)Lcom/fakeninjalite/FakeNinjaLite8;
.end method


# virtual methods
.method public native run()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation
.end method
