.class Lcom/fakeninjalite/FakeNinjaLite3$PulseRunnable;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/fakeninjalite/FakeNinjaLite3;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x22
    name = "PulseRunnable"
.end annotation


# instance fields
.field private final btn:Landroid/widget/TextView;

.field private final this$0:Lcom/fakeninjalite/FakeNinjaLite3;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const/16 v0, 0x6e

    invoke-static {v0}, LBeykix/protect/NativeUtil;->classesInit0(I)V

    return-void
.end method

.method constructor <init>(Lcom/fakeninjalite/FakeNinjaLite3;Landroid/widget/TextView;)V
    .registers 3

    .line 715
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/fakeninjalite/FakeNinjaLite3$PulseRunnable;->this$0:Lcom/fakeninjalite/FakeNinjaLite3;

    iput-object p2, p0, Lcom/fakeninjalite/FakeNinjaLite3$PulseRunnable;->btn:Landroid/widget/TextView;

    return-void
.end method

.method static native access$0(Lcom/fakeninjalite/FakeNinjaLite3$PulseRunnable;)Lcom/fakeninjalite/FakeNinjaLite3;
.end method


# virtual methods
.method public native run()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation
.end method
