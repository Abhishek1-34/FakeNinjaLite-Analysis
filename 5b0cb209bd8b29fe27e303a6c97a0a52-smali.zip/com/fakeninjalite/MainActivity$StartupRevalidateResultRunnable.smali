.class Lcom/fakeninjalite/MainActivity$StartupRevalidateResultRunnable;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/fakeninjalite/MainActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x22
    name = "StartupRevalidateResultRunnable"
.end annotation


# instance fields
.field private final r:I

.field private final this$0:Lcom/fakeninjalite/MainActivity;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const/16 v0, 0x7d

    invoke-static {v0}, LBeykix/protect/NativeUtil;->classesInit0(I)V

    return-void
.end method

.method constructor <init>(Lcom/fakeninjalite/MainActivity;I)V
    .registers 3

    .line 1283
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/fakeninjalite/MainActivity$StartupRevalidateResultRunnable;->this$0:Lcom/fakeninjalite/MainActivity;

    iput p2, p0, Lcom/fakeninjalite/MainActivity$StartupRevalidateResultRunnable;->r:I

    return-void
.end method

.method static native access$0(Lcom/fakeninjalite/MainActivity$StartupRevalidateResultRunnable;)Lcom/fakeninjalite/MainActivity;
.end method


# virtual methods
.method public native run()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation
.end method
