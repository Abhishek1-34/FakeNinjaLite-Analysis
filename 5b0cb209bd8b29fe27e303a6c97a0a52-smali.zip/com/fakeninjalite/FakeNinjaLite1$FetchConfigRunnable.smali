.class Lcom/fakeninjalite/FakeNinjaLite1$FetchConfigRunnable;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/fakeninjalite/FakeNinjaLite1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2a
    name = "FetchConfigRunnable"
.end annotation


# instance fields
.field private final cb:Lcom/fakeninjalite/FakeNinjaLite1$ConfigCallback;

.field private final ctx:Landroid/content/Context;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const/16 v0, 0x16

    invoke-static {v0}, LBeykix/protect/NativeUtil;->classesInit0(I)V

    return-void
.end method

.method constructor <init>(Landroid/content/Context;Lcom/fakeninjalite/FakeNinjaLite1$ConfigCallback;)V
    .registers 3

    .line 64
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 65
    iput-object p1, p0, Lcom/fakeninjalite/FakeNinjaLite1$FetchConfigRunnable;->ctx:Landroid/content/Context;

    .line 66
    iput-object p2, p0, Lcom/fakeninjalite/FakeNinjaLite1$FetchConfigRunnable;->cb:Lcom/fakeninjalite/FakeNinjaLite1$ConfigCallback;

    return-void
.end method


# virtual methods
.method public native run()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation
.end method
