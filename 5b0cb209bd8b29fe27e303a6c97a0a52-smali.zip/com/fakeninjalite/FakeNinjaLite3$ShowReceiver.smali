.class Lcom/fakeninjalite/FakeNinjaLite3$ShowReceiver;
.super Landroid/content/BroadcastReceiver;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/fakeninjalite/FakeNinjaLite3;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x22
    name = "ShowReceiver"
.end annotation


# instance fields
.field private final this$0:Lcom/fakeninjalite/FakeNinjaLite3;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const/16 v0, 0x31

    invoke-static {v0}, LBeykix/protect/NativeUtil;->classesInit0(I)V

    return-void
.end method

.method public constructor <init>(Lcom/fakeninjalite/FakeNinjaLite3;)V
    .registers 2

    .line 658
    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    iput-object p1, p0, Lcom/fakeninjalite/FakeNinjaLite3$ShowReceiver;->this$0:Lcom/fakeninjalite/FakeNinjaLite3;

    return-void
.end method

.method static native access$0(Lcom/fakeninjalite/FakeNinjaLite3$ShowReceiver;)Lcom/fakeninjalite/FakeNinjaLite3;
.end method


# virtual methods
.method public native onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Landroid/content/Intent;",
            ")V"
        }
    .end annotation
.end method
