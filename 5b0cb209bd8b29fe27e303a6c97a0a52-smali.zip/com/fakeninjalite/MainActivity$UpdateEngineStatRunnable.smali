.class Lcom/fakeninjalite/MainActivity$UpdateEngineStatRunnable;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/fakeninjalite/MainActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x22
    name = "UpdateEngineStatRunnable"
.end annotation


# instance fields
.field private final this$0:Lcom/fakeninjalite/MainActivity;

.field private final vpnActive:Z


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const/16 v0, 0x56

    invoke-static {v0}, LBeykix/protect/NativeUtil;->classesInit0(I)V

    return-void
.end method

.method constructor <init>(Lcom/fakeninjalite/MainActivity;Z)V
    .registers 3

    .line 491
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/fakeninjalite/MainActivity$UpdateEngineStatRunnable;->this$0:Lcom/fakeninjalite/MainActivity;

    iput-boolean p2, p0, Lcom/fakeninjalite/MainActivity$UpdateEngineStatRunnable;->vpnActive:Z

    return-void
.end method

.method static native access$0(Lcom/fakeninjalite/MainActivity$UpdateEngineStatRunnable;)Lcom/fakeninjalite/MainActivity;
.end method


# virtual methods
.method public native run()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation
.end method
