.class Lcom/fakeninjalite/MainActivity$StepTeleTextWatcher;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/text/TextWatcher;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/fakeninjalite/MainActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x22
    name = "StepTeleTextWatcher"
.end annotation


# instance fields
.field private final this$0:Lcom/fakeninjalite/MainActivity;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const/16 v0, 0x12

    invoke-static {v0}, LBeykix/protect/NativeUtil;->classesInit0(I)V

    return-void
.end method

.method public constructor <init>(Lcom/fakeninjalite/MainActivity;)V
    .registers 2

    .line 367
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/fakeninjalite/MainActivity$StepTeleTextWatcher;->this$0:Lcom/fakeninjalite/MainActivity;

    return-void
.end method

.method static native access$0(Lcom/fakeninjalite/MainActivity$StepTeleTextWatcher;)Lcom/fakeninjalite/MainActivity;
.end method


# virtual methods
.method public native afterTextChanged(Landroid/text/Editable;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/text/Editable;",
            ")V"
        }
    .end annotation
.end method

.method public native beforeTextChanged(Ljava/lang/CharSequence;III)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/CharSequence;",
            "III)V"
        }
    .end annotation
.end method

.method public native onTextChanged(Ljava/lang/CharSequence;III)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/CharSequence;",
            "III)V"
        }
    .end annotation
.end method
