.class public final Lcom/fakeninjalite/R$string;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/fakeninjalite/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x39
    name = "string"
.end annotation


# static fields
.field public static final app_name:I = 0x7f040000

.field public static final engine_off:I = 0x7f040002

.field public static final engine_on:I = 0x7f040001

.field public static final vpn_off:I = 0x7f040004

.field public static final vpn_on:I = 0x7f040003


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 82
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
