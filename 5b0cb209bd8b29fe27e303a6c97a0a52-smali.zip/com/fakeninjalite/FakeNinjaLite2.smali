.class public Lcom/fakeninjalite/FakeNinjaLite2;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/fakeninjalite/FakeNinjaLite2$Callbacks;,
        Lcom/fakeninjalite/FakeNinjaLite2$100000000;,
        Lcom/fakeninjalite/FakeNinjaLite2$100000002;,
        Lcom/fakeninjalite/FakeNinjaLite2$100000003;,
        Lcom/fakeninjalite/FakeNinjaLite2$100000005;,
        Lcom/fakeninjalite/FakeNinjaLite2$100000006;,
        Lcom/fakeninjalite/FakeNinjaLite2$100000008;,
        Lcom/fakeninjalite/FakeNinjaLite2$100000009;,
        Lcom/fakeninjalite/FakeNinjaLite2$100000011;,
        Lcom/fakeninjalite/FakeNinjaLite2$100000012;,
        Lcom/fakeninjalite/FakeNinjaLite2$100000014;,
        Lcom/fakeninjalite/FakeNinjaLite2$100000015;
    }
.end annotation


# static fields
.field private static final ANCHOR_B_DELAY_MS:J = 0x4b0L

.field private static final ANCHOR_C_DELAY_MS:J = 0x960L

.field private static final TAG:Ljava/lang/String; = "FNL2"

.field private static final WATCH_INTERVAL_MS:J = 0x1f40L

.field private static final acFiredA:Ljava/util/concurrent/atomic/AtomicBoolean;

.field private static final acFiredB:Ljava/util/concurrent/atomic/AtomicBoolean;

.field private static final acFiredC:Ljava/util/concurrent/atomic/AtomicBoolean;

.field private static final acFiredD:Ljava/util/concurrent/atomic/AtomicBoolean;

.field private static actRef:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference<",
            "Landroid/app/Activity;",
            ">;"
        }
    .end annotation
.end field

.field private static final autoCloseActive:Ljava/util/concurrent/atomic/AtomicBoolean;

.field private static cbRef:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference<",
            "Lcom/fakeninjalite/FakeNinjaLite2$Callbacks;",
            ">;"
        }
    .end annotation
.end field

.field private static final keyFired:Ljava/util/concurrent/atomic/AtomicBoolean;

.field private static final keyGuardActive:Ljava/util/concurrent/atomic/AtomicBoolean;

.field private static final killFired:Ljava/util/concurrent/atomic/AtomicBoolean;

.field private static final killGuardActive:Ljava/util/concurrent/atomic/AtomicBoolean;

.field private static final mainH:Landroid/os/Handler;

.field private static final noNetActive:Ljava/util/concurrent/atomic/AtomicBoolean;

.field private static final noNetFired:Ljava/util/concurrent/atomic/AtomicBoolean;

.field private static volatile savedAutoCloseMsg:Ljava/lang/String;

.field private static volatile savedKeyReason:Ljava/lang/String;

.field private static volatile savedKillMsg:Ljava/lang/String;

.field private static volatile savedUpdateMandatory:Z

.field private static volatile savedUpdateMsg:Ljava/lang/String;

.field private static volatile savedUpdateTitle:Ljava/lang/String;

.field private static volatile savedUpdateUrl:Ljava/lang/String;

.field private static final updateFired:Ljava/util/concurrent/atomic/AtomicBoolean;

.field private static final watchH:Landroid/os/Handler;

.field private static watchdogR:Ljava/lang/Runnable;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    const/16 v0, 0x42

    invoke-static {v0}, LBeykix/protect/NativeUtil;->classesInit0(I)V

    const/4 v0, 0x0

    move-object v1, v0

    check-cast v1, Ljava/lang/ref/WeakReference;

    sput-object v0, Lcom/fakeninjalite/FakeNinjaLite2;->actRef:Ljava/lang/ref/WeakReference;

    sput-object v0, Lcom/fakeninjalite/FakeNinjaLite2;->cbRef:Ljava/lang/ref/WeakReference;

    new-instance v1, Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v2, 0x0

    invoke-direct {v1, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    sput-object v1, Lcom/fakeninjalite/FakeNinjaLite2;->keyGuardActive:Ljava/util/concurrent/atomic/AtomicBoolean;

    new-instance v1, Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-direct {v1, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    sput-object v1, Lcom/fakeninjalite/FakeNinjaLite2;->killGuardActive:Ljava/util/concurrent/atomic/AtomicBoolean;

    new-instance v1, Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-direct {v1, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    sput-object v1, Lcom/fakeninjalite/FakeNinjaLite2;->noNetActive:Ljava/util/concurrent/atomic/AtomicBoolean;

    new-instance v1, Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-direct {v1, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    sput-object v1, Lcom/fakeninjalite/FakeNinjaLite2;->autoCloseActive:Ljava/util/concurrent/atomic/AtomicBoolean;

    new-instance v1, Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-direct {v1, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    sput-object v1, Lcom/fakeninjalite/FakeNinjaLite2;->acFiredA:Ljava/util/concurrent/atomic/AtomicBoolean;

    new-instance v1, Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-direct {v1, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    sput-object v1, Lcom/fakeninjalite/FakeNinjaLite2;->acFiredB:Ljava/util/concurrent/atomic/AtomicBoolean;

    new-instance v1, Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-direct {v1, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    sput-object v1, Lcom/fakeninjalite/FakeNinjaLite2;->acFiredC:Ljava/util/concurrent/atomic/AtomicBoolean;

    new-instance v1, Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-direct {v1, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    sput-object v1, Lcom/fakeninjalite/FakeNinjaLite2;->acFiredD:Ljava/util/concurrent/atomic/AtomicBoolean;

    move-object v1, v0

    check-cast v1, Ljava/lang/String;

    sput-object v0, Lcom/fakeninjalite/FakeNinjaLite2;->savedAutoCloseMsg:Ljava/lang/String;

    new-instance v1, Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-direct {v1, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    sput-object v1, Lcom/fakeninjalite/FakeNinjaLite2;->keyFired:Ljava/util/concurrent/atomic/AtomicBoolean;

    new-instance v1, Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-direct {v1, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    sput-object v1, Lcom/fakeninjalite/FakeNinjaLite2;->killFired:Ljava/util/concurrent/atomic/AtomicBoolean;

    new-instance v1, Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-direct {v1, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    sput-object v1, Lcom/fakeninjalite/FakeNinjaLite2;->noNetFired:Ljava/util/concurrent/atomic/AtomicBoolean;

    new-instance v1, Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-direct {v1, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    sput-object v1, Lcom/fakeninjalite/FakeNinjaLite2;->updateFired:Ljava/util/concurrent/atomic/AtomicBoolean;

    sput-object v0, Lcom/fakeninjalite/FakeNinjaLite2;->savedKeyReason:Ljava/lang/String;

    sput-object v0, Lcom/fakeninjalite/FakeNinjaLite2;->savedKillMsg:Ljava/lang/String;

    sput-object v0, Lcom/fakeninjalite/FakeNinjaLite2;->savedUpdateTitle:Ljava/lang/String;

    sput-object v0, Lcom/fakeninjalite/FakeNinjaLite2;->savedUpdateMsg:Ljava/lang/String;

    sput-object v0, Lcom/fakeninjalite/FakeNinjaLite2;->savedUpdateUrl:Ljava/lang/String;

    sput-boolean v2, Lcom/fakeninjalite/FakeNinjaLite2;->savedUpdateMandatory:Z

    new-instance v1, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v2

    invoke-direct {v1, v2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    sput-object v1, Lcom/fakeninjalite/FakeNinjaLite2;->mainH:Landroid/os/Handler;

    new-instance v1, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v2

    invoke-direct {v1, v2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    sput-object v1, Lcom/fakeninjalite/FakeNinjaLite2;->watchH:Landroid/os/Handler;

    move-object v1, v0

    check-cast v1, Ljava/lang/Runnable;

    sput-object v0, Lcom/fakeninjalite/FakeNinjaLite2;->watchdogR:Ljava/lang/Runnable;

    return-void
.end method

.method public constructor <init>()V
    .registers 1

    .line 371
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static native _acAnchorA()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation
.end method

.method private static native _acAnchorB()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation
.end method

.method private static native _acAnchorC()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation
.end method

.method private static native _acAnchorD()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation
.end method

.method private static native _anchorKeyB(Ljava/lang/String;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation
.end method

.method private static native _anchorKillB(Ljava/lang/String;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation
.end method

.method private static native _anchorNoNetB(Ljava/lang/String;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation
.end method

.method private static native _anchorUpdateB(Ljava/lang/String;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation
.end method

.method private static native _fireKey(Ljava/lang/String;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation
.end method

.method private static native _fireKill(Ljava/lang/String;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation
.end method

.method private static native _fireNoNet(Ljava/lang/String;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation
.end method

.method private static native _fireUpdate(Ljava/lang/String;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation
.end method

.method private static native _kA_dispatch(Ljava/lang/String;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation
.end method

.method private static native _kl_dispatch(Ljava/lang/String;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation
.end method

.method private static native _nn_dispatch(Ljava/lang/String;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation
.end method

.method private static native _upd_dispatch(Ljava/lang/String;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation
.end method

.method static synthetic access$1000043(Ljava/lang/String;)V
    .registers 1

    invoke-static {p0}, Lcom/fakeninjalite/FakeNinjaLite2;->_fireKey(Ljava/lang/String;)V

    return-void
.end method

.method static synthetic access$1000044(Ljava/lang/String;)V
    .registers 1

    invoke-static {p0}, Lcom/fakeninjalite/FakeNinjaLite2;->_anchorKeyB(Ljava/lang/String;)V

    return-void
.end method

.method static synthetic access$1000045(Ljava/lang/String;)V
    .registers 1

    invoke-static {p0}, Lcom/fakeninjalite/FakeNinjaLite2;->_kA_dispatch(Ljava/lang/String;)V

    return-void
.end method

.method static synthetic access$1000046(Ljava/lang/String;)V
    .registers 1

    invoke-static {p0}, Lcom/fakeninjalite/FakeNinjaLite2;->_fireKill(Ljava/lang/String;)V

    return-void
.end method

.method static synthetic access$1000047(Ljava/lang/String;)V
    .registers 1

    invoke-static {p0}, Lcom/fakeninjalite/FakeNinjaLite2;->_anchorKillB(Ljava/lang/String;)V

    return-void
.end method

.method static synthetic access$1000048(Ljava/lang/String;)V
    .registers 1

    invoke-static {p0}, Lcom/fakeninjalite/FakeNinjaLite2;->_kl_dispatch(Ljava/lang/String;)V

    return-void
.end method

.method static synthetic access$1000050(Ljava/lang/String;)V
    .registers 1

    invoke-static {p0}, Lcom/fakeninjalite/FakeNinjaLite2;->_anchorUpdateB(Ljava/lang/String;)V

    return-void
.end method

.method static synthetic access$1000051(Ljava/lang/String;)V
    .registers 1

    invoke-static {p0}, Lcom/fakeninjalite/FakeNinjaLite2;->_upd_dispatch(Ljava/lang/String;)V

    return-void
.end method

.method static synthetic access$1000053(Ljava/lang/String;)V
    .registers 1

    invoke-static {p0}, Lcom/fakeninjalite/FakeNinjaLite2;->_anchorNoNetB(Ljava/lang/String;)V

    return-void
.end method

.method static synthetic access$1000054(Ljava/lang/String;)V
    .registers 1

    invoke-static {p0}, Lcom/fakeninjalite/FakeNinjaLite2;->_nn_dispatch(Ljava/lang/String;)V

    return-void
.end method

.method static synthetic access$1000056()V
    .registers 0

    invoke-static {}, Lcom/fakeninjalite/FakeNinjaLite2;->_acAnchorB()V

    return-void
.end method

.method static synthetic access$1000057()V
    .registers 0

    invoke-static {}, Lcom/fakeninjalite/FakeNinjaLite2;->_acAnchorC()V

    return-void
.end method

.method static synthetic access$1000058()V
    .registers 0

    invoke-static {}, Lcom/fakeninjalite/FakeNinjaLite2;->_acAnchorD()V

    return-void
.end method

.method static synthetic access$L1000000()Ljava/lang/String;
    .registers 1

    sget-object v0, Lcom/fakeninjalite/FakeNinjaLite2;->TAG:Ljava/lang/String;

    return-object v0
.end method

.method static synthetic access$L1000002()J
    .registers 2

    sget-wide v0, Lcom/fakeninjalite/FakeNinjaLite2;->ANCHOR_C_DELAY_MS:J

    return-wide v0
.end method

.method static synthetic access$L1000003()J
    .registers 2

    sget-wide v0, Lcom/fakeninjalite/FakeNinjaLite2;->WATCH_INTERVAL_MS:J

    return-wide v0
.end method

.method static synthetic access$L1000004()Ljava/lang/ref/WeakReference;
    .registers 1

    sget-object v0, Lcom/fakeninjalite/FakeNinjaLite2;->actRef:Ljava/lang/ref/WeakReference;

    return-object v0
.end method

.method static synthetic access$L1000006()Ljava/util/concurrent/atomic/AtomicBoolean;
    .registers 1

    sget-object v0, Lcom/fakeninjalite/FakeNinjaLite2;->keyGuardActive:Ljava/util/concurrent/atomic/AtomicBoolean;

    return-object v0
.end method

.method static synthetic access$L1000007()Ljava/util/concurrent/atomic/AtomicBoolean;
    .registers 1

    sget-object v0, Lcom/fakeninjalite/FakeNinjaLite2;->killGuardActive:Ljava/util/concurrent/atomic/AtomicBoolean;

    return-object v0
.end method

.method static synthetic access$L1000009()Ljava/util/concurrent/atomic/AtomicBoolean;
    .registers 1

    sget-object v0, Lcom/fakeninjalite/FakeNinjaLite2;->autoCloseActive:Ljava/util/concurrent/atomic/AtomicBoolean;

    return-object v0
.end method

.method static synthetic access$L1000010()Ljava/util/concurrent/atomic/AtomicBoolean;
    .registers 1

    sget-object v0, Lcom/fakeninjalite/FakeNinjaLite2;->acFiredA:Ljava/util/concurrent/atomic/AtomicBoolean;

    return-object v0
.end method

.method static synthetic access$L1000011()Ljava/util/concurrent/atomic/AtomicBoolean;
    .registers 1

    sget-object v0, Lcom/fakeninjalite/FakeNinjaLite2;->acFiredB:Ljava/util/concurrent/atomic/AtomicBoolean;

    return-object v0
.end method

.method static synthetic access$L1000012()Ljava/util/concurrent/atomic/AtomicBoolean;
    .registers 1

    sget-object v0, Lcom/fakeninjalite/FakeNinjaLite2;->acFiredC:Ljava/util/concurrent/atomic/AtomicBoolean;

    return-object v0
.end method

.method static synthetic access$L1000013()Ljava/util/concurrent/atomic/AtomicBoolean;
    .registers 1

    sget-object v0, Lcom/fakeninjalite/FakeNinjaLite2;->acFiredD:Ljava/util/concurrent/atomic/AtomicBoolean;

    return-object v0
.end method

.method static synthetic access$L1000015()Ljava/util/concurrent/atomic/AtomicBoolean;
    .registers 1

    sget-object v0, Lcom/fakeninjalite/FakeNinjaLite2;->keyFired:Ljava/util/concurrent/atomic/AtomicBoolean;

    return-object v0
.end method

.method static synthetic access$L1000016()Ljava/util/concurrent/atomic/AtomicBoolean;
    .registers 1

    sget-object v0, Lcom/fakeninjalite/FakeNinjaLite2;->killFired:Ljava/util/concurrent/atomic/AtomicBoolean;

    return-object v0
.end method

.method static synthetic access$L1000025()Landroid/os/Handler;
    .registers 1

    sget-object v0, Lcom/fakeninjalite/FakeNinjaLite2;->mainH:Landroid/os/Handler;

    return-object v0
.end method

.method static synthetic access$L1000026()Landroid/os/Handler;
    .registers 1

    sget-object v0, Lcom/fakeninjalite/FakeNinjaLite2;->watchH:Landroid/os/Handler;

    return-object v0
.end method

.method static synthetic access$S1000000(Ljava/lang/String;)V
    .registers 1

    sput-object p0, Lcom/fakeninjalite/FakeNinjaLite2;->TAG:Ljava/lang/String;

    return-void
.end method

.method static synthetic access$S1000002(J)V
    .registers 2

    sput-wide p0, Lcom/fakeninjalite/FakeNinjaLite2;->ANCHOR_C_DELAY_MS:J

    return-void
.end method

.method static synthetic access$S1000003(J)V
    .registers 2

    sput-wide p0, Lcom/fakeninjalite/FakeNinjaLite2;->WATCH_INTERVAL_MS:J

    return-void
.end method

.method static synthetic access$S1000004(Ljava/lang/ref/WeakReference;)V
    .registers 1

    sput-object p0, Lcom/fakeninjalite/FakeNinjaLite2;->actRef:Ljava/lang/ref/WeakReference;

    return-void
.end method

.method static synthetic access$S1000006(Ljava/util/concurrent/atomic/AtomicBoolean;)V
    .registers 1

    sput-object p0, Lcom/fakeninjalite/FakeNinjaLite2;->keyGuardActive:Ljava/util/concurrent/atomic/AtomicBoolean;

    return-void
.end method

.method static synthetic access$S1000007(Ljava/util/concurrent/atomic/AtomicBoolean;)V
    .registers 1

    sput-object p0, Lcom/fakeninjalite/FakeNinjaLite2;->killGuardActive:Ljava/util/concurrent/atomic/AtomicBoolean;

    return-void
.end method

.method static synthetic access$S1000009(Ljava/util/concurrent/atomic/AtomicBoolean;)V
    .registers 1

    sput-object p0, Lcom/fakeninjalite/FakeNinjaLite2;->autoCloseActive:Ljava/util/concurrent/atomic/AtomicBoolean;

    return-void
.end method

.method static synthetic access$S1000010(Ljava/util/concurrent/atomic/AtomicBoolean;)V
    .registers 1

    sput-object p0, Lcom/fakeninjalite/FakeNinjaLite2;->acFiredA:Ljava/util/concurrent/atomic/AtomicBoolean;

    return-void
.end method

.method static synthetic access$S1000011(Ljava/util/concurrent/atomic/AtomicBoolean;)V
    .registers 1

    sput-object p0, Lcom/fakeninjalite/FakeNinjaLite2;->acFiredB:Ljava/util/concurrent/atomic/AtomicBoolean;

    return-void
.end method

.method static synthetic access$S1000012(Ljava/util/concurrent/atomic/AtomicBoolean;)V
    .registers 1

    sput-object p0, Lcom/fakeninjalite/FakeNinjaLite2;->acFiredC:Ljava/util/concurrent/atomic/AtomicBoolean;

    return-void
.end method

.method static synthetic access$S1000013(Ljava/util/concurrent/atomic/AtomicBoolean;)V
    .registers 1

    sput-object p0, Lcom/fakeninjalite/FakeNinjaLite2;->acFiredD:Ljava/util/concurrent/atomic/AtomicBoolean;

    return-void
.end method

.method static synthetic access$S1000015(Ljava/util/concurrent/atomic/AtomicBoolean;)V
    .registers 1

    sput-object p0, Lcom/fakeninjalite/FakeNinjaLite2;->keyFired:Ljava/util/concurrent/atomic/AtomicBoolean;

    return-void
.end method

.method static synthetic access$S1000016(Ljava/util/concurrent/atomic/AtomicBoolean;)V
    .registers 1

    sput-object p0, Lcom/fakeninjalite/FakeNinjaLite2;->killFired:Ljava/util/concurrent/atomic/AtomicBoolean;

    return-void
.end method

.method static synthetic access$S1000025(Landroid/os/Handler;)V
    .registers 1

    sput-object p0, Lcom/fakeninjalite/FakeNinjaLite2;->mainH:Landroid/os/Handler;

    return-void
.end method

.method static synthetic access$S1000026(Landroid/os/Handler;)V
    .registers 1

    sput-object p0, Lcom/fakeninjalite/FakeNinjaLite2;->watchH:Landroid/os/Handler;

    return-void
.end method

.method public static native init(Landroid/app/Activity;Lcom/fakeninjalite/FakeNinjaLite2$Callbacks;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/app/Activity;",
            "Lcom/fakeninjalite/FakeNinjaLite2$Callbacks;",
            ")V"
        }
    .end annotation
.end method

.method public static native pulse(Landroid/app/Activity;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/app/Activity;",
            ")V"
        }
    .end annotation
.end method

.method public static native resetKeyGuard()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation
.end method

.method public static native resetNoInternetGuard()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation
.end method

.method private static native startWatchdog()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation
.end method

.method public static native stopWatchdog()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation
.end method

.method public static native triggerAutoClose(Ljava/lang/String;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation
.end method

.method public static native triggerKey(Ljava/lang/String;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation
.end method

.method public static native triggerKill(Ljava/lang/String;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation
.end method

.method public static native triggerNoInternet()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation
.end method

.method public static native triggerUpdate(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Z)V"
        }
    .end annotation
.end method
