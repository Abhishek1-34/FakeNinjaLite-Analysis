.class public final Lcom/fakeninjalite/R$id;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/fakeninjalite/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x39
    name = "id"
.end annotation


# static fields
.field public static final act_freeze:I = 0x7f06000f

.field public static final act_freeze_v2:I = 0x7f060010

.field public static final act_ghost_v2:I = 0x7f06000e

.field public static final act_notif:I = 0x7f060021

.field public static final act_overlay:I = 0x7f06001e

.field public static final act_storage:I = 0x7f060024

.field public static final act_tele_v2:I = 0x7f060014

.field public static final act_vpn:I = 0x7f06000d

.field public static final act_vpn_perm:I = 0x7f06001b

.field public static final btn_change_key:I = 0x7f060006

.field public static final btn_config_save:I = 0x7f060016

.field public static final btn_engine_toggle:I = 0x7f06000a

.field public static final btn_ff_max:I = 0x7f06000c

.field public static final btn_ff_normal:I = 0x7f06000b

.field public static final btn_retry_server:I = 0x7f060002

.field public static final dot_engine:I = 0x7f060007

.field public static final dot_key:I = 0x7f060003

.field public static final dot_notif:I = 0x7f06001f

.field public static final dot_overlay:I = 0x7f06001c

.field public static final dot_server:I = 0x7f060000

.field public static final dot_storage:I = 0x7f060022

.field public static final dot_vpn:I = 0x7f060019

.field public static final et_config_name:I = 0x7f060015

.field public static final et_freeze_v2_delay:I = 0x7f060012

.field public static final et_freeze_v2_on:I = 0x7f060011

.field public static final et_step_tele_v2:I = 0x7f060013

.field public static final ll_config_list:I = 0x7f060018

.field public static final tv_config_empty:I = 0x7f060017

.field public static final tv_engine_desc:I = 0x7f060009

.field public static final tv_key_expiry:I = 0x7f060005

.field public static final tv_key_value:I = 0x7f060004

.field public static final tv_notif_status:I = 0x7f060020

.field public static final tv_overlay_status:I = 0x7f06001d

.field public static final tv_server_status:I = 0x7f060001

.field public static final tv_status:I = 0x7f060008

.field public static final tv_storage_status:I = 0x7f060023

.field public static final tv_vpn_status:I = 0x7f06001a


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 72
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
