.class Lcom/fakeninjalite/FakeNinjaLite8$Pkt;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/fakeninjalite/FakeNinjaLite8;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x28
    name = "Pkt"
.end annotation


# instance fields
.field data:[B

.field dataLen:I

.field dstIp:I

.field dstPort:S

.field proto:I

.field srcPort:S


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const/16 v0, 0x69

    invoke-static {v0}, LBeykix/protect/NativeUtil;->classesInit0(I)V

    return-void
.end method

.method constructor <init>(Ljava/nio/ByteBuffer;)V
    .registers 5

    .line 748
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 749
    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Ljava/nio/ByteBuffer;->position(I)Ljava/nio/Buffer;

    .line 750
    invoke-virtual {p1, v0}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v0

    and-int/lit8 v0, v0, 0xf

    mul-int/lit8 v0, v0, 0x4

    .line 751
    const/16 v1, 0x9

    invoke-virtual {p1, v1}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v1

    and-int/lit16 v1, v1, 0xff

    iput v1, p0, Lcom/fakeninjalite/FakeNinjaLite8$Pkt;->proto:I

    .line 752
    const/16 v1, 0x10

    invoke-virtual {p1, v1}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v1

    iput v1, p0, Lcom/fakeninjalite/FakeNinjaLite8$Pkt;->dstIp:I

    .line 754
    iget v1, p0, Lcom/fakeninjalite/FakeNinjaLite8$Pkt;->proto:I

    const/16 v2, 0x11

    if-ne v1, v2, :cond_5e

    invoke-virtual {p1}, Ljava/nio/ByteBuffer;->remaining()I

    move-result v1

    add-int/lit8 v2, v0, 0x8

    if-lt v1, v2, :cond_5e

    .line 755
    invoke-virtual {p1, v0}, Ljava/nio/ByteBuffer;->position(I)Ljava/nio/Buffer;

    .line 756
    invoke-virtual {p1}, Ljava/nio/ByteBuffer;->getShort()S

    move-result v1

    iput-short v1, p0, Lcom/fakeninjalite/FakeNinjaLite8$Pkt;->srcPort:S

    .line 757
    invoke-virtual {p1}, Ljava/nio/ByteBuffer;->getShort()S

    move-result v1

    iput-short v1, p0, Lcom/fakeninjalite/FakeNinjaLite8$Pkt;->dstPort:S

    .line 758
    add-int/lit8 v0, v0, 0x4

    invoke-virtual {p1, v0}, Ljava/nio/ByteBuffer;->getShort(I)S

    move-result v0

    const v1, 0xffff

    and-int/2addr v0, v1

    add-int/lit8 v0, v0, -0x8

    iput v0, p0, Lcom/fakeninjalite/FakeNinjaLite8$Pkt;->dataLen:I

    .line 759
    if-lez v0, :cond_5e

    const/16 v1, 0x5dc

    if-ge v0, v1, :cond_5e

    .line 760
    new-array v0, v0, [B

    iput-object v0, p0, Lcom/fakeninjalite/FakeNinjaLite8$Pkt;->data:[B

    .line 761
    invoke-virtual {p1, v2}, Ljava/nio/ByteBuffer;->position(I)Ljava/nio/Buffer;

    .line 762
    iget-object v0, p0, Lcom/fakeninjalite/FakeNinjaLite8$Pkt;->data:[B

    invoke-virtual {p1, v0}, Ljava/nio/ByteBuffer;->get([B)Ljava/nio/ByteBuffer;

    :cond_5e
    return-void
.end method


# virtual methods
.method native isSyncPkt()Z
.end method
