.class Lcom/fakeninjalite/FakeNinjaLite8$QueuedPkt;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/fakeninjalite/FakeNinjaLite8;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x28
    name = "QueuedPkt"
.end annotation


# instance fields
.field final data:[B

.field final dataLen:I

.field final dstIp:I

.field final dstPort:I

.field final sock:Ljava/net/DatagramSocket;


# direct methods
.method constructor <init>([BIIILjava/net/DatagramSocket;)V
    .registers 6

    .line 776
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 777
    iput-object p1, p0, Lcom/fakeninjalite/FakeNinjaLite8$QueuedPkt;->data:[B

    iput p2, p0, Lcom/fakeninjalite/FakeNinjaLite8$QueuedPkt;->dataLen:I

    iput p3, p0, Lcom/fakeninjalite/FakeNinjaLite8$QueuedPkt;->dstIp:I

    iput p4, p0, Lcom/fakeninjalite/FakeNinjaLite8$QueuedPkt;->dstPort:I

    iput-object p5, p0, Lcom/fakeninjalite/FakeNinjaLite8$QueuedPkt;->sock:Ljava/net/DatagramSocket;

    return-void
.end method
