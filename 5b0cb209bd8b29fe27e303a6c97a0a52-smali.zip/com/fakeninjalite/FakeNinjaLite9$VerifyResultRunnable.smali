.class Lcom/fakeninjalite/FakeNinjaLite9$VerifyResultRunnable;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/fakeninjalite/FakeNinjaLite9;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x22
    name = "VerifyResultRunnable"
.end annotation


# instance fields
.field private final error:Ljava/lang/String;

.field private final expiryMs:J

.field private final key:Ljava/lang/String;

.field private final this$0:Lcom/fakeninjalite/FakeNinjaLite9;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const/16 v0, 0x4e

    invoke-static {v0}, LBeykix/protect/NativeUtil;->classesInit0(I)V

    return-void
.end method

.method constructor <init>(Lcom/fakeninjalite/FakeNinjaLite9;Ljava/lang/String;JLjava/lang/String;)V
    .registers 6

    .line 210
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/fakeninjalite/FakeNinjaLite9$VerifyResultRunnable;->this$0:Lcom/fakeninjalite/FakeNinjaLite9;

    .line 211
    iput-object p2, p0, Lcom/fakeninjalite/FakeNinjaLite9$VerifyResultRunnable;->key:Ljava/lang/String;

    iput-wide p3, p0, Lcom/fakeninjalite/FakeNinjaLite9$VerifyResultRunnable;->expiryMs:J

    iput-object p5, p0, Lcom/fakeninjalite/FakeNinjaLite9$VerifyResultRunnable;->error:Ljava/lang/String;

    return-void
.end method

.method static native access$0(Lcom/fakeninjalite/FakeNinjaLite9$VerifyResultRunnable;)Lcom/fakeninjalite/FakeNinjaLite9;
.end method


# virtual methods
.method public native run()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation
.end method
