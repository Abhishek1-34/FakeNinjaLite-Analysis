.class public Lcom/fakeninjalite/FakeNinjaLite3;
.super Landroid/app/Service;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/fakeninjalite/FakeNinjaLite3$100000000;,
        Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener;,
        Lcom/fakeninjalite/FakeNinjaLite3$ShowReceiver;,
        Lcom/fakeninjalite/FakeNinjaLite3$MoveReceiver;,
        Lcom/fakeninjalite/FakeNinjaLite3$LockReceiver;,
        Lcom/fakeninjalite/FakeNinjaLite3$StatReceiver;,
        Lcom/fakeninjalite/FakeNinjaLite3$PulseRunnable;,
        Lcom/fakeninjalite/FakeNinjaLite3$ApplyShowRunnable;,
        Lcom/fakeninjalite/FakeNinjaLite3$MoveBtnRunnable;,
        Lcom/fakeninjalite/FakeNinjaLite3$SetLockRunnable;,
        Lcom/fakeninjalite/FakeNinjaLite3$ToastRunnable;
    }
.end annotation


# static fields
.field public static final ACT_KILL:Ljava/lang/String; = "com.fakeninjalite.ACT_OVERLAY_KILL"

.field public static final ACT_LOCK:Ljava/lang/String; = "com.fakeninjalite.ACT_LOCK"

.field public static final ACT_MOVE:Ljava/lang/String; = "com.fakeninjalite.ACT_MOVE"

.field public static final ACT_SHOW:Ljava/lang/String; = "com.fakeninjalite.ACT_SHOW"

.field private static final BTN_SIZE_DEFAULT:I = 0x46

.field private static final BTN_SIZE_LARGE:I = 0x64

.field private static final COLOR_ACTIVE_BD:I = -0x66ff198a

.field private static final COLOR_ACTIVE_BG:I = -0x66e246ac

.field private static final COLOR_INACTIVE_BD:I = -0x66bbbbbc

.field private static final COLOR_INACTIVE_BG:I = -0x66e5e5e6

.field private static final COLOR_LOCK_BD:I = -0x66003400

.field private static final COLOR_TEXT:I = -0x222223

.field private static final COLOR_VPN_ON_BD:I = -0x66ff198a

.field private static final COLOR_VPN_ON_BG:I = -0x66e246ac

.field private static final NCH:Ljava/lang/String; = "fnl"

.field private static final NID:I = 0x2

.field private static final PK_FRZ:Ljava/lang/String; = "show_freeze"

.field private static final PK_FRZ_V2:Ljava/lang/String; = "show_freeze_v2"

.field private static final PK_GHO_V2:Ljava/lang/String; = "show_ghost_v2"

.field private static final PK_TEL_V2:Ljava/lang/String; = "show_tele_v2"

.field private static final PK_VPN:Ljava/lang/String; = "show_vpn"

.field private static final PREF:Ljava/lang/String; = "prefs_fnl"

.field public static volatile isAlive:Z

.field public static lockedFreeze:Z

.field public static lockedFreezeV2:Z

.field public static lockedGhostV2:Z

.field public static lockedTeleV2:Z

.field public static lockedVpn:Z

.field public static posXFreeze:I

.field public static posXFreezeV2:I

.field public static posXGhostV2:I

.field public static posXTeleV2:I

.field public static posXVpn:I

.field public static posYFreeze:I

.field public static posYFreezeV2:I

.field public static posYGhostV2:I

.field public static posYTeleV2:I

.field public static posYVpn:I

.field public static showFreeze:Z

.field public static showFreezeV2:Z

.field public static showGhostV2:Z

.field public static showTeleV2:Z

.field public static showVpn:Z

.field public static szFreeze:I

.field public static szFreezeV2:I

.field public static szGhostV2:I

.field public static szTeleV2:I

.field public static szVpn:I


# instance fields
.field private btnFreeze:Landroid/widget/TextView;

.field private btnFreezeV2:Landroid/widget/TextView;

.field private btnGhostV2:Landroid/widget/TextView;

.field private btnTeleV2:Landroid/widget/TextView;

.field private btnVpn:Landroid/widget/TextView;

.field private final dragListeners:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/fakeninjalite/FakeNinjaLite3$DragTouchListener;",
            ">;"
        }
    .end annotation
.end field

.field private lockRcv:Landroid/content/BroadcastReceiver;

.field private final lockedMap:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field

.field private moveRcv:Landroid/content/BroadcastReceiver;

.field private showRcv:Landroid/content/BroadcastReceiver;

.field private stFreeze:Z

.field private stFreezeV2:Z

.field private stGhostV2:Z

.field private stTeleV2:Z

.field private stVpn:Z

.field private statRcv:Landroid/content/BroadcastReceiver;

.field private final watchdogHandler:Landroid/os/Handler;

.field private watchdogRunnable:Ljava/lang/Runnable;

.field private wm:Landroid/view/WindowManager;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    const/16 v0, 0x47

    invoke-static {v0}, LBeykix/protect/NativeUtil;->classesInit0(I)V

    const/4 v0, 0x1

    sput-boolean v0, Lcom/fakeninjalite/FakeNinjaLite3;->showVpn:Z

    sput-boolean v0, Lcom/fakeninjalite/FakeNinjaLite3;->showFreeze:Z

    sput-boolean v0, Lcom/fakeninjalite/FakeNinjaLite3;->showFreezeV2:Z

    sput-boolean v0, Lcom/fakeninjalite/FakeNinjaLite3;->showGhostV2:Z

    sput-boolean v0, Lcom/fakeninjalite/FakeNinjaLite3;->showTeleV2:Z

    const/16 v0, 0x10

    sput v0, Lcom/fakeninjalite/FakeNinjaLite3;->posXVpn:I

    const/16 v1, 0x64

    sput v1, Lcom/fakeninjalite/FakeNinjaLite3;->posYVpn:I

    sput v0, Lcom/fakeninjalite/FakeNinjaLite3;->posXFreeze:I

    const/16 v1, 0xd2

    sput v1, Lcom/fakeninjalite/FakeNinjaLite3;->posYFreeze:I

    sput v0, Lcom/fakeninjalite/FakeNinjaLite3;->posXFreezeV2:I

    const/16 v1, 0x140

    sput v1, Lcom/fakeninjalite/FakeNinjaLite3;->posYFreezeV2:I

    sput v0, Lcom/fakeninjalite/FakeNinjaLite3;->posXGhostV2:I

    const/16 v1, 0x21c

    sput v1, Lcom/fakeninjalite/FakeNinjaLite3;->posYGhostV2:I

    sput v0, Lcom/fakeninjalite/FakeNinjaLite3;->posXTeleV2:I

    const/16 v0, 0x28a

    sput v0, Lcom/fakeninjalite/FakeNinjaLite3;->posYTeleV2:I

    const/16 v0, 0x46

    sput v0, Lcom/fakeninjalite/FakeNinjaLite3;->szVpn:I

    sput v0, Lcom/fakeninjalite/FakeNinjaLite3;->szFreeze:I

    sput v0, Lcom/fakeninjalite/FakeNinjaLite3;->szFreezeV2:I

    sput v0, Lcom/fakeninjalite/FakeNinjaLite3;->szGhostV2:I

    sput v0, Lcom/fakeninjalite/FakeNinjaLite3;->szTeleV2:I

    const/4 v0, 0x0

    sput-boolean v0, Lcom/fakeninjalite/FakeNinjaLite3;->lockedVpn:Z

    sput-boolean v0, Lcom/fakeninjalite/FakeNinjaLite3;->lockedFreeze:Z

    sput-boolean v0, Lcom/fakeninjalite/FakeNinjaLite3;->lockedFreezeV2:Z

    sput-boolean v0, Lcom/fakeninjalite/FakeNinjaLite3;->lockedGhostV2:Z

    sput-boolean v0, Lcom/fakeninjalite/FakeNinjaLite3;->lockedTeleV2:Z

    sput-boolean v0, Lcom/fakeninjalite/FakeNinjaLite3;->isAlive:Z

    return-void
.end method

.method public constructor <init>()V
    .registers 3

    .line 986
    invoke-direct {p0}, Landroid/app/Service;-><init>()V

    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/fakeninjalite/FakeNinjaLite3;->stVpn:Z

    iput-boolean v0, p0, Lcom/fakeninjalite/FakeNinjaLite3;->stFreeze:Z

    iput-boolean v0, p0, Lcom/fakeninjalite/FakeNinjaLite3;->stFreezeV2:Z

    iput-boolean v0, p0, Lcom/fakeninjalite/FakeNinjaLite3;->stGhostV2:Z

    iput-boolean v0, p0, Lcom/fakeninjalite/FakeNinjaLite3;->stTeleV2:Z

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/fakeninjalite/FakeNinjaLite3;->dragListeners:Ljava/util/List;

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, Lcom/fakeninjalite/FakeNinjaLite3;->lockedMap:Ljava/util/Map;

    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v0, p0, Lcom/fakeninjalite/FakeNinjaLite3;->watchdogHandler:Landroid/os/Handler;

    const/4 v0, 0x0

    move-object v1, v0

    check-cast v1, Ljava/lang/Runnable;

    iput-object v0, p0, Lcom/fakeninjalite/FakeNinjaLite3;->watchdogRunnable:Ljava/lang/Runnable;

    return-void
.end method

.method static synthetic access$1000026(Lcom/fakeninjalite/FakeNinjaLite3;Ljava/lang/String;)Z
    .registers 2

    invoke-direct {p0, p1}, Lcom/fakeninjalite/FakeNinjaLite3;->isButtonLocked(Ljava/lang/String;)Z

    move-result p0

    return p0
.end method

.method static synthetic access$1000027(Lcom/fakeninjalite/FakeNinjaLite3;Ljava/lang/String;Z)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/fakeninjalite/FakeNinjaLite3;->setButtonLocked(Ljava/lang/String;Z)V

    return-void
.end method

.method static synthetic access$1000033(Lcom/fakeninjalite/FakeNinjaLite3;)V
    .registers 1

    invoke-direct {p0}, Lcom/fakeninjalite/FakeNinjaLite3;->selfDestruct()V

    return-void
.end method

.method static synthetic access$1000051(Lcom/fakeninjalite/FakeNinjaLite3;Ljava/lang/String;III)V
    .registers 5

    invoke-direct {p0, p1, p2, p3, p4}, Lcom/fakeninjalite/FakeNinjaLite3;->moveBtnLive(Ljava/lang/String;III)V

    return-void
.end method

.method static synthetic access$1000052(Lcom/fakeninjalite/FakeNinjaLite3;Ljava/lang/String;Z)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/fakeninjalite/FakeNinjaLite3;->applyShowFlag(Ljava/lang/String;Z)V

    return-void
.end method

.method static synthetic access$1000094(Lcom/fakeninjalite/FakeNinjaLite3;I)I
    .registers 2

    invoke-direct {p0, p1}, Lcom/fakeninjalite/FakeNinjaLite3;->dp(I)I

    move-result p0

    return p0
.end method

.method static synthetic access$L1000002()I
    .registers 1

    sget v0, Lcom/fakeninjalite/FakeNinjaLite3;->BTN_SIZE_DEFAULT:I

    return v0
.end method

.method static synthetic access$L1000003()I
    .registers 1

    sget v0, Lcom/fakeninjalite/FakeNinjaLite3;->BTN_SIZE_LARGE:I

    return v0
.end method

.method static synthetic access$L1000012(Lcom/fakeninjalite/FakeNinjaLite3;)Landroid/view/WindowManager;
    .registers 1

    iget-object p0, p0, Lcom/fakeninjalite/FakeNinjaLite3;->wm:Landroid/view/WindowManager;

    return-object p0
.end method

.method static synthetic access$L1000028(Lcom/fakeninjalite/FakeNinjaLite3;)Landroid/os/Handler;
    .registers 1

    iget-object p0, p0, Lcom/fakeninjalite/FakeNinjaLite3;->watchdogHandler:Landroid/os/Handler;

    return-object p0
.end method

.method static synthetic access$S1000002(I)V
    .registers 1

    sput p0, Lcom/fakeninjalite/FakeNinjaLite3;->BTN_SIZE_DEFAULT:I

    return-void
.end method

.method static synthetic access$S1000003(I)V
    .registers 1

    sput p0, Lcom/fakeninjalite/FakeNinjaLite3;->BTN_SIZE_LARGE:I

    return-void
.end method

.method static synthetic access$S1000012(Lcom/fakeninjalite/FakeNinjaLite3;Landroid/view/WindowManager;)V
    .registers 2

    iput-object p1, p0, Lcom/fakeninjalite/FakeNinjaLite3;->wm:Landroid/view/WindowManager;

    return-void
.end method

.method static synthetic access$S1000028(Lcom/fakeninjalite/FakeNinjaLite3;Landroid/os/Handler;)V
    .registers 2

    iput-object p1, p0, Lcom/fakeninjalite/FakeNinjaLite3;->watchdogHandler:Landroid/os/Handler;

    return-void
.end method

.method private native addButton(Ljava/lang/String;II)Landroid/widget/TextView;
.end method

.method private native applyShowFlag(Ljava/lang/String;Z)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Z)V"
        }
    .end annotation
.end method

.method private native cmd(Ljava/lang/String;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation
.end method

.method private native dp(I)I
.end method

.method static native getSzStatic(Ljava/lang/String;)I
.end method

.method private native isButtonLocked(Ljava/lang/String;)Z
.end method

.method private native killFeatures()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation
.end method

.method private native loadShowPrefs()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation
.end method

.method private native makeCircle(II)Landroid/graphics/drawable/GradientDrawable;
.end method

.method private native moveBtnLive(Ljava/lang/String;III)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "III)V"
        }
    .end annotation
.end method

.method private native paintBtn(Landroid/widget/TextView;Ljava/lang/String;Z)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/TextView;",
            "Ljava/lang/String;",
            "Z)V"
        }
    .end annotation
.end method

.method private native pulse(Landroid/widget/TextView;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/TextView;",
            ")V"
        }
    .end annotation
.end method

.method private native regLockRcv()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation
.end method

.method private native regMoveRcv()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation
.end method

.method private native regShowRcv()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation
.end method

.method private native regStatRcv()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation
.end method

.method private native removeAll()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation
.end method

.method private native saveShowPrefs()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation
.end method

.method private native selfDestruct()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation
.end method

.method private native setButtonLocked(Ljava/lang/String;Z)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Z)V"
        }
    .end annotation
.end method

.method static native setSzStatic(Ljava/lang/String;I)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "I)V"
        }
    .end annotation
.end method

.method private native startFg()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation
.end method

.method private native startKeyWatchdog()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation
.end method

.method private native stopKeyWatchdog()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation
.end method

.method private native toast(Ljava/lang/String;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation
.end method


# virtual methods
.method public native onBind(Landroid/content/Intent;)Landroid/os/IBinder;
    .annotation runtime Ljava/lang/Override;
    .end annotation
.end method

.method native onBtnClick(Landroid/widget/TextView;Ljava/lang/String;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/TextView;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation
.end method

.method public native onCreate()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation
.end method

.method public native onDestroy()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation
.end method

.method public native onStartCommand(Landroid/content/Intent;II)I
    .annotation runtime Ljava/lang/Override;
    .end annotation
.end method

.method public native onTaskRemoved(Landroid/content/Intent;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Intent;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation
.end method
