.class Lcom/fakeninjalite/MainActivity$ActivateKeyClickListener;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/fakeninjalite/MainActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x22
    name = "ActivateKeyClickListener"
.end annotation


# instance fields
.field private final dlg:Landroid/app/AlertDialog;

.field private final et:Landroid/widget/EditText;

.field private final this$0:Lcom/fakeninjalite/MainActivity;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const/16 v0, 0x19

    invoke-static {v0}, LBeykix/protect/NativeUtil;->classesInit0(I)V

    return-void
.end method

.method constructor <init>(Lcom/fakeninjalite/MainActivity;Landroid/widget/EditText;Landroid/app/AlertDialog;)V
    .registers 4

    .line 569
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/fakeninjalite/MainActivity$ActivateKeyClickListener;->this$0:Lcom/fakeninjalite/MainActivity;

    .line 570
    iput-object p2, p0, Lcom/fakeninjalite/MainActivity$ActivateKeyClickListener;->et:Landroid/widget/EditText;

    iput-object p3, p0, Lcom/fakeninjalite/MainActivity$ActivateKeyClickListener;->dlg:Landroid/app/AlertDialog;

    return-void
.end method

.method static native access$0(Lcom/fakeninjalite/MainActivity$ActivateKeyClickListener;)Lcom/fakeninjalite/MainActivity;
.end method


# virtual methods
.method public native onClick(Landroid/view/View;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation
.end method
