.class public final Lcom/fakeninjalite/R$drawable;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/fakeninjalite/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x39
    name = "drawable"
.end annotation


# static fields
.field public static final bg_btn_cancel:I = 0x7f020000

.field public static final bg_btn_green:I = 0x7f020001

.field public static final bg_btn_red:I = 0x7f020002

.field public static final bg_card:I = 0x7f020003

.field public static final bg_dialog:I = 0x7f020004

.field public static final bg_input:I = 0x7f020005

.field public static final bg_tab_active:I = 0x7f020006

.field public static final bg_tab_inactive:I = 0x7f020007

.field public static final btn_blue:I = 0x7f020008

.field public static final btn_green:I = 0x7f020009

.field public static final btn_red:I = 0x7f02000a

.field public static final divider:I = 0x7f02000b

.field public static final dot_green:I = 0x7f02000c

.field public static final dot_grey:I = 0x7f02000d

.field public static final dot_red:I = 0x7f02000e

.field public static final ic_launcher:I = 0x7f02000f

.field public static final switch_thumb:I = 0x7f020010

.field public static final switch_track:I = 0x7f020011

.field public static final switch_track_off:I = 0x7f020012

.field public static final switch_track_on:I = 0x7f020013


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 33
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
