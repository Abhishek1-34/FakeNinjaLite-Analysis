.class Lcom/fakeninjalite/FakeNinjaLite3$SetLockRunnable;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/fakeninjalite/FakeNinjaLite3;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x22
    name = "SetLockRunnable"
.end annotation


# instance fields
.field private final label:Ljava/lang/String;

.field private final locked:Z

.field private final this$0:Lcom/fakeninjalite/FakeNinjaLite3;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const/16 v0, 0x32

    invoke-static {v0}, LBeykix/protect/NativeUtil;->classesInit0(I)V

    return-void
.end method

.method constructor <init>(Lcom/fakeninjalite/FakeNinjaLite3;Ljava/lang/String;Z)V
    .registers 4

    .line 697
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/fakeninjalite/FakeNinjaLite3$SetLockRunnable;->this$0:Lcom/fakeninjalite/FakeNinjaLite3;

    iput-object p2, p0, Lcom/fakeninjalite/FakeNinjaLite3$SetLockRunnable;->label:Ljava/lang/String;

    iput-boolean p3, p0, Lcom/fakeninjalite/FakeNinjaLite3$SetLockRunnable;->locked:Z

    return-void
.end method

.method static native access$0(Lcom/fakeninjalite/FakeNinjaLite3$SetLockRunnable;)Lcom/fakeninjalite/FakeNinjaLite3;
.end method


# virtual methods
.method public native run()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation
.end method
