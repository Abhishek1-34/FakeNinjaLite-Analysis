.class Lcom/fakeninjalite/FakeNinjaLite9$PreflightResultRunnable;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/fakeninjalite/FakeNinjaLite9;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x22
    name = "PreflightResultRunnable"
.end annotation


# instance fields
.field private final error:Ljava/lang/String;

.field private final hmac:Ljava/lang/String;

.field private final this$0:Lcom/fakeninjalite/FakeNinjaLite9;

.field private final token:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const/4 v0, 0x4

    invoke-static {v0}, LBeykix/protect/NativeUtil;->classesInit0(I)V

    return-void
.end method

.method constructor <init>(Lcom/fakeninjalite/FakeNinjaLite9;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .registers 5

    .line 183
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/fakeninjalite/FakeNinjaLite9$PreflightResultRunnable;->this$0:Lcom/fakeninjalite/FakeNinjaLite9;

    .line 184
    iput-object p2, p0, Lcom/fakeninjalite/FakeNinjaLite9$PreflightResultRunnable;->token:Ljava/lang/String;

    iput-object p3, p0, Lcom/fakeninjalite/FakeNinjaLite9$PreflightResultRunnable;->hmac:Ljava/lang/String;

    iput-object p4, p0, Lcom/fakeninjalite/FakeNinjaLite9$PreflightResultRunnable;->error:Ljava/lang/String;

    return-void
.end method

.method static native access$0(Lcom/fakeninjalite/FakeNinjaLite9$PreflightResultRunnable;)Lcom/fakeninjalite/FakeNinjaLite9;
.end method


# virtual methods
.method public native run()V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation
.end method
