package com.google.android.material.timepicker;

/* loaded from: classes.dex */
public final /* synthetic */ class d {
    public final /* synthetic */ TimePickerView a;

    public final void a() {
        int i = TimePickerView.r;
        this.a.getClass();
    }
}
