package com.google.android.material.datepicker;

import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import java.util.Calendar;
import org.conscrypt.R;
import x.AbstractC0324qd;
import x.B;
import x.C0032bb;
import x.C0163i3;
import x.C0494zd;
import x.Jg;
import x.Kb;
import x.Lb;
import x.Md;

/* loaded from: classes.dex */
public final class c extends AbstractC0324qd {
    public final C0163i3 c;
    public final B d;
    public final int e;

    public c(ContextThemeWrapper contextThemeWrapper, C0163i3 c0163i3, B b) {
        int i;
        Kb kb = c0163i3.a;
        Kb kb2 = c0163i3.d;
        if (kb.a.compareTo(kb2.a) <= 0) {
            if (kb2.a.compareTo(c0163i3.b.a) <= 0) {
                int dimensionPixelSize = contextThemeWrapper.getResources().getDimensionPixelSize(R.dimen.mtrl_calendar_day_height) * Lb.d;
                if (C0032bb.K(contextThemeWrapper, android.R.attr.windowFullscreen)) {
                    i = contextThemeWrapper.getResources().getDimensionPixelSize(R.dimen.mtrl_calendar_day_height);
                } else {
                    i = 0;
                }
                this.e = dimensionPixelSize + i;
                this.c = c0163i3;
                this.d = b;
                if (!this.a.a()) {
                    this.b = true;
                    return;
                }
                throw new IllegalStateException("Cannot change whether this adapter has stable IDs while the adapter has registered observers.");
            }
            throw new IllegalArgumentException("currentPage cannot be after lastPage");
        }
        throw new IllegalArgumentException("firstPage cannot be after currentPage");
    }

    @Override // x.AbstractC0324qd
    public final int a() {
        return this.c.g;
    }

    @Override // x.AbstractC0324qd
    public final long b(int i) {
        Calendar a = Jg.a(this.c.a.a);
        a.add(2, i);
        a.set(5, 1);
        Calendar a2 = Jg.a(a);
        a2.get(2);
        a2.get(1);
        a2.getMaximum(7);
        a2.getActualMaximum(5);
        a2.getTimeInMillis();
        return a2.getTimeInMillis();
    }

    @Override // x.AbstractC0324qd
    public final void c(Md md, int i) {
        b bVar = (b) md;
        C0163i3 c0163i3 = this.c;
        Calendar a = Jg.a(c0163i3.a.a);
        a.add(2, i);
        Kb kb = new Kb(a);
        bVar.t.setText(kb.c());
        MaterialCalendarGridView materialCalendarGridView = (MaterialCalendarGridView) bVar.u.findViewById(R.id.month_grid);
        if (materialCalendarGridView.a() != null && kb.equals(materialCalendarGridView.a().a)) {
            materialCalendarGridView.invalidate();
            materialCalendarGridView.a().getClass();
            throw null;
        }
        new Lb(kb, c0163i3);
        throw null;
    }

    @Override // x.AbstractC0324qd
    public final Md d(ViewGroup viewGroup) {
        LinearLayout linearLayout = (LinearLayout) LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.mtrl_calendar_month_labeled, viewGroup, false);
        if (C0032bb.K(viewGroup.getContext(), android.R.attr.windowFullscreen)) {
            linearLayout.setLayoutParams(new C0494zd(-1, this.e));
            return new b(linearLayout, true);
        }
        return new b(linearLayout, false);
    }
}
