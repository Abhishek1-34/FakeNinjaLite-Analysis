package com.google.android.material.button;

import android.R;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Parcelable;
import android.text.Layout;
import android.text.TextPaint;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Button;
import android.widget.Checkable;
import android.widget.CompoundButton;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.WeakHashMap;
import x.AbstractC0060d;
import x.AbstractC0112fb;
import x.AbstractC0124g3;
import x.AbstractC0135ge;
import x.AbstractC0191jd;
import x.AbstractC0309ph;
import x.B;
import x.C0080e;
import x.C0476ye;
import x.C0495ze;
import x.E9;
import x.Ke;
import x.La;
import x.Ma;
import x.Na;
import x.U0;

/* loaded from: classes.dex */
public class MaterialButton extends U0 implements Checkable, Ke {
    public static final int[] r = {R.attr.state_checkable};
    public static final int[] s = {R.attr.state_checked};
    public final Na d;
    public final LinkedHashSet e;
    public La f;
    public PorterDuff.Mode g;
    public ColorStateList h;
    public Drawable i;
    public String j;
    public int k;
    public int l;
    public int m;
    public int n;
    public boolean o;
    public boolean p;
    public int q;

    public MaterialButton(Context context, AttributeSet attributeSet) {
        super(AbstractC0124g3.V(context, attributeSet, org.conscrypt.R.attr.materialButtonStyle, org.conscrypt.R.style.Widget_MaterialComponents_Button), attributeSet, org.conscrypt.R.attr.materialButtonStyle);
        this.e = new LinkedHashSet();
        this.o = false;
        this.p = false;
        Context context2 = getContext();
        TypedArray O = E9.O(context2, attributeSet, AbstractC0191jd.j, org.conscrypt.R.attr.materialButtonStyle, org.conscrypt.R.style.Widget_MaterialComponents_Button, new int[0]);
        this.n = O.getDimensionPixelSize(12, 0);
        int i = O.getInt(15, -1);
        PorterDuff.Mode mode = PorterDuff.Mode.SRC_IN;
        this.g = AbstractC0112fb.E(i, mode);
        this.h = E9.B(getContext(), O, 14);
        this.i = E9.E(getContext(), O, 10);
        this.q = O.getInteger(11, 1);
        this.k = O.getDimensionPixelSize(13, 0);
        Na na = new Na(this, C0495ze.b(context2, attributeSet, org.conscrypt.R.attr.materialButtonStyle, org.conscrypt.R.style.Widget_MaterialComponents_Button).a());
        this.d = na;
        na.c = O.getDimensionPixelOffset(1, 0);
        na.d = O.getDimensionPixelOffset(2, 0);
        na.e = O.getDimensionPixelOffset(3, 0);
        na.f = O.getDimensionPixelOffset(4, 0);
        if (O.hasValue(8)) {
            int dimensionPixelSize = O.getDimensionPixelSize(8, -1);
            na.g = dimensionPixelSize;
            float f = dimensionPixelSize;
            C0476ye e = na.b.e();
            e.e = new C0080e(f);
            e.f = new C0080e(f);
            e.g = new C0080e(f);
            e.h = new C0080e(f);
            na.c(e.a());
            na.p = true;
        }
        na.h = O.getDimensionPixelSize(20, 0);
        na.i = AbstractC0112fb.E(O.getInt(7, -1), mode);
        na.j = E9.B(getContext(), O, 6);
        na.k = E9.B(getContext(), O, 19);
        na.l = E9.B(getContext(), O, 16);
        na.q = O.getBoolean(5, false);
        na.t = O.getDimensionPixelSize(9, 0);
        na.r = O.getBoolean(21, true);
        WeakHashMap weakHashMap = AbstractC0309ph.a;
        int paddingStart = getPaddingStart();
        int paddingTop = getPaddingTop();
        int paddingEnd = getPaddingEnd();
        int paddingBottom = getPaddingBottom();
        if (O.hasValue(0)) {
            na.o = true;
            setSupportBackgroundTintList(na.j);
            setSupportBackgroundTintMode(na.i);
        } else {
            na.e();
        }
        setPaddingRelative(paddingStart + na.c, paddingTop + na.e, paddingEnd + na.d, paddingBottom + na.f);
        O.recycle();
        setCompoundDrawablePadding(this.n);
        d(this.i != null);
    }

    private Layout.Alignment getActualTextAlignment() {
        int textAlignment = getTextAlignment();
        if (textAlignment != 1) {
            if (textAlignment != 6 && textAlignment != 3) {
                if (textAlignment != 4) {
                    return Layout.Alignment.ALIGN_NORMAL;
                }
                return Layout.Alignment.ALIGN_CENTER;
            }
            return Layout.Alignment.ALIGN_OPPOSITE;
        }
        return getGravityTextAlignment();
    }

    private Layout.Alignment getGravityTextAlignment() {
        int gravity = getGravity() & 8388615;
        if (gravity != 1) {
            if (gravity != 5 && gravity != 8388613) {
                return Layout.Alignment.ALIGN_NORMAL;
            }
            return Layout.Alignment.ALIGN_OPPOSITE;
        }
        return Layout.Alignment.ALIGN_CENTER;
    }

    private int getTextHeight() {
        if (getLineCount() > 1) {
            return getLayout().getHeight();
        }
        TextPaint paint = getPaint();
        String charSequence = getText().toString();
        if (getTransformationMethod() != null) {
            charSequence = getTransformationMethod().getTransformation(charSequence, this).toString();
        }
        Rect rect = new Rect();
        paint.getTextBounds(charSequence, 0, charSequence.length(), rect);
        return Math.min(rect.height(), getLayout().getHeight());
    }

    private int getTextLayoutWidth() {
        int lineCount = getLineCount();
        float f = 0.0f;
        for (int i = 0; i < lineCount; i++) {
            f = Math.max(f, getLayout().getLineWidth(i));
        }
        return (int) Math.ceil(f);
    }

    public final boolean a() {
        Na na = this.d;
        if (na != null && na.q) {
            return true;
        }
        return false;
    }

    public final boolean b() {
        Na na = this.d;
        if (na != null && !na.o) {
            return true;
        }
        return false;
    }

    public final void c() {
        int i = this.q;
        boolean z = true;
        if (i != 1 && i != 2) {
            z = false;
        }
        if (z) {
            setCompoundDrawablesRelative(this.i, null, null, null);
            return;
        }
        if (i != 3 && i != 4) {
            if (i == 16 || i == 32) {
                setCompoundDrawablesRelative(null, this.i, null, null);
                return;
            }
            return;
        }
        setCompoundDrawablesRelative(null, null, this.i, null);
    }

    public final void d(boolean z) {
        Drawable drawable = this.i;
        if (drawable != null) {
            Drawable mutate = drawable.mutate();
            this.i = mutate;
            mutate.setTintList(this.h);
            PorterDuff.Mode mode = this.g;
            if (mode != null) {
                this.i.setTintMode(mode);
            }
            int i = this.k;
            if (i == 0) {
                i = this.i.getIntrinsicWidth();
            }
            int i2 = this.k;
            if (i2 == 0) {
                i2 = this.i.getIntrinsicHeight();
            }
            Drawable drawable2 = this.i;
            int i3 = this.l;
            int i4 = this.m;
            drawable2.setBounds(i3, i4, i + i3, i2 + i4);
            this.i.setVisible(true, z);
        }
        if (z) {
            c();
            return;
        }
        Drawable[] compoundDrawablesRelative = getCompoundDrawablesRelative();
        Drawable drawable3 = compoundDrawablesRelative[0];
        Drawable drawable4 = compoundDrawablesRelative[1];
        Drawable drawable5 = compoundDrawablesRelative[2];
        int i5 = this.q;
        if (((i5 == 1 || i5 == 2) && drawable3 != this.i) || (((i5 == 3 || i5 == 4) && drawable5 != this.i) || ((i5 == 16 || i5 == 32) && drawable4 != this.i))) {
            c();
        }
    }

    public final void e(int i, int i2) {
        boolean z;
        boolean z2;
        if (this.i != null && getLayout() != null) {
            int i3 = this.q;
            boolean z3 = true;
            if (i3 != 1 && i3 != 2) {
                z = false;
            } else {
                z = true;
            }
            if (!z && i3 != 3 && i3 != 4) {
                if (i3 == 16 || i3 == 32) {
                    this.l = 0;
                    if (i3 == 16) {
                        this.m = 0;
                        d(false);
                        return;
                    }
                    int i4 = this.k;
                    if (i4 == 0) {
                        i4 = this.i.getIntrinsicHeight();
                    }
                    int max = Math.max(0, (((((i2 - getTextHeight()) - getPaddingTop()) - i4) - this.n) - getPaddingBottom()) / 2);
                    if (this.m != max) {
                        this.m = max;
                        d(false);
                        return;
                    }
                    return;
                }
                return;
            }
            this.m = 0;
            Layout.Alignment actualTextAlignment = getActualTextAlignment();
            int i5 = this.q;
            if (i5 != 1 && i5 != 3 && ((i5 != 2 || actualTextAlignment != Layout.Alignment.ALIGN_NORMAL) && (i5 != 4 || actualTextAlignment != Layout.Alignment.ALIGN_OPPOSITE))) {
                int i6 = this.k;
                if (i6 == 0) {
                    i6 = this.i.getIntrinsicWidth();
                }
                int textLayoutWidth = i - getTextLayoutWidth();
                WeakHashMap weakHashMap = AbstractC0309ph.a;
                int paddingEnd = (((textLayoutWidth - getPaddingEnd()) - i6) - this.n) - getPaddingStart();
                if (actualTextAlignment == Layout.Alignment.ALIGN_CENTER) {
                    paddingEnd /= 2;
                }
                if (getLayoutDirection() == 1) {
                    z2 = true;
                } else {
                    z2 = false;
                }
                if (this.q != 4) {
                    z3 = false;
                }
                if (z2 != z3) {
                    paddingEnd = -paddingEnd;
                }
                if (this.l != paddingEnd) {
                    this.l = paddingEnd;
                    d(false);
                    return;
                }
                return;
            }
            this.l = 0;
            d(false);
        }
    }

    public String getA11yClassName() {
        Class cls;
        if (!TextUtils.isEmpty(this.j)) {
            return this.j;
        }
        if (a()) {
            cls = CompoundButton.class;
        } else {
            cls = Button.class;
        }
        return cls.getName();
    }

    @Override // android.view.View
    public ColorStateList getBackgroundTintList() {
        return getSupportBackgroundTintList();
    }

    @Override // android.view.View
    public PorterDuff.Mode getBackgroundTintMode() {
        return getSupportBackgroundTintMode();
    }

    public int getCornerRadius() {
        if (b()) {
            return this.d.g;
        }
        return 0;
    }

    public Drawable getIcon() {
        return this.i;
    }

    public int getIconGravity() {
        return this.q;
    }

    public int getIconPadding() {
        return this.n;
    }

    public int getIconSize() {
        return this.k;
    }

    public ColorStateList getIconTint() {
        return this.h;
    }

    public PorterDuff.Mode getIconTintMode() {
        return this.g;
    }

    public int getInsetBottom() {
        return this.d.f;
    }

    public int getInsetTop() {
        return this.d.e;
    }

    public ColorStateList getRippleColor() {
        if (b()) {
            return this.d.l;
        }
        return null;
    }

    public C0495ze getShapeAppearanceModel() {
        if (b()) {
            return this.d.b;
        }
        throw new IllegalStateException("Attempted to get ShapeAppearanceModel from a MaterialButton which has an overwritten background.");
    }

    public ColorStateList getStrokeColor() {
        if (b()) {
            return this.d.k;
        }
        return null;
    }

    public int getStrokeWidth() {
        if (b()) {
            return this.d.h;
        }
        return 0;
    }

    @Override // x.U0
    public ColorStateList getSupportBackgroundTintList() {
        if (b()) {
            return this.d.j;
        }
        return super.getSupportBackgroundTintList();
    }

    @Override // x.U0
    public PorterDuff.Mode getSupportBackgroundTintMode() {
        if (b()) {
            return this.d.i;
        }
        return super.getSupportBackgroundTintMode();
    }

    @Override // android.widget.Checkable
    public final boolean isChecked() {
        return this.o;
    }

    @Override // android.widget.TextView, android.view.View
    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (b()) {
            AbstractC0112fb.M(this, this.d.b(false));
        }
    }

    @Override // android.widget.TextView, android.view.View
    public final int[] onCreateDrawableState(int i) {
        int[] onCreateDrawableState = super.onCreateDrawableState(i + 2);
        if (a()) {
            View.mergeDrawableStates(onCreateDrawableState, r);
        }
        if (this.o) {
            View.mergeDrawableStates(onCreateDrawableState, s);
        }
        return onCreateDrawableState;
    }

    @Override // x.U0, android.view.View
    public final void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        super.onInitializeAccessibilityEvent(accessibilityEvent);
        accessibilityEvent.setClassName(getA11yClassName());
        accessibilityEvent.setChecked(this.o);
    }

    @Override // x.U0, android.view.View
    public final void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        accessibilityNodeInfo.setClassName(getA11yClassName());
        accessibilityNodeInfo.setCheckable(a());
        accessibilityNodeInfo.setChecked(this.o);
        accessibilityNodeInfo.setClickable(isClickable());
    }

    @Override // x.U0, android.widget.TextView, android.view.View
    public final void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
        e(getMeasuredWidth(), getMeasuredHeight());
    }

    @Override // android.widget.TextView, android.view.View
    public final void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof Ma)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        Ma ma = (Ma) parcelable;
        super.onRestoreInstanceState(ma.a);
        setChecked(ma.c);
    }

    /* JADX WARN: Type inference failed for: r1v0, types: [android.os.Parcelable, x.Ma, x.d] */
    @Override // android.widget.TextView, android.view.View
    public final Parcelable onSaveInstanceState() {
        ?? abstractC0060d = new AbstractC0060d(super.onSaveInstanceState());
        abstractC0060d.c = this.o;
        return abstractC0060d;
    }

    @Override // x.U0, android.widget.TextView
    public final void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        super.onTextChanged(charSequence, i, i2, i3);
        e(getMeasuredWidth(), getMeasuredHeight());
    }

    @Override // android.view.View
    public final boolean performClick() {
        if (this.d.r) {
            toggle();
        }
        return super.performClick();
    }

    @Override // android.view.View
    public final void refreshDrawableState() {
        super.refreshDrawableState();
        if (this.i != null) {
            if (this.i.setState(getDrawableState())) {
                invalidate();
            }
        }
    }

    public void setA11yClassName(String str) {
        this.j = str;
    }

    @Override // android.view.View
    public void setBackground(Drawable drawable) {
        setBackgroundDrawable(drawable);
    }

    @Override // android.view.View
    public void setBackgroundColor(int i) {
        if (b()) {
            Na na = this.d;
            if (na.b(false) != null) {
                na.b(false).setTint(i);
                return;
            }
            return;
        }
        super.setBackgroundColor(i);
    }

    @Override // x.U0, android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        if (b()) {
            if (drawable != getBackground()) {
                Log.w("MaterialButton", "MaterialButton manages its own background to control elevation, shape, color and states. Consider using backgroundTint, shapeAppearance and other attributes where available. A custom background will ignore these attributes and you should consider handling interaction states such as pressed, focused and disabled");
                Na na = this.d;
                na.o = true;
                ColorStateList colorStateList = na.j;
                MaterialButton materialButton = na.a;
                materialButton.setSupportBackgroundTintList(colorStateList);
                materialButton.setSupportBackgroundTintMode(na.i);
                super.setBackgroundDrawable(drawable);
                return;
            }
            getBackground().setState(drawable.getState());
            return;
        }
        super.setBackgroundDrawable(drawable);
    }

    @Override // x.U0, android.view.View
    public void setBackgroundResource(int i) {
        Drawable drawable;
        if (i != 0) {
            drawable = AbstractC0124g3.r(getContext(), i);
        } else {
            drawable = null;
        }
        setBackgroundDrawable(drawable);
    }

    @Override // android.view.View
    public void setBackgroundTintList(ColorStateList colorStateList) {
        setSupportBackgroundTintList(colorStateList);
    }

    @Override // android.view.View
    public void setBackgroundTintMode(PorterDuff.Mode mode) {
        setSupportBackgroundTintMode(mode);
    }

    public void setCheckable(boolean z) {
        if (b()) {
            this.d.q = z;
        }
    }

    @Override // android.widget.Checkable
    public void setChecked(boolean z) {
        if (a() && isEnabled() && this.o != z) {
            this.o = z;
            refreshDrawableState();
            if (getParent() instanceof MaterialButtonToggleGroup) {
                MaterialButtonToggleGroup materialButtonToggleGroup = (MaterialButtonToggleGroup) getParent();
                boolean z2 = this.o;
                if (!materialButtonToggleGroup.f) {
                    materialButtonToggleGroup.b(getId(), z2);
                }
            }
            if (this.p) {
                return;
            }
            this.p = true;
            Iterator it = this.e.iterator();
            if (!it.hasNext()) {
                this.p = false;
            } else {
                it.next().getClass();
                throw new ClassCastException();
            }
        }
    }

    public void setCornerRadius(int i) {
        if (b()) {
            Na na = this.d;
            if (!na.p || na.g != i) {
                na.g = i;
                na.p = true;
                float f = i;
                C0476ye e = na.b.e();
                e.e = new C0080e(f);
                e.f = new C0080e(f);
                e.g = new C0080e(f);
                e.h = new C0080e(f);
                na.c(e.a());
            }
        }
    }

    public void setCornerRadiusResource(int i) {
        if (b()) {
            setCornerRadius(getResources().getDimensionPixelSize(i));
        }
    }

    @Override // android.view.View
    public void setElevation(float f) {
        super.setElevation(f);
        if (b()) {
            this.d.b(false).i(f);
        }
    }

    public void setIcon(Drawable drawable) {
        if (this.i != drawable) {
            this.i = drawable;
            d(true);
            e(getMeasuredWidth(), getMeasuredHeight());
        }
    }

    public void setIconGravity(int i) {
        if (this.q != i) {
            this.q = i;
            e(getMeasuredWidth(), getMeasuredHeight());
        }
    }

    public void setIconPadding(int i) {
        if (this.n != i) {
            this.n = i;
            setCompoundDrawablePadding(i);
        }
    }

    public void setIconResource(int i) {
        Drawable drawable;
        if (i != 0) {
            drawable = AbstractC0124g3.r(getContext(), i);
        } else {
            drawable = null;
        }
        setIcon(drawable);
    }

    public void setIconSize(int i) {
        if (i >= 0) {
            if (this.k != i) {
                this.k = i;
                d(true);
                return;
            }
            return;
        }
        throw new IllegalArgumentException("iconSize cannot be less than 0");
    }

    public void setIconTint(ColorStateList colorStateList) {
        if (this.h != colorStateList) {
            this.h = colorStateList;
            d(false);
        }
    }

    public void setIconTintMode(PorterDuff.Mode mode) {
        if (this.g != mode) {
            this.g = mode;
            d(false);
        }
    }

    public void setIconTintResource(int i) {
        setIconTint(E9.A(getContext(), i));
    }

    public void setInsetBottom(int i) {
        Na na = this.d;
        na.d(na.e, i);
    }

    public void setInsetTop(int i) {
        Na na = this.d;
        na.d(i, na.f);
    }

    public void setInternalBackground(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
    }

    public void setOnPressedChangeListenerInternal(La la) {
        this.f = la;
    }

    @Override // android.view.View
    public void setPressed(boolean z) {
        La la = this.f;
        if (la != null) {
            ((MaterialButtonToggleGroup) ((B) la).b).invalidate();
        }
        super.setPressed(z);
    }

    public void setRippleColor(ColorStateList colorStateList) {
        if (b()) {
            Na na = this.d;
            if (na.l != colorStateList) {
                na.l = colorStateList;
                MaterialButton materialButton = na.a;
                if (materialButton.getBackground() instanceof RippleDrawable) {
                    ((RippleDrawable) materialButton.getBackground()).setColor(AbstractC0135ge.a(colorStateList));
                }
            }
        }
    }

    public void setRippleColorResource(int i) {
        if (b()) {
            setRippleColor(E9.A(getContext(), i));
        }
    }

    @Override // x.Ke
    public void setShapeAppearanceModel(C0495ze c0495ze) {
        if (b()) {
            this.d.c(c0495ze);
            return;
        }
        throw new IllegalStateException("Attempted to set ShapeAppearanceModel on a MaterialButton which has an overwritten background.");
    }

    public void setShouldDrawSurfaceColorStroke(boolean z) {
        if (b()) {
            Na na = this.d;
            na.n = z;
            na.f();
        }
    }

    public void setStrokeColor(ColorStateList colorStateList) {
        if (b()) {
            Na na = this.d;
            if (na.k != colorStateList) {
                na.k = colorStateList;
                na.f();
            }
        }
    }

    public void setStrokeColorResource(int i) {
        if (b()) {
            setStrokeColor(E9.A(getContext(), i));
        }
    }

    public void setStrokeWidth(int i) {
        if (b()) {
            Na na = this.d;
            if (na.h != i) {
                na.h = i;
                na.f();
            }
        }
    }

    public void setStrokeWidthResource(int i) {
        if (b()) {
            setStrokeWidth(getResources().getDimensionPixelSize(i));
        }
    }

    @Override // x.U0
    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        if (b()) {
            Na na = this.d;
            if (na.j != colorStateList) {
                na.j = colorStateList;
                if (na.b(false) != null) {
                    na.b(false).setTintList(na.j);
                    return;
                }
                return;
            }
            return;
        }
        super.setSupportBackgroundTintList(colorStateList);
    }

    @Override // x.U0
    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        if (b()) {
            Na na = this.d;
            if (na.i != mode) {
                na.i = mode;
                if (na.b(false) != null && na.i != null) {
                    na.b(false).setTintMode(na.i);
                    return;
                }
                return;
            }
            return;
        }
        super.setSupportBackgroundTintMode(mode);
    }

    @Override // android.view.View
    public void setTextAlignment(int i) {
        super.setTextAlignment(i);
        e(getMeasuredWidth(), getMeasuredHeight());
    }

    public void setToggleCheckedStateOnClick(boolean z) {
        this.d.r = z;
    }

    @Override // android.widget.Checkable
    public final void toggle() {
        setChecked(!this.o);
    }
}
