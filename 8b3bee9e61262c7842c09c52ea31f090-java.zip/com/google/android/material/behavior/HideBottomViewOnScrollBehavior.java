package com.google.android.material.behavior;

import android.animation.TimeInterpolator;
import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewPropertyAnimator;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import java.util.Iterator;
import java.util.LinkedHashSet;
import org.conscrypt.R;
import x.AbstractC0171ib;
import x.M4;
import x.N0;
import x.P;

/* loaded from: classes.dex */
public class HideBottomViewOnScrollBehavior<V extends View> extends M4 {
    public int b;
    public int c;
    public TimeInterpolator d;
    public TimeInterpolator e;
    public ViewPropertyAnimator h;
    public final LinkedHashSet a = new LinkedHashSet();
    public int f = 0;
    public int g = 2;

    public HideBottomViewOnScrollBehavior() {
    }

    @Override // x.M4
    public boolean g(CoordinatorLayout coordinatorLayout, View view, int i) {
        this.f = view.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) view.getLayoutParams()).bottomMargin;
        this.b = AbstractC0171ib.Q(view.getContext(), R.attr.motionDurationLong2, 225);
        this.c = AbstractC0171ib.Q(view.getContext(), R.attr.motionDurationMedium4, 175);
        this.d = AbstractC0171ib.R(view.getContext(), R.attr.motionEasingEmphasizedInterpolator, N0.d);
        this.e = AbstractC0171ib.R(view.getContext(), R.attr.motionEasingEmphasizedInterpolator, N0.c);
        return false;
    }

    @Override // x.M4
    public final void k(CoordinatorLayout coordinatorLayout, View view, int i, int i2, int i3, int[] iArr) {
        LinkedHashSet linkedHashSet = this.a;
        if (i > 0) {
            if (this.g != 1) {
                ViewPropertyAnimator viewPropertyAnimator = this.h;
                if (viewPropertyAnimator != null) {
                    viewPropertyAnimator.cancel();
                    view.clearAnimation();
                }
                this.g = 1;
                Iterator it = linkedHashSet.iterator();
                if (!it.hasNext()) {
                    this.h = view.animate().translationY(this.f).setInterpolator(this.e).setDuration(this.c).setListener(new P(3, this));
                    return;
                }
                it.next().getClass();
                throw new ClassCastException();
            }
            return;
        }
        if (i < 0 && this.g != 2) {
            ViewPropertyAnimator viewPropertyAnimator2 = this.h;
            if (viewPropertyAnimator2 != null) {
                viewPropertyAnimator2.cancel();
                view.clearAnimation();
            }
            this.g = 2;
            Iterator it2 = linkedHashSet.iterator();
            if (!it2.hasNext()) {
                this.h = view.animate().translationY(0).setInterpolator(this.d).setDuration(this.b).setListener(new P(3, this));
                return;
            }
            it2.next().getClass();
            throw new ClassCastException();
        }
    }

    @Override // x.M4
    public boolean o(View view, int i, int i2) {
        if (i == 2) {
            return true;
        }
        return false;
    }

    public HideBottomViewOnScrollBehavior(Context context, AttributeSet attributeSet) {
    }
}
