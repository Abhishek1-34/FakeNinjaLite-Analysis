package com.google.android.material.behavior;

import android.view.MotionEvent;
import android.view.View;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import java.util.WeakHashMap;
import x.AbstractC0309ph;
import x.B;
import x.C0346rh;
import x.C0442x;
import x.C0496zf;
import x.M4;

/* loaded from: classes.dex */
public class SwipeDismissBehavior<V extends View> extends M4 {
    public C0346rh a;
    public boolean b;
    public boolean c;
    public int d = 2;
    public float e = 0.0f;
    public float f = 0.5f;
    public final C0496zf g = new C0496zf(this);

    @Override // x.M4
    public boolean f(CoordinatorLayout coordinatorLayout, View view, MotionEvent motionEvent) {
        boolean z = this.b;
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked != 0) {
            if (actionMasked == 1 || actionMasked == 3) {
                this.b = false;
            }
        } else {
            z = coordinatorLayout.o(view, (int) motionEvent.getX(), (int) motionEvent.getY());
            this.b = z;
        }
        if (!z) {
            return false;
        }
        if (this.a == null) {
            this.a = new C0346rh(coordinatorLayout.getContext(), coordinatorLayout, this.g);
        }
        if (!this.c && this.a.p(motionEvent)) {
            return true;
        }
        return false;
    }

    @Override // x.M4
    public final boolean g(CoordinatorLayout coordinatorLayout, View view, int i) {
        WeakHashMap weakHashMap = AbstractC0309ph.a;
        if (view.getImportantForAccessibility() == 0) {
            view.setImportantForAccessibility(1);
            AbstractC0309ph.i(view, 1048576);
            AbstractC0309ph.g(view, 0);
            if (r(view)) {
                AbstractC0309ph.j(view, C0442x.j, new B(27, this));
            }
        }
        return false;
    }

    @Override // x.M4
    public final boolean q(View view, MotionEvent motionEvent) {
        if (this.a != null) {
            if (!this.c || motionEvent.getActionMasked() != 3) {
                this.a.j(motionEvent);
                return true;
            }
            return true;
        }
        return false;
    }

    public boolean r(View view) {
        return true;
    }
}
