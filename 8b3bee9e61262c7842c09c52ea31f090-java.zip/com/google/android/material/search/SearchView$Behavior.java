package com.google.android.material.search;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import x.M4;

/* loaded from: classes.dex */
public class SearchView$Behavior extends M4 {
    public SearchView$Behavior() {
    }

    @Override // x.M4
    public final boolean d(CoordinatorLayout coordinatorLayout, View view, View view2) {
        throw new ClassCastException();
    }

    public SearchView$Behavior(Context context, AttributeSet attributeSet) {
    }
}
