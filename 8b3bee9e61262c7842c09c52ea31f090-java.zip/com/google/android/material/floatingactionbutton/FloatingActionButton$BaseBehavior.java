package com.google.android.material.floatingactionbutton;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import x.AbstractC0191jd;
import x.M4;
import x.P4;

/* loaded from: classes.dex */
public class FloatingActionButton$BaseBehavior<T> extends M4 {
    public FloatingActionButton$BaseBehavior() {
    }

    @Override // x.M4
    public final boolean a(View view) {
        throw new ClassCastException();
    }

    @Override // x.M4
    public final void c(P4 p4) {
        if (p4.h == 0) {
            p4.h = 80;
        }
    }

    @Override // x.M4
    public final boolean d(CoordinatorLayout coordinatorLayout, View view, View view2) {
        throw new ClassCastException();
    }

    @Override // x.M4
    public final boolean g(CoordinatorLayout coordinatorLayout, View view, int i) {
        throw new ClassCastException();
    }

    public FloatingActionButton$BaseBehavior(Context context, AttributeSet attributeSet) {
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, AbstractC0191jd.g);
        obtainStyledAttributes.getBoolean(0, true);
        obtainStyledAttributes.recycle();
    }
}
