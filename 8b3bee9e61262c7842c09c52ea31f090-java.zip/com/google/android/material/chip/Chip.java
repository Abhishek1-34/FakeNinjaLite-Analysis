package com.google.android.material.chip;

import android.R;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.InsetDrawable;
import android.graphics.drawable.RippleDrawable;
import android.text.TextPaint;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.PointerIcon;
import android.view.View;
import android.view.accessibility.AccessibilityManager;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Checkable;
import android.widget.CompoundButton;
import android.widget.TextView;
import java.lang.ref.WeakReference;
import java.util.Arrays;
import java.util.Locale;
import java.util.WeakHashMap;
import org.conscrypt.BuildConfig;
import org.conscrypt.PSKKeyManager;
import x.AbstractC0112fb;
import x.AbstractC0124g3;
import x.AbstractC0135ge;
import x.AbstractC0158hh;
import x.AbstractC0191jd;
import x.AbstractC0309ph;
import x.C0024b3;
import x.C0336r7;
import x.C0495ze;
import x.Ci;
import x.E9;
import x.Ef;
import x.Ff;
import x.H3;
import x.Hf;
import x.I3;
import x.J3;
import x.K3;
import x.Ke;
import x.L3;
import x.Nb;
import x.W0;
import x.X2;
import x.Za;

/* loaded from: classes.dex */
public class Chip extends W0 implements K3, Ke, Checkable {
    public static final Rect w = new Rect();

    /* renamed from: x, reason: collision with root package name */
    public static final int[] f10x = {R.attr.state_selected};
    public static final int[] y = {R.attr.state_checkable};
    public L3 e;
    public InsetDrawable f;
    public RippleDrawable g;
    public View.OnClickListener h;
    public CompoundButton.OnCheckedChangeListener i;
    public boolean j;
    public boolean k;
    public boolean l;
    public boolean m;
    public boolean n;
    public int o;
    public int p;
    public CharSequence q;
    public final J3 r;
    public boolean s;
    public final Rect t;
    public final RectF u;
    public final H3 v;

    public Chip(Context context, AttributeSet attributeSet) {
        super(AbstractC0124g3.V(context, attributeSet, org.conscrypt.R.attr.chipStyle, org.conscrypt.R.style.Widget_MaterialComponents_Chip_Action), attributeSet, org.conscrypt.R.attr.chipStyle);
        Ef ef;
        Nb nb;
        Nb nb2;
        int resourceId;
        int resourceId2;
        int resourceId3;
        this.t = new Rect();
        this.u = new RectF();
        this.v = new H3(0, this);
        Context context2 = getContext();
        if (attributeSet != null) {
            if (attributeSet.getAttributeValue("http://schemas.android.com/apk/res/android", "background") != null) {
                Log.w("Chip", "Do not set the background; Chip manages its own background drawable.");
            }
            if (attributeSet.getAttributeValue("http://schemas.android.com/apk/res/android", "drawableLeft") == null) {
                if (attributeSet.getAttributeValue("http://schemas.android.com/apk/res/android", "drawableStart") == null) {
                    if (attributeSet.getAttributeValue("http://schemas.android.com/apk/res/android", "drawableEnd") == null) {
                        if (attributeSet.getAttributeValue("http://schemas.android.com/apk/res/android", "drawableRight") == null) {
                            if (attributeSet.getAttributeBooleanValue("http://schemas.android.com/apk/res/android", "singleLine", true) && attributeSet.getAttributeIntValue("http://schemas.android.com/apk/res/android", "lines", 1) == 1 && attributeSet.getAttributeIntValue("http://schemas.android.com/apk/res/android", "minLines", 1) == 1 && attributeSet.getAttributeIntValue("http://schemas.android.com/apk/res/android", "maxLines", 1) == 1) {
                                if (attributeSet.getAttributeIntValue("http://schemas.android.com/apk/res/android", "gravity", 8388627) != 8388627) {
                                    Log.w("Chip", "Chip text must be vertically center and start aligned");
                                }
                            } else {
                                throw new UnsupportedOperationException("Chip does not support multi-line text");
                            }
                        } else {
                            throw new UnsupportedOperationException("Please set end drawable using R.attr#closeIcon.");
                        }
                    } else {
                        throw new UnsupportedOperationException("Please set end drawable using R.attr#closeIcon.");
                    }
                } else {
                    throw new UnsupportedOperationException("Please set start drawable using R.attr#chipIcon.");
                }
            } else {
                throw new UnsupportedOperationException("Please set left drawable using R.attr#chipIcon.");
            }
        }
        L3 l3 = new L3(context2, attributeSet);
        int[] iArr = AbstractC0191jd.c;
        TypedArray O = E9.O(l3.e0, attributeSet, iArr, org.conscrypt.R.attr.chipStyle, org.conscrypt.R.style.Widget_MaterialComponents_Chip_Action, new int[0]);
        l3.E0 = O.hasValue(37);
        Context context3 = l3.e0;
        ColorStateList B = E9.B(context3, O, 24);
        if (l3.f15x != B) {
            l3.f15x = B;
            l3.onStateChange(l3.getState());
        }
        ColorStateList B2 = E9.B(context3, O, 11);
        if (l3.y != B2) {
            l3.y = B2;
            l3.onStateChange(l3.getState());
        }
        float dimension = O.getDimension(19, 0.0f);
        if (l3.z != dimension) {
            l3.z = dimension;
            l3.invalidateSelf();
            l3.u();
        }
        if (O.hasValue(12)) {
            l3.A(O.getDimension(12, 0.0f));
        }
        l3.F(E9.B(context3, O, 22));
        l3.G(O.getDimension(23, 0.0f));
        l3.P(E9.B(context3, O, 36));
        CharSequence text = O.getText(5);
        text = text == null ? BuildConfig.FLAVOR : text;
        if (!TextUtils.equals(l3.E, text)) {
            l3.E = text;
            l3.k0.d = true;
            l3.invalidateSelf();
            l3.u();
        }
        if (O.hasValue(0) && (resourceId3 = O.getResourceId(0, 0)) != 0) {
            ef = new Ef(context3, resourceId3);
        } else {
            ef = null;
        }
        ef.k = O.getDimension(1, ef.k);
        l3.Q(ef);
        int i = O.getInt(3, 0);
        if (i != 1) {
            if (i != 2) {
                if (i == 3) {
                    l3.B0 = TextUtils.TruncateAt.END;
                }
            } else {
                l3.B0 = TextUtils.TruncateAt.MIDDLE;
            }
        } else {
            l3.B0 = TextUtils.TruncateAt.START;
        }
        l3.E(O.getBoolean(18, false));
        if (attributeSet != null && attributeSet.getAttributeValue("http://schemas.android.com/apk/res-auto", "chipIconEnabled") != null && attributeSet.getAttributeValue("http://schemas.android.com/apk/res-auto", "chipIconVisible") == null) {
            l3.E(O.getBoolean(15, false));
        }
        l3.B(E9.E(context3, O, 14));
        if (O.hasValue(17)) {
            l3.D(E9.B(context3, O, 17));
        }
        l3.C(O.getDimension(16, -1.0f));
        l3.M(O.getBoolean(31, false));
        if (attributeSet != null && attributeSet.getAttributeValue("http://schemas.android.com/apk/res-auto", "closeIconEnabled") != null && attributeSet.getAttributeValue("http://schemas.android.com/apk/res-auto", "closeIconVisible") == null) {
            l3.M(O.getBoolean(26, false));
        }
        l3.H(E9.E(context3, O, 25));
        l3.L(E9.B(context3, O, 30));
        l3.J(O.getDimension(28, 0.0f));
        l3.w(O.getBoolean(6, false));
        l3.z(O.getBoolean(10, false));
        if (attributeSet != null && attributeSet.getAttributeValue("http://schemas.android.com/apk/res-auto", "checkedIconEnabled") != null && attributeSet.getAttributeValue("http://schemas.android.com/apk/res-auto", "checkedIconVisible") == null) {
            l3.z(O.getBoolean(8, false));
        }
        l3.x(E9.E(context3, O, 7));
        if (O.hasValue(9)) {
            l3.y(E9.B(context3, O, 9));
        }
        if (O.hasValue(39) && (resourceId2 = O.getResourceId(39, 0)) != 0) {
            nb = Nb.a(context3, resourceId2);
        } else {
            nb = null;
        }
        l3.U = nb;
        if (O.hasValue(33) && (resourceId = O.getResourceId(33, 0)) != 0) {
            nb2 = Nb.a(context3, resourceId);
        } else {
            nb2 = null;
        }
        l3.V = nb2;
        float dimension2 = O.getDimension(21, 0.0f);
        if (l3.W != dimension2) {
            l3.W = dimension2;
            l3.invalidateSelf();
            l3.u();
        }
        l3.O(O.getDimension(35, 0.0f));
        l3.N(O.getDimension(34, 0.0f));
        float dimension3 = O.getDimension(41, 0.0f);
        if (l3.Z != dimension3) {
            l3.Z = dimension3;
            l3.invalidateSelf();
            l3.u();
        }
        float dimension4 = O.getDimension(40, 0.0f);
        if (l3.a0 != dimension4) {
            l3.a0 = dimension4;
            l3.invalidateSelf();
            l3.u();
        }
        l3.K(O.getDimension(29, 0.0f));
        l3.I(O.getDimension(27, 0.0f));
        float dimension5 = O.getDimension(13, 0.0f);
        if (l3.d0 != dimension5) {
            l3.d0 = dimension5;
            l3.invalidateSelf();
            l3.u();
        }
        l3.D0 = O.getDimensionPixelSize(4, Integer.MAX_VALUE);
        O.recycle();
        E9.j(context2, attributeSet, org.conscrypt.R.attr.chipStyle, org.conscrypt.R.style.Widget_MaterialComponents_Chip_Action);
        E9.p(context2, attributeSet, iArr, org.conscrypt.R.attr.chipStyle, org.conscrypt.R.style.Widget_MaterialComponents_Chip_Action, new int[0]);
        TypedArray obtainStyledAttributes = context2.obtainStyledAttributes(attributeSet, iArr, org.conscrypt.R.attr.chipStyle, org.conscrypt.R.style.Widget_MaterialComponents_Chip_Action);
        this.n = obtainStyledAttributes.getBoolean(32, false);
        this.p = (int) Math.ceil(obtainStyledAttributes.getDimension(20, (float) Math.ceil(TypedValue.applyDimension(1, 48, getContext().getResources().getDisplayMetrics()))));
        obtainStyledAttributes.recycle();
        setChipDrawable(l3);
        l3.i(AbstractC0158hh.e(this));
        E9.j(context2, attributeSet, org.conscrypt.R.attr.chipStyle, org.conscrypt.R.style.Widget_MaterialComponents_Chip_Action);
        E9.p(context2, attributeSet, iArr, org.conscrypt.R.attr.chipStyle, org.conscrypt.R.style.Widget_MaterialComponents_Chip_Action, new int[0]);
        TypedArray obtainStyledAttributes2 = context2.obtainStyledAttributes(attributeSet, iArr, org.conscrypt.R.attr.chipStyle, org.conscrypt.R.style.Widget_MaterialComponents_Chip_Action);
        boolean hasValue = obtainStyledAttributes2.hasValue(37);
        obtainStyledAttributes2.recycle();
        this.r = new J3(this, this);
        e();
        if (!hasValue) {
            setOutlineProvider(new I3(this));
        }
        setChecked(this.j);
        setText(l3.E);
        setEllipsize(l3.B0);
        h();
        if (!this.e.C0) {
            setLines(1);
            setHorizontallyScrolling(true);
        }
        setGravity(8388627);
        g();
        if (this.n) {
            setMinHeight(this.p);
        }
        this.o = getLayoutDirection();
        super.setOnCheckedChangeListener(new C0336r7(9, this));
    }

    private RectF getCloseIconTouchBounds() {
        RectF rectF = this.u;
        rectF.setEmpty();
        if (c() && this.h != null) {
            L3 l3 = this.e;
            Rect bounds = l3.getBounds();
            rectF.setEmpty();
            if (l3.T()) {
                float f = l3.d0 + l3.c0 + l3.O + l3.b0 + l3.a0;
                if (l3.getLayoutDirection() == 0) {
                    float f2 = bounds.right;
                    rectF.right = f2;
                    rectF.left = f2 - f;
                } else {
                    float f3 = bounds.left;
                    rectF.left = f3;
                    rectF.right = f3 + f;
                }
                rectF.top = bounds.top;
                rectF.bottom = bounds.bottom;
            }
        }
        return rectF;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public Rect getCloseIconTouchBoundsInt() {
        RectF closeIconTouchBounds = getCloseIconTouchBounds();
        int i = (int) closeIconTouchBounds.left;
        int i2 = (int) closeIconTouchBounds.top;
        int i3 = (int) closeIconTouchBounds.right;
        int i4 = (int) closeIconTouchBounds.bottom;
        Rect rect = this.t;
        rect.set(i, i2, i3, i4);
        return rect;
    }

    private Ef getTextAppearance() {
        L3 l3 = this.e;
        if (l3 != null) {
            return l3.k0.f;
        }
        return null;
    }

    private void setCloseIconHovered(boolean z) {
        if (this.l != z) {
            this.l = z;
            refreshDrawableState();
        }
    }

    private void setCloseIconPressed(boolean z) {
        if (this.k != z) {
            this.k = z;
            refreshDrawableState();
        }
    }

    public final void b(int i) {
        int i2;
        this.p = i;
        int i3 = 0;
        if (!this.n) {
            InsetDrawable insetDrawable = this.f;
            if (insetDrawable != null) {
                if (insetDrawable != null) {
                    this.f = null;
                    setMinWidth(0);
                    setMinHeight((int) getChipMinHeight());
                    int[] iArr = AbstractC0135ge.a;
                    f();
                    return;
                }
                return;
            }
            int[] iArr2 = AbstractC0135ge.a;
            f();
            return;
        }
        int max = Math.max(0, i - ((int) this.e.z));
        int max2 = Math.max(0, i - this.e.getIntrinsicWidth());
        if (max2 <= 0 && max <= 0) {
            InsetDrawable insetDrawable2 = this.f;
            if (insetDrawable2 != null) {
                if (insetDrawable2 != null) {
                    this.f = null;
                    setMinWidth(0);
                    setMinHeight((int) getChipMinHeight());
                    int[] iArr3 = AbstractC0135ge.a;
                    f();
                    return;
                }
                return;
            }
            int[] iArr4 = AbstractC0135ge.a;
            f();
            return;
        }
        if (max2 > 0) {
            i2 = max2 / 2;
        } else {
            i2 = 0;
        }
        if (max > 0) {
            i3 = max / 2;
        }
        int i4 = i3;
        if (this.f != null) {
            Rect rect = new Rect();
            this.f.getPadding(rect);
            if (rect.top == i4 && rect.bottom == i4 && rect.left == i2 && rect.right == i2) {
                int[] iArr5 = AbstractC0135ge.a;
                f();
                return;
            }
        }
        if (getMinHeight() != i) {
            setMinHeight(i);
        }
        if (getMinWidth() != i) {
            setMinWidth(i);
        }
        this.f = new InsetDrawable((Drawable) this.e, i2, i4, i2, i4);
        int[] iArr6 = AbstractC0135ge.a;
        f();
    }

    /* JADX WARN: Removed duplicated region for block: B:9:0x0011 A[RETURN, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final boolean c() {
        L3 l3 = this.e;
        if (l3 != null) {
            Object obj = l3.L;
            if (obj != null) {
                if (obj instanceof Ci) {
                }
                if (obj == null) {
                    return true;
                }
            }
            obj = null;
            if (obj == null) {
            }
        }
        return false;
    }

    public final boolean d() {
        L3 l3 = this.e;
        if (l3 != null && l3.Q) {
            return true;
        }
        return false;
    }

    @Override // android.view.View
    public final boolean dispatchHoverEvent(MotionEvent motionEvent) {
        int i;
        int i2;
        if (!this.s) {
            return super.dispatchHoverEvent(motionEvent);
        }
        J3 j3 = this.r;
        AccessibilityManager accessibilityManager = j3.h;
        if (accessibilityManager.isEnabled() && accessibilityManager.isTouchExplorationEnabled()) {
            int action = motionEvent.getAction();
            if (action != 7 && action != 9) {
                if (action == 10 && (i2 = j3.m) != Integer.MIN_VALUE) {
                    if (i2 == Integer.MIN_VALUE) {
                        return true;
                    }
                    j3.m = Integer.MIN_VALUE;
                    j3.p(i2, PSKKeyManager.MAX_KEY_LENGTH_BYTES);
                    return true;
                }
            } else {
                float x2 = motionEvent.getX();
                float y2 = motionEvent.getY();
                Chip chip = j3.n;
                if (chip.c() && chip.getCloseIconTouchBounds().contains(x2, y2)) {
                    i = 1;
                } else {
                    i = 0;
                }
                int i3 = j3.m;
                if (i3 != i) {
                    j3.m = i;
                    j3.p(i, 128);
                    j3.p(i3, PSKKeyManager.MAX_KEY_LENGTH_BYTES);
                }
                if (i != Integer.MIN_VALUE) {
                    return true;
                }
            }
        }
        if (super.dispatchHoverEvent(motionEvent)) {
            return true;
        }
        return false;
    }

    @Override // android.view.View
    public final boolean dispatchKeyEvent(KeyEvent keyEvent) {
        if (!this.s) {
            return super.dispatchKeyEvent(keyEvent);
        }
        J3 j3 = this.r;
        j3.getClass();
        boolean z = false;
        int i = 0;
        z = false;
        z = false;
        z = false;
        z = false;
        z = false;
        if (keyEvent.getAction() != 1) {
            int keyCode = keyEvent.getKeyCode();
            if (keyCode != 61) {
                int i2 = 66;
                if (keyCode != 66) {
                    switch (keyCode) {
                        case 19:
                        case 20:
                        case 21:
                        case 22:
                            if (keyEvent.hasNoModifiers()) {
                                if (keyCode != 19) {
                                    if (keyCode != 21) {
                                        if (keyCode != 22) {
                                            i2 = 130;
                                        }
                                    } else {
                                        i2 = 17;
                                    }
                                } else {
                                    i2 = 33;
                                }
                                int repeatCount = keyEvent.getRepeatCount() + 1;
                                boolean z2 = false;
                                while (i < repeatCount && j3.m(i2, null)) {
                                    i++;
                                    z2 = true;
                                }
                                z = z2;
                                break;
                            }
                            break;
                    }
                }
                if (keyEvent.hasNoModifiers() && keyEvent.getRepeatCount() == 0) {
                    int i3 = j3.l;
                    if (i3 != Integer.MIN_VALUE) {
                        Chip chip = j3.n;
                        if (i3 == 0) {
                            chip.performClick();
                        } else if (i3 == 1) {
                            chip.playSoundEffect(0);
                            View.OnClickListener onClickListener = chip.h;
                            if (onClickListener != null) {
                                onClickListener.onClick(chip);
                            }
                            if (chip.s) {
                                chip.r.p(1, 1);
                            }
                        }
                    }
                    z = true;
                }
            } else if (keyEvent.hasNoModifiers()) {
                z = j3.m(2, null);
            } else if (keyEvent.hasModifiers(1)) {
                z = j3.m(1, null);
            }
        }
        if (z && j3.l != Integer.MIN_VALUE) {
            return true;
        }
        return super.dispatchKeyEvent(keyEvent);
    }

    /* JADX WARN: Type inference failed for: r2v0, types: [boolean, int] */
    @Override // x.W0, android.widget.CompoundButton, android.widget.TextView, android.view.View
    public final void drawableStateChanged() {
        int i;
        super.drawableStateChanged();
        L3 l3 = this.e;
        boolean z = false;
        if (l3 != null && L3.t(l3.L)) {
            L3 l32 = this.e;
            ?? isEnabled = isEnabled();
            int i2 = isEnabled;
            if (this.m) {
                i2 = isEnabled + 1;
            }
            int i3 = i2;
            if (this.l) {
                i3 = i2 + 1;
            }
            int i4 = i3;
            if (this.k) {
                i4 = i3 + 1;
            }
            int i5 = i4;
            if (isChecked()) {
                i5 = i4 + 1;
            }
            int[] iArr = new int[i5];
            if (isEnabled()) {
                iArr[0] = 16842910;
                i = 1;
            } else {
                i = 0;
            }
            if (this.m) {
                iArr[i] = 16842908;
                i++;
            }
            if (this.l) {
                iArr[i] = 16843623;
                i++;
            }
            if (this.k) {
                iArr[i] = 16842919;
                i++;
            }
            if (isChecked()) {
                iArr[i] = 16842913;
            }
            if (!Arrays.equals(l32.y0, iArr)) {
                l32.y0 = iArr;
                if (l32.T()) {
                    z = l32.v(l32.getState(), iArr);
                }
            }
        }
        if (z) {
            invalidate();
        }
    }

    public final void e() {
        L3 l3;
        if (c() && (l3 = this.e) != null && l3.K && this.h != null) {
            AbstractC0309ph.l(this, this.r);
            this.s = true;
        } else {
            AbstractC0309ph.l(this, null);
            this.s = false;
        }
    }

    public final void f() {
        this.g = new RippleDrawable(AbstractC0135ge.a(this.e.D), getBackgroundDrawable(), null);
        this.e.getClass();
        RippleDrawable rippleDrawable = this.g;
        WeakHashMap weakHashMap = AbstractC0309ph.a;
        setBackground(rippleDrawable);
        g();
    }

    public final void g() {
        L3 l3;
        if (!TextUtils.isEmpty(getText()) && (l3 = this.e) != null) {
            int q = (int) (l3.q() + l3.d0 + l3.a0);
            L3 l32 = this.e;
            int p = (int) (l32.p() + l32.W + l32.Z);
            if (this.f != null) {
                Rect rect = new Rect();
                this.f.getPadding(rect);
                p += rect.left;
                q += rect.right;
            }
            int paddingTop = getPaddingTop();
            int paddingBottom = getPaddingBottom();
            WeakHashMap weakHashMap = AbstractC0309ph.a;
            setPaddingRelative(p, paddingTop, q, paddingBottom);
        }
    }

    @Override // android.widget.CheckBox, android.widget.CompoundButton, android.widget.Button, android.widget.TextView, android.view.View
    public CharSequence getAccessibilityClassName() {
        if (!TextUtils.isEmpty(this.q)) {
            return this.q;
        }
        if (d()) {
            getParent();
            return "android.widget.Button";
        }
        if (isClickable()) {
            return "android.widget.Button";
        }
        return "android.view.View";
    }

    public Drawable getBackgroundDrawable() {
        InsetDrawable insetDrawable = this.f;
        if (insetDrawable == null) {
            return this.e;
        }
        return insetDrawable;
    }

    public Drawable getCheckedIcon() {
        L3 l3 = this.e;
        if (l3 != null) {
            return l3.S;
        }
        return null;
    }

    public ColorStateList getCheckedIconTint() {
        L3 l3 = this.e;
        if (l3 != null) {
            return l3.T;
        }
        return null;
    }

    public ColorStateList getChipBackgroundColor() {
        L3 l3 = this.e;
        if (l3 != null) {
            return l3.y;
        }
        return null;
    }

    public float getChipCornerRadius() {
        L3 l3 = this.e;
        if (l3 == null) {
            return 0.0f;
        }
        return Math.max(0.0f, l3.r());
    }

    public Drawable getChipDrawable() {
        return this.e;
    }

    public float getChipEndPadding() {
        L3 l3 = this.e;
        if (l3 != null) {
            return l3.d0;
        }
        return 0.0f;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public Drawable getChipIcon() {
        Drawable drawable;
        L3 l3 = this.e;
        if (l3 == null || (drawable = l3.G) == 0) {
            return null;
        }
        boolean z = drawable instanceof Ci;
        Drawable drawable2 = drawable;
        if (z) {
            drawable2 = null;
        }
        return drawable2;
    }

    public float getChipIconSize() {
        L3 l3 = this.e;
        if (l3 != null) {
            return l3.I;
        }
        return 0.0f;
    }

    public ColorStateList getChipIconTint() {
        L3 l3 = this.e;
        if (l3 != null) {
            return l3.H;
        }
        return null;
    }

    public float getChipMinHeight() {
        L3 l3 = this.e;
        if (l3 != null) {
            return l3.z;
        }
        return 0.0f;
    }

    public float getChipStartPadding() {
        L3 l3 = this.e;
        if (l3 != null) {
            return l3.W;
        }
        return 0.0f;
    }

    public ColorStateList getChipStrokeColor() {
        L3 l3 = this.e;
        if (l3 != null) {
            return l3.B;
        }
        return null;
    }

    public float getChipStrokeWidth() {
        L3 l3 = this.e;
        if (l3 != null) {
            return l3.C;
        }
        return 0.0f;
    }

    @Deprecated
    public CharSequence getChipText() {
        return getText();
    }

    /* JADX WARN: Multi-variable type inference failed */
    public Drawable getCloseIcon() {
        Drawable drawable;
        L3 l3 = this.e;
        if (l3 == null || (drawable = l3.L) == 0) {
            return null;
        }
        boolean z = drawable instanceof Ci;
        Drawable drawable2 = drawable;
        if (z) {
            drawable2 = null;
        }
        return drawable2;
    }

    public CharSequence getCloseIconContentDescription() {
        L3 l3 = this.e;
        if (l3 != null) {
            return l3.P;
        }
        return null;
    }

    public float getCloseIconEndPadding() {
        L3 l3 = this.e;
        if (l3 != null) {
            return l3.c0;
        }
        return 0.0f;
    }

    public float getCloseIconSize() {
        L3 l3 = this.e;
        if (l3 != null) {
            return l3.O;
        }
        return 0.0f;
    }

    public float getCloseIconStartPadding() {
        L3 l3 = this.e;
        if (l3 != null) {
            return l3.b0;
        }
        return 0.0f;
    }

    public ColorStateList getCloseIconTint() {
        L3 l3 = this.e;
        if (l3 != null) {
            return l3.N;
        }
        return null;
    }

    @Override // android.widget.TextView
    public TextUtils.TruncateAt getEllipsize() {
        L3 l3 = this.e;
        if (l3 != null) {
            return l3.B0;
        }
        return null;
    }

    @Override // android.widget.TextView, android.view.View
    public final void getFocusedRect(Rect rect) {
        if (this.s) {
            J3 j3 = this.r;
            if (j3.l == 1 || j3.k == 1) {
                rect.set(getCloseIconTouchBoundsInt());
                return;
            }
        }
        super.getFocusedRect(rect);
    }

    public Nb getHideMotionSpec() {
        L3 l3 = this.e;
        if (l3 != null) {
            return l3.V;
        }
        return null;
    }

    public float getIconEndPadding() {
        L3 l3 = this.e;
        if (l3 != null) {
            return l3.Y;
        }
        return 0.0f;
    }

    public float getIconStartPadding() {
        L3 l3 = this.e;
        if (l3 != null) {
            return l3.X;
        }
        return 0.0f;
    }

    public ColorStateList getRippleColor() {
        L3 l3 = this.e;
        if (l3 != null) {
            return l3.D;
        }
        return null;
    }

    public C0495ze getShapeAppearanceModel() {
        return this.e.a.a;
    }

    public Nb getShowMotionSpec() {
        L3 l3 = this.e;
        if (l3 != null) {
            return l3.U;
        }
        return null;
    }

    public float getTextEndPadding() {
        L3 l3 = this.e;
        if (l3 != null) {
            return l3.a0;
        }
        return 0.0f;
    }

    public float getTextStartPadding() {
        L3 l3 = this.e;
        if (l3 != null) {
            return l3.Z;
        }
        return 0.0f;
    }

    public final void h() {
        TextPaint paint = getPaint();
        L3 l3 = this.e;
        if (l3 != null) {
            paint.drawableState = l3.getState();
        }
        Ef textAppearance = getTextAppearance();
        if (textAppearance != null) {
            textAppearance.e(getContext(), paint, this.v);
        }
    }

    @Override // android.widget.TextView, android.view.View
    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
        AbstractC0112fb.M(this, this.e);
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    public final int[] onCreateDrawableState(int i) {
        int[] onCreateDrawableState = super.onCreateDrawableState(i + 2);
        if (isChecked()) {
            View.mergeDrawableStates(onCreateDrawableState, f10x);
        }
        if (d()) {
            View.mergeDrawableStates(onCreateDrawableState, y);
        }
        return onCreateDrawableState;
    }

    @Override // android.widget.TextView, android.view.View
    public final void onFocusChanged(boolean z, int i, Rect rect) {
        super.onFocusChanged(z, i, rect);
        if (this.s) {
            J3 j3 = this.r;
            int i2 = j3.l;
            if (i2 != Integer.MIN_VALUE) {
                j3.j(i2);
            }
            if (z) {
                j3.m(i, rect);
            }
        }
    }

    @Override // android.view.View
    public final boolean onHoverEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked != 7) {
            if (actionMasked == 10) {
                setCloseIconHovered(false);
            }
        } else {
            setCloseIconHovered(getCloseIconTouchBounds().contains(motionEvent.getX(), motionEvent.getY()));
        }
        return super.onHoverEvent(motionEvent);
    }

    @Override // android.view.View
    public final void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        accessibilityNodeInfo.setClassName(getAccessibilityClassName());
        accessibilityNodeInfo.setCheckable(d());
        accessibilityNodeInfo.setClickable(isClickable());
        getParent();
    }

    @Override // android.widget.Button, android.widget.TextView, android.view.View
    public final PointerIcon onResolvePointerIcon(MotionEvent motionEvent, int i) {
        if (getCloseIconTouchBounds().contains(motionEvent.getX(), motionEvent.getY()) && isEnabled()) {
            return PointerIcon.getSystemIcon(getContext(), 1002);
        }
        return super.onResolvePointerIcon(motionEvent, i);
    }

    @Override // android.widget.TextView, android.view.View
    public final void onRtlPropertiesChanged(int i) {
        super.onRtlPropertiesChanged(i);
        if (this.o != i) {
            this.o = i;
            g();
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:7:0x001e, code lost:
    
        if (r0 != 3) goto L28;
     */
    @Override // android.widget.TextView, android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        boolean z;
        int actionMasked = motionEvent.getActionMasked();
        boolean contains = getCloseIconTouchBounds().contains(motionEvent.getX(), motionEvent.getY());
        if (actionMasked != 0) {
            if (actionMasked != 1) {
                if (actionMasked == 2) {
                    if (this.k) {
                        if (!contains) {
                            setCloseIconPressed(false);
                        }
                        z = true;
                    }
                }
                z = false;
            } else if (this.k) {
                playSoundEffect(0);
                View.OnClickListener onClickListener = this.h;
                if (onClickListener != null) {
                    onClickListener.onClick(this);
                }
                if (this.s) {
                    this.r.p(1, 1);
                }
                z = true;
                setCloseIconPressed(false);
            }
            z = false;
            setCloseIconPressed(false);
        } else {
            if (contains) {
                setCloseIconPressed(true);
                z = true;
            }
            z = false;
        }
        if (!z && !super.onTouchEvent(motionEvent)) {
            return false;
        }
        return true;
    }

    public void setAccessibilityClassName(CharSequence charSequence) {
        this.q = charSequence;
    }

    @Override // android.view.View
    public void setBackground(Drawable drawable) {
        if (drawable != getBackgroundDrawable() && drawable != this.g) {
            Log.w("Chip", "Do not set the background; Chip manages its own background drawable.");
        } else {
            super.setBackground(drawable);
        }
    }

    @Override // android.view.View
    public void setBackgroundColor(int i) {
        Log.w("Chip", "Do not set the background color; Chip manages its own background drawable.");
    }

    @Override // x.W0, android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        if (drawable != getBackgroundDrawable() && drawable != this.g) {
            Log.w("Chip", "Do not set the background drawable; Chip manages its own background drawable.");
        } else {
            super.setBackgroundDrawable(drawable);
        }
    }

    @Override // x.W0, android.view.View
    public void setBackgroundResource(int i) {
        Log.w("Chip", "Do not set the background resource; Chip manages its own background drawable.");
    }

    @Override // android.view.View
    public void setBackgroundTintList(ColorStateList colorStateList) {
        Log.w("Chip", "Do not set the background tint list; Chip manages its own background drawable.");
    }

    @Override // android.view.View
    public void setBackgroundTintMode(PorterDuff.Mode mode) {
        Log.w("Chip", "Do not set the background tint mode; Chip manages its own background drawable.");
    }

    public void setCheckable(boolean z) {
        L3 l3 = this.e;
        if (l3 != null) {
            l3.w(z);
        }
    }

    public void setCheckableResource(int i) {
        L3 l3 = this.e;
        if (l3 != null) {
            l3.w(l3.e0.getResources().getBoolean(i));
        }
    }

    @Override // android.widget.CompoundButton, android.widget.Checkable
    public void setChecked(boolean z) {
        L3 l3 = this.e;
        if (l3 == null) {
            this.j = z;
        } else if (l3.Q) {
            super.setChecked(z);
        }
    }

    public void setCheckedIcon(Drawable drawable) {
        L3 l3 = this.e;
        if (l3 != null) {
            l3.x(drawable);
        }
    }

    @Deprecated
    public void setCheckedIconEnabled(boolean z) {
        setCheckedIconVisible(z);
    }

    @Deprecated
    public void setCheckedIconEnabledResource(int i) {
        setCheckedIconVisible(i);
    }

    public void setCheckedIconResource(int i) {
        L3 l3 = this.e;
        if (l3 != null) {
            l3.x(AbstractC0124g3.r(l3.e0, i));
        }
    }

    public void setCheckedIconTint(ColorStateList colorStateList) {
        L3 l3 = this.e;
        if (l3 != null) {
            l3.y(colorStateList);
        }
    }

    public void setCheckedIconTintResource(int i) {
        L3 l3 = this.e;
        if (l3 != null) {
            l3.y(E9.A(l3.e0, i));
        }
    }

    public void setCheckedIconVisible(int i) {
        L3 l3 = this.e;
        if (l3 != null) {
            l3.z(l3.e0.getResources().getBoolean(i));
        }
    }

    public void setChipBackgroundColor(ColorStateList colorStateList) {
        L3 l3 = this.e;
        if (l3 != null && l3.y != colorStateList) {
            l3.y = colorStateList;
            l3.onStateChange(l3.getState());
        }
    }

    public void setChipBackgroundColorResource(int i) {
        ColorStateList A;
        L3 l3 = this.e;
        if (l3 != null && l3.y != (A = E9.A(l3.e0, i))) {
            l3.y = A;
            l3.onStateChange(l3.getState());
        }
    }

    @Deprecated
    public void setChipCornerRadius(float f) {
        L3 l3 = this.e;
        if (l3 != null) {
            l3.A(f);
        }
    }

    @Deprecated
    public void setChipCornerRadiusResource(int i) {
        L3 l3 = this.e;
        if (l3 != null) {
            l3.A(l3.e0.getResources().getDimension(i));
        }
    }

    public void setChipDrawable(L3 l3) {
        L3 l32 = this.e;
        if (l32 != l3) {
            if (l32 != null) {
                l32.A0 = new WeakReference(null);
            }
            this.e = l3;
            l3.C0 = false;
            l3.A0 = new WeakReference(this);
            b(this.p);
        }
    }

    public void setChipEndPadding(float f) {
        L3 l3 = this.e;
        if (l3 != null && l3.d0 != f) {
            l3.d0 = f;
            l3.invalidateSelf();
            l3.u();
        }
    }

    public void setChipEndPaddingResource(int i) {
        L3 l3 = this.e;
        if (l3 != null) {
            float dimension = l3.e0.getResources().getDimension(i);
            if (l3.d0 != dimension) {
                l3.d0 = dimension;
                l3.invalidateSelf();
                l3.u();
            }
        }
    }

    public void setChipIcon(Drawable drawable) {
        L3 l3 = this.e;
        if (l3 != null) {
            l3.B(drawable);
        }
    }

    @Deprecated
    public void setChipIconEnabled(boolean z) {
        setChipIconVisible(z);
    }

    @Deprecated
    public void setChipIconEnabledResource(int i) {
        setChipIconVisible(i);
    }

    public void setChipIconResource(int i) {
        L3 l3 = this.e;
        if (l3 != null) {
            l3.B(AbstractC0124g3.r(l3.e0, i));
        }
    }

    public void setChipIconSize(float f) {
        L3 l3 = this.e;
        if (l3 != null) {
            l3.C(f);
        }
    }

    public void setChipIconSizeResource(int i) {
        L3 l3 = this.e;
        if (l3 != null) {
            l3.C(l3.e0.getResources().getDimension(i));
        }
    }

    public void setChipIconTint(ColorStateList colorStateList) {
        L3 l3 = this.e;
        if (l3 != null) {
            l3.D(colorStateList);
        }
    }

    public void setChipIconTintResource(int i) {
        L3 l3 = this.e;
        if (l3 != null) {
            l3.D(E9.A(l3.e0, i));
        }
    }

    public void setChipIconVisible(int i) {
        L3 l3 = this.e;
        if (l3 != null) {
            l3.E(l3.e0.getResources().getBoolean(i));
        }
    }

    public void setChipMinHeight(float f) {
        L3 l3 = this.e;
        if (l3 != null && l3.z != f) {
            l3.z = f;
            l3.invalidateSelf();
            l3.u();
        }
    }

    public void setChipMinHeightResource(int i) {
        L3 l3 = this.e;
        if (l3 != null) {
            float dimension = l3.e0.getResources().getDimension(i);
            if (l3.z != dimension) {
                l3.z = dimension;
                l3.invalidateSelf();
                l3.u();
            }
        }
    }

    public void setChipStartPadding(float f) {
        L3 l3 = this.e;
        if (l3 != null && l3.W != f) {
            l3.W = f;
            l3.invalidateSelf();
            l3.u();
        }
    }

    public void setChipStartPaddingResource(int i) {
        L3 l3 = this.e;
        if (l3 != null) {
            float dimension = l3.e0.getResources().getDimension(i);
            if (l3.W != dimension) {
                l3.W = dimension;
                l3.invalidateSelf();
                l3.u();
            }
        }
    }

    public void setChipStrokeColor(ColorStateList colorStateList) {
        L3 l3 = this.e;
        if (l3 != null) {
            l3.F(colorStateList);
        }
    }

    public void setChipStrokeColorResource(int i) {
        L3 l3 = this.e;
        if (l3 != null) {
            l3.F(E9.A(l3.e0, i));
        }
    }

    public void setChipStrokeWidth(float f) {
        L3 l3 = this.e;
        if (l3 != null) {
            l3.G(f);
        }
    }

    public void setChipStrokeWidthResource(int i) {
        L3 l3 = this.e;
        if (l3 != null) {
            l3.G(l3.e0.getResources().getDimension(i));
        }
    }

    @Deprecated
    public void setChipText(CharSequence charSequence) {
        setText(charSequence);
    }

    @Deprecated
    public void setChipTextResource(int i) {
        setText(getResources().getString(i));
    }

    public void setCloseIcon(Drawable drawable) {
        L3 l3 = this.e;
        if (l3 != null) {
            l3.H(drawable);
        }
        e();
    }

    public void setCloseIconContentDescription(CharSequence charSequence) {
        X2 x2;
        L3 l3 = this.e;
        if (l3 != null && l3.P != charSequence) {
            String str = X2.b;
            if (TextUtils.getLayoutDirectionFromLocale(Locale.getDefault()) == 1) {
                x2 = X2.e;
            } else {
                x2 = X2.d;
            }
            x2.getClass();
            C0024b3 c0024b3 = Ff.a;
            l3.P = x2.c(charSequence);
            l3.invalidateSelf();
        }
    }

    @Deprecated
    public void setCloseIconEnabled(boolean z) {
        setCloseIconVisible(z);
    }

    @Deprecated
    public void setCloseIconEnabledResource(int i) {
        setCloseIconVisible(i);
    }

    public void setCloseIconEndPadding(float f) {
        L3 l3 = this.e;
        if (l3 != null) {
            l3.I(f);
        }
    }

    public void setCloseIconEndPaddingResource(int i) {
        L3 l3 = this.e;
        if (l3 != null) {
            l3.I(l3.e0.getResources().getDimension(i));
        }
    }

    public void setCloseIconResource(int i) {
        L3 l3 = this.e;
        if (l3 != null) {
            l3.H(AbstractC0124g3.r(l3.e0, i));
        }
        e();
    }

    public void setCloseIconSize(float f) {
        L3 l3 = this.e;
        if (l3 != null) {
            l3.J(f);
        }
    }

    public void setCloseIconSizeResource(int i) {
        L3 l3 = this.e;
        if (l3 != null) {
            l3.J(l3.e0.getResources().getDimension(i));
        }
    }

    public void setCloseIconStartPadding(float f) {
        L3 l3 = this.e;
        if (l3 != null) {
            l3.K(f);
        }
    }

    public void setCloseIconStartPaddingResource(int i) {
        L3 l3 = this.e;
        if (l3 != null) {
            l3.K(l3.e0.getResources().getDimension(i));
        }
    }

    public void setCloseIconTint(ColorStateList colorStateList) {
        L3 l3 = this.e;
        if (l3 != null) {
            l3.L(colorStateList);
        }
    }

    public void setCloseIconTintResource(int i) {
        L3 l3 = this.e;
        if (l3 != null) {
            l3.L(E9.A(l3.e0, i));
        }
    }

    public void setCloseIconVisible(int i) {
        setCloseIconVisible(getResources().getBoolean(i));
    }

    @Override // x.W0, android.widget.TextView
    public final void setCompoundDrawables(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        if (drawable == null) {
            if (drawable3 == null) {
                super.setCompoundDrawables(drawable, drawable2, drawable3, drawable4);
                return;
            }
            throw new UnsupportedOperationException("Please set end drawable using R.attr#closeIcon.");
        }
        throw new UnsupportedOperationException("Please set start drawable using R.attr#chipIcon.");
    }

    @Override // x.W0, android.widget.TextView
    public final void setCompoundDrawablesRelative(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        if (drawable == null) {
            if (drawable3 == null) {
                super.setCompoundDrawablesRelative(drawable, drawable2, drawable3, drawable4);
                return;
            }
            throw new UnsupportedOperationException("Please set end drawable using R.attr#closeIcon.");
        }
        throw new UnsupportedOperationException("Please set start drawable using R.attr#chipIcon.");
    }

    @Override // android.widget.TextView
    public final void setCompoundDrawablesRelativeWithIntrinsicBounds(int i, int i2, int i3, int i4) {
        if (i != 0) {
            throw new UnsupportedOperationException("Please set start drawable using R.attr#chipIcon.");
        }
        if (i3 == 0) {
            super.setCompoundDrawablesRelativeWithIntrinsicBounds(i, i2, i3, i4);
            return;
        }
        throw new UnsupportedOperationException("Please set end drawable using R.attr#closeIcon.");
    }

    @Override // android.widget.TextView
    public final void setCompoundDrawablesWithIntrinsicBounds(int i, int i2, int i3, int i4) {
        if (i != 0) {
            throw new UnsupportedOperationException("Please set start drawable using R.attr#chipIcon.");
        }
        if (i3 == 0) {
            super.setCompoundDrawablesWithIntrinsicBounds(i, i2, i3, i4);
            return;
        }
        throw new UnsupportedOperationException("Please set end drawable using R.attr#closeIcon.");
    }

    @Override // android.view.View
    public void setElevation(float f) {
        super.setElevation(f);
        L3 l3 = this.e;
        if (l3 != null) {
            l3.i(f);
        }
    }

    @Override // android.widget.TextView
    public void setEllipsize(TextUtils.TruncateAt truncateAt) {
        if (this.e == null) {
            return;
        }
        if (truncateAt != TextUtils.TruncateAt.MARQUEE) {
            super.setEllipsize(truncateAt);
            L3 l3 = this.e;
            if (l3 != null) {
                l3.B0 = truncateAt;
                return;
            }
            return;
        }
        throw new UnsupportedOperationException("Text within a chip are not allowed to scroll.");
    }

    public void setEnsureMinTouchTargetSize(boolean z) {
        this.n = z;
        b(this.p);
    }

    @Override // android.widget.TextView
    public void setGravity(int i) {
        if (i != 8388627) {
            Log.w("Chip", "Chip text must be vertically center and start aligned");
        } else {
            super.setGravity(i);
        }
    }

    public void setHideMotionSpec(Nb nb) {
        L3 l3 = this.e;
        if (l3 != null) {
            l3.V = nb;
        }
    }

    public void setHideMotionSpecResource(int i) {
        L3 l3 = this.e;
        if (l3 != null) {
            l3.V = Nb.a(l3.e0, i);
        }
    }

    public void setIconEndPadding(float f) {
        L3 l3 = this.e;
        if (l3 != null) {
            l3.N(f);
        }
    }

    public void setIconEndPaddingResource(int i) {
        L3 l3 = this.e;
        if (l3 != null) {
            l3.N(l3.e0.getResources().getDimension(i));
        }
    }

    public void setIconStartPadding(float f) {
        L3 l3 = this.e;
        if (l3 != null) {
            l3.O(f);
        }
    }

    public void setIconStartPaddingResource(int i) {
        L3 l3 = this.e;
        if (l3 != null) {
            l3.O(l3.e0.getResources().getDimension(i));
        }
    }

    public void setInternalOnCheckedChangeListener(Za za) {
    }

    @Override // android.view.View
    public void setLayoutDirection(int i) {
        if (this.e == null) {
            return;
        }
        super.setLayoutDirection(i);
    }

    @Override // android.widget.TextView
    public void setLines(int i) {
        if (i <= 1) {
            super.setLines(i);
            return;
        }
        throw new UnsupportedOperationException("Chip does not support multi-line text");
    }

    @Override // android.widget.TextView
    public void setMaxLines(int i) {
        if (i <= 1) {
            super.setMaxLines(i);
            return;
        }
        throw new UnsupportedOperationException("Chip does not support multi-line text");
    }

    @Override // android.widget.TextView
    public void setMaxWidth(int i) {
        super.setMaxWidth(i);
        L3 l3 = this.e;
        if (l3 != null) {
            l3.D0 = i;
        }
    }

    @Override // android.widget.TextView
    public void setMinLines(int i) {
        if (i <= 1) {
            super.setMinLines(i);
            return;
        }
        throw new UnsupportedOperationException("Chip does not support multi-line text");
    }

    @Override // android.widget.CompoundButton
    public void setOnCheckedChangeListener(CompoundButton.OnCheckedChangeListener onCheckedChangeListener) {
        this.i = onCheckedChangeListener;
    }

    public void setOnCloseIconClickListener(View.OnClickListener onClickListener) {
        this.h = onClickListener;
        e();
    }

    public void setRippleColor(ColorStateList colorStateList) {
        L3 l3 = this.e;
        if (l3 != null) {
            l3.P(colorStateList);
        }
        this.e.getClass();
        f();
    }

    public void setRippleColorResource(int i) {
        L3 l3 = this.e;
        if (l3 != null) {
            l3.P(E9.A(l3.e0, i));
            this.e.getClass();
            f();
        }
    }

    @Override // x.Ke
    public void setShapeAppearanceModel(C0495ze c0495ze) {
        this.e.setShapeAppearanceModel(c0495ze);
    }

    public void setShowMotionSpec(Nb nb) {
        L3 l3 = this.e;
        if (l3 != null) {
            l3.U = nb;
        }
    }

    public void setShowMotionSpecResource(int i) {
        L3 l3 = this.e;
        if (l3 != null) {
            l3.U = Nb.a(l3.e0, i);
        }
    }

    @Override // android.widget.TextView
    public void setSingleLine(boolean z) {
        if (z) {
            super.setSingleLine(z);
            return;
        }
        throw new UnsupportedOperationException("Chip does not support multi-line text");
    }

    @Override // android.widget.TextView
    public final void setText(CharSequence charSequence, TextView.BufferType bufferType) {
        CharSequence charSequence2;
        L3 l3 = this.e;
        if (l3 == null) {
            return;
        }
        if (charSequence == null) {
            charSequence = BuildConfig.FLAVOR;
        }
        if (l3.C0) {
            charSequence2 = null;
        } else {
            charSequence2 = charSequence;
        }
        super.setText(charSequence2, bufferType);
        L3 l32 = this.e;
        if (l32 != null && !TextUtils.equals(l32.E, charSequence)) {
            l32.E = charSequence;
            l32.k0.d = true;
            l32.invalidateSelf();
            l32.u();
        }
    }

    public void setTextAppearance(Ef ef) {
        L3 l3 = this.e;
        if (l3 != null) {
            l3.Q(ef);
        }
        h();
    }

    public void setTextAppearanceResource(int i) {
        setTextAppearance(getContext(), i);
    }

    public void setTextEndPadding(float f) {
        L3 l3 = this.e;
        if (l3 != null && l3.a0 != f) {
            l3.a0 = f;
            l3.invalidateSelf();
            l3.u();
        }
    }

    public void setTextEndPaddingResource(int i) {
        L3 l3 = this.e;
        if (l3 != null) {
            float dimension = l3.e0.getResources().getDimension(i);
            if (l3.a0 != dimension) {
                l3.a0 = dimension;
                l3.invalidateSelf();
                l3.u();
            }
        }
    }

    @Override // android.widget.TextView
    public final void setTextSize(int i, float f) {
        super.setTextSize(i, f);
        L3 l3 = this.e;
        if (l3 != null) {
            float applyDimension = TypedValue.applyDimension(i, f, getResources().getDisplayMetrics());
            Hf hf = l3.k0;
            Ef ef = hf.f;
            if (ef != null) {
                ef.k = applyDimension;
                hf.a.setTextSize(applyDimension);
                l3.u();
                l3.invalidateSelf();
            }
        }
        h();
    }

    public void setTextStartPadding(float f) {
        L3 l3 = this.e;
        if (l3 != null && l3.Z != f) {
            l3.Z = f;
            l3.invalidateSelf();
            l3.u();
        }
    }

    public void setTextStartPaddingResource(int i) {
        L3 l3 = this.e;
        if (l3 != null) {
            float dimension = l3.e0.getResources().getDimension(i);
            if (l3.Z != dimension) {
                l3.Z = dimension;
                l3.invalidateSelf();
                l3.u();
            }
        }
    }

    public void setCloseIconVisible(boolean z) {
        L3 l3 = this.e;
        if (l3 != null) {
            l3.M(z);
        }
        e();
    }

    public void setCheckedIconVisible(boolean z) {
        L3 l3 = this.e;
        if (l3 != null) {
            l3.z(z);
        }
    }

    public void setChipIconVisible(boolean z) {
        L3 l3 = this.e;
        if (l3 != null) {
            l3.E(z);
        }
    }

    @Override // android.widget.TextView
    public final void setCompoundDrawablesRelativeWithIntrinsicBounds(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        if (drawable != null) {
            throw new UnsupportedOperationException("Please set start drawable using R.attr#chipIcon.");
        }
        if (drawable3 == null) {
            super.setCompoundDrawablesRelativeWithIntrinsicBounds(drawable, drawable2, drawable3, drawable4);
            return;
        }
        throw new UnsupportedOperationException("Please set end drawable using R.attr#closeIcon.");
    }

    @Override // android.widget.TextView
    public final void setCompoundDrawablesWithIntrinsicBounds(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        if (drawable != null) {
            throw new UnsupportedOperationException("Please set left drawable using R.attr#chipIcon.");
        }
        if (drawable3 == null) {
            super.setCompoundDrawablesWithIntrinsicBounds(drawable, drawable2, drawable3, drawable4);
            return;
        }
        throw new UnsupportedOperationException("Please set right drawable using R.attr#closeIcon.");
    }

    @Override // android.widget.TextView
    public final void setTextAppearance(Context context, int i) {
        super.setTextAppearance(context, i);
        L3 l3 = this.e;
        if (l3 != null) {
            l3.Q(new Ef(l3.e0, i));
        }
        h();
    }

    @Override // android.widget.TextView
    public void setTextAppearance(int i) {
        super.setTextAppearance(i);
        L3 l3 = this.e;
        if (l3 != null) {
            l3.Q(new Ef(l3.e0, i));
        }
        h();
    }
}
