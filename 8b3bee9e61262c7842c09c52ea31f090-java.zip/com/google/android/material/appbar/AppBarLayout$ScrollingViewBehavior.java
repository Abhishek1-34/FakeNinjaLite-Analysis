package com.google.android.material.appbar;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.View;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import java.util.ArrayList;
import java.util.WeakHashMap;
import x.AbstractC0171ib;
import x.AbstractC0191jd;
import x.AbstractC0309ph;
import x.AbstractC0498zh;
import x.M4;
import x.P4;

/* loaded from: classes.dex */
public class AppBarLayout$ScrollingViewBehavior extends AbstractC0498zh {
    public final int b;

    public AppBarLayout$ScrollingViewBehavior() {
        new Rect();
        new Rect();
    }

    public static void s(ArrayList arrayList) {
        int size = arrayList.size();
        for (int i = 0; i < size; i++) {
        }
    }

    @Override // x.M4
    public final void b(View view) {
    }

    @Override // x.M4
    public boolean d(CoordinatorLayout coordinatorLayout, View view, View view2) {
        int i;
        M4 m4 = ((P4) view2.getLayoutParams()).a;
        if (m4 instanceof AppBarLayout$BaseBehavior) {
            int bottom = view2.getBottom() - view.getTop();
            ((AppBarLayout$BaseBehavior) m4).getClass();
            int i2 = this.b;
            if (i2 == 0) {
                i = 0;
            } else {
                i = AbstractC0171ib.i((int) (0.0f * i2), 0, i2);
            }
            int i3 = bottom - i;
            WeakHashMap weakHashMap = AbstractC0309ph.a;
            view.offsetTopAndBottom(i3);
        }
        return false;
    }

    @Override // x.M4
    public final boolean h(CoordinatorLayout coordinatorLayout, View view, int i, int i2, int i3) {
        int i4 = view.getLayoutParams().height;
        if (i4 == -1 || i4 == -2) {
            s(coordinatorLayout.j(view));
            return false;
        }
        return false;
    }

    @Override // x.M4
    public final void l(CoordinatorLayout coordinatorLayout, View view) {
        s(coordinatorLayout.j(view));
    }

    @Override // x.AbstractC0498zh
    public final void r(CoordinatorLayout coordinatorLayout, View view, int i) {
        s(coordinatorLayout.j(view));
        coordinatorLayout.q(view, i);
    }

    public AppBarLayout$ScrollingViewBehavior(Context context, AttributeSet attributeSet) {
        new Rect();
        new Rect();
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, AbstractC0191jd.u);
        this.b = obtainStyledAttributes.getDimensionPixelSize(0, 0);
        obtainStyledAttributes.recycle();
    }
}
