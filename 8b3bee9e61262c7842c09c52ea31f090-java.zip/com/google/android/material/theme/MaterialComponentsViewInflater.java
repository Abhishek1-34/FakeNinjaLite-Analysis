package com.google.android.material.theme;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import com.google.android.material.button.MaterialButton;
import org.conscrypt.R;
import x.AbstractC0124g3;
import x.AbstractC0191jd;
import x.C0123g2;
import x.C0152hb;
import x.C0275o2;
import x.E9;
import x.G1;
import x.Ka;
import x.S0;
import x.U0;
import x.W0;
import x.Ya;

/* loaded from: classes.dex */
public class MaterialComponentsViewInflater extends C0275o2 {
    @Override // x.C0275o2
    public final S0 a(Context context, AttributeSet attributeSet) {
        return new Ka(context, attributeSet);
    }

    @Override // x.C0275o2
    public final U0 b(Context context, AttributeSet attributeSet) {
        return new MaterialButton(context, attributeSet);
    }

    @Override // x.C0275o2
    public final W0 c(Context context, AttributeSet attributeSet) {
        return new Ya(context, attributeSet);
    }

    /* JADX WARN: Type inference failed for: r0v0, types: [x.cb, android.widget.CompoundButton, x.G1, android.view.View] */
    @Override // x.C0275o2
    public final G1 d(Context context, AttributeSet attributeSet) {
        ?? g1 = new G1(AbstractC0124g3.V(context, attributeSet, R.attr.radioButtonStyle, R.style.Widget_MaterialComponents_CompoundButton_RadioButton), attributeSet);
        Context context2 = g1.getContext();
        TypedArray O = E9.O(context2, attributeSet, AbstractC0191jd.o, R.attr.radioButtonStyle, R.style.Widget_MaterialComponents_CompoundButton_RadioButton, new int[0]);
        if (O.hasValue(0)) {
            g1.setButtonTintList(E9.B(context2, O, 0));
        }
        g1.f = O.getBoolean(1, false);
        O.recycle();
        return g1;
    }

    @Override // x.C0275o2
    public final C0123g2 e(Context context, AttributeSet attributeSet) {
        C0123g2 c0123g2 = new C0123g2(AbstractC0124g3.V(context, attributeSet, android.R.attr.textViewStyle, 0), attributeSet, android.R.attr.textViewStyle);
        Context context2 = c0123g2.getContext();
        if (E9.g0(context2, R.attr.textAppearanceLineHeightEnabled, true)) {
            Resources.Theme theme = context2.getTheme();
            int[] iArr = AbstractC0191jd.r;
            TypedArray obtainStyledAttributes = theme.obtainStyledAttributes(attributeSet, iArr, android.R.attr.textViewStyle, 0);
            int h = C0152hb.h(context2, obtainStyledAttributes, 1, 2);
            obtainStyledAttributes.recycle();
            if (h == -1) {
                TypedArray obtainStyledAttributes2 = theme.obtainStyledAttributes(attributeSet, iArr, android.R.attr.textViewStyle, 0);
                int resourceId = obtainStyledAttributes2.getResourceId(0, -1);
                obtainStyledAttributes2.recycle();
                if (resourceId != -1) {
                    TypedArray obtainStyledAttributes3 = theme.obtainStyledAttributes(resourceId, AbstractC0191jd.q);
                    int h2 = C0152hb.h(c0123g2.getContext(), obtainStyledAttributes3, 1, 2);
                    obtainStyledAttributes3.recycle();
                    if (h2 >= 0) {
                        c0123g2.setLineHeight(h2);
                    }
                }
            }
        }
        return c0123g2;
    }
}
