package com.google.android.material.carousel;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.PointF;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.carousel.CarouselLayoutManager;
import org.conscrypt.R;
import x.AbstractC0191jd;
import x.AbstractC0475yd;
import x.C0028b7;
import x.C0314q3;
import x.C0332r3;
import x.C0351s3;
import x.C0494zd;
import x.Ed;
import x.Id;
import x.Jd;
import x.Ue;

/* loaded from: classes.dex */
public class CarouselLayoutManager extends AbstractC0475yd implements Id {
    public final C0028b7 p;
    public C0351s3 q;
    public final View.OnLayoutChangeListener r;

    public CarouselLayoutManager() {
        C0028b7 c0028b7 = new C0028b7();
        new C0332r3();
        this.r = new View.OnLayoutChangeListener() { // from class: x.p3
            @Override // android.view.View.OnLayoutChangeListener
            public final void onLayoutChange(View view, int i, int i2, int i3, int i4, int i5, int i6, int i7, int i8) {
                CarouselLayoutManager carouselLayoutManager = CarouselLayoutManager.this;
                carouselLayoutManager.getClass();
                if (i != i5 || i2 != i6 || i3 != i7 || i4 != i8) {
                    view.post(new RunnableC0141h0(2, carouselLayoutManager));
                }
            }
        };
        this.p = c0028b7;
        l0();
        C0(0);
    }

    public final boolean A0() {
        if (this.q.a == 0) {
            return true;
        }
        return false;
    }

    public final boolean B0() {
        if (A0() && C() == 1) {
            return true;
        }
        return false;
    }

    public final void C0(int i) {
        C0351s3 c0351s3;
        if (i != 0 && i != 1) {
            throw new IllegalArgumentException(Ue.d("invalid orientation:", i));
        }
        c(null);
        C0351s3 c0351s32 = this.q;
        if (c0351s32 == null || i != c0351s32.a) {
            if (i != 0) {
                if (i == 1) {
                    c0351s3 = new C0351s3(this, 0);
                } else {
                    throw new IllegalArgumentException("invalid orientation");
                }
            } else {
                c0351s3 = new C0351s3(this, 1);
            }
            this.q = c0351s3;
            l0();
        }
    }

    @Override // x.AbstractC0475yd
    public final boolean L() {
        return true;
    }

    @Override // x.AbstractC0475yd
    public final void Q(RecyclerView recyclerView) {
        C0028b7 c0028b7 = this.p;
        Context context = recyclerView.getContext();
        float f = c0028b7.a;
        if (f <= 0.0f) {
            f = context.getResources().getDimension(R.dimen.m3_carousel_small_item_size_min);
        }
        c0028b7.a = f;
        float f2 = c0028b7.b;
        if (f2 <= 0.0f) {
            f2 = context.getResources().getDimension(R.dimen.m3_carousel_small_item_size_max);
        }
        c0028b7.b = f2;
        l0();
        recyclerView.addOnLayoutChangeListener(this.r);
    }

    @Override // x.AbstractC0475yd
    public final void R(RecyclerView recyclerView) {
        recyclerView.removeOnLayoutChangeListener(this.r);
    }

    /* JADX WARN: Code restructure failed: missing block: B:51:0x003a, code lost:
    
        if (r7 == 1) goto L30;
     */
    /* JADX WARN: Code restructure failed: missing block: B:54:0x0043, code lost:
    
        if (B0() != false) goto L31;
     */
    /* JADX WARN: Code restructure failed: missing block: B:55:0x0046, code lost:
    
        if (r7 == 1) goto L31;
     */
    /* JADX WARN: Code restructure failed: missing block: B:58:0x004f, code lost:
    
        if (B0() != false) goto L30;
     */
    /* JADX WARN: Removed duplicated region for block: B:20:0x0056 A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:21:0x0057  */
    @Override // x.AbstractC0475yd
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final View S(View view, int i, Ed ed, Jd jd) {
        char c;
        if (v() == 0) {
            return null;
        }
        int i2 = this.q.a;
        if (i != 1) {
            if (i != 2) {
                if (i != 17) {
                    if (i != 33) {
                        if (i != 66) {
                            if (i != 130) {
                                Log.d("CarouselLayoutManager", "Unknown focus request:" + i);
                            }
                            c = 0;
                        } else {
                            if (i2 == 0) {
                            }
                            c = 0;
                        }
                    }
                } else {
                    if (i2 == 0) {
                    }
                    c = 0;
                }
                if (c == 0) {
                    return null;
                }
                int i3 = 0;
                if (c == 65535) {
                    if (AbstractC0475yd.H(view) == 0) {
                        return null;
                    }
                    int H = AbstractC0475yd.H(u(0)) - 1;
                    if (H >= 0 && H < B()) {
                        this.q.a();
                        throw null;
                    }
                    if (B0()) {
                        i3 = v() - 1;
                    }
                    return u(i3);
                }
                if (AbstractC0475yd.H(view) == B() - 1) {
                    return null;
                }
                int H2 = AbstractC0475yd.H(u(v() - 1)) + 1;
                if (H2 >= 0 && H2 < B()) {
                    this.q.a();
                    throw null;
                }
                if (!B0()) {
                    i3 = v() - 1;
                }
                return u(i3);
            }
            c = 1;
            if (c == 0) {
            }
        }
        c = 65535;
        if (c == 0) {
        }
    }

    @Override // x.AbstractC0475yd
    public final void T(AccessibilityEvent accessibilityEvent) {
        super.T(accessibilityEvent);
        if (v() > 0) {
            accessibilityEvent.setFromIndex(AbstractC0475yd.H(u(0)));
            accessibilityEvent.setToIndex(AbstractC0475yd.H(u(v() - 1)));
        }
    }

    @Override // x.AbstractC0475yd
    public final void W(int i, int i2) {
        B();
    }

    @Override // x.AbstractC0475yd
    public final void Z(int i, int i2) {
        B();
    }

    @Override // x.Id
    public final PointF a(int i) {
        return null;
    }

    @Override // x.AbstractC0475yd
    public final void b0(Ed ed, Jd jd) {
        int i;
        if (jd.b() > 0) {
            if (A0()) {
                i = this.n;
            } else {
                i = this.o;
            }
            if (i > 0.0f) {
                B0();
                View view = ed.i(Long.MAX_VALUE, 0).a;
                throw new IllegalStateException("All children of a RecyclerView using CarouselLayoutManager must use MaskableFrameLayout as their root ViewGroup.");
            }
        }
        g0(ed);
    }

    @Override // x.AbstractC0475yd
    public final void c0(Jd jd) {
        if (v() != 0) {
            AbstractC0475yd.H(u(0));
        }
    }

    @Override // x.AbstractC0475yd
    public final boolean d() {
        return A0();
    }

    @Override // x.AbstractC0475yd
    public final boolean e() {
        return !A0();
    }

    @Override // x.AbstractC0475yd
    public final int j(Jd jd) {
        v();
        return 0;
    }

    @Override // x.AbstractC0475yd
    public final int k(Jd jd) {
        return 0;
    }

    @Override // x.AbstractC0475yd
    public final boolean k0(RecyclerView recyclerView, View view, Rect rect, boolean z, boolean z2) {
        return false;
    }

    @Override // x.AbstractC0475yd
    public final int l(Jd jd) {
        return 0;
    }

    @Override // x.AbstractC0475yd
    public final int m(Jd jd) {
        v();
        return 0;
    }

    @Override // x.AbstractC0475yd
    public final int m0(int i, Ed ed, Jd jd) {
        if (!A0() || v() == 0 || i == 0) {
            return 0;
        }
        View view = ed.i(Long.MAX_VALUE, 0).a;
        throw new IllegalStateException("All children of a RecyclerView using CarouselLayoutManager must use MaskableFrameLayout as their root ViewGroup.");
    }

    @Override // x.AbstractC0475yd
    public final int n(Jd jd) {
        return 0;
    }

    @Override // x.AbstractC0475yd
    public final void n0(int i) {
    }

    @Override // x.AbstractC0475yd
    public final int o(Jd jd) {
        return 0;
    }

    @Override // x.AbstractC0475yd
    public final int o0(int i, Ed ed, Jd jd) {
        if (!e() || v() == 0 || i == 0) {
            return 0;
        }
        View view = ed.i(Long.MAX_VALUE, 0).a;
        throw new IllegalStateException("All children of a RecyclerView using CarouselLayoutManager must use MaskableFrameLayout as their root ViewGroup.");
    }

    @Override // x.AbstractC0475yd
    public final C0494zd r() {
        return new C0494zd(-2, -2);
    }

    @Override // x.AbstractC0475yd
    public final void x0(RecyclerView recyclerView, int i) {
        C0314q3 c0314q3 = new C0314q3(this, recyclerView.getContext(), 0);
        c0314q3.a = i;
        y0(c0314q3);
    }

    @Override // x.AbstractC0475yd
    public final void y(View view, Rect rect) {
        super.y(view, rect);
        rect.centerY();
        if (A0()) {
            rect.centerX();
        }
        throw null;
    }

    @SuppressLint({"UnknownNullness"})
    public CarouselLayoutManager(Context context, AttributeSet attributeSet, int i, int i2) {
        new C0332r3();
        this.r = new View.OnLayoutChangeListener() { // from class: x.p3
            @Override // android.view.View.OnLayoutChangeListener
            public final void onLayoutChange(View view, int i3, int i22, int i32, int i4, int i5, int i6, int i7, int i8) {
                CarouselLayoutManager carouselLayoutManager = CarouselLayoutManager.this;
                carouselLayoutManager.getClass();
                if (i3 != i5 || i22 != i6 || i32 != i7 || i4 != i8) {
                    view.post(new RunnableC0141h0(2, carouselLayoutManager));
                }
            }
        };
        this.p = new C0028b7();
        l0();
        if (attributeSet != null) {
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, AbstractC0191jd.b);
            obtainStyledAttributes.getInt(0, 0);
            l0();
            C0(obtainStyledAttributes.getInt(0, 0));
            obtainStyledAttributes.recycle();
        }
    }
}
