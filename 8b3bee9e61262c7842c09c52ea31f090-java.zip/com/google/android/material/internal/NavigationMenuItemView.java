package com.google.android.material.internal;

import android.R;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.StateListDrawable;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewStub;
import android.widget.CheckedTextView;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import java.util.WeakHashMap;
import x.AbstractC0095ee;
import x.AbstractC0171ib;
import x.AbstractC0309ph;
import x.C0031ba;
import x.C0303pb;
import x.Db;
import x.E3;
import x.X7;

/* loaded from: classes.dex */
public class NavigationMenuItemView extends X7 implements Db {
    public static final int[] G = {R.attr.state_checked};
    public FrameLayout A;
    public C0303pb B;
    public ColorStateList C;
    public boolean D;
    public Drawable E;
    public final E3 F;
    public int v;
    public boolean w;

    /* renamed from: x, reason: collision with root package name */
    public boolean f11x;
    public final boolean y;
    public final CheckedTextView z;

    public NavigationMenuItemView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.y = true;
        E3 e3 = new E3(3, this);
        this.F = e3;
        setOrientation(0);
        LayoutInflater.from(context).inflate(org.conscrypt.R.layout.design_navigation_menu_item, (ViewGroup) this, true);
        setIconSize(context.getResources().getDimensionPixelSize(org.conscrypt.R.dimen.design_navigation_icon_size));
        CheckedTextView checkedTextView = (CheckedTextView) findViewById(org.conscrypt.R.id.design_menu_item_text);
        this.z = checkedTextView;
        checkedTextView.setDuplicateParentStateEnabled(true);
        AbstractC0309ph.l(checkedTextView, e3);
    }

    private void setActionView(View view) {
        if (view != null) {
            if (this.A == null) {
                this.A = (FrameLayout) ((ViewStub) findViewById(org.conscrypt.R.id.design_menu_item_action_area_stub)).inflate();
            }
            if (view.getParent() != null) {
                ((ViewGroup) view.getParent()).removeView(view);
            }
            this.A.removeAllViews();
            this.A.addView(view);
        }
    }

    @Override // x.Db
    public final void c(C0303pb c0303pb) {
        int i;
        StateListDrawable stateListDrawable;
        this.B = c0303pb;
        int i2 = c0303pb.a;
        if (i2 > 0) {
            setId(i2);
        }
        if (c0303pb.isVisible()) {
            i = 0;
        } else {
            i = 8;
        }
        setVisibility(i);
        if (getBackground() == null) {
            TypedValue typedValue = new TypedValue();
            if (getContext().getTheme().resolveAttribute(org.conscrypt.R.attr.colorControlHighlight, typedValue, true)) {
                stateListDrawable = new StateListDrawable();
                stateListDrawable.addState(G, new ColorDrawable(typedValue.data));
                stateListDrawable.addState(ViewGroup.EMPTY_STATE_SET, new ColorDrawable(0));
            } else {
                stateListDrawable = null;
            }
            WeakHashMap weakHashMap = AbstractC0309ph.a;
            setBackground(stateListDrawable);
        }
        setCheckable(c0303pb.isCheckable());
        setChecked(c0303pb.isChecked());
        setEnabled(c0303pb.isEnabled());
        setTitle(c0303pb.e);
        setIcon(c0303pb.getIcon());
        setActionView(c0303pb.getActionView());
        setContentDescription(c0303pb.q);
        AbstractC0171ib.U(this, c0303pb.r);
        C0303pb c0303pb2 = this.B;
        CharSequence charSequence = c0303pb2.e;
        CheckedTextView checkedTextView = this.z;
        if (charSequence == null && c0303pb2.getIcon() == null && this.B.getActionView() != null) {
            checkedTextView.setVisibility(8);
            FrameLayout frameLayout = this.A;
            if (frameLayout != null) {
                C0031ba c0031ba = (C0031ba) frameLayout.getLayoutParams();
                ((LinearLayout.LayoutParams) c0031ba).width = -1;
                this.A.setLayoutParams(c0031ba);
                return;
            }
            return;
        }
        checkedTextView.setVisibility(0);
        FrameLayout frameLayout2 = this.A;
        if (frameLayout2 != null) {
            C0031ba c0031ba2 = (C0031ba) frameLayout2.getLayoutParams();
            ((LinearLayout.LayoutParams) c0031ba2).width = -2;
            this.A.setLayoutParams(c0031ba2);
        }
    }

    @Override // x.Db
    public C0303pb getItemData() {
        return this.B;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final int[] onCreateDrawableState(int i) {
        int[] onCreateDrawableState = super.onCreateDrawableState(i + 1);
        C0303pb c0303pb = this.B;
        if (c0303pb != null && c0303pb.isCheckable() && this.B.isChecked()) {
            View.mergeDrawableStates(onCreateDrawableState, G);
        }
        return onCreateDrawableState;
    }

    public void setCheckable(boolean z) {
        refreshDrawableState();
        if (this.f11x != z) {
            this.f11x = z;
            this.F.h(this.z, 2048);
        }
    }

    public void setChecked(boolean z) {
        int i;
        refreshDrawableState();
        CheckedTextView checkedTextView = this.z;
        checkedTextView.setChecked(z);
        Typeface typeface = checkedTextView.getTypeface();
        if (z && this.y) {
            i = 1;
        } else {
            i = 0;
        }
        checkedTextView.setTypeface(typeface, i);
    }

    public void setHorizontalPadding(int i) {
        setPadding(i, getPaddingTop(), i, getPaddingBottom());
    }

    public void setIcon(Drawable drawable) {
        if (drawable != null) {
            if (this.D) {
                Drawable.ConstantState constantState = drawable.getConstantState();
                if (constantState != null) {
                    drawable = constantState.newDrawable();
                }
                drawable = drawable.mutate();
                drawable.setTintList(this.C);
            }
            int i = this.v;
            drawable.setBounds(0, 0, i, i);
        } else if (this.w) {
            if (this.E == null) {
                Resources resources = getResources();
                Resources.Theme theme = getContext().getTheme();
                ThreadLocal threadLocal = AbstractC0095ee.a;
                Drawable drawable2 = resources.getDrawable(org.conscrypt.R.drawable.navigation_empty_icon, theme);
                this.E = drawable2;
                if (drawable2 != null) {
                    int i2 = this.v;
                    drawable2.setBounds(0, 0, i2, i2);
                }
            }
            drawable = this.E;
        }
        this.z.setCompoundDrawablesRelative(drawable, null, null, null);
    }

    public void setIconPadding(int i) {
        this.z.setCompoundDrawablePadding(i);
    }

    public void setIconSize(int i) {
        this.v = i;
    }

    public void setIconTintList(ColorStateList colorStateList) {
        boolean z;
        this.C = colorStateList;
        if (colorStateList != null) {
            z = true;
        } else {
            z = false;
        }
        this.D = z;
        C0303pb c0303pb = this.B;
        if (c0303pb != null) {
            setIcon(c0303pb.getIcon());
        }
    }

    public void setMaxLines(int i) {
        this.z.setMaxLines(i);
    }

    public void setNeedsEmptyIcon(boolean z) {
        this.w = z;
    }

    public void setTextAppearance(int i) {
        this.z.setTextAppearance(i);
    }

    public void setTextColor(ColorStateList colorStateList) {
        this.z.setTextColor(colorStateList);
    }

    public void setTitle(CharSequence charSequence) {
        this.z.setText(charSequence);
    }
}
