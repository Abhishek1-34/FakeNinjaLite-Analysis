package com.google.android.material.internal;

import android.R;
import android.content.Context;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import android.widget.Checkable;
import x.A1;
import x.AbstractC0060d;
import x.AbstractC0309ph;
import x.E3;
import x.F3;

/* loaded from: classes.dex */
public class CheckableImageButton extends A1 implements Checkable {
    public static final int[] g = {R.attr.state_checked};
    public boolean d;
    public boolean e;
    public boolean f;

    public CheckableImageButton(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, org.conscrypt.R.attr.imageButtonStyle);
        this.e = true;
        this.f = true;
        AbstractC0309ph.l(this, new E3(0, this));
    }

    @Override // android.widget.Checkable
    public final boolean isChecked() {
        return this.d;
    }

    @Override // android.widget.ImageView, android.view.View
    public final int[] onCreateDrawableState(int i) {
        if (this.d) {
            return View.mergeDrawableStates(super.onCreateDrawableState(i + 1), g);
        }
        return super.onCreateDrawableState(i);
    }

    @Override // android.view.View
    public final void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof F3)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        F3 f3 = (F3) parcelable;
        super.onRestoreInstanceState(f3.a);
        setChecked(f3.c);
    }

    /* JADX WARN: Type inference failed for: r1v0, types: [android.os.Parcelable, x.F3, x.d] */
    @Override // android.view.View
    public final Parcelable onSaveInstanceState() {
        ?? abstractC0060d = new AbstractC0060d(super.onSaveInstanceState());
        abstractC0060d.c = this.d;
        return abstractC0060d;
    }

    public void setCheckable(boolean z) {
        if (this.e != z) {
            this.e = z;
            sendAccessibilityEvent(0);
        }
    }

    @Override // android.widget.Checkable
    public void setChecked(boolean z) {
        if (this.e && this.d != z) {
            this.d = z;
            refreshDrawableState();
            sendAccessibilityEvent(2048);
        }
    }

    public void setPressable(boolean z) {
        this.f = z;
    }

    @Override // android.view.View
    public void setPressed(boolean z) {
        if (this.f) {
            super.setPressed(z);
        }
    }

    @Override // android.widget.Checkable
    public final void toggle() {
        setChecked(!this.d);
    }
}
