package com.google.android.material.internal;

import android.content.Context;
import android.util.AttributeSet;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import x.Eb;
import x.MenuC0246mb;

/* loaded from: classes.dex */
public class NavigationMenuView extends RecyclerView implements Eb {
    public NavigationMenuView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 0);
        setLayoutManager(new LinearLayoutManager(1));
    }

    @Override // x.Eb
    public final void a(MenuC0246mb menuC0246mb) {
    }

    public int getWindowAnimations() {
        return 0;
    }
}
