package com.google.android.material.sidesheet;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.animation.PathInterpolator;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import com.google.android.material.sidesheet.SideSheetBehavior;
import java.lang.ref.WeakReference;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.WeakHashMap;
import org.conscrypt.R;
import x.AbstractC0158hh;
import x.AbstractC0171ib;
import x.AbstractC0191jd;
import x.AbstractC0309ph;
import x.C0044c3;
import x.C0080e;
import x.C0084e3;
import x.C0092eb;
import x.C0346rh;
import x.C0442x;
import x.C0476ye;
import x.C0495ze;
import x.E9;
import x.M;
import x.M4;
import x.O9;
import x.Oe;
import x.P4;
import x.Ue;

/* loaded from: classes.dex */
public class SideSheetBehavior<V extends View> extends M4 {
    public AbstractC0171ib a;
    public final C0092eb b;
    public final ColorStateList c;
    public final C0495ze d;
    public final C0084e3 e;
    public final float f;
    public final boolean g;
    public int h;
    public C0346rh i;
    public boolean j;
    public final float k;
    public int l;
    public int m;
    public int n;
    public int o;
    public WeakReference p;
    public WeakReference q;
    public final int r;
    public VelocityTracker s;
    public int t;
    public final LinkedHashSet u;
    public final C0044c3 v;

    public SideSheetBehavior() {
        this.e = new C0084e3(this);
        this.g = true;
        this.h = 5;
        this.k = 0.1f;
        this.r = -1;
        this.u = new LinkedHashSet();
        this.v = new C0044c3(this, 1);
    }

    @Override // x.M4
    public final void c(P4 p4) {
        this.p = null;
        this.i = null;
    }

    @Override // x.M4
    public final void e() {
        this.p = null;
        this.i = null;
    }

    @Override // x.M4
    public final boolean f(CoordinatorLayout coordinatorLayout, View view, MotionEvent motionEvent) {
        C0346rh c0346rh;
        VelocityTracker velocityTracker;
        if ((view.isShown() || AbstractC0309ph.d(view) != null) && this.g) {
            int actionMasked = motionEvent.getActionMasked();
            if (actionMasked == 0 && (velocityTracker = this.s) != null) {
                velocityTracker.recycle();
                this.s = null;
            }
            if (this.s == null) {
                this.s = VelocityTracker.obtain();
            }
            this.s.addMovement(motionEvent);
            if (actionMasked != 0) {
                if ((actionMasked == 1 || actionMasked == 3) && this.j) {
                    this.j = false;
                    return false;
                }
            } else {
                this.t = (int) motionEvent.getX();
            }
            if (!this.j && (c0346rh = this.i) != null && c0346rh.p(motionEvent)) {
                return true;
            }
            return false;
        }
        this.j = true;
        return false;
    }

    @Override // x.M4
    public final boolean g(CoordinatorLayout coordinatorLayout, View view, int i) {
        int i2;
        View view2;
        View view3;
        int i3;
        int i4;
        View findViewById;
        int i5;
        int i6 = 0;
        int i7 = 1;
        C0092eb c0092eb = this.b;
        WeakHashMap weakHashMap = AbstractC0309ph.a;
        if (coordinatorLayout.getFitsSystemWindows() && !view.getFitsSystemWindows()) {
            view.setFitsSystemWindows(true);
        }
        if (this.p == null) {
            this.p = new WeakReference(view);
            Context context = view.getContext();
            AbstractC0171ib.R(context, R.attr.motionEasingStandardDecelerateInterpolator, new PathInterpolator(0.0f, 0.0f, 0.0f, 1.0f));
            AbstractC0171ib.Q(context, R.attr.motionDurationMedium2, 300);
            AbstractC0171ib.Q(context, R.attr.motionDurationShort3, 150);
            AbstractC0171ib.Q(context, R.attr.motionDurationShort2, 100);
            Resources resources = view.getResources();
            resources.getDimension(R.dimen.m3_back_progress_side_container_max_scale_x_distance_shrink);
            resources.getDimension(R.dimen.m3_back_progress_side_container_max_scale_x_distance_grow);
            resources.getDimension(R.dimen.m3_back_progress_side_container_max_scale_y_distance);
            if (c0092eb != null) {
                view.setBackground(c0092eb);
                float f = this.f;
                if (f == -1.0f) {
                    f = AbstractC0158hh.e(view);
                }
                c0092eb.i(f);
            } else {
                ColorStateList colorStateList = this.c;
                if (colorStateList != null) {
                    AbstractC0158hh.i(view, colorStateList);
                }
            }
            if (this.h == 5) {
                i5 = 4;
            } else {
                i5 = 0;
            }
            if (view.getVisibility() != i5) {
                view.setVisibility(i5);
            }
            u();
            if (view.getImportantForAccessibility() == 0) {
                view.setImportantForAccessibility(1);
            }
            if (AbstractC0309ph.d(view) == null) {
                AbstractC0309ph.m(view, view.getResources().getString(R.string.side_sheet_accessibility_pane_title));
            }
        }
        if (Gravity.getAbsoluteGravity(((P4) view.getLayoutParams()).c, i) == 3) {
            i2 = 1;
        } else {
            i2 = 0;
        }
        AbstractC0171ib abstractC0171ib = this.a;
        if (abstractC0171ib == null || abstractC0171ib.B() != i2) {
            C0495ze c0495ze = this.d;
            P4 p4 = null;
            if (i2 == 0) {
                this.a = new O9(this, i7);
                if (c0495ze != null) {
                    WeakReference weakReference = this.p;
                    if (weakReference != null && (view3 = (View) weakReference.get()) != null && (view3.getLayoutParams() instanceof P4)) {
                        p4 = (P4) view3.getLayoutParams();
                    }
                    if (p4 == null || ((ViewGroup.MarginLayoutParams) p4).rightMargin <= 0) {
                        C0476ye e = c0495ze.e();
                        e.f = new C0080e(0.0f);
                        e.g = new C0080e(0.0f);
                        C0495ze a = e.a();
                        if (c0092eb != null) {
                            c0092eb.setShapeAppearanceModel(a);
                        }
                    }
                }
            } else if (i2 == 1) {
                this.a = new O9(this, i6);
                if (c0495ze != null) {
                    WeakReference weakReference2 = this.p;
                    if (weakReference2 != null && (view2 = (View) weakReference2.get()) != null && (view2.getLayoutParams() instanceof P4)) {
                        p4 = (P4) view2.getLayoutParams();
                    }
                    if (p4 == null || ((ViewGroup.MarginLayoutParams) p4).leftMargin <= 0) {
                        C0476ye e2 = c0495ze.e();
                        e2.e = new C0080e(0.0f);
                        e2.h = new C0080e(0.0f);
                        C0495ze a2 = e2.a();
                        if (c0092eb != null) {
                            c0092eb.setShapeAppearanceModel(a2);
                        }
                    }
                }
            } else {
                throw new IllegalArgumentException("Invalid sheet edge position value: " + i2 + ". Must be 0 or 1.");
            }
        }
        if (this.i == null) {
            this.i = new C0346rh(coordinatorLayout.getContext(), coordinatorLayout, this.v);
        }
        int z = this.a.z(view);
        coordinatorLayout.q(view, i);
        this.m = coordinatorLayout.getWidth();
        this.n = this.a.A(coordinatorLayout);
        this.l = view.getWidth();
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        if (marginLayoutParams != null) {
            i3 = this.a.d(marginLayoutParams);
        } else {
            i3 = 0;
        }
        this.o = i3;
        int i8 = this.h;
        if (i8 != 1 && i8 != 2) {
            if (i8 != 3) {
                if (i8 == 5) {
                    i6 = this.a.v();
                } else {
                    throw new IllegalStateException("Unexpected value: " + this.h);
                }
            }
        } else {
            i6 = z - this.a.z(view);
        }
        view.offsetLeftAndRight(i6);
        if (this.q == null && (i4 = this.r) != -1 && (findViewById = coordinatorLayout.findViewById(i4)) != null) {
            this.q = new WeakReference(findViewById);
        }
        Iterator it = this.u.iterator();
        while (it.hasNext()) {
            if (it.next() != null) {
                throw new ClassCastException();
            }
        }
        return true;
    }

    @Override // x.M4
    public final boolean h(CoordinatorLayout coordinatorLayout, View view, int i, int i2, int i3) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        view.measure(ViewGroup.getChildMeasureSpec(i, coordinatorLayout.getPaddingRight() + coordinatorLayout.getPaddingLeft() + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + i2, marginLayoutParams.width), ViewGroup.getChildMeasureSpec(i3, coordinatorLayout.getPaddingBottom() + coordinatorLayout.getPaddingTop() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin, marginLayoutParams.height));
        return true;
    }

    @Override // x.M4
    public final void m(View view, Parcelable parcelable) {
        int i = ((Oe) parcelable).c;
        if (i == 1 || i == 2) {
            i = 5;
        }
        this.h = i;
    }

    @Override // x.M4
    public final Parcelable n(View view) {
        return new Oe(View.BaseSavedState.EMPTY_STATE, this);
    }

    @Override // x.M4
    public final boolean q(View view, MotionEvent motionEvent) {
        VelocityTracker velocityTracker;
        if (!view.isShown()) {
            return false;
        }
        int actionMasked = motionEvent.getActionMasked();
        if (this.h == 1 && actionMasked == 0) {
            return true;
        }
        if (s()) {
            this.i.j(motionEvent);
        }
        if (actionMasked == 0 && (velocityTracker = this.s) != null) {
            velocityTracker.recycle();
            this.s = null;
        }
        if (this.s == null) {
            this.s = VelocityTracker.obtain();
        }
        this.s.addMovement(motionEvent);
        if (s() && actionMasked == 2 && !this.j && s()) {
            float abs = Math.abs(this.t - motionEvent.getX());
            C0346rh c0346rh = this.i;
            if (abs > c0346rh.b) {
                c0346rh.b(view, motionEvent.getPointerId(motionEvent.getActionIndex()));
            }
        }
        return !this.j;
    }

    public final void r(int i) {
        View view;
        int i2;
        if (this.h == i) {
            return;
        }
        this.h = i;
        WeakReference weakReference = this.p;
        if (weakReference == null || (view = (View) weakReference.get()) == null) {
            return;
        }
        if (this.h == 5) {
            i2 = 4;
        } else {
            i2 = 0;
        }
        if (view.getVisibility() != i2) {
            view.setVisibility(i2);
        }
        Iterator it = this.u.iterator();
        if (!it.hasNext()) {
            u();
        } else {
            it.next().getClass();
            throw new ClassCastException();
        }
    }

    public final boolean s() {
        if (this.i != null && (this.g || this.h == 1)) {
            return true;
        }
        return false;
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x002d, code lost:
    
        if (r1.o(r0, r3.getTop()) != false) goto L24;
     */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x004d, code lost:
    
        r(2);
        r2.e.a(r4);
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:?, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x004b, code lost:
    
        if (r3 != false) goto L24;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void t(View view, int i, boolean z) {
        int u;
        if (i != 3) {
            if (i == 5) {
                u = this.a.v();
            } else {
                throw new IllegalArgumentException(Ue.d("Invalid state to get outer edge offset: ", i));
            }
        } else {
            u = this.a.u();
        }
        C0346rh c0346rh = this.i;
        if (c0346rh != null) {
            if (!z) {
                int top = view.getTop();
                c0346rh.r = view;
                c0346rh.c = -1;
                boolean h = c0346rh.h(u, top, 0, 0);
                if (!h && c0346rh.a == 0 && c0346rh.r != null) {
                    c0346rh.r = null;
                }
            }
        }
        r(i);
    }

    public final void u() {
        View view;
        WeakReference weakReference = this.p;
        if (weakReference == null || (view = (View) weakReference.get()) == null) {
            return;
        }
        AbstractC0309ph.i(view, 262144);
        AbstractC0309ph.g(view, 0);
        AbstractC0309ph.i(view, 1048576);
        AbstractC0309ph.g(view, 0);
        final int i = 5;
        if (this.h != 5) {
            AbstractC0309ph.j(view, C0442x.j, new M() { // from class: x.Ne
                @Override // x.M
                public final boolean j(View view2) {
                    String str;
                    int i2 = 1;
                    SideSheetBehavior sideSheetBehavior = SideSheetBehavior.this;
                    sideSheetBehavior.getClass();
                    int i3 = i;
                    if (i3 != 1 && i3 != 2) {
                        WeakReference weakReference2 = sideSheetBehavior.p;
                        if (weakReference2 != null && weakReference2.get() != null) {
                            View view3 = (View) sideSheetBehavior.p.get();
                            RunnableC0075de runnableC0075de = new RunnableC0075de(sideSheetBehavior, i3, i2);
                            ViewParent parent = view3.getParent();
                            if (parent != null && parent.isLayoutRequested()) {
                                WeakHashMap weakHashMap = AbstractC0309ph.a;
                                if (view3.isAttachedToWindow()) {
                                    view3.post(runnableC0075de);
                                }
                            }
                            runnableC0075de.run();
                        } else {
                            sideSheetBehavior.r(i3);
                        }
                        return true;
                    }
                    StringBuilder sb = new StringBuilder("STATE_");
                    if (i3 == 1) {
                        str = "DRAGGING";
                    } else {
                        str = "SETTLING";
                    }
                    sb.append(str);
                    sb.append(" should not be set externally.");
                    throw new IllegalArgumentException(sb.toString());
                }
            });
        }
        final int i2 = 3;
        if (this.h != 3) {
            AbstractC0309ph.j(view, C0442x.h, new M() { // from class: x.Ne
                @Override // x.M
                public final boolean j(View view2) {
                    String str;
                    int i22 = 1;
                    SideSheetBehavior sideSheetBehavior = SideSheetBehavior.this;
                    sideSheetBehavior.getClass();
                    int i3 = i2;
                    if (i3 != 1 && i3 != 2) {
                        WeakReference weakReference2 = sideSheetBehavior.p;
                        if (weakReference2 != null && weakReference2.get() != null) {
                            View view3 = (View) sideSheetBehavior.p.get();
                            RunnableC0075de runnableC0075de = new RunnableC0075de(sideSheetBehavior, i3, i22);
                            ViewParent parent = view3.getParent();
                            if (parent != null && parent.isLayoutRequested()) {
                                WeakHashMap weakHashMap = AbstractC0309ph.a;
                                if (view3.isAttachedToWindow()) {
                                    view3.post(runnableC0075de);
                                }
                            }
                            runnableC0075de.run();
                        } else {
                            sideSheetBehavior.r(i3);
                        }
                        return true;
                    }
                    StringBuilder sb = new StringBuilder("STATE_");
                    if (i3 == 1) {
                        str = "DRAGGING";
                    } else {
                        str = "SETTLING";
                    }
                    sb.append(str);
                    sb.append(" should not be set externally.");
                    throw new IllegalArgumentException(sb.toString());
                }
            });
        }
    }

    public SideSheetBehavior(Context context, AttributeSet attributeSet) {
        this.e = new C0084e3(this);
        this.g = true;
        this.h = 5;
        this.k = 0.1f;
        this.r = -1;
        this.u = new LinkedHashSet();
        this.v = new C0044c3(this, 1);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, AbstractC0191jd.w);
        if (obtainStyledAttributes.hasValue(3)) {
            this.c = E9.B(context, obtainStyledAttributes, 3);
        }
        if (obtainStyledAttributes.hasValue(6)) {
            this.d = C0495ze.b(context, attributeSet, 0, R.style.Widget_Material3_SideSheet).a();
        }
        if (obtainStyledAttributes.hasValue(5)) {
            int resourceId = obtainStyledAttributes.getResourceId(5, -1);
            this.r = resourceId;
            WeakReference weakReference = this.q;
            if (weakReference != null) {
                weakReference.clear();
            }
            this.q = null;
            WeakReference weakReference2 = this.p;
            if (weakReference2 != null) {
                View view = (View) weakReference2.get();
                if (resourceId != -1) {
                    WeakHashMap weakHashMap = AbstractC0309ph.a;
                    if (view.isLaidOut()) {
                        view.requestLayout();
                    }
                }
            }
        }
        C0495ze c0495ze = this.d;
        if (c0495ze != null) {
            C0092eb c0092eb = new C0092eb(c0495ze);
            this.b = c0092eb;
            c0092eb.h(context);
            ColorStateList colorStateList = this.c;
            if (colorStateList != null) {
                this.b.j(colorStateList);
            } else {
                TypedValue typedValue = new TypedValue();
                context.getTheme().resolveAttribute(android.R.attr.colorBackground, typedValue, true);
                this.b.setTint(typedValue.data);
            }
        }
        this.f = obtainStyledAttributes.getDimension(2, -1.0f);
        this.g = obtainStyledAttributes.getBoolean(4, true);
        obtainStyledAttributes.recycle();
        ViewConfiguration.get(context).getScaledMaximumFlingVelocity();
    }
}
