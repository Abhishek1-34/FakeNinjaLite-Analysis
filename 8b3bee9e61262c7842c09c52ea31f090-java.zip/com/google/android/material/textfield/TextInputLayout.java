package com.google.android.material.textfield;

import android.R;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.RippleDrawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Build;
import android.os.Parcelable;
import android.text.Editable;
import android.text.TextPaint;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewStructure;
import android.view.ViewTreeObserver;
import android.view.animation.LinearInterpolator;
import android.widget.AutoCompleteTextView;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.google.android.material.internal.CheckableImageButton;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.WeakHashMap;
import org.conscrypt.BuildConfig;
import x.A5;
import x.AbstractC0005a4;
import x.AbstractC0060d;
import x.AbstractC0112fb;
import x.AbstractC0124g3;
import x.AbstractC0171ib;
import x.AbstractC0191jd;
import x.AbstractC0195jh;
import x.AbstractC0309ph;
import x.AbstractC0345rg;
import x.B;
import x.C0004a3;
import x.C0024b3;
import x.C0047c6;
import x.C0072db;
import x.C0080e;
import x.C0092eb;
import x.C0107f6;
import x.C0123g2;
import x.C0167i7;
import x.C0219l3;
import x.C0294p2;
import x.C0395u9;
import x.C0414v9;
import x.C0425w1;
import x.C0476ye;
import x.C0495ze;
import x.Cif;
import x.E9;
import x.Ef;
import x.Ff;
import x.I2;
import x.I5;
import x.If;
import x.Jf;
import x.Ka;
import x.Kf;
import x.L6;
import x.Lf;
import x.N0;
import x.N6;
import x.R5;
import x.RunnableC0141h0;
import x.T4;
import x.X2;
import x.Y3;
import x.Y4;
import x.Z4;

/* loaded from: classes.dex */
public class TextInputLayout extends LinearLayout implements ViewTreeObserver.OnGlobalLayoutListener {
    public static final int[][] C0 = {new int[]{R.attr.state_pressed}, new int[0]};
    public ColorStateList A;
    public boolean A0;
    public ColorStateList B;
    public boolean B0;
    public boolean C;
    public CharSequence D;
    public boolean E;
    public C0092eb F;
    public C0092eb G;
    public StateListDrawable H;
    public boolean I;
    public C0092eb J;
    public C0092eb K;
    public C0495ze L;
    public boolean M;
    public final int N;
    public int O;
    public int P;
    public int Q;
    public int R;
    public int S;
    public int T;
    public int U;
    public final Rect V;
    public final Rect W;
    public final FrameLayout a;
    public final RectF a0;
    public final Cif b;
    public Typeface b0;
    public final N6 c;
    public ColorDrawable c0;
    public EditText d;
    public int d0;
    public CharSequence e;
    public final LinkedHashSet e0;
    public int f;
    public ColorDrawable f0;
    public int g;
    public int g0;
    public int h;
    public Drawable h0;
    public int i;
    public ColorStateList i0;
    public final C0414v9 j;
    public ColorStateList j0;
    public boolean k;
    public int k0;
    public int l;
    public int l0;
    public boolean m;
    public int m0;
    public Kf n;
    public ColorStateList n0;
    public C0123g2 o;
    public int o0;
    public int p;
    public int p0;
    public int q;
    public int q0;
    public CharSequence r;
    public int r0;
    public boolean s;
    public int s0;
    public C0123g2 t;
    public int t0;
    public ColorStateList u;
    public boolean u0;
    public int v;
    public final Y3 v0;
    public C0167i7 w;
    public boolean w0;

    /* renamed from: x, reason: collision with root package name */
    public C0167i7 f12x;
    public boolean x0;
    public ColorStateList y;
    public ValueAnimator y0;
    public ColorStateList z;
    public boolean z0;

    public TextInputLayout(Context context, AttributeSet attributeSet) {
        super(AbstractC0124g3.V(context, attributeSet, org.conscrypt.R.attr.textInputStyle, org.conscrypt.R.style.Widget_Design_TextInputLayout), attributeSet, org.conscrypt.R.attr.textInputStyle);
        this.f = -1;
        this.g = -1;
        this.h = -1;
        this.i = -1;
        this.j = new C0414v9(this);
        this.n = new I5(2);
        this.V = new Rect();
        this.W = new Rect();
        this.a0 = new RectF();
        this.e0 = new LinkedHashSet();
        Y3 y3 = new Y3(this);
        this.v0 = y3;
        this.B0 = false;
        Context context2 = getContext();
        setOrientation(1);
        setWillNotDraw(false);
        setAddStatesFromChildren(true);
        FrameLayout frameLayout = new FrameLayout(context2);
        this.a = frameLayout;
        frameLayout.setAddStatesFromChildren(true);
        LinearInterpolator linearInterpolator = N0.a;
        y3.Q = linearInterpolator;
        y3.h(false);
        y3.P = linearInterpolator;
        y3.h(false);
        if (y3.g != 8388659) {
            y3.g = 8388659;
            y3.h(false);
        }
        int[] iArr = AbstractC0191jd.A;
        E9.j(context2, attributeSet, org.conscrypt.R.attr.textInputStyle, org.conscrypt.R.style.Widget_Design_TextInputLayout);
        E9.p(context2, attributeSet, iArr, org.conscrypt.R.attr.textInputStyle, org.conscrypt.R.style.Widget_Design_TextInputLayout, 22, 20, 40, 45, 49);
        TypedArray obtainStyledAttributes = context2.obtainStyledAttributes(attributeSet, iArr, org.conscrypt.R.attr.textInputStyle, org.conscrypt.R.style.Widget_Design_TextInputLayout);
        C0294p2 c0294p2 = new C0294p2(context2, obtainStyledAttributes);
        Cif cif = new Cif(this, c0294p2);
        this.b = cif;
        this.C = obtainStyledAttributes.getBoolean(48, true);
        setHint(obtainStyledAttributes.getText(4));
        this.x0 = obtainStyledAttributes.getBoolean(47, true);
        this.w0 = obtainStyledAttributes.getBoolean(42, true);
        if (obtainStyledAttributes.hasValue(6)) {
            setMinEms(obtainStyledAttributes.getInt(6, -1));
        } else if (obtainStyledAttributes.hasValue(3)) {
            setMinWidth(obtainStyledAttributes.getDimensionPixelSize(3, -1));
        }
        if (obtainStyledAttributes.hasValue(5)) {
            setMaxEms(obtainStyledAttributes.getInt(5, -1));
        } else if (obtainStyledAttributes.hasValue(2)) {
            setMaxWidth(obtainStyledAttributes.getDimensionPixelSize(2, -1));
        }
        this.L = C0495ze.b(context2, attributeSet, org.conscrypt.R.attr.textInputStyle, org.conscrypt.R.style.Widget_Design_TextInputLayout).a();
        this.N = context2.getResources().getDimensionPixelOffset(org.conscrypt.R.dimen.mtrl_textinput_box_label_cutout_padding);
        this.P = obtainStyledAttributes.getDimensionPixelOffset(9, 0);
        this.R = obtainStyledAttributes.getDimensionPixelSize(16, context2.getResources().getDimensionPixelSize(org.conscrypt.R.dimen.mtrl_textinput_box_stroke_width_default));
        this.S = obtainStyledAttributes.getDimensionPixelSize(17, context2.getResources().getDimensionPixelSize(org.conscrypt.R.dimen.mtrl_textinput_box_stroke_width_focused));
        this.Q = this.R;
        float dimension = obtainStyledAttributes.getDimension(13, -1.0f);
        float dimension2 = obtainStyledAttributes.getDimension(12, -1.0f);
        float dimension3 = obtainStyledAttributes.getDimension(10, -1.0f);
        float dimension4 = obtainStyledAttributes.getDimension(11, -1.0f);
        C0476ye e = this.L.e();
        if (dimension >= 0.0f) {
            e.e = new C0080e(dimension);
        }
        if (dimension2 >= 0.0f) {
            e.f = new C0080e(dimension2);
        }
        if (dimension3 >= 0.0f) {
            e.g = new C0080e(dimension3);
        }
        if (dimension4 >= 0.0f) {
            e.h = new C0080e(dimension4);
        }
        this.L = e.a();
        ColorStateList C = E9.C(context2, c0294p2, 7);
        if (C != null) {
            int defaultColor = C.getDefaultColor();
            this.o0 = defaultColor;
            this.U = defaultColor;
            if (C.isStateful()) {
                this.p0 = C.getColorForState(new int[]{-16842910}, -1);
                this.q0 = C.getColorForState(new int[]{R.attr.state_focused, R.attr.state_enabled}, -1);
                this.r0 = C.getColorForState(new int[]{R.attr.state_hovered, R.attr.state_enabled}, -1);
            } else {
                this.q0 = this.o0;
                ColorStateList A = E9.A(context2, org.conscrypt.R.color.mtrl_filled_background_color);
                this.p0 = A.getColorForState(new int[]{-16842910}, -1);
                this.r0 = A.getColorForState(new int[]{R.attr.state_hovered}, -1);
            }
        } else {
            this.U = 0;
            this.o0 = 0;
            this.p0 = 0;
            this.q0 = 0;
            this.r0 = 0;
        }
        if (obtainStyledAttributes.hasValue(1)) {
            ColorStateList n = c0294p2.n(1);
            this.j0 = n;
            this.i0 = n;
        }
        ColorStateList C2 = E9.C(context2, c0294p2, 14);
        this.m0 = obtainStyledAttributes.getColor(14, 0);
        this.k0 = context2.getColor(org.conscrypt.R.color.mtrl_textinput_default_box_stroke_color);
        this.s0 = context2.getColor(org.conscrypt.R.color.mtrl_textinput_disabled_color);
        this.l0 = context2.getColor(org.conscrypt.R.color.mtrl_textinput_hovered_box_stroke_color);
        if (C2 != null) {
            setBoxStrokeColorStateList(C2);
        }
        if (obtainStyledAttributes.hasValue(15)) {
            setBoxStrokeErrorColor(E9.C(context2, c0294p2, 15));
        }
        if (obtainStyledAttributes.getResourceId(49, -1) != -1) {
            setHintTextAppearance(obtainStyledAttributes.getResourceId(49, 0));
        }
        this.A = c0294p2.n(24);
        this.B = c0294p2.n(25);
        int resourceId = obtainStyledAttributes.getResourceId(40, 0);
        CharSequence text = obtainStyledAttributes.getText(35);
        int i = obtainStyledAttributes.getInt(34, 1);
        boolean z = obtainStyledAttributes.getBoolean(36, false);
        int resourceId2 = obtainStyledAttributes.getResourceId(45, 0);
        boolean z2 = obtainStyledAttributes.getBoolean(44, false);
        CharSequence text2 = obtainStyledAttributes.getText(43);
        int resourceId3 = obtainStyledAttributes.getResourceId(57, 0);
        CharSequence text3 = obtainStyledAttributes.getText(56);
        boolean z3 = obtainStyledAttributes.getBoolean(18, false);
        setCounterMaxLength(obtainStyledAttributes.getInt(19, -1));
        this.q = obtainStyledAttributes.getResourceId(22, 0);
        this.p = obtainStyledAttributes.getResourceId(20, 0);
        setBoxBackgroundMode(obtainStyledAttributes.getInt(8, 0));
        setErrorContentDescription(text);
        setErrorAccessibilityLiveRegion(i);
        setCounterOverflowTextAppearance(this.p);
        setHelperTextTextAppearance(resourceId2);
        setErrorTextAppearance(resourceId);
        setCounterTextAppearance(this.q);
        setPlaceholderText(text3);
        setPlaceholderTextAppearance(resourceId3);
        if (obtainStyledAttributes.hasValue(41)) {
            setErrorTextColor(c0294p2.n(41));
        }
        if (obtainStyledAttributes.hasValue(46)) {
            setHelperTextColor(c0294p2.n(46));
        }
        if (obtainStyledAttributes.hasValue(50)) {
            setHintTextColor(c0294p2.n(50));
        }
        if (obtainStyledAttributes.hasValue(23)) {
            setCounterTextColor(c0294p2.n(23));
        }
        if (obtainStyledAttributes.hasValue(21)) {
            setCounterOverflowTextColor(c0294p2.n(21));
        }
        if (obtainStyledAttributes.hasValue(58)) {
            setPlaceholderTextColor(c0294p2.n(58));
        }
        N6 n6 = new N6(this, c0294p2);
        this.c = n6;
        boolean z4 = obtainStyledAttributes.getBoolean(0, true);
        c0294p2.A();
        setImportantForAccessibility(2);
        int i2 = Build.VERSION.SDK_INT;
        if (i2 >= 26 && i2 >= 26) {
            AbstractC0195jh.b(this, 1);
        }
        frameLayout.addView(cif);
        frameLayout.addView(n6);
        addView(frameLayout);
        setEnabled(z4);
        setHelperTextEnabled(z2);
        setErrorEnabled(z);
        setCounterEnabled(z3);
        setHelperText(text2);
    }

    private Drawable getEditTextBoxBackground() {
        int i;
        EditText editText = this.d;
        if ((editText instanceof AutoCompleteTextView) && !AbstractC0124g3.z(editText)) {
            int o = AbstractC0124g3.o(this.d, org.conscrypt.R.attr.colorControlHighlight);
            int i2 = this.O;
            int[][] iArr = C0;
            if (i2 == 2) {
                Context context = getContext();
                C0092eb c0092eb = this.F;
                TypedValue h0 = E9.h0(context, org.conscrypt.R.attr.colorSurface, "TextInputLayout");
                int i3 = h0.resourceId;
                if (i3 != 0) {
                    i = context.getColor(i3);
                } else {
                    i = h0.data;
                }
                C0092eb c0092eb2 = new C0092eb(c0092eb.a.a);
                int A = AbstractC0124g3.A(o, i, 0.1f);
                c0092eb2.j(new ColorStateList(iArr, new int[]{A, 0}));
                c0092eb2.setTint(i);
                ColorStateList colorStateList = new ColorStateList(iArr, new int[]{A, i});
                C0092eb c0092eb3 = new C0092eb(c0092eb.a.a);
                c0092eb3.setTint(-1);
                return new LayerDrawable(new Drawable[]{new RippleDrawable(colorStateList, c0092eb2, c0092eb3), c0092eb});
            }
            if (i2 == 1) {
                C0092eb c0092eb4 = this.F;
                int i4 = this.U;
                return new RippleDrawable(new ColorStateList(iArr, new int[]{AbstractC0124g3.A(o, i4, 0.1f), i4}), c0092eb4, c0092eb4);
            }
            return null;
        }
        return this.F;
    }

    private Drawable getOrCreateFilledDropDownMenuBackground() {
        if (this.H == null) {
            StateListDrawable stateListDrawable = new StateListDrawable();
            this.H = stateListDrawable;
            stateListDrawable.addState(new int[]{R.attr.state_above_anchor}, getOrCreateOutlinedDropDownMenuBackground());
            this.H.addState(new int[0], f(false));
        }
        return this.H;
    }

    private Drawable getOrCreateOutlinedDropDownMenuBackground() {
        if (this.G == null) {
            this.G = f(true);
        }
        return this.G;
    }

    public static void k(ViewGroup viewGroup, boolean z) {
        int childCount = viewGroup.getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = viewGroup.getChildAt(i);
            childAt.setEnabled(z);
            if (childAt instanceof ViewGroup) {
                k((ViewGroup) childAt, z);
            }
        }
    }

    private void setEditText(EditText editText) {
        if (this.d == null) {
            if (getEndIconMode() != 3 && !(editText instanceof TextInputEditText)) {
                Log.i("TextInputLayout", "EditText added is not a TextInputEditText. Please switch to using that class instead.");
            }
            this.d = editText;
            int i = this.f;
            if (i != -1) {
                setMinEms(i);
            } else {
                setMinWidth(this.h);
            }
            int i2 = this.g;
            if (i2 != -1) {
                setMaxEms(i2);
            } else {
                setMaxWidth(this.i);
            }
            this.I = false;
            i();
            setTextInputAccessibilityDelegate(new Jf(this));
            Typeface typeface = this.d.getTypeface();
            Y3 y3 = this.v0;
            y3.m(typeface);
            float textSize = this.d.getTextSize();
            if (y3.h != textSize) {
                y3.h = textSize;
                y3.h(false);
            }
            int i3 = Build.VERSION.SDK_INT;
            float letterSpacing = this.d.getLetterSpacing();
            if (y3.W != letterSpacing) {
                y3.W = letterSpacing;
                y3.h(false);
            }
            int gravity = this.d.getGravity();
            int i4 = (gravity & (-113)) | 48;
            if (y3.g != i4) {
                y3.g = i4;
                y3.h(false);
            }
            if (y3.f != gravity) {
                y3.f = gravity;
                y3.h(false);
            }
            WeakHashMap weakHashMap = AbstractC0309ph.a;
            this.t0 = editText.getMinimumHeight();
            this.d.addTextChangedListener(new If(this, editText));
            if (this.i0 == null) {
                this.i0 = this.d.getHintTextColors();
            }
            if (this.C) {
                if (TextUtils.isEmpty(this.D)) {
                    CharSequence hint = this.d.getHint();
                    this.e = hint;
                    setHint(hint);
                    this.d.setHint((CharSequence) null);
                }
                this.E = true;
            }
            if (i3 >= 29) {
                p();
            }
            if (this.o != null) {
                n(this.d.getText());
            }
            r();
            this.j.b();
            this.b.bringToFront();
            N6 n6 = this.c;
            n6.bringToFront();
            Iterator it = this.e0.iterator();
            while (it.hasNext()) {
                ((L6) it.next()).a(this);
            }
            n6.m();
            if (!isEnabled()) {
                editText.setEnabled(false);
            }
            u(false, true);
            return;
        }
        throw new IllegalArgumentException("We already have an EditText, can only have one");
    }

    private void setHintInternal(CharSequence charSequence) {
        if (!TextUtils.equals(charSequence, this.D)) {
            this.D = charSequence;
            Y3 y3 = this.v0;
            if (charSequence == null || !TextUtils.equals(y3.A, charSequence)) {
                y3.A = charSequence;
                y3.B = null;
                Bitmap bitmap = y3.E;
                if (bitmap != null) {
                    bitmap.recycle();
                    y3.E = null;
                }
                y3.h(false);
            }
            if (!this.u0) {
                j();
            }
        }
    }

    private void setPlaceholderTextEnabled(boolean z) {
        if (this.s == z) {
            return;
        }
        if (z) {
            C0123g2 c0123g2 = this.t;
            if (c0123g2 != null) {
                this.a.addView(c0123g2);
                this.t.setVisibility(0);
            }
        } else {
            C0123g2 c0123g22 = this.t;
            if (c0123g22 != null) {
                c0123g22.setVisibility(8);
            }
            this.t = null;
        }
        this.s = z;
    }

    public final void a(float f) {
        int i = 2;
        Y3 y3 = this.v0;
        if (y3.b == f) {
            return;
        }
        if (this.y0 == null) {
            ValueAnimator valueAnimator = new ValueAnimator();
            this.y0 = valueAnimator;
            valueAnimator.setInterpolator(AbstractC0171ib.R(getContext(), org.conscrypt.R.attr.motionEasingEmphasizedInterpolator, N0.b));
            this.y0.setDuration(AbstractC0171ib.Q(getContext(), org.conscrypt.R.attr.motionDurationMedium4, 167));
            this.y0.addUpdateListener(new C0004a3(i, this));
        }
        this.y0.setFloatValues(y3.b, f);
        this.y0.start();
    }

    @Override // android.view.ViewGroup
    public final void addView(View view, int i, ViewGroup.LayoutParams layoutParams) {
        if (view instanceof EditText) {
            FrameLayout.LayoutParams layoutParams2 = new FrameLayout.LayoutParams(layoutParams);
            layoutParams2.gravity = (layoutParams2.gravity & (-113)) | 16;
            FrameLayout frameLayout = this.a;
            frameLayout.addView(view, layoutParams2);
            frameLayout.setLayoutParams(layoutParams);
            t();
            setEditText((EditText) view);
            return;
        }
        super.addView(view, i, layoutParams);
    }

    public final void b() {
        ColorStateList valueOf;
        int i;
        int i2;
        C0092eb c0092eb = this.F;
        if (c0092eb == null) {
            return;
        }
        C0495ze c0495ze = c0092eb.a.a;
        C0495ze c0495ze2 = this.L;
        if (c0495ze != c0495ze2) {
            c0092eb.setShapeAppearanceModel(c0495ze2);
        }
        if (this.O == 2 && (i = this.Q) > -1 && (i2 = this.T) != 0) {
            C0092eb c0092eb2 = this.F;
            c0092eb2.a.j = i;
            c0092eb2.invalidateSelf();
            ColorStateList valueOf2 = ColorStateList.valueOf(i2);
            C0072db c0072db = c0092eb2.a;
            if (c0072db.d != valueOf2) {
                c0072db.d = valueOf2;
                c0092eb2.onStateChange(c0092eb2.getState());
            }
        }
        int i3 = this.U;
        if (this.O == 1) {
            i3 = AbstractC0005a4.b(this.U, AbstractC0124g3.n(getContext(), org.conscrypt.R.attr.colorSurface, 0));
        }
        this.U = i3;
        this.F.j(ColorStateList.valueOf(i3));
        C0092eb c0092eb3 = this.J;
        if (c0092eb3 != null && this.K != null) {
            if (this.Q > -1 && this.T != 0) {
                if (this.d.isFocused()) {
                    valueOf = ColorStateList.valueOf(this.k0);
                } else {
                    valueOf = ColorStateList.valueOf(this.T);
                }
                c0092eb3.j(valueOf);
                this.K.j(ColorStateList.valueOf(this.T));
            }
            invalidate();
        }
        s();
    }

    public final int c() {
        float d;
        if (!this.C) {
            return 0;
        }
        int i = this.O;
        Y3 y3 = this.v0;
        if (i != 0) {
            if (i != 2) {
                return 0;
            }
            d = y3.d() / 2.0f;
        } else {
            d = y3.d();
        }
        return (int) d;
    }

    public final C0167i7 d() {
        C0167i7 c0167i7 = new C0167i7();
        c0167i7.c = AbstractC0171ib.Q(getContext(), org.conscrypt.R.attr.motionDurationShort2, 87);
        c0167i7.d = AbstractC0171ib.R(getContext(), org.conscrypt.R.attr.motionEasingLinearInterpolator, N0.a);
        return c0167i7;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void dispatchProvideAutofillStructure(ViewStructure viewStructure, int i) {
        EditText editText = this.d;
        if (editText == null) {
            super.dispatchProvideAutofillStructure(viewStructure, i);
            return;
        }
        if (this.e != null) {
            boolean z = this.E;
            this.E = false;
            CharSequence hint = editText.getHint();
            this.d.setHint(this.e);
            try {
                super.dispatchProvideAutofillStructure(viewStructure, i);
                return;
            } finally {
                this.d.setHint(hint);
                this.E = z;
            }
        }
        viewStructure.setAutofillId(getAutofillId());
        onProvideAutofillStructure(viewStructure, i);
        onProvideAutofillVirtualStructure(viewStructure, i);
        FrameLayout frameLayout = this.a;
        viewStructure.setChildCount(frameLayout.getChildCount());
        for (int i2 = 0; i2 < frameLayout.getChildCount(); i2++) {
            View childAt = frameLayout.getChildAt(i2);
            ViewStructure newChild = viewStructure.newChild(i2);
            childAt.dispatchProvideAutofillStructure(newChild, i);
            if (childAt == this.d) {
                newChild.setHint(getHint());
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void dispatchRestoreInstanceState(SparseArray sparseArray) {
        this.A0 = true;
        super.dispatchRestoreInstanceState(sparseArray);
        this.A0 = false;
    }

    @Override // android.view.View
    public final void draw(Canvas canvas) {
        C0092eb c0092eb;
        int i;
        super.draw(canvas);
        boolean z = this.C;
        Y3 y3 = this.v0;
        if (z) {
            y3.getClass();
            int save = canvas.save();
            if (y3.B != null) {
                RectF rectF = y3.e;
                if (rectF.width() > 0.0f && rectF.height() > 0.0f) {
                    TextPaint textPaint = y3.N;
                    textPaint.setTextSize(y3.G);
                    float f = y3.p;
                    float f2 = y3.q;
                    float f3 = y3.F;
                    if (f3 != 1.0f) {
                        canvas.scale(f3, f3, f, f2);
                    }
                    if (y3.d0 > 1 && !y3.C) {
                        float lineStart = y3.p - y3.Y.getLineStart(0);
                        int alpha = textPaint.getAlpha();
                        canvas.translate(lineStart, f2);
                        float f4 = alpha;
                        textPaint.setAlpha((int) (y3.b0 * f4));
                        int i2 = Build.VERSION.SDK_INT;
                        if (i2 >= 31) {
                            float f5 = y3.H;
                            float f6 = y3.I;
                            float f7 = y3.J;
                            int i3 = y3.K;
                            textPaint.setShadowLayer(f5, f6, f7, AbstractC0005a4.d(i3, (textPaint.getAlpha() * Color.alpha(i3)) / 255));
                        }
                        y3.Y.draw(canvas);
                        textPaint.setAlpha((int) (y3.a0 * f4));
                        if (i2 >= 31) {
                            float f8 = y3.H;
                            float f9 = y3.I;
                            float f10 = y3.J;
                            int i4 = y3.K;
                            textPaint.setShadowLayer(f8, f9, f10, AbstractC0005a4.d(i4, (Color.alpha(i4) * textPaint.getAlpha()) / 255));
                        }
                        int lineBaseline = y3.Y.getLineBaseline(0);
                        CharSequence charSequence = y3.c0;
                        float f11 = lineBaseline;
                        canvas.drawText(charSequence, 0, charSequence.length(), 0.0f, f11, textPaint);
                        if (i2 >= 31) {
                            textPaint.setShadowLayer(y3.H, y3.I, y3.J, y3.K);
                        }
                        String trim = y3.c0.toString().trim();
                        if (trim.endsWith("…")) {
                            i = 0;
                            trim = trim.substring(0, trim.length() - 1);
                        } else {
                            i = 0;
                        }
                        String str = trim;
                        textPaint.setAlpha(alpha);
                        canvas.drawText(str, 0, Math.min(y3.Y.getLineEnd(i), str.length()), 0.0f, f11, (Paint) textPaint);
                    } else {
                        canvas.translate(f, f2);
                        y3.Y.draw(canvas);
                    }
                    canvas.restoreToCount(save);
                }
            }
        }
        if (this.K != null && (c0092eb = this.J) != null) {
            c0092eb.draw(canvas);
            if (this.d.isFocused()) {
                Rect bounds = this.K.getBounds();
                Rect bounds2 = this.J.getBounds();
                float f12 = y3.b;
                int centerX = bounds2.centerX();
                bounds.left = N0.c(centerX, bounds2.left, f12);
                bounds.right = N0.c(centerX, bounds2.right, f12);
                this.K.draw(canvas);
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:14:0x0034  */
    /* JADX WARN: Removed duplicated region for block: B:22:0x004f  */
    @Override // android.view.ViewGroup, android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void drawableStateChanged() {
        boolean z;
        ColorStateList colorStateList;
        if (this.z0) {
            return;
        }
        boolean z2 = true;
        this.z0 = true;
        super.drawableStateChanged();
        int[] drawableState = getDrawableState();
        Y3 y3 = this.v0;
        if (y3 != null) {
            y3.L = drawableState;
            ColorStateList colorStateList2 = y3.k;
            if ((colorStateList2 != null && colorStateList2.isStateful()) || ((colorStateList = y3.j) != null && colorStateList.isStateful())) {
                y3.h(false);
                z = true;
                if (this.d != null) {
                    WeakHashMap weakHashMap = AbstractC0309ph.a;
                    if (!isLaidOut() || !isEnabled()) {
                        z2 = false;
                    }
                    u(z2, false);
                }
                r();
                x();
                if (z) {
                    invalidate();
                }
                this.z0 = false;
            }
        }
        z = false;
        if (this.d != null) {
        }
        r();
        x();
        if (z) {
        }
        this.z0 = false;
    }

    public final boolean e() {
        if (this.C && !TextUtils.isEmpty(this.D) && (this.F instanceof Z4)) {
            return true;
        }
        return false;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r2v3, types: [x.ze, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r6v1, types: [x.g3, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r7v0, types: [x.g3, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r8v0, types: [x.g3, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r9v0, types: [x.g3, java.lang.Object] */
    public final C0092eb f(boolean z) {
        float f;
        float dimensionPixelOffset;
        ColorStateList colorStateList;
        int i;
        int i2 = 0;
        float dimensionPixelOffset2 = getResources().getDimensionPixelOffset(org.conscrypt.R.dimen.mtrl_shape_corner_size_small_component);
        if (z) {
            f = dimensionPixelOffset2;
        } else {
            f = 0.0f;
        }
        EditText editText = this.d;
        if (editText instanceof Ka) {
            dimensionPixelOffset = ((Ka) editText).getPopupElevation();
        } else {
            dimensionPixelOffset = getResources().getDimensionPixelOffset(org.conscrypt.R.dimen.m3_comp_outlined_autocomplete_menu_container_elevation);
        }
        int dimensionPixelOffset3 = getResources().getDimensionPixelOffset(org.conscrypt.R.dimen.mtrl_exposed_dropdown_menu_popup_vertical_padding);
        ?? obj = new Object();
        ?? obj2 = new Object();
        ?? obj3 = new Object();
        ?? obj4 = new Object();
        C0107f6 c0107f6 = new C0107f6(i2);
        C0107f6 c0107f62 = new C0107f6(i2);
        C0107f6 c0107f63 = new C0107f6(i2);
        C0107f6 c0107f64 = new C0107f6(i2);
        C0080e c0080e = new C0080e(f);
        C0080e c0080e2 = new C0080e(f);
        C0080e c0080e3 = new C0080e(dimensionPixelOffset2);
        C0080e c0080e4 = new C0080e(dimensionPixelOffset2);
        ?? obj5 = new Object();
        obj5.a = obj;
        obj5.b = obj2;
        obj5.c = obj3;
        obj5.d = obj4;
        obj5.e = c0080e;
        obj5.f = c0080e2;
        obj5.g = c0080e4;
        obj5.h = c0080e3;
        obj5.i = c0107f6;
        obj5.j = c0107f62;
        obj5.k = c0107f63;
        obj5.l = c0107f64;
        EditText editText2 = this.d;
        if (editText2 instanceof Ka) {
            colorStateList = ((Ka) editText2).getDropDownBackgroundTintList();
        } else {
            colorStateList = null;
        }
        Context context = getContext();
        if (colorStateList == null) {
            Paint paint = C0092eb.w;
            TypedValue h0 = E9.h0(context, org.conscrypt.R.attr.colorSurface, C0092eb.class.getSimpleName());
            int i3 = h0.resourceId;
            if (i3 != 0) {
                i = context.getColor(i3);
            } else {
                i = h0.data;
            }
            colorStateList = ColorStateList.valueOf(i);
        }
        C0092eb c0092eb = new C0092eb();
        c0092eb.h(context);
        c0092eb.j(colorStateList);
        c0092eb.i(dimensionPixelOffset);
        c0092eb.setShapeAppearanceModel(obj5);
        C0072db c0072db = c0092eb.a;
        if (c0072db.g == null) {
            c0072db.g = new Rect();
        }
        c0092eb.a.g.set(0, dimensionPixelOffset3, 0, dimensionPixelOffset3);
        c0092eb.invalidateSelf();
        return c0092eb;
    }

    public final int g(int i, boolean z) {
        int compoundPaddingLeft;
        if (!z && getPrefixText() != null) {
            compoundPaddingLeft = this.b.a();
        } else if (z && getSuffixText() != null) {
            compoundPaddingLeft = this.c.c();
        } else {
            compoundPaddingLeft = this.d.getCompoundPaddingLeft();
        }
        return compoundPaddingLeft + i;
    }

    @Override // android.widget.LinearLayout, android.view.View
    public int getBaseline() {
        EditText editText = this.d;
        if (editText != null) {
            return c() + getPaddingTop() + editText.getBaseline();
        }
        return super.getBaseline();
    }

    public C0092eb getBoxBackground() {
        int i = this.O;
        if (i != 1 && i != 2) {
            throw new IllegalStateException();
        }
        return this.F;
    }

    public int getBoxBackgroundColor() {
        return this.U;
    }

    public int getBoxBackgroundMode() {
        return this.O;
    }

    public int getBoxCollapsedPaddingTop() {
        return this.P;
    }

    public float getBoxCornerRadiusBottomEnd() {
        boolean v = AbstractC0112fb.v(this);
        RectF rectF = this.a0;
        if (v) {
            return this.L.h.a(rectF);
        }
        return this.L.g.a(rectF);
    }

    public float getBoxCornerRadiusBottomStart() {
        boolean v = AbstractC0112fb.v(this);
        RectF rectF = this.a0;
        if (v) {
            return this.L.g.a(rectF);
        }
        return this.L.h.a(rectF);
    }

    public float getBoxCornerRadiusTopEnd() {
        boolean v = AbstractC0112fb.v(this);
        RectF rectF = this.a0;
        if (v) {
            return this.L.e.a(rectF);
        }
        return this.L.f.a(rectF);
    }

    public float getBoxCornerRadiusTopStart() {
        boolean v = AbstractC0112fb.v(this);
        RectF rectF = this.a0;
        if (v) {
            return this.L.f.a(rectF);
        }
        return this.L.e.a(rectF);
    }

    public int getBoxStrokeColor() {
        return this.m0;
    }

    public ColorStateList getBoxStrokeErrorColor() {
        return this.n0;
    }

    public int getBoxStrokeWidth() {
        return this.R;
    }

    public int getBoxStrokeWidthFocused() {
        return this.S;
    }

    public int getCounterMaxLength() {
        return this.l;
    }

    public CharSequence getCounterOverflowDescription() {
        C0123g2 c0123g2;
        if (this.k && this.m && (c0123g2 = this.o) != null) {
            return c0123g2.getContentDescription();
        }
        return null;
    }

    public ColorStateList getCounterOverflowTextColor() {
        return this.z;
    }

    public ColorStateList getCounterTextColor() {
        return this.y;
    }

    public ColorStateList getCursorColor() {
        return this.A;
    }

    public ColorStateList getCursorErrorColor() {
        return this.B;
    }

    public ColorStateList getDefaultHintTextColor() {
        return this.i0;
    }

    public EditText getEditText() {
        return this.d;
    }

    public CharSequence getEndIconContentDescription() {
        return this.c.g.getContentDescription();
    }

    public Drawable getEndIconDrawable() {
        return this.c.g.getDrawable();
    }

    public int getEndIconMinSize() {
        return this.c.m;
    }

    public int getEndIconMode() {
        return this.c.i;
    }

    public ImageView.ScaleType getEndIconScaleType() {
        return this.c.n;
    }

    public CheckableImageButton getEndIconView() {
        return this.c.g;
    }

    public CharSequence getError() {
        C0414v9 c0414v9 = this.j;
        if (c0414v9.q) {
            return c0414v9.p;
        }
        return null;
    }

    public int getErrorAccessibilityLiveRegion() {
        return this.j.t;
    }

    public CharSequence getErrorContentDescription() {
        return this.j.s;
    }

    public int getErrorCurrentTextColors() {
        C0123g2 c0123g2 = this.j.r;
        if (c0123g2 != null) {
            return c0123g2.getCurrentTextColor();
        }
        return -1;
    }

    public Drawable getErrorIconDrawable() {
        return this.c.c.getDrawable();
    }

    public CharSequence getHelperText() {
        C0414v9 c0414v9 = this.j;
        if (c0414v9.f35x) {
            return c0414v9.w;
        }
        return null;
    }

    public int getHelperTextCurrentTextColor() {
        C0123g2 c0123g2 = this.j.y;
        if (c0123g2 != null) {
            return c0123g2.getCurrentTextColor();
        }
        return -1;
    }

    public CharSequence getHint() {
        if (this.C) {
            return this.D;
        }
        return null;
    }

    public final float getHintCollapsedTextHeight() {
        return this.v0.d();
    }

    public final int getHintCurrentCollapsedTextColor() {
        Y3 y3 = this.v0;
        return y3.e(y3.k);
    }

    public ColorStateList getHintTextColor() {
        return this.j0;
    }

    public Kf getLengthCounter() {
        return this.n;
    }

    public int getMaxEms() {
        return this.g;
    }

    public int getMaxWidth() {
        return this.i;
    }

    public int getMinEms() {
        return this.f;
    }

    public int getMinWidth() {
        return this.h;
    }

    @Deprecated
    public CharSequence getPasswordVisibilityToggleContentDescription() {
        return this.c.g.getContentDescription();
    }

    @Deprecated
    public Drawable getPasswordVisibilityToggleDrawable() {
        return this.c.g.getDrawable();
    }

    public CharSequence getPlaceholderText() {
        if (this.s) {
            return this.r;
        }
        return null;
    }

    public int getPlaceholderTextAppearance() {
        return this.v;
    }

    public ColorStateList getPlaceholderTextColor() {
        return this.u;
    }

    public CharSequence getPrefixText() {
        return this.b.c;
    }

    public ColorStateList getPrefixTextColor() {
        return this.b.b.getTextColors();
    }

    public TextView getPrefixTextView() {
        return this.b.b;
    }

    public C0495ze getShapeAppearanceModel() {
        return this.L;
    }

    public CharSequence getStartIconContentDescription() {
        return this.b.d.getContentDescription();
    }

    public Drawable getStartIconDrawable() {
        return this.b.d.getDrawable();
    }

    public int getStartIconMinSize() {
        return this.b.g;
    }

    public ImageView.ScaleType getStartIconScaleType() {
        return this.b.h;
    }

    public CharSequence getSuffixText() {
        return this.c.p;
    }

    public ColorStateList getSuffixTextColor() {
        return this.c.q.getTextColors();
    }

    public TextView getSuffixTextView() {
        return this.c.q;
    }

    public Typeface getTypeface() {
        return this.b0;
    }

    public final int h(int i, boolean z) {
        int compoundPaddingRight;
        if (!z && getSuffixText() != null) {
            compoundPaddingRight = this.c.c();
        } else if (z && getPrefixText() != null) {
            compoundPaddingRight = this.b.a();
        } else {
            compoundPaddingRight = this.d.getCompoundPaddingRight();
        }
        return i - compoundPaddingRight;
    }

    /* JADX WARN: Type inference failed for: r0v37, types: [x.eb, x.Z4] */
    public final void i() {
        int i = this.O;
        if (i != 0) {
            if (i != 1) {
                if (i == 2) {
                    if (this.C && !(this.F instanceof Z4)) {
                        C0495ze c0495ze = this.L;
                        int i2 = Z4.y;
                        if (c0495ze == null) {
                            c0495ze = new C0495ze();
                        }
                        Y4 y4 = new Y4(c0495ze, new RectF());
                        ?? c0092eb = new C0092eb(y4);
                        c0092eb.f19x = y4;
                        this.F = c0092eb;
                    } else {
                        this.F = new C0092eb(this.L);
                    }
                    this.J = null;
                    this.K = null;
                } else {
                    throw new IllegalArgumentException(this.O + " is illegal; only @BoxBackgroundMode constants are supported.");
                }
            } else {
                this.F = new C0092eb(this.L);
                this.J = new C0092eb();
                this.K = new C0092eb();
            }
        } else {
            this.F = null;
            this.J = null;
            this.K = null;
        }
        s();
        x();
        if (this.O == 1) {
            if (getContext().getResources().getConfiguration().fontScale >= 2.0f) {
                this.P = getResources().getDimensionPixelSize(org.conscrypt.R.dimen.material_font_2_0_box_collapsed_padding_top);
            } else if (E9.K(getContext())) {
                this.P = getResources().getDimensionPixelSize(org.conscrypt.R.dimen.material_font_1_3_box_collapsed_padding_top);
            }
        }
        if (this.d != null && this.O == 1) {
            if (getContext().getResources().getConfiguration().fontScale >= 2.0f) {
                EditText editText = this.d;
                WeakHashMap weakHashMap = AbstractC0309ph.a;
                editText.setPaddingRelative(editText.getPaddingStart(), getResources().getDimensionPixelSize(org.conscrypt.R.dimen.material_filled_edittext_font_2_0_padding_top), this.d.getPaddingEnd(), getResources().getDimensionPixelSize(org.conscrypt.R.dimen.material_filled_edittext_font_2_0_padding_bottom));
            } else if (E9.K(getContext())) {
                EditText editText2 = this.d;
                WeakHashMap weakHashMap2 = AbstractC0309ph.a;
                editText2.setPaddingRelative(editText2.getPaddingStart(), getResources().getDimensionPixelSize(org.conscrypt.R.dimen.material_filled_edittext_font_1_3_padding_top), this.d.getPaddingEnd(), getResources().getDimensionPixelSize(org.conscrypt.R.dimen.material_filled_edittext_font_1_3_padding_bottom));
            }
        }
        if (this.O != 0) {
            t();
        }
        EditText editText3 = this.d;
        if (editText3 instanceof AutoCompleteTextView) {
            AutoCompleteTextView autoCompleteTextView = (AutoCompleteTextView) editText3;
            if (autoCompleteTextView.getDropDownBackground() == null) {
                int i3 = this.O;
                if (i3 == 2) {
                    autoCompleteTextView.setDropDownBackgroundDrawable(getOrCreateOutlinedDropDownMenuBackground());
                } else if (i3 == 1) {
                    autoCompleteTextView.setDropDownBackgroundDrawable(getOrCreateFilledDropDownMenuBackground());
                }
            }
        }
    }

    public final void j() {
        float f;
        float f2;
        float f3;
        RectF rectF;
        float f4;
        int i;
        int i2;
        if (!e()) {
            return;
        }
        int width = this.d.getWidth();
        int gravity = this.d.getGravity();
        Y3 y3 = this.v0;
        boolean b = y3.b(y3.A);
        y3.C = b;
        Rect rect = y3.d;
        if (gravity != 17 && (gravity & 7) != 1) {
            if ((gravity & 8388613) != 8388613 && (gravity & 5) != 5) {
                if (b) {
                    f = rect.right;
                    f2 = y3.Z;
                } else {
                    i2 = rect.left;
                    f3 = i2;
                }
            } else if (b) {
                i2 = rect.left;
                f3 = i2;
            } else {
                f = rect.right;
                f2 = y3.Z;
            }
            float max = Math.max(f3, rect.left);
            rectF = this.a0;
            rectF.left = max;
            rectF.top = rect.top;
            if (gravity == 17 && (gravity & 7) != 1) {
                if ((gravity & 8388613) != 8388613 && (gravity & 5) != 5) {
                    if (y3.C) {
                        i = rect.right;
                        f4 = i;
                    } else {
                        f4 = y3.Z + max;
                    }
                } else if (y3.C) {
                    f4 = max + y3.Z;
                } else {
                    i = rect.right;
                    f4 = i;
                }
            } else {
                f4 = (width / 2.0f) + (y3.Z / 2.0f);
            }
            rectF.right = Math.min(f4, rect.right);
            rectF.bottom = y3.d() + rect.top;
            if (rectF.width() <= 0.0f && rectF.height() > 0.0f) {
                float f5 = rectF.left;
                float f6 = this.N;
                rectF.left = f5 - f6;
                rectF.right += f6;
                rectF.offset(-getPaddingLeft(), ((-getPaddingTop()) - (rectF.height() / 2.0f)) + this.Q);
                Z4 z4 = (Z4) this.F;
                z4.getClass();
                z4.n(rectF.left, rectF.top, rectF.right, rectF.bottom);
                return;
            }
        }
        f = width / 2.0f;
        f2 = y3.Z / 2.0f;
        f3 = f - f2;
        float max2 = Math.max(f3, rect.left);
        rectF = this.a0;
        rectF.left = max2;
        rectF.top = rect.top;
        if (gravity == 17) {
        }
        f4 = (width / 2.0f) + (y3.Z / 2.0f);
        rectF.right = Math.min(f4, rect.right);
        rectF.bottom = y3.d() + rect.top;
        if (rectF.width() <= 0.0f) {
        }
    }

    public final void l(C0123g2 c0123g2, int i) {
        try {
            c0123g2.setTextAppearance(i);
            if (c0123g2.getTextColors().getDefaultColor() != -65281) {
                return;
            }
        } catch (Exception unused) {
        }
        c0123g2.setTextAppearance(org.conscrypt.R.style.TextAppearance_AppCompat_Caption);
        c0123g2.setTextColor(getContext().getColor(org.conscrypt.R.color.design_error));
    }

    public final boolean m() {
        C0414v9 c0414v9 = this.j;
        if (c0414v9.o == 1 && c0414v9.r != null && !TextUtils.isEmpty(c0414v9.p)) {
            return true;
        }
        return false;
    }

    public final void n(Editable editable) {
        int i;
        boolean z;
        int i2;
        X2 x2;
        ((I5) this.n).getClass();
        if (editable != null) {
            i = editable.length();
        } else {
            i = 0;
        }
        boolean z2 = this.m;
        int i3 = this.l;
        String str = null;
        if (i3 == -1) {
            this.o.setText(String.valueOf(i));
            this.o.setContentDescription(null);
            this.m = false;
        } else {
            if (i > i3) {
                z = true;
            } else {
                z = false;
            }
            this.m = z;
            Context context = getContext();
            C0123g2 c0123g2 = this.o;
            int i4 = this.l;
            if (this.m) {
                i2 = org.conscrypt.R.string.character_counter_overflowed_content_description;
            } else {
                i2 = org.conscrypt.R.string.character_counter_content_description;
            }
            c0123g2.setContentDescription(context.getString(i2, Integer.valueOf(i), Integer.valueOf(i4)));
            if (z2 != this.m) {
                o();
            }
            String str2 = X2.b;
            if (TextUtils.getLayoutDirectionFromLocale(Locale.getDefault()) == 1) {
                x2 = X2.e;
            } else {
                x2 = X2.d;
            }
            C0123g2 c0123g22 = this.o;
            String string = getContext().getString(org.conscrypt.R.string.character_counter_pattern, Integer.valueOf(i), Integer.valueOf(this.l));
            if (string == null) {
                x2.getClass();
            } else {
                x2.getClass();
                C0024b3 c0024b3 = Ff.a;
                str = x2.c(string).toString();
            }
            c0123g22.setText(str);
        }
        if (this.d != null && z2 != this.m) {
            u(false, false);
            x();
            r();
        }
    }

    public final void o() {
        int i;
        ColorStateList colorStateList;
        ColorStateList colorStateList2;
        C0123g2 c0123g2 = this.o;
        if (c0123g2 != null) {
            if (this.m) {
                i = this.p;
            } else {
                i = this.q;
            }
            l(c0123g2, i);
            if (!this.m && (colorStateList2 = this.y) != null) {
                this.o.setTextColor(colorStateList2);
            }
            if (this.m && (colorStateList = this.z) != null) {
                this.o.setTextColor(colorStateList);
            }
        }
    }

    @Override // android.view.View
    public final void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        this.v0.g(configuration);
    }

    @Override // android.view.ViewTreeObserver.OnGlobalLayoutListener
    public final void onGlobalLayout() {
        int max;
        N6 n6 = this.c;
        n6.getViewTreeObserver().removeOnGlobalLayoutListener(this);
        boolean z = false;
        this.B0 = false;
        if (this.d != null && this.d.getMeasuredHeight() < (max = Math.max(n6.getMeasuredHeight(), this.b.getMeasuredHeight()))) {
            this.d.setMinimumHeight(max);
            z = true;
        }
        boolean q = q();
        if (z || q) {
            this.d.post(new RunnableC0141h0(14, this));
        }
    }

    @Override // android.widget.LinearLayout, android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z, int i, int i2, int i3, int i4) {
        int compoundPaddingTop;
        int compoundPaddingBottom;
        super.onLayout(z, i, i2, i3, i4);
        EditText editText = this.d;
        if (editText != null) {
            ThreadLocal threadLocal = A5.a;
            int width = editText.getWidth();
            int height = editText.getHeight();
            Rect rect = this.V;
            rect.set(0, 0, width, height);
            ThreadLocal threadLocal2 = A5.a;
            Matrix matrix = (Matrix) threadLocal2.get();
            if (matrix == null) {
                matrix = new Matrix();
                threadLocal2.set(matrix);
            } else {
                matrix.reset();
            }
            A5.a(this, editText, matrix);
            ThreadLocal threadLocal3 = A5.b;
            RectF rectF = (RectF) threadLocal3.get();
            if (rectF == null) {
                rectF = new RectF();
                threadLocal3.set(rectF);
            }
            rectF.set(rect);
            matrix.mapRect(rectF);
            rect.set((int) (rectF.left + 0.5f), (int) (rectF.top + 0.5f), (int) (rectF.right + 0.5f), (int) (rectF.bottom + 0.5f));
            C0092eb c0092eb = this.J;
            if (c0092eb != null) {
                int i5 = rect.bottom;
                c0092eb.setBounds(rect.left, i5 - this.R, rect.right, i5);
            }
            C0092eb c0092eb2 = this.K;
            if (c0092eb2 != null) {
                int i6 = rect.bottom;
                c0092eb2.setBounds(rect.left, i6 - this.S, rect.right, i6);
            }
            if (this.C) {
                float textSize = this.d.getTextSize();
                Y3 y3 = this.v0;
                if (y3.h != textSize) {
                    y3.h = textSize;
                    y3.h(false);
                }
                int gravity = this.d.getGravity();
                int i7 = (gravity & (-113)) | 48;
                if (y3.g != i7) {
                    y3.g = i7;
                    y3.h(false);
                }
                if (y3.f != gravity) {
                    y3.f = gravity;
                    y3.h(false);
                }
                if (this.d != null) {
                    boolean v = AbstractC0112fb.v(this);
                    int i8 = rect.bottom;
                    Rect rect2 = this.W;
                    rect2.bottom = i8;
                    int i9 = this.O;
                    if (i9 != 1) {
                        if (i9 != 2) {
                            rect2.left = g(rect.left, v);
                            rect2.top = getPaddingTop();
                            rect2.right = h(rect.right, v);
                        } else {
                            rect2.left = this.d.getPaddingLeft() + rect.left;
                            rect2.top = rect.top - c();
                            rect2.right = rect.right - this.d.getPaddingRight();
                        }
                    } else {
                        rect2.left = g(rect.left, v);
                        rect2.top = rect.top + this.P;
                        rect2.right = h(rect.right, v);
                    }
                    int i10 = rect2.left;
                    int i11 = rect2.top;
                    int i12 = rect2.right;
                    int i13 = rect2.bottom;
                    Rect rect3 = y3.d;
                    if (rect3.left != i10 || rect3.top != i11 || rect3.right != i12 || rect3.bottom != i13) {
                        rect3.set(i10, i11, i12, i13);
                        y3.M = true;
                    }
                    if (this.d != null) {
                        TextPaint textPaint = y3.O;
                        textPaint.setTextSize(y3.h);
                        textPaint.setTypeface(y3.u);
                        textPaint.setLetterSpacing(y3.W);
                        float f = -textPaint.ascent();
                        rect2.left = this.d.getCompoundPaddingLeft() + rect.left;
                        if (this.O == 1 && this.d.getMinLines() <= 1) {
                            compoundPaddingTop = (int) (rect.centerY() - (f / 2.0f));
                        } else {
                            compoundPaddingTop = rect.top + this.d.getCompoundPaddingTop();
                        }
                        rect2.top = compoundPaddingTop;
                        rect2.right = rect.right - this.d.getCompoundPaddingRight();
                        if (this.O == 1 && this.d.getMinLines() <= 1) {
                            compoundPaddingBottom = (int) (rect2.top + f);
                        } else {
                            compoundPaddingBottom = rect.bottom - this.d.getCompoundPaddingBottom();
                        }
                        rect2.bottom = compoundPaddingBottom;
                        int i14 = rect2.left;
                        int i15 = rect2.top;
                        int i16 = rect2.right;
                        Rect rect4 = y3.c;
                        if (rect4.left != i14 || rect4.top != i15 || rect4.right != i16 || rect4.bottom != compoundPaddingBottom) {
                            rect4.set(i14, i15, i16, compoundPaddingBottom);
                            y3.M = true;
                        }
                        y3.h(false);
                        if (e() && !this.u0) {
                            j();
                            return;
                        }
                        return;
                    }
                    throw new IllegalStateException();
                }
                throw new IllegalStateException();
            }
        }
    }

    @Override // android.widget.LinearLayout, android.view.View
    public final void onMeasure(int i, int i2) {
        EditText editText;
        super.onMeasure(i, i2);
        boolean z = this.B0;
        N6 n6 = this.c;
        if (!z) {
            n6.getViewTreeObserver().addOnGlobalLayoutListener(this);
            this.B0 = true;
        }
        if (this.t != null && (editText = this.d) != null) {
            this.t.setGravity(editText.getGravity());
            this.t.setPadding(this.d.getCompoundPaddingLeft(), this.d.getCompoundPaddingTop(), this.d.getCompoundPaddingRight(), this.d.getCompoundPaddingBottom());
        }
        n6.m();
    }

    @Override // android.view.View
    public final void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof Lf)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        Lf lf = (Lf) parcelable;
        super.onRestoreInstanceState(lf.a);
        setError(lf.c);
        if (lf.d) {
            post(new I2(11, this));
        }
        requestLayout();
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r3v3, types: [x.ze, java.lang.Object] */
    @Override // android.widget.LinearLayout, android.view.View
    public final void onRtlPropertiesChanged(int i) {
        super.onRtlPropertiesChanged(i);
        boolean z = true;
        if (i != 1) {
            z = false;
        }
        if (z != this.M) {
            T4 t4 = this.L.e;
            RectF rectF = this.a0;
            float a = t4.a(rectF);
            float a2 = this.L.f.a(rectF);
            float a3 = this.L.h.a(rectF);
            float a4 = this.L.g.a(rectF);
            C0495ze c0495ze = this.L;
            AbstractC0124g3 abstractC0124g3 = c0495ze.a;
            AbstractC0124g3 abstractC0124g32 = c0495ze.b;
            AbstractC0124g3 abstractC0124g33 = c0495ze.d;
            AbstractC0124g3 abstractC0124g34 = c0495ze.c;
            C0107f6 c0107f6 = new C0107f6(0);
            C0107f6 c0107f62 = new C0107f6(0);
            C0107f6 c0107f63 = new C0107f6(0);
            C0107f6 c0107f64 = new C0107f6(0);
            C0476ye.b(abstractC0124g32);
            C0476ye.b(abstractC0124g3);
            C0476ye.b(abstractC0124g34);
            C0476ye.b(abstractC0124g33);
            C0080e c0080e = new C0080e(a2);
            C0080e c0080e2 = new C0080e(a);
            C0080e c0080e3 = new C0080e(a4);
            C0080e c0080e4 = new C0080e(a3);
            ?? obj = new Object();
            obj.a = abstractC0124g32;
            obj.b = abstractC0124g3;
            obj.c = abstractC0124g33;
            obj.d = abstractC0124g34;
            obj.e = c0080e;
            obj.f = c0080e2;
            obj.g = c0080e4;
            obj.h = c0080e3;
            obj.i = c0107f6;
            obj.j = c0107f62;
            obj.k = c0107f63;
            obj.l = c0107f64;
            this.M = z;
            setShapeAppearanceModel(obj);
        }
    }

    /* JADX WARN: Type inference failed for: r1v0, types: [android.os.Parcelable, x.Lf, x.d] */
    @Override // android.view.View
    public final Parcelable onSaveInstanceState() {
        boolean z;
        ?? abstractC0060d = new AbstractC0060d(super.onSaveInstanceState());
        if (m()) {
            abstractC0060d.c = getError();
        }
        N6 n6 = this.c;
        if (n6.i != 0 && n6.g.d) {
            z = true;
        } else {
            z = false;
        }
        abstractC0060d.d = z;
        return abstractC0060d;
    }

    public final void p() {
        Drawable textCursorDrawable;
        Drawable textCursorDrawable2;
        ColorStateList colorStateList;
        ColorStateList colorStateList2 = this.A;
        if (colorStateList2 == null) {
            Context context = getContext();
            TypedValue f0 = E9.f0(context, org.conscrypt.R.attr.colorControlActivated);
            if (f0 != null) {
                int i = f0.resourceId;
                if (i != 0) {
                    colorStateList2 = E9.A(context, i);
                } else {
                    int i2 = f0.data;
                    if (i2 != 0) {
                        colorStateList2 = ColorStateList.valueOf(i2);
                    }
                }
            }
            colorStateList2 = null;
        }
        EditText editText = this.d;
        if (editText != null) {
            textCursorDrawable = editText.getTextCursorDrawable();
            if (textCursorDrawable != null) {
                textCursorDrawable2 = this.d.getTextCursorDrawable();
                Drawable mutate = textCursorDrawable2.mutate();
                if ((m() || (this.o != null && this.m)) && (colorStateList = this.B) != null) {
                    colorStateList2 = colorStateList;
                }
                mutate.setTintList(colorStateList2);
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:17:0x0081  */
    /* JADX WARN: Removed duplicated region for block: B:37:0x00a8  */
    /* JADX WARN: Removed duplicated region for block: B:39:0x00b9  */
    /* JADX WARN: Removed duplicated region for block: B:42:0x00d4  */
    /* JADX WARN: Removed duplicated region for block: B:46:0x00ed  */
    /* JADX WARN: Removed duplicated region for block: B:49:0x00ff  */
    /* JADX WARN: Removed duplicated region for block: B:50:0x010d  */
    /* JADX WARN: Removed duplicated region for block: B:51:0x00ab  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final boolean q() {
        boolean z;
        N6 n6;
        Drawable[] compoundDrawablesRelative;
        ColorDrawable colorDrawable;
        Drawable drawable;
        ColorDrawable colorDrawable2;
        if (this.d == null) {
            return false;
        }
        CheckableImageButton checkableImageButton = null;
        boolean z2 = true;
        if (getStartIconDrawable() != null || (getPrefixText() != null && getPrefixTextView().getVisibility() == 0)) {
            Cif cif = this.b;
            if (cif.getMeasuredWidth() > 0) {
                int measuredWidth = cif.getMeasuredWidth() - this.d.getPaddingLeft();
                if (this.c0 == null || this.d0 != measuredWidth) {
                    ColorDrawable colorDrawable3 = new ColorDrawable();
                    this.c0 = colorDrawable3;
                    this.d0 = measuredWidth;
                    colorDrawable3.setBounds(0, 0, measuredWidth, 1);
                }
                Drawable[] compoundDrawablesRelative2 = this.d.getCompoundDrawablesRelative();
                Drawable drawable2 = compoundDrawablesRelative2[0];
                ColorDrawable colorDrawable4 = this.c0;
                if (drawable2 != colorDrawable4) {
                    this.d.setCompoundDrawablesRelative(colorDrawable4, compoundDrawablesRelative2[1], compoundDrawablesRelative2[2], compoundDrawablesRelative2[3]);
                    z = true;
                    n6 = this.c;
                    if ((!n6.e() || ((n6.i != 0 && n6.d()) || n6.p != null)) && n6.getMeasuredWidth() > 0) {
                        int measuredWidth2 = n6.q.getMeasuredWidth() - this.d.getPaddingRight();
                        if (!n6.e()) {
                            checkableImageButton = n6.c;
                        } else if (n6.i != 0 && n6.d()) {
                            checkableImageButton = n6.g;
                        }
                        if (checkableImageButton != null) {
                            measuredWidth2 = ((ViewGroup.MarginLayoutParams) checkableImageButton.getLayoutParams()).getMarginStart() + checkableImageButton.getMeasuredWidth() + measuredWidth2;
                        }
                        compoundDrawablesRelative = this.d.getCompoundDrawablesRelative();
                        colorDrawable = this.f0;
                        if (colorDrawable == null && this.g0 != measuredWidth2) {
                            this.g0 = measuredWidth2;
                            colorDrawable.setBounds(0, 0, measuredWidth2, 1);
                            this.d.setCompoundDrawablesRelative(compoundDrawablesRelative[0], compoundDrawablesRelative[1], this.f0, compoundDrawablesRelative[3]);
                        } else {
                            if (colorDrawable == null) {
                                ColorDrawable colorDrawable5 = new ColorDrawable();
                                this.f0 = colorDrawable5;
                                this.g0 = measuredWidth2;
                                colorDrawable5.setBounds(0, 0, measuredWidth2, 1);
                            }
                            drawable = compoundDrawablesRelative[2];
                            colorDrawable2 = this.f0;
                            if (drawable == colorDrawable2) {
                                this.h0 = drawable;
                                this.d.setCompoundDrawablesRelative(compoundDrawablesRelative[0], compoundDrawablesRelative[1], colorDrawable2, compoundDrawablesRelative[3]);
                            } else {
                                z2 = z;
                            }
                        }
                    } else if (this.f0 != null) {
                        Drawable[] compoundDrawablesRelative3 = this.d.getCompoundDrawablesRelative();
                        if (compoundDrawablesRelative3[2] == this.f0) {
                            this.d.setCompoundDrawablesRelative(compoundDrawablesRelative3[0], compoundDrawablesRelative3[1], this.h0, compoundDrawablesRelative3[3]);
                        } else {
                            z2 = z;
                        }
                        this.f0 = null;
                    } else {
                        return z;
                    }
                    return z2;
                }
                z = false;
                n6 = this.c;
                if (!n6.e()) {
                }
                int measuredWidth22 = n6.q.getMeasuredWidth() - this.d.getPaddingRight();
                if (!n6.e()) {
                }
                if (checkableImageButton != null) {
                }
                compoundDrawablesRelative = this.d.getCompoundDrawablesRelative();
                colorDrawable = this.f0;
                if (colorDrawable == null) {
                }
                if (colorDrawable == null) {
                }
                drawable = compoundDrawablesRelative[2];
                colorDrawable2 = this.f0;
                if (drawable == colorDrawable2) {
                }
                return z2;
            }
        }
        if (this.c0 != null) {
            Drawable[] compoundDrawablesRelative4 = this.d.getCompoundDrawablesRelative();
            this.d.setCompoundDrawablesRelative(null, compoundDrawablesRelative4[1], compoundDrawablesRelative4[2], compoundDrawablesRelative4[3]);
            this.c0 = null;
            z = true;
            n6 = this.c;
            if (!n6.e()) {
            }
            int measuredWidth222 = n6.q.getMeasuredWidth() - this.d.getPaddingRight();
            if (!n6.e()) {
            }
            if (checkableImageButton != null) {
            }
            compoundDrawablesRelative = this.d.getCompoundDrawablesRelative();
            colorDrawable = this.f0;
            if (colorDrawable == null) {
            }
            if (colorDrawable == null) {
            }
            drawable = compoundDrawablesRelative[2];
            colorDrawable2 = this.f0;
            if (drawable == colorDrawable2) {
            }
            return z2;
        }
        z = false;
        n6 = this.c;
        if (!n6.e()) {
        }
        int measuredWidth2222 = n6.q.getMeasuredWidth() - this.d.getPaddingRight();
        if (!n6.e()) {
        }
        if (checkableImageButton != null) {
        }
        compoundDrawablesRelative = this.d.getCompoundDrawablesRelative();
        colorDrawable = this.f0;
        if (colorDrawable == null) {
        }
        if (colorDrawable == null) {
        }
        drawable = compoundDrawablesRelative[2];
        colorDrawable2 = this.f0;
        if (drawable == colorDrawable2) {
        }
        return z2;
    }

    public final void r() {
        Drawable background;
        C0123g2 c0123g2;
        EditText editText = this.d;
        if (editText == null || this.O != 0 || (background = editText.getBackground()) == null) {
            return;
        }
        int[] iArr = R5.a;
        Drawable mutate = background.mutate();
        if (m()) {
            mutate.setColorFilter(C0425w1.c(getErrorCurrentTextColors(), PorterDuff.Mode.SRC_IN));
        } else if (this.m && (c0123g2 = this.o) != null) {
            mutate.setColorFilter(C0425w1.c(c0123g2.getCurrentTextColor(), PorterDuff.Mode.SRC_IN));
        } else {
            mutate.clearColorFilter();
            this.d.refreshDrawableState();
        }
    }

    public final void s() {
        EditText editText = this.d;
        if (editText != null && this.F != null) {
            if ((this.I || editText.getBackground() == null) && this.O != 0) {
                Drawable editTextBoxBackground = getEditTextBoxBackground();
                EditText editText2 = this.d;
                WeakHashMap weakHashMap = AbstractC0309ph.a;
                editText2.setBackground(editTextBoxBackground);
                this.I = true;
            }
        }
    }

    public void setBoxBackgroundColor(int i) {
        if (this.U != i) {
            this.U = i;
            this.o0 = i;
            this.q0 = i;
            this.r0 = i;
            b();
        }
    }

    public void setBoxBackgroundColorResource(int i) {
        setBoxBackgroundColor(getContext().getColor(i));
    }

    public void setBoxBackgroundColorStateList(ColorStateList colorStateList) {
        int defaultColor = colorStateList.getDefaultColor();
        this.o0 = defaultColor;
        this.U = defaultColor;
        this.p0 = colorStateList.getColorForState(new int[]{-16842910}, -1);
        this.q0 = colorStateList.getColorForState(new int[]{R.attr.state_focused, R.attr.state_enabled}, -1);
        this.r0 = colorStateList.getColorForState(new int[]{R.attr.state_hovered, R.attr.state_enabled}, -1);
        b();
    }

    public void setBoxBackgroundMode(int i) {
        if (i == this.O) {
            return;
        }
        this.O = i;
        if (this.d != null) {
            i();
        }
    }

    public void setBoxCollapsedPaddingTop(int i) {
        this.P = i;
    }

    public void setBoxCornerFamily(int i) {
        C0476ye e = this.L.e();
        T4 t4 = this.L.e;
        AbstractC0124g3 j = AbstractC0112fb.j(i);
        e.a = j;
        C0476ye.b(j);
        e.e = t4;
        T4 t42 = this.L.f;
        AbstractC0124g3 j2 = AbstractC0112fb.j(i);
        e.b = j2;
        C0476ye.b(j2);
        e.f = t42;
        T4 t43 = this.L.h;
        AbstractC0124g3 j3 = AbstractC0112fb.j(i);
        e.d = j3;
        C0476ye.b(j3);
        e.h = t43;
        T4 t44 = this.L.g;
        AbstractC0124g3 j4 = AbstractC0112fb.j(i);
        e.c = j4;
        C0476ye.b(j4);
        e.g = t44;
        this.L = e.a();
        b();
    }

    public void setBoxStrokeColor(int i) {
        if (this.m0 != i) {
            this.m0 = i;
            x();
        }
    }

    public void setBoxStrokeColorStateList(ColorStateList colorStateList) {
        if (colorStateList.isStateful()) {
            this.k0 = colorStateList.getDefaultColor();
            this.s0 = colorStateList.getColorForState(new int[]{-16842910}, -1);
            this.l0 = colorStateList.getColorForState(new int[]{R.attr.state_hovered, R.attr.state_enabled}, -1);
            this.m0 = colorStateList.getColorForState(new int[]{R.attr.state_focused, R.attr.state_enabled}, -1);
        } else if (this.m0 != colorStateList.getDefaultColor()) {
            this.m0 = colorStateList.getDefaultColor();
        }
        x();
    }

    public void setBoxStrokeErrorColor(ColorStateList colorStateList) {
        if (this.n0 != colorStateList) {
            this.n0 = colorStateList;
            x();
        }
    }

    public void setBoxStrokeWidth(int i) {
        this.R = i;
        x();
    }

    public void setBoxStrokeWidthFocused(int i) {
        this.S = i;
        x();
    }

    public void setBoxStrokeWidthFocusedResource(int i) {
        setBoxStrokeWidthFocused(getResources().getDimensionPixelSize(i));
    }

    public void setBoxStrokeWidthResource(int i) {
        setBoxStrokeWidth(getResources().getDimensionPixelSize(i));
    }

    public void setCounterEnabled(boolean z) {
        if (this.k != z) {
            Editable editable = null;
            C0414v9 c0414v9 = this.j;
            if (z) {
                C0123g2 c0123g2 = new C0123g2(getContext(), null);
                this.o = c0123g2;
                c0123g2.setId(org.conscrypt.R.id.textinput_counter);
                Typeface typeface = this.b0;
                if (typeface != null) {
                    this.o.setTypeface(typeface);
                }
                this.o.setMaxLines(1);
                c0414v9.a(this.o, 2);
                ((ViewGroup.MarginLayoutParams) this.o.getLayoutParams()).setMarginStart(getResources().getDimensionPixelOffset(org.conscrypt.R.dimen.mtrl_textinput_counter_margin_start));
                o();
                if (this.o != null) {
                    EditText editText = this.d;
                    if (editText != null) {
                        editable = editText.getText();
                    }
                    n(editable);
                }
            } else {
                c0414v9.g(this.o, 2);
                this.o = null;
            }
            this.k = z;
        }
    }

    public void setCounterMaxLength(int i) {
        Editable text;
        if (this.l != i) {
            if (i > 0) {
                this.l = i;
            } else {
                this.l = -1;
            }
            if (this.k && this.o != null) {
                EditText editText = this.d;
                if (editText == null) {
                    text = null;
                } else {
                    text = editText.getText();
                }
                n(text);
            }
        }
    }

    public void setCounterOverflowTextAppearance(int i) {
        if (this.p != i) {
            this.p = i;
            o();
        }
    }

    public void setCounterOverflowTextColor(ColorStateList colorStateList) {
        if (this.z != colorStateList) {
            this.z = colorStateList;
            o();
        }
    }

    public void setCounterTextAppearance(int i) {
        if (this.q != i) {
            this.q = i;
            o();
        }
    }

    public void setCounterTextColor(ColorStateList colorStateList) {
        if (this.y != colorStateList) {
            this.y = colorStateList;
            o();
        }
    }

    public void setCursorColor(ColorStateList colorStateList) {
        if (this.A != colorStateList) {
            this.A = colorStateList;
            p();
        }
    }

    public void setCursorErrorColor(ColorStateList colorStateList) {
        if (this.B != colorStateList) {
            this.B = colorStateList;
            if (m() || (this.o != null && this.m)) {
                p();
            }
        }
    }

    public void setDefaultHintTextColor(ColorStateList colorStateList) {
        this.i0 = colorStateList;
        this.j0 = colorStateList;
        if (this.d != null) {
            u(false, false);
        }
    }

    @Override // android.view.View
    public void setEnabled(boolean z) {
        k(this, z);
        super.setEnabled(z);
    }

    public void setEndIconActivated(boolean z) {
        this.c.g.setActivated(z);
    }

    public void setEndIconCheckable(boolean z) {
        this.c.g.setCheckable(z);
    }

    public void setEndIconContentDescription(int i) {
        N6 n6 = this.c;
        CharSequence text = i != 0 ? n6.getResources().getText(i) : null;
        CheckableImageButton checkableImageButton = n6.g;
        if (checkableImageButton.getContentDescription() != text) {
            checkableImageButton.setContentDescription(text);
        }
    }

    public void setEndIconDrawable(int i) {
        N6 n6 = this.c;
        Drawable r = i != 0 ? AbstractC0124g3.r(n6.getContext(), i) : null;
        CheckableImageButton checkableImageButton = n6.g;
        checkableImageButton.setImageDrawable(r);
        if (r != null) {
            ColorStateList colorStateList = n6.k;
            PorterDuff.Mode mode = n6.l;
            TextInputLayout textInputLayout = n6.a;
            AbstractC0124g3.f(textInputLayout, checkableImageButton, colorStateList, mode);
            AbstractC0124g3.R(textInputLayout, checkableImageButton, n6.k);
        }
    }

    public void setEndIconMinSize(int i) {
        N6 n6 = this.c;
        if (i >= 0) {
            if (i != n6.m) {
                n6.m = i;
                CheckableImageButton checkableImageButton = n6.g;
                checkableImageButton.setMinimumWidth(i);
                checkableImageButton.setMinimumHeight(i);
                CheckableImageButton checkableImageButton2 = n6.c;
                checkableImageButton2.setMinimumWidth(i);
                checkableImageButton2.setMinimumHeight(i);
                return;
            }
            return;
        }
        n6.getClass();
        throw new IllegalArgumentException("endIconSize cannot be less than 0");
    }

    public void setEndIconMode(int i) {
        this.c.g(i);
    }

    public void setEndIconOnClickListener(View.OnClickListener onClickListener) {
        N6 n6 = this.c;
        View.OnLongClickListener onLongClickListener = n6.o;
        CheckableImageButton checkableImageButton = n6.g;
        checkableImageButton.setOnClickListener(onClickListener);
        AbstractC0124g3.T(checkableImageButton, onLongClickListener);
    }

    public void setEndIconOnLongClickListener(View.OnLongClickListener onLongClickListener) {
        N6 n6 = this.c;
        n6.o = onLongClickListener;
        CheckableImageButton checkableImageButton = n6.g;
        checkableImageButton.setOnLongClickListener(onLongClickListener);
        AbstractC0124g3.T(checkableImageButton, onLongClickListener);
    }

    public void setEndIconScaleType(ImageView.ScaleType scaleType) {
        N6 n6 = this.c;
        n6.n = scaleType;
        n6.g.setScaleType(scaleType);
        n6.c.setScaleType(scaleType);
    }

    public void setEndIconTintList(ColorStateList colorStateList) {
        N6 n6 = this.c;
        if (n6.k != colorStateList) {
            n6.k = colorStateList;
            AbstractC0124g3.f(n6.a, n6.g, colorStateList, n6.l);
        }
    }

    public void setEndIconTintMode(PorterDuff.Mode mode) {
        N6 n6 = this.c;
        if (n6.l != mode) {
            n6.l = mode;
            AbstractC0124g3.f(n6.a, n6.g, n6.k, mode);
        }
    }

    public void setEndIconVisible(boolean z) {
        this.c.h(z);
    }

    public void setError(CharSequence charSequence) {
        C0414v9 c0414v9 = this.j;
        if (!c0414v9.q) {
            if (TextUtils.isEmpty(charSequence)) {
                return;
            } else {
                setErrorEnabled(true);
            }
        }
        if (!TextUtils.isEmpty(charSequence)) {
            c0414v9.c();
            c0414v9.p = charSequence;
            c0414v9.r.setText(charSequence);
            int i = c0414v9.n;
            if (i != 1) {
                c0414v9.o = 1;
            }
            c0414v9.i(i, c0414v9.o, c0414v9.h(c0414v9.r, charSequence));
            return;
        }
        c0414v9.f();
    }

    public void setErrorAccessibilityLiveRegion(int i) {
        C0414v9 c0414v9 = this.j;
        c0414v9.t = i;
        C0123g2 c0123g2 = c0414v9.r;
        if (c0123g2 != null) {
            WeakHashMap weakHashMap = AbstractC0309ph.a;
            c0123g2.setAccessibilityLiveRegion(i);
        }
    }

    public void setErrorContentDescription(CharSequence charSequence) {
        C0414v9 c0414v9 = this.j;
        c0414v9.s = charSequence;
        C0123g2 c0123g2 = c0414v9.r;
        if (c0123g2 != null) {
            c0123g2.setContentDescription(charSequence);
        }
    }

    public void setErrorEnabled(boolean z) {
        C0414v9 c0414v9 = this.j;
        if (c0414v9.q != z) {
            c0414v9.c();
            TextInputLayout textInputLayout = c0414v9.h;
            if (z) {
                C0123g2 c0123g2 = new C0123g2(c0414v9.g, null);
                c0414v9.r = c0123g2;
                c0123g2.setId(org.conscrypt.R.id.textinput_error);
                c0414v9.r.setTextAlignment(5);
                Typeface typeface = c0414v9.B;
                if (typeface != null) {
                    c0414v9.r.setTypeface(typeface);
                }
                int i = c0414v9.u;
                c0414v9.u = i;
                C0123g2 c0123g22 = c0414v9.r;
                if (c0123g22 != null) {
                    textInputLayout.l(c0123g22, i);
                }
                ColorStateList colorStateList = c0414v9.v;
                c0414v9.v = colorStateList;
                C0123g2 c0123g23 = c0414v9.r;
                if (c0123g23 != null && colorStateList != null) {
                    c0123g23.setTextColor(colorStateList);
                }
                CharSequence charSequence = c0414v9.s;
                c0414v9.s = charSequence;
                C0123g2 c0123g24 = c0414v9.r;
                if (c0123g24 != null) {
                    c0123g24.setContentDescription(charSequence);
                }
                int i2 = c0414v9.t;
                c0414v9.t = i2;
                C0123g2 c0123g25 = c0414v9.r;
                if (c0123g25 != null) {
                    WeakHashMap weakHashMap = AbstractC0309ph.a;
                    c0123g25.setAccessibilityLiveRegion(i2);
                }
                c0414v9.r.setVisibility(4);
                c0414v9.a(c0414v9.r, 0);
            } else {
                c0414v9.f();
                c0414v9.g(c0414v9.r, 0);
                c0414v9.r = null;
                textInputLayout.r();
                textInputLayout.x();
            }
            c0414v9.q = z;
        }
    }

    public void setErrorIconDrawable(int i) {
        N6 n6 = this.c;
        n6.i(i != 0 ? AbstractC0124g3.r(n6.getContext(), i) : null);
        AbstractC0124g3.R(n6.a, n6.c, n6.d);
    }

    public void setErrorIconOnClickListener(View.OnClickListener onClickListener) {
        N6 n6 = this.c;
        CheckableImageButton checkableImageButton = n6.c;
        View.OnLongClickListener onLongClickListener = n6.f;
        checkableImageButton.setOnClickListener(onClickListener);
        AbstractC0124g3.T(checkableImageButton, onLongClickListener);
    }

    public void setErrorIconOnLongClickListener(View.OnLongClickListener onLongClickListener) {
        N6 n6 = this.c;
        n6.f = onLongClickListener;
        CheckableImageButton checkableImageButton = n6.c;
        checkableImageButton.setOnLongClickListener(onLongClickListener);
        AbstractC0124g3.T(checkableImageButton, onLongClickListener);
    }

    public void setErrorIconTintList(ColorStateList colorStateList) {
        N6 n6 = this.c;
        if (n6.d != colorStateList) {
            n6.d = colorStateList;
            AbstractC0124g3.f(n6.a, n6.c, colorStateList, n6.e);
        }
    }

    public void setErrorIconTintMode(PorterDuff.Mode mode) {
        N6 n6 = this.c;
        if (n6.e != mode) {
            n6.e = mode;
            AbstractC0124g3.f(n6.a, n6.c, n6.d, mode);
        }
    }

    public void setErrorTextAppearance(int i) {
        C0414v9 c0414v9 = this.j;
        c0414v9.u = i;
        C0123g2 c0123g2 = c0414v9.r;
        if (c0123g2 != null) {
            c0414v9.h.l(c0123g2, i);
        }
    }

    public void setErrorTextColor(ColorStateList colorStateList) {
        C0414v9 c0414v9 = this.j;
        c0414v9.v = colorStateList;
        C0123g2 c0123g2 = c0414v9.r;
        if (c0123g2 != null && colorStateList != null) {
            c0123g2.setTextColor(colorStateList);
        }
    }

    public void setExpandedHintEnabled(boolean z) {
        if (this.w0 != z) {
            this.w0 = z;
            u(false, false);
        }
    }

    public void setHelperText(CharSequence charSequence) {
        boolean isEmpty = TextUtils.isEmpty(charSequence);
        C0414v9 c0414v9 = this.j;
        if (isEmpty) {
            if (c0414v9.f35x) {
                setHelperTextEnabled(false);
                return;
            }
            return;
        }
        if (!c0414v9.f35x) {
            setHelperTextEnabled(true);
        }
        c0414v9.c();
        c0414v9.w = charSequence;
        c0414v9.y.setText(charSequence);
        int i = c0414v9.n;
        if (i != 2) {
            c0414v9.o = 2;
        }
        c0414v9.i(i, c0414v9.o, c0414v9.h(c0414v9.y, charSequence));
    }

    public void setHelperTextColor(ColorStateList colorStateList) {
        C0414v9 c0414v9 = this.j;
        c0414v9.A = colorStateList;
        C0123g2 c0123g2 = c0414v9.y;
        if (c0123g2 != null && colorStateList != null) {
            c0123g2.setTextColor(colorStateList);
        }
    }

    public void setHelperTextEnabled(boolean z) {
        C0414v9 c0414v9 = this.j;
        if (c0414v9.f35x != z) {
            c0414v9.c();
            if (z) {
                C0123g2 c0123g2 = new C0123g2(c0414v9.g, null);
                c0414v9.y = c0123g2;
                c0123g2.setId(org.conscrypt.R.id.textinput_helper_text);
                c0414v9.y.setTextAlignment(5);
                Typeface typeface = c0414v9.B;
                if (typeface != null) {
                    c0414v9.y.setTypeface(typeface);
                }
                c0414v9.y.setVisibility(4);
                c0414v9.y.setAccessibilityLiveRegion(1);
                int i = c0414v9.z;
                c0414v9.z = i;
                C0123g2 c0123g22 = c0414v9.y;
                if (c0123g22 != null) {
                    c0123g22.setTextAppearance(i);
                }
                ColorStateList colorStateList = c0414v9.A;
                c0414v9.A = colorStateList;
                C0123g2 c0123g23 = c0414v9.y;
                if (c0123g23 != null && colorStateList != null) {
                    c0123g23.setTextColor(colorStateList);
                }
                c0414v9.a(c0414v9.y, 1);
                c0414v9.y.setAccessibilityDelegate(new C0395u9(c0414v9));
            } else {
                c0414v9.c();
                int i2 = c0414v9.n;
                if (i2 == 2) {
                    c0414v9.o = 0;
                }
                c0414v9.i(i2, c0414v9.o, c0414v9.h(c0414v9.y, BuildConfig.FLAVOR));
                c0414v9.g(c0414v9.y, 1);
                c0414v9.y = null;
                TextInputLayout textInputLayout = c0414v9.h;
                textInputLayout.r();
                textInputLayout.x();
            }
            c0414v9.f35x = z;
        }
    }

    public void setHelperTextTextAppearance(int i) {
        C0414v9 c0414v9 = this.j;
        c0414v9.z = i;
        C0123g2 c0123g2 = c0414v9.y;
        if (c0123g2 != null) {
            c0123g2.setTextAppearance(i);
        }
    }

    public void setHint(CharSequence charSequence) {
        if (this.C) {
            setHintInternal(charSequence);
            sendAccessibilityEvent(2048);
        }
    }

    public void setHintAnimationEnabled(boolean z) {
        this.x0 = z;
    }

    public void setHintEnabled(boolean z) {
        if (z != this.C) {
            this.C = z;
            if (!z) {
                this.E = false;
                if (!TextUtils.isEmpty(this.D) && TextUtils.isEmpty(this.d.getHint())) {
                    this.d.setHint(this.D);
                }
                setHintInternal(null);
            } else {
                CharSequence hint = this.d.getHint();
                if (!TextUtils.isEmpty(hint)) {
                    if (TextUtils.isEmpty(this.D)) {
                        setHint(hint);
                    }
                    this.d.setHint((CharSequence) null);
                }
                this.E = true;
            }
            if (this.d != null) {
                t();
            }
        }
    }

    public void setHintTextAppearance(int i) {
        Y3 y3 = this.v0;
        TextInputLayout textInputLayout = y3.a;
        Ef ef = new Ef(textInputLayout.getContext(), i);
        ColorStateList colorStateList = ef.j;
        if (colorStateList != null) {
            y3.k = colorStateList;
        }
        float f = ef.k;
        if (f != 0.0f) {
            y3.i = f;
        }
        ColorStateList colorStateList2 = ef.a;
        if (colorStateList2 != null) {
            y3.U = colorStateList2;
        }
        y3.S = ef.e;
        y3.T = ef.f;
        y3.R = ef.g;
        y3.V = ef.i;
        C0219l3 c0219l3 = y3.y;
        if (c0219l3 != null) {
            c0219l3.n = true;
        }
        B b = new B(7, y3);
        ef.a();
        y3.y = new C0219l3(b, ef.n);
        ef.c(textInputLayout.getContext(), y3.y);
        y3.h(false);
        this.j0 = y3.k;
        if (this.d != null) {
            u(false, false);
            t();
        }
    }

    public void setHintTextColor(ColorStateList colorStateList) {
        if (this.j0 != colorStateList) {
            if (this.i0 == null) {
                Y3 y3 = this.v0;
                if (y3.k != colorStateList) {
                    y3.k = colorStateList;
                    y3.h(false);
                }
            }
            this.j0 = colorStateList;
            if (this.d != null) {
                u(false, false);
            }
        }
    }

    public void setLengthCounter(Kf kf) {
        this.n = kf;
    }

    public void setMaxEms(int i) {
        this.g = i;
        EditText editText = this.d;
        if (editText != null && i != -1) {
            editText.setMaxEms(i);
        }
    }

    public void setMaxWidth(int i) {
        this.i = i;
        EditText editText = this.d;
        if (editText != null && i != -1) {
            editText.setMaxWidth(i);
        }
    }

    public void setMaxWidthResource(int i) {
        setMaxWidth(getContext().getResources().getDimensionPixelSize(i));
    }

    public void setMinEms(int i) {
        this.f = i;
        EditText editText = this.d;
        if (editText != null && i != -1) {
            editText.setMinEms(i);
        }
    }

    public void setMinWidth(int i) {
        this.h = i;
        EditText editText = this.d;
        if (editText != null && i != -1) {
            editText.setMinWidth(i);
        }
    }

    public void setMinWidthResource(int i) {
        setMinWidth(getContext().getResources().getDimensionPixelSize(i));
    }

    @Deprecated
    public void setPasswordVisibilityToggleContentDescription(int i) {
        N6 n6 = this.c;
        n6.g.setContentDescription(i != 0 ? n6.getResources().getText(i) : null);
    }

    @Deprecated
    public void setPasswordVisibilityToggleDrawable(int i) {
        N6 n6 = this.c;
        n6.g.setImageDrawable(i != 0 ? AbstractC0124g3.r(n6.getContext(), i) : null);
    }

    @Deprecated
    public void setPasswordVisibilityToggleEnabled(boolean z) {
        N6 n6 = this.c;
        if (z && n6.i != 1) {
            n6.g(1);
        } else if (!z) {
            n6.g(0);
        } else {
            n6.getClass();
        }
    }

    @Deprecated
    public void setPasswordVisibilityToggleTintList(ColorStateList colorStateList) {
        N6 n6 = this.c;
        n6.k = colorStateList;
        AbstractC0124g3.f(n6.a, n6.g, colorStateList, n6.l);
    }

    @Deprecated
    public void setPasswordVisibilityToggleTintMode(PorterDuff.Mode mode) {
        N6 n6 = this.c;
        n6.l = mode;
        AbstractC0124g3.f(n6.a, n6.g, n6.k, mode);
    }

    public void setPlaceholderText(CharSequence charSequence) {
        Editable editable = null;
        if (this.t == null) {
            C0123g2 c0123g2 = new C0123g2(getContext(), null);
            this.t = c0123g2;
            c0123g2.setId(org.conscrypt.R.id.textinput_placeholder);
            this.t.setImportantForAccessibility(2);
            C0167i7 d = d();
            this.w = d;
            d.b = 67L;
            this.f12x = d();
            setPlaceholderTextAppearance(this.v);
            setPlaceholderTextColor(this.u);
        }
        if (TextUtils.isEmpty(charSequence)) {
            setPlaceholderTextEnabled(false);
        } else {
            if (!this.s) {
                setPlaceholderTextEnabled(true);
            }
            this.r = charSequence;
        }
        EditText editText = this.d;
        if (editText != null) {
            editable = editText.getText();
        }
        v(editable);
    }

    public void setPlaceholderTextAppearance(int i) {
        this.v = i;
        C0123g2 c0123g2 = this.t;
        if (c0123g2 != null) {
            c0123g2.setTextAppearance(i);
        }
    }

    public void setPlaceholderTextColor(ColorStateList colorStateList) {
        if (this.u != colorStateList) {
            this.u = colorStateList;
            C0123g2 c0123g2 = this.t;
            if (c0123g2 != null && colorStateList != null) {
                c0123g2.setTextColor(colorStateList);
            }
        }
    }

    public void setPrefixText(CharSequence charSequence) {
        CharSequence charSequence2;
        Cif cif = this.b;
        cif.getClass();
        if (TextUtils.isEmpty(charSequence)) {
            charSequence2 = null;
        } else {
            charSequence2 = charSequence;
        }
        cif.c = charSequence2;
        cif.b.setText(charSequence);
        cif.e();
    }

    public void setPrefixTextAppearance(int i) {
        this.b.b.setTextAppearance(i);
    }

    public void setPrefixTextColor(ColorStateList colorStateList) {
        this.b.b.setTextColor(colorStateList);
    }

    public void setShapeAppearanceModel(C0495ze c0495ze) {
        C0092eb c0092eb = this.F;
        if (c0092eb != null && c0092eb.a.a != c0495ze) {
            this.L = c0495ze;
            b();
        }
    }

    public void setStartIconCheckable(boolean z) {
        this.b.d.setCheckable(z);
    }

    public void setStartIconContentDescription(CharSequence charSequence) {
        CheckableImageButton checkableImageButton = this.b.d;
        if (checkableImageButton.getContentDescription() != charSequence) {
            checkableImageButton.setContentDescription(charSequence);
        }
    }

    public void setStartIconDrawable(int i) {
        setStartIconDrawable(i != 0 ? AbstractC0124g3.r(getContext(), i) : null);
    }

    public void setStartIconMinSize(int i) {
        Cif cif = this.b;
        if (i >= 0) {
            if (i != cif.g) {
                cif.g = i;
                CheckableImageButton checkableImageButton = cif.d;
                checkableImageButton.setMinimumWidth(i);
                checkableImageButton.setMinimumHeight(i);
                return;
            }
            return;
        }
        cif.getClass();
        throw new IllegalArgumentException("startIconSize cannot be less than 0");
    }

    public void setStartIconOnClickListener(View.OnClickListener onClickListener) {
        Cif cif = this.b;
        View.OnLongClickListener onLongClickListener = cif.i;
        CheckableImageButton checkableImageButton = cif.d;
        checkableImageButton.setOnClickListener(onClickListener);
        AbstractC0124g3.T(checkableImageButton, onLongClickListener);
    }

    public void setStartIconOnLongClickListener(View.OnLongClickListener onLongClickListener) {
        Cif cif = this.b;
        cif.i = onLongClickListener;
        CheckableImageButton checkableImageButton = cif.d;
        checkableImageButton.setOnLongClickListener(onLongClickListener);
        AbstractC0124g3.T(checkableImageButton, onLongClickListener);
    }

    public void setStartIconScaleType(ImageView.ScaleType scaleType) {
        Cif cif = this.b;
        cif.h = scaleType;
        cif.d.setScaleType(scaleType);
    }

    public void setStartIconTintList(ColorStateList colorStateList) {
        Cif cif = this.b;
        if (cif.e != colorStateList) {
            cif.e = colorStateList;
            AbstractC0124g3.f(cif.a, cif.d, colorStateList, cif.f);
        }
    }

    public void setStartIconTintMode(PorterDuff.Mode mode) {
        Cif cif = this.b;
        if (cif.f != mode) {
            cif.f = mode;
            AbstractC0124g3.f(cif.a, cif.d, cif.e, mode);
        }
    }

    public void setStartIconVisible(boolean z) {
        this.b.c(z);
    }

    public void setSuffixText(CharSequence charSequence) {
        CharSequence charSequence2;
        N6 n6 = this.c;
        n6.getClass();
        if (TextUtils.isEmpty(charSequence)) {
            charSequence2 = null;
        } else {
            charSequence2 = charSequence;
        }
        n6.p = charSequence2;
        n6.q.setText(charSequence);
        n6.n();
    }

    public void setSuffixTextAppearance(int i) {
        this.c.q.setTextAppearance(i);
    }

    public void setSuffixTextColor(ColorStateList colorStateList) {
        this.c.q.setTextColor(colorStateList);
    }

    public void setTextInputAccessibilityDelegate(Jf jf) {
        EditText editText = this.d;
        if (editText != null) {
            AbstractC0309ph.l(editText, jf);
        }
    }

    public void setTypeface(Typeface typeface) {
        if (typeface != this.b0) {
            this.b0 = typeface;
            this.v0.m(typeface);
            C0414v9 c0414v9 = this.j;
            if (typeface != c0414v9.B) {
                c0414v9.B = typeface;
                C0123g2 c0123g2 = c0414v9.r;
                if (c0123g2 != null) {
                    c0123g2.setTypeface(typeface);
                }
                C0123g2 c0123g22 = c0414v9.y;
                if (c0123g22 != null) {
                    c0123g22.setTypeface(typeface);
                }
            }
            C0123g2 c0123g23 = this.o;
            if (c0123g23 != null) {
                c0123g23.setTypeface(typeface);
            }
        }
    }

    public final void t() {
        if (this.O != 1) {
            FrameLayout frameLayout = this.a;
            LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) frameLayout.getLayoutParams();
            int c = c();
            if (c != layoutParams.topMargin) {
                layoutParams.topMargin = c;
                frameLayout.requestLayout();
            }
        }
    }

    public final void u(boolean z, boolean z2) {
        boolean z3;
        boolean z4;
        ColorStateList colorStateList;
        C0123g2 c0123g2;
        ColorStateList colorStateList2;
        int i;
        boolean isEnabled = isEnabled();
        EditText editText = this.d;
        if (editText != null && !TextUtils.isEmpty(editText.getText())) {
            z3 = true;
        } else {
            z3 = false;
        }
        EditText editText2 = this.d;
        if (editText2 != null && editText2.hasFocus()) {
            z4 = true;
        } else {
            z4 = false;
        }
        ColorStateList colorStateList3 = this.i0;
        Y3 y3 = this.v0;
        if (colorStateList3 != null) {
            y3.i(colorStateList3);
        }
        Editable editable = null;
        if (!isEnabled) {
            ColorStateList colorStateList4 = this.i0;
            if (colorStateList4 != null) {
                i = colorStateList4.getColorForState(new int[]{-16842910}, this.s0);
            } else {
                i = this.s0;
            }
            y3.i(ColorStateList.valueOf(i));
        } else if (m()) {
            C0123g2 c0123g22 = this.j.r;
            if (c0123g22 != null) {
                colorStateList2 = c0123g22.getTextColors();
            } else {
                colorStateList2 = null;
            }
            y3.i(colorStateList2);
        } else if (this.m && (c0123g2 = this.o) != null) {
            y3.i(c0123g2.getTextColors());
        } else if (z4 && (colorStateList = this.j0) != null && y3.k != colorStateList) {
            y3.k = colorStateList;
            y3.h(false);
        }
        N6 n6 = this.c;
        Cif cif = this.b;
        if (!z3 && this.w0 && (!isEnabled() || !z4)) {
            if (z2 || !this.u0) {
                ValueAnimator valueAnimator = this.y0;
                if (valueAnimator != null && valueAnimator.isRunning()) {
                    this.y0.cancel();
                }
                if (z && this.x0) {
                    a(0.0f);
                } else {
                    y3.k(0.0f);
                }
                if (e() && !((Z4) this.F).f19x.q.isEmpty() && e()) {
                    ((Z4) this.F).n(0.0f, 0.0f, 0.0f, 0.0f);
                }
                this.u0 = true;
                C0123g2 c0123g23 = this.t;
                if (c0123g23 != null && this.s) {
                    c0123g23.setText((CharSequence) null);
                    AbstractC0345rg.a(this.a, this.f12x);
                    this.t.setVisibility(4);
                }
                cif.j = true;
                cif.e();
                n6.r = true;
                n6.n();
                return;
            }
            return;
        }
        if (z2 || this.u0) {
            ValueAnimator valueAnimator2 = this.y0;
            if (valueAnimator2 != null && valueAnimator2.isRunning()) {
                this.y0.cancel();
            }
            if (z && this.x0) {
                a(1.0f);
            } else {
                y3.k(1.0f);
            }
            this.u0 = false;
            if (e()) {
                j();
            }
            EditText editText3 = this.d;
            if (editText3 != null) {
                editable = editText3.getText();
            }
            v(editable);
            cif.j = false;
            cif.e();
            n6.r = false;
            n6.n();
        }
    }

    public final void v(Editable editable) {
        int i;
        ((I5) this.n).getClass();
        if (editable != null) {
            i = editable.length();
        } else {
            i = 0;
        }
        FrameLayout frameLayout = this.a;
        if (i == 0 && !this.u0) {
            if (this.t != null && this.s && !TextUtils.isEmpty(this.r)) {
                this.t.setText(this.r);
                AbstractC0345rg.a(frameLayout, this.w);
                this.t.setVisibility(0);
                this.t.bringToFront();
                announceForAccessibility(this.r);
                return;
            }
            return;
        }
        C0123g2 c0123g2 = this.t;
        if (c0123g2 != null && this.s) {
            c0123g2.setText((CharSequence) null);
            AbstractC0345rg.a(frameLayout, this.f12x);
            this.t.setVisibility(4);
        }
    }

    public final void w(boolean z, boolean z2) {
        int defaultColor = this.n0.getDefaultColor();
        int colorForState = this.n0.getColorForState(new int[]{R.attr.state_hovered, R.attr.state_enabled}, defaultColor);
        int colorForState2 = this.n0.getColorForState(new int[]{R.attr.state_activated, R.attr.state_enabled}, defaultColor);
        if (z) {
            this.T = colorForState2;
        } else if (z2) {
            this.T = colorForState;
        } else {
            this.T = defaultColor;
        }
    }

    public final void x() {
        boolean z;
        C0123g2 c0123g2;
        EditText editText;
        EditText editText2;
        if (this.F != null && this.O != 0) {
            boolean z2 = false;
            if (!isFocused() && ((editText2 = this.d) == null || !editText2.hasFocus())) {
                z = false;
            } else {
                z = true;
            }
            if (isHovered() || ((editText = this.d) != null && editText.isHovered())) {
                z2 = true;
            }
            if (!isEnabled()) {
                this.T = this.s0;
            } else if (m()) {
                if (this.n0 != null) {
                    w(z, z2);
                } else {
                    this.T = getErrorCurrentTextColors();
                }
            } else if (this.m && (c0123g2 = this.o) != null) {
                if (this.n0 != null) {
                    w(z, z2);
                } else {
                    this.T = c0123g2.getCurrentTextColor();
                }
            } else if (z) {
                this.T = this.m0;
            } else if (z2) {
                this.T = this.l0;
            } else {
                this.T = this.k0;
            }
            if (Build.VERSION.SDK_INT >= 29) {
                p();
            }
            N6 n6 = this.c;
            n6.l();
            CheckableImageButton checkableImageButton = n6.c;
            ColorStateList colorStateList = n6.d;
            TextInputLayout textInputLayout = n6.a;
            AbstractC0124g3.R(textInputLayout, checkableImageButton, colorStateList);
            ColorStateList colorStateList2 = n6.k;
            CheckableImageButton checkableImageButton2 = n6.g;
            AbstractC0124g3.R(textInputLayout, checkableImageButton2, colorStateList2);
            if (n6.b() instanceof C0047c6) {
                if (textInputLayout.m() && checkableImageButton2.getDrawable() != null) {
                    Drawable mutate = checkableImageButton2.getDrawable().mutate();
                    mutate.setTint(textInputLayout.getErrorCurrentTextColors());
                    checkableImageButton2.setImageDrawable(mutate);
                } else {
                    AbstractC0124g3.f(textInputLayout, checkableImageButton2, n6.k, n6.l);
                }
            }
            Cif cif = this.b;
            AbstractC0124g3.R(cif.a, cif.d, cif.e);
            if (this.O == 2) {
                int i = this.Q;
                if (z && isEnabled()) {
                    this.Q = this.S;
                } else {
                    this.Q = this.R;
                }
                if (this.Q != i && e() && !this.u0) {
                    if (e()) {
                        ((Z4) this.F).n(0.0f, 0.0f, 0.0f, 0.0f);
                    }
                    j();
                }
            }
            if (this.O == 1) {
                if (!isEnabled()) {
                    this.U = this.p0;
                } else if (z2 && !z) {
                    this.U = this.r0;
                } else if (z) {
                    this.U = this.q0;
                } else {
                    this.U = this.o0;
                }
            }
            b();
        }
    }

    public void setStartIconDrawable(Drawable drawable) {
        this.b.b(drawable);
    }

    public void setHint(int i) {
        setHint(i != 0 ? getResources().getText(i) : null);
    }

    public void setStartIconContentDescription(int i) {
        setStartIconContentDescription(i != 0 ? getResources().getText(i) : null);
    }

    @Deprecated
    public void setPasswordVisibilityToggleContentDescription(CharSequence charSequence) {
        this.c.g.setContentDescription(charSequence);
    }

    @Deprecated
    public void setPasswordVisibilityToggleDrawable(Drawable drawable) {
        this.c.g.setImageDrawable(drawable);
    }

    public void setErrorIconDrawable(Drawable drawable) {
        this.c.i(drawable);
    }

    public void setEndIconContentDescription(CharSequence charSequence) {
        CheckableImageButton checkableImageButton = this.c.g;
        if (checkableImageButton.getContentDescription() != charSequence) {
            checkableImageButton.setContentDescription(charSequence);
        }
    }

    public void setEndIconDrawable(Drawable drawable) {
        N6 n6 = this.c;
        CheckableImageButton checkableImageButton = n6.g;
        checkableImageButton.setImageDrawable(drawable);
        if (drawable != null) {
            ColorStateList colorStateList = n6.k;
            PorterDuff.Mode mode = n6.l;
            TextInputLayout textInputLayout = n6.a;
            AbstractC0124g3.f(textInputLayout, checkableImageButton, colorStateList, mode);
            AbstractC0124g3.R(textInputLayout, checkableImageButton, n6.k);
        }
    }
}
