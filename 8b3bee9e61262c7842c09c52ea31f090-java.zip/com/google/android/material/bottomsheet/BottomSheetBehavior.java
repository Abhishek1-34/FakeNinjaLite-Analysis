package com.google.android.material.bottomsheet;

import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.os.Build;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseIntArray;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.RoundedCorner;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.WindowInsets;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.animation.PathInterpolator;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.WeakHashMap;
import org.conscrypt.R;
import x.AbstractC0118fh;
import x.AbstractC0158hh;
import x.AbstractC0171ib;
import x.AbstractC0191jd;
import x.AbstractC0309ph;
import x.C0004a3;
import x.C0024b3;
import x.C0044c3;
import x.C0064d3;
import x.C0072db;
import x.C0084e3;
import x.C0092eb;
import x.C0119fi;
import x.C0139gi;
import x.C0272o;
import x.C0291p;
import x.C0346rh;
import x.C0442x;
import x.C0495ze;
import x.E9;
import x.F0;
import x.F1;
import x.G4;
import x.M4;
import x.P4;
import x.Ue;
import x.ViewOnApplyWindowInsetsListenerC0099ei;
import x.Y1;

/* loaded from: classes.dex */
public class BottomSheetBehavior<V extends View> extends M4 {
    public final C0084e3 A;
    public final ValueAnimator B;
    public final int C;
    public int D;
    public int E;
    public final float F;
    public int G;
    public final float H;
    public boolean I;
    public boolean J;
    public final boolean K;
    public int L;
    public C0346rh M;
    public boolean N;
    public int O;
    public boolean P;
    public final float Q;
    public int R;
    public int S;
    public int T;
    public WeakReference U;
    public WeakReference V;
    public final ArrayList W;
    public VelocityTracker X;
    public int Y;
    public int Z;
    public final int a;
    public boolean a0;
    public boolean b;
    public HashMap b0;
    public final float c;
    public final SparseIntArray c0;
    public final int d;
    public final C0044c3 d0;
    public int e;
    public boolean f;
    public int g;
    public final int h;
    public final C0092eb i;
    public final ColorStateList j;
    public final int k;
    public final int l;
    public int m;
    public final boolean n;
    public final boolean o;
    public final boolean p;
    public final boolean q;
    public final boolean r;
    public final boolean s;
    public final boolean t;
    public final boolean u;
    public int v;
    public int w;

    /* renamed from: x, reason: collision with root package name */
    public final boolean f9x;
    public final C0495ze y;
    public boolean z;

    public BottomSheetBehavior() {
        this.a = 0;
        this.b = true;
        this.k = -1;
        this.l = -1;
        this.A = new C0084e3(this);
        this.F = 0.5f;
        this.H = -1.0f;
        this.K = true;
        this.L = 4;
        this.Q = 0.1f;
        this.W = new ArrayList();
        this.Z = -1;
        this.c0 = new SparseIntArray();
        this.d0 = new C0044c3(this, 0);
    }

    public static View v(View view) {
        if (view.getVisibility() != 0) {
            return null;
        }
        WeakHashMap weakHashMap = AbstractC0309ph.a;
        if (AbstractC0158hh.h(view)) {
            return view;
        }
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            int childCount = viewGroup.getChildCount();
            for (int i = 0; i < childCount; i++) {
                View v = v(viewGroup.getChildAt(i));
                if (v != null) {
                    return v;
                }
            }
        }
        return null;
    }

    public static int w(int i, int i2, int i3, int i4) {
        int childMeasureSpec = ViewGroup.getChildMeasureSpec(i, i2, i4);
        if (i3 == -1) {
            return childMeasureSpec;
        }
        int mode = View.MeasureSpec.getMode(childMeasureSpec);
        int size = View.MeasureSpec.getSize(childMeasureSpec);
        if (mode != 1073741824) {
            if (size != 0) {
                i3 = Math.min(size, i3);
            }
            return View.MeasureSpec.makeMeasureSpec(i3, Integer.MIN_VALUE);
        }
        return View.MeasureSpec.makeMeasureSpec(Math.min(size, i3), 1073741824);
    }

    public final void A(int i) {
        if (i == -1) {
            if (!this.f) {
                this.f = true;
            } else {
                return;
            }
        } else if (this.f || this.e != i) {
            this.f = false;
            this.e = Math.max(0, i);
        } else {
            return;
        }
        I();
    }

    public final void B(int i) {
        String str;
        int i2;
        if (i != 1 && i != 2) {
            if (!this.I && i == 5) {
                Log.w("BottomSheetBehavior", "Cannot set state: " + i);
                return;
            }
            if (i == 6 && this.b && y(i) <= this.D) {
                i2 = 3;
            } else {
                i2 = i;
            }
            WeakReference weakReference = this.U;
            if (weakReference != null && weakReference.get() != null) {
                View view = (View) this.U.get();
                Y1 y1 = new Y1(this, view, i2);
                ViewParent parent = view.getParent();
                if (parent != null && parent.isLayoutRequested()) {
                    WeakHashMap weakHashMap = AbstractC0309ph.a;
                    if (view.isAttachedToWindow()) {
                        view.post(y1);
                        return;
                    }
                }
                y1.run();
                return;
            }
            C(i);
            return;
        }
        StringBuilder sb = new StringBuilder("STATE_");
        if (i == 1) {
            str = "DRAGGING";
        } else {
            str = "SETTLING";
        }
        sb.append(str);
        sb.append(" should not be set externally.");
        throw new IllegalArgumentException(sb.toString());
    }

    public final void C(int i) {
        if (this.L == i) {
            return;
        }
        this.L = i;
        if (i != 4 && i != 3 && i != 6) {
            boolean z = this.I;
        }
        WeakReference weakReference = this.U;
        if (weakReference == null || ((View) weakReference.get()) == null) {
            return;
        }
        if (i == 3) {
            H(true);
        } else if (i == 6 || i == 5 || i == 4) {
            H(false);
        }
        G(i, true);
        ArrayList arrayList = this.W;
        if (arrayList.size() <= 0) {
            F();
        } else {
            arrayList.get(0).getClass();
            throw new ClassCastException();
        }
    }

    public final boolean D(View view, float f) {
        if (this.J) {
            return true;
        }
        if (view.getTop() < this.G) {
            return false;
        }
        if (Math.abs(((f * this.Q) + view.getTop()) - this.G) / t() > 0.5f) {
            return true;
        }
        return false;
    }

    /* JADX WARN: Code restructure failed: missing block: B:16:0x0030, code lost:
    
        if (r3 != false) goto L16;
     */
    /* JADX WARN: Code restructure failed: missing block: B:5:0x0012, code lost:
    
        if (r1.o(r3.getLeft(), r0) != false) goto L16;
     */
    /* JADX WARN: Code restructure failed: missing block: B:6:0x0032, code lost:
    
        C(2);
        G(r4, true);
        r2.A.a(r4);
     */
    /* JADX WARN: Code restructure failed: missing block: B:7:?, code lost:
    
        return;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void E(View view, int i, boolean z) {
        int y = y(i);
        C0346rh c0346rh = this.M;
        if (c0346rh != null) {
            if (!z) {
                int left = view.getLeft();
                c0346rh.r = view;
                c0346rh.c = -1;
                boolean h = c0346rh.h(left, y, 0, 0);
                if (!h && c0346rh.a == 0 && c0346rh.r != null) {
                    c0346rh.r = null;
                }
            }
        }
        C(i);
    }

    public final void F() {
        View view;
        int i;
        boolean z;
        C0291p c0291p;
        WeakReference weakReference = this.U;
        if (weakReference != null && (view = (View) weakReference.get()) != null) {
            AbstractC0309ph.i(view, 524288);
            AbstractC0309ph.g(view, 0);
            AbstractC0309ph.i(view, 262144);
            AbstractC0309ph.g(view, 0);
            AbstractC0309ph.i(view, 1048576);
            AbstractC0309ph.g(view, 0);
            SparseIntArray sparseIntArray = this.c0;
            int i2 = sparseIntArray.get(0, -1);
            if (i2 != -1) {
                AbstractC0309ph.i(view, i2);
                AbstractC0309ph.g(view, 0);
                sparseIntArray.delete(0);
            }
            int i3 = 6;
            if (!this.b && this.L != 6) {
                String string = view.getResources().getString(R.string.bottomsheet_action_expand_halfway);
                F0 f0 = new F0(this, 6);
                ArrayList e = AbstractC0309ph.e(view);
                int i4 = 0;
                while (true) {
                    if (i4 < e.size()) {
                        if (TextUtils.equals(string, ((AccessibilityNodeInfo.AccessibilityAction) ((C0442x) e.get(i4)).a).getLabel())) {
                            i = ((C0442x) e.get(i4)).a();
                            break;
                        }
                        i4++;
                    } else {
                        int i5 = -1;
                        for (int i6 = 0; i6 < 32 && i5 == -1; i6++) {
                            int i7 = AbstractC0309ph.d[i6];
                            boolean z2 = true;
                            for (int i8 = 0; i8 < e.size(); i8++) {
                                if (((C0442x) e.get(i8)).a() != i7) {
                                    z = true;
                                } else {
                                    z = false;
                                }
                                z2 &= z;
                            }
                            if (z2) {
                                i5 = i7;
                            }
                        }
                        i = i5;
                    }
                }
                if (i != -1) {
                    C0442x c0442x = new C0442x(null, i, string, f0, null);
                    View.AccessibilityDelegate c = AbstractC0309ph.c(view);
                    if (c == null) {
                        c0291p = null;
                    } else if (c instanceof C0272o) {
                        c0291p = ((C0272o) c).a;
                    } else {
                        c0291p = new C0291p(c);
                    }
                    if (c0291p == null) {
                        c0291p = new C0291p();
                    }
                    AbstractC0309ph.l(view, c0291p);
                    AbstractC0309ph.i(view, c0442x.a());
                    AbstractC0309ph.e(view).add(c0442x);
                    AbstractC0309ph.g(view, 0);
                }
                sparseIntArray.put(0, i);
            }
            if (this.I && this.L != 5) {
                AbstractC0309ph.j(view, C0442x.j, new F0(this, 5));
            }
            int i9 = this.L;
            if (i9 != 3) {
                if (i9 != 4) {
                    if (i9 == 6) {
                        AbstractC0309ph.j(view, C0442x.i, new F0(this, 4));
                        AbstractC0309ph.j(view, C0442x.h, new F0(this, 3));
                        return;
                    }
                    return;
                }
                if (this.b) {
                    i3 = 3;
                }
                AbstractC0309ph.j(view, C0442x.h, new F0(this, i3));
                return;
            }
            if (this.b) {
                i3 = 4;
            }
            AbstractC0309ph.j(view, C0442x.i, new F0(this, i3));
        }
    }

    public final void G(int i, boolean z) {
        boolean z2;
        C0092eb c0092eb = this.i;
        ValueAnimator valueAnimator = this.B;
        if (i == 2) {
            return;
        }
        if (this.L == 3 && (this.f9x || z())) {
            z2 = true;
        } else {
            z2 = false;
        }
        if (this.z != z2 && c0092eb != null) {
            this.z = z2;
            float f = 1.0f;
            if (z && valueAnimator != null) {
                if (valueAnimator.isRunning()) {
                    valueAnimator.reverse();
                    return;
                }
                float f2 = c0092eb.a.i;
                if (z2) {
                    f = s();
                }
                valueAnimator.setFloatValues(f2, f);
                valueAnimator.start();
                return;
            }
            if (valueAnimator != null && valueAnimator.isRunning()) {
                valueAnimator.cancel();
            }
            if (this.z) {
                f = s();
            }
            C0072db c0072db = c0092eb.a;
            if (c0072db.i != f) {
                c0072db.i = f;
                c0092eb.e = true;
                c0092eb.invalidateSelf();
            }
        }
    }

    public final void H(boolean z) {
        WeakReference weakReference = this.U;
        if (weakReference == null) {
            return;
        }
        ViewParent parent = ((View) weakReference.get()).getParent();
        if (!(parent instanceof CoordinatorLayout)) {
            return;
        }
        CoordinatorLayout coordinatorLayout = (CoordinatorLayout) parent;
        int childCount = coordinatorLayout.getChildCount();
        if (z) {
            if (this.b0 == null) {
                this.b0 = new HashMap(childCount);
            } else {
                return;
            }
        }
        for (int i = 0; i < childCount; i++) {
            View childAt = coordinatorLayout.getChildAt(i);
            if (childAt != this.U.get() && z) {
                this.b0.put(childAt, Integer.valueOf(childAt.getImportantForAccessibility()));
            }
        }
        if (!z) {
            this.b0 = null;
        }
    }

    public final void I() {
        View view;
        if (this.U != null) {
            r();
            if (this.L == 4 && (view = (View) this.U.get()) != null) {
                view.requestLayout();
            }
        }
    }

    @Override // x.M4
    public final void c(P4 p4) {
        this.U = null;
        this.M = null;
    }

    @Override // x.M4
    public final void e() {
        this.U = null;
        this.M = null;
    }

    @Override // x.M4
    public final boolean f(CoordinatorLayout coordinatorLayout, View view, MotionEvent motionEvent) {
        boolean z;
        View view2;
        int i;
        C0346rh c0346rh;
        if (view.isShown() && this.K) {
            int actionMasked = motionEvent.getActionMasked();
            View view3 = null;
            if (actionMasked == 0) {
                this.Y = -1;
                this.Z = -1;
                VelocityTracker velocityTracker = this.X;
                if (velocityTracker != null) {
                    velocityTracker.recycle();
                    this.X = null;
                }
            }
            if (this.X == null) {
                this.X = VelocityTracker.obtain();
            }
            this.X.addMovement(motionEvent);
            if (actionMasked != 0) {
                if (actionMasked == 1 || actionMasked == 3) {
                    this.a0 = false;
                    this.Y = -1;
                    if (this.N) {
                        this.N = false;
                        return false;
                    }
                }
            } else {
                int x2 = (int) motionEvent.getX();
                this.Z = (int) motionEvent.getY();
                if (this.L != 2) {
                    WeakReference weakReference = this.V;
                    if (weakReference != null) {
                        view2 = (View) weakReference.get();
                    } else {
                        view2 = null;
                    }
                    if (view2 != null && coordinatorLayout.o(view2, x2, this.Z)) {
                        this.Y = motionEvent.getPointerId(motionEvent.getActionIndex());
                        this.a0 = true;
                    }
                }
                if (this.Y == -1 && !coordinatorLayout.o(view, x2, this.Z)) {
                    z = true;
                } else {
                    z = false;
                }
                this.N = z;
            }
            if (!this.N && (c0346rh = this.M) != null && c0346rh.p(motionEvent)) {
                return true;
            }
            WeakReference weakReference2 = this.V;
            if (weakReference2 != null) {
                view3 = (View) weakReference2.get();
            }
            if (actionMasked != 2 || view3 == null || this.N || this.L == 1 || coordinatorLayout.o(view3, (int) motionEvent.getX(), (int) motionEvent.getY()) || this.M == null || (i = this.Z) == -1 || Math.abs(i - motionEvent.getY()) <= this.M.b) {
                return false;
            }
            return true;
        }
        this.N = true;
        return false;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r6v6, types: [x.Gh, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r6v8, types: [java.lang.Object, android.view.View$OnAttachStateChangeListener] */
    @Override // x.M4
    public final boolean g(CoordinatorLayout coordinatorLayout, View view, int i) {
        boolean z;
        int i2 = this.l;
        C0092eb c0092eb = this.i;
        WeakHashMap weakHashMap = AbstractC0309ph.a;
        if (coordinatorLayout.getFitsSystemWindows() && !view.getFitsSystemWindows()) {
            view.setFitsSystemWindows(true);
        }
        if (this.U == null) {
            this.g = coordinatorLayout.getResources().getDimensionPixelSize(R.dimen.design_bottom_sheet_peek_height_min);
            int i3 = Build.VERSION.SDK_INT;
            if (i3 >= 29 && !this.n && !this.f) {
                z = true;
            } else {
                z = false;
            }
            if (this.o || this.p || this.q || this.s || this.t || this.u || z) {
                C0024b3 c0024b3 = new C0024b3(this, z);
                int paddingStart = view.getPaddingStart();
                view.getPaddingTop();
                int paddingEnd = view.getPaddingEnd();
                int paddingBottom = view.getPaddingBottom();
                ?? obj = new Object();
                obj.a = paddingStart;
                obj.b = paddingEnd;
                obj.c = paddingBottom;
                AbstractC0158hh.l(view, new F1(c0024b3, 19, (Object) obj));
                if (view.isAttachedToWindow()) {
                    AbstractC0118fh.c(view);
                } else {
                    view.addOnAttachStateChangeListener(new Object());
                }
            }
            G4 g4 = new G4(view);
            if (i3 >= 30) {
                view.setWindowInsetsAnimationCallback(new C0139gi(g4));
            } else {
                PathInterpolator pathInterpolator = C0119fi.e;
                Object tag = view.getTag(R.id.tag_on_apply_window_listener);
                ViewOnApplyWindowInsetsListenerC0099ei viewOnApplyWindowInsetsListenerC0099ei = new ViewOnApplyWindowInsetsListenerC0099ei(view, g4);
                view.setTag(R.id.tag_window_insets_animation_callback, viewOnApplyWindowInsetsListenerC0099ei);
                if (tag == null) {
                    view.setOnApplyWindowInsetsListener(viewOnApplyWindowInsetsListenerC0099ei);
                }
            }
            this.U = new WeakReference(view);
            Context context = view.getContext();
            AbstractC0171ib.R(context, R.attr.motionEasingStandardDecelerateInterpolator, new PathInterpolator(0.0f, 0.0f, 0.0f, 1.0f));
            AbstractC0171ib.Q(context, R.attr.motionDurationMedium2, 300);
            AbstractC0171ib.Q(context, R.attr.motionDurationShort3, 150);
            AbstractC0171ib.Q(context, R.attr.motionDurationShort2, 100);
            Resources resources = view.getResources();
            resources.getDimension(R.dimen.m3_back_progress_bottom_container_max_scale_x_distance);
            resources.getDimension(R.dimen.m3_back_progress_bottom_container_max_scale_y_distance);
            if (c0092eb != null) {
                view.setBackground(c0092eb);
                float f = this.H;
                if (f == -1.0f) {
                    f = AbstractC0158hh.e(view);
                }
                c0092eb.i(f);
            } else {
                ColorStateList colorStateList = this.j;
                if (colorStateList != null) {
                    AbstractC0158hh.i(view, colorStateList);
                }
            }
            F();
            if (view.getImportantForAccessibility() == 0) {
                view.setImportantForAccessibility(1);
            }
        }
        if (this.M == null) {
            this.M = new C0346rh(coordinatorLayout.getContext(), coordinatorLayout, this.d0);
        }
        int top = view.getTop();
        coordinatorLayout.q(view, i);
        this.S = coordinatorLayout.getWidth();
        this.T = coordinatorLayout.getHeight();
        int height = view.getHeight();
        this.R = height;
        int i4 = this.T;
        int i5 = i4 - height;
        int i6 = this.w;
        if (i5 < i6) {
            if (this.r) {
                if (i2 != -1) {
                    i4 = Math.min(i4, i2);
                }
                this.R = i4;
            } else {
                int i7 = i4 - i6;
                if (i2 != -1) {
                    i7 = Math.min(i7, i2);
                }
                this.R = i7;
            }
        }
        this.D = Math.max(0, this.T - this.R);
        this.E = (int) ((1.0f - this.F) * this.T);
        r();
        int i8 = this.L;
        if (i8 == 3) {
            view.offsetTopAndBottom(x());
        } else if (i8 == 6) {
            view.offsetTopAndBottom(this.E);
        } else if (this.I && i8 == 5) {
            view.offsetTopAndBottom(this.T);
        } else if (i8 == 4) {
            view.offsetTopAndBottom(this.G);
        } else if (i8 == 1 || i8 == 2) {
            view.offsetTopAndBottom(top - view.getTop());
        }
        G(this.L, false);
        this.V = new WeakReference(v(view));
        ArrayList arrayList = this.W;
        if (arrayList.size() <= 0) {
            return true;
        }
        arrayList.get(0).getClass();
        throw new ClassCastException();
    }

    @Override // x.M4
    public final boolean h(CoordinatorLayout coordinatorLayout, View view, int i, int i2, int i3) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        view.measure(w(i, coordinatorLayout.getPaddingRight() + coordinatorLayout.getPaddingLeft() + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + i2, this.k, marginLayoutParams.width), w(i3, coordinatorLayout.getPaddingBottom() + coordinatorLayout.getPaddingTop() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin, this.l, marginLayoutParams.height));
        return true;
    }

    @Override // x.M4
    public final boolean i(View view) {
        WeakReference weakReference = this.V;
        if (weakReference == null || view != weakReference.get() || this.L == 3) {
            return false;
        }
        return true;
    }

    @Override // x.M4
    public final void j(CoordinatorLayout coordinatorLayout, View view, View view2, int i, int i2, int[] iArr, int i3) {
        View view3;
        boolean z = this.K;
        if (i3 == 1) {
            return;
        }
        WeakReference weakReference = this.V;
        if (weakReference != null) {
            view3 = (View) weakReference.get();
        } else {
            view3 = null;
        }
        if (view2 != view3) {
            return;
        }
        int top = view.getTop();
        int i4 = top - i2;
        if (i2 > 0) {
            if (i4 < x()) {
                int x2 = top - x();
                iArr[1] = x2;
                WeakHashMap weakHashMap = AbstractC0309ph.a;
                view.offsetTopAndBottom(-x2);
                C(3);
            } else {
                if (!z) {
                    return;
                }
                iArr[1] = i2;
                WeakHashMap weakHashMap2 = AbstractC0309ph.a;
                view.offsetTopAndBottom(-i2);
                C(1);
            }
        } else if (i2 < 0 && !view2.canScrollVertically(-1)) {
            int i5 = this.G;
            if (i4 > i5 && !this.I) {
                int i6 = top - i5;
                iArr[1] = i6;
                WeakHashMap weakHashMap3 = AbstractC0309ph.a;
                view.offsetTopAndBottom(-i6);
                C(4);
            } else {
                if (!z) {
                    return;
                }
                iArr[1] = i2;
                WeakHashMap weakHashMap4 = AbstractC0309ph.a;
                view.offsetTopAndBottom(-i2);
                C(1);
            }
        }
        u(view.getTop());
        this.O = i2;
        this.P = true;
    }

    @Override // x.M4
    public final void k(CoordinatorLayout coordinatorLayout, View view, int i, int i2, int i3, int[] iArr) {
    }

    @Override // x.M4
    public final void m(View view, Parcelable parcelable) {
        C0064d3 c0064d3 = (C0064d3) parcelable;
        int i = this.a;
        if (i != 0) {
            if (i == -1 || (i & 1) == 1) {
                this.e = c0064d3.d;
            }
            if (i == -1 || (i & 2) == 2) {
                this.b = c0064d3.e;
            }
            if (i == -1 || (i & 4) == 4) {
                this.I = c0064d3.f;
            }
            if (i == -1 || (i & 8) == 8) {
                this.J = c0064d3.g;
            }
        }
        int i2 = c0064d3.c;
        if (i2 != 1 && i2 != 2) {
            this.L = i2;
        } else {
            this.L = 4;
        }
    }

    @Override // x.M4
    public final Parcelable n(View view) {
        return new C0064d3(View.BaseSavedState.EMPTY_STATE, this);
    }

    @Override // x.M4
    public final boolean o(View view, int i, int i2) {
        this.O = 0;
        this.P = false;
        if ((i & 2) == 0) {
            return false;
        }
        return true;
    }

    /* JADX WARN: Code restructure failed: missing block: B:17:0x0030, code lost:
    
        if (r4.getTop() <= r3.E) goto L51;
     */
    /* JADX WARN: Code restructure failed: missing block: B:35:0x0071, code lost:
    
        if (java.lang.Math.abs(r5 - r3.D) < java.lang.Math.abs(r5 - r3.G)) goto L51;
     */
    /* JADX WARN: Code restructure failed: missing block: B:40:0x0080, code lost:
    
        if (r5 < java.lang.Math.abs(r5 - r3.G)) goto L51;
     */
    /* JADX WARN: Code restructure failed: missing block: B:42:0x0090, code lost:
    
        if (java.lang.Math.abs(r5 - r2) < java.lang.Math.abs(r5 - r3.G)) goto L50;
     */
    /* JADX WARN: Code restructure failed: missing block: B:46:0x00ac, code lost:
    
        if (java.lang.Math.abs(r5 - r3.E) < java.lang.Math.abs(r5 - r3.G)) goto L50;
     */
    @Override // x.M4
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void p(View view, View view2, int i) {
        float yVelocity;
        int i2 = 3;
        if (view.getTop() == x()) {
            C(3);
            return;
        }
        WeakReference weakReference = this.V;
        if (weakReference != null && view2 == weakReference.get() && this.P) {
            if (this.O > 0) {
                if (!this.b) {
                }
                E(view, i2, false);
                this.P = false;
            }
            if (this.I) {
                VelocityTracker velocityTracker = this.X;
                if (velocityTracker == null) {
                    yVelocity = 0.0f;
                } else {
                    velocityTracker.computeCurrentVelocity(1000, this.c);
                    yVelocity = this.X.getYVelocity(this.Y);
                }
                if (D(view, yVelocity)) {
                    i2 = 5;
                    E(view, i2, false);
                    this.P = false;
                }
            }
            if (this.O == 0) {
                int top = view.getTop();
                if (!this.b) {
                    int i3 = this.E;
                    if (top < i3) {
                    }
                    i2 = 6;
                }
            } else {
                if (!this.b) {
                    int top2 = view.getTop();
                }
                i2 = 4;
            }
            E(view, i2, false);
            this.P = false;
        }
    }

    @Override // x.M4
    public final boolean q(View view, MotionEvent motionEvent) {
        if (!view.isShown()) {
            return false;
        }
        int actionMasked = motionEvent.getActionMasked();
        int i = this.L;
        if (i == 1 && actionMasked == 0) {
            return true;
        }
        C0346rh c0346rh = this.M;
        if (c0346rh != null && (this.K || i == 1)) {
            c0346rh.j(motionEvent);
        }
        if (actionMasked == 0) {
            this.Y = -1;
            this.Z = -1;
            VelocityTracker velocityTracker = this.X;
            if (velocityTracker != null) {
                velocityTracker.recycle();
                this.X = null;
            }
        }
        if (this.X == null) {
            this.X = VelocityTracker.obtain();
        }
        this.X.addMovement(motionEvent);
        if (this.M != null && ((this.K || this.L == 1) && actionMasked == 2 && !this.N)) {
            float abs = Math.abs(this.Z - motionEvent.getY());
            C0346rh c0346rh2 = this.M;
            if (abs > c0346rh2.b) {
                c0346rh2.b(view, motionEvent.getPointerId(motionEvent.getActionIndex()));
            }
        }
        return !this.N;
    }

    public final void r() {
        int t = t();
        if (this.b) {
            this.G = Math.max(this.T - t, this.D);
        } else {
            this.G = this.T - t;
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:22:0x0065  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final float s() {
        WeakReference weakReference;
        WindowInsets rootWindowInsets;
        RoundedCorner roundedCorner;
        float f;
        RoundedCorner roundedCorner2;
        int radius;
        int radius2;
        float f2 = 0.0f;
        if (this.i != null && (weakReference = this.U) != null && weakReference.get() != null && Build.VERSION.SDK_INT >= 31) {
            View view = (View) this.U.get();
            if (z() && (rootWindowInsets = view.getRootWindowInsets()) != null) {
                C0092eb c0092eb = this.i;
                float a = c0092eb.a.a.e.a(c0092eb.f());
                roundedCorner = rootWindowInsets.getRoundedCorner(0);
                if (roundedCorner != null) {
                    radius2 = roundedCorner.getRadius();
                    float f3 = radius2;
                    if (f3 > 0.0f && a > 0.0f) {
                        f = f3 / a;
                        C0092eb c0092eb2 = this.i;
                        float a2 = c0092eb2.a.a.f.a(c0092eb2.f());
                        roundedCorner2 = rootWindowInsets.getRoundedCorner(1);
                        if (roundedCorner2 != null) {
                            radius = roundedCorner2.getRadius();
                            float f4 = radius;
                            if (f4 > 0.0f && a2 > 0.0f) {
                                f2 = f4 / a2;
                            }
                        }
                        return Math.max(f, f2);
                    }
                }
                f = 0.0f;
                C0092eb c0092eb22 = this.i;
                float a22 = c0092eb22.a.a.f.a(c0092eb22.f());
                roundedCorner2 = rootWindowInsets.getRoundedCorner(1);
                if (roundedCorner2 != null) {
                }
                return Math.max(f, f2);
            }
        }
        return 0.0f;
    }

    public final int t() {
        int i;
        if (this.f) {
            return Math.min(Math.max(this.g, this.T - ((this.S * 9) / 16)), this.R) + this.v;
        }
        if (!this.n && !this.o && (i = this.m) > 0) {
            return Math.max(this.e, i + this.h);
        }
        return this.e + this.v;
    }

    public final void u(int i) {
        if (((View) this.U.get()) != null) {
            ArrayList arrayList = this.W;
            if (!arrayList.isEmpty()) {
                int i2 = this.G;
                if (i <= i2 && i2 != x()) {
                    x();
                }
                if (arrayList.size() > 0) {
                    arrayList.get(0).getClass();
                    throw new ClassCastException();
                }
            }
        }
    }

    public final int x() {
        int i;
        if (this.b) {
            return this.D;
        }
        int i2 = this.C;
        if (this.r) {
            i = 0;
        } else {
            i = this.w;
        }
        return Math.max(i2, i);
    }

    public final int y(int i) {
        if (i != 3) {
            if (i != 4) {
                if (i != 5) {
                    if (i == 6) {
                        return this.E;
                    }
                    throw new IllegalArgumentException(Ue.d("Invalid state to get top offset: ", i));
                }
                return this.T;
            }
            return this.G;
        }
        return x();
    }

    public final boolean z() {
        WeakReference weakReference = this.U;
        if (weakReference == null || weakReference.get() == null) {
            return false;
        }
        int[] iArr = new int[2];
        ((View) this.U.get()).getLocationOnScreen(iArr);
        if (iArr[1] != 0) {
            return false;
        }
        return true;
    }

    public BottomSheetBehavior(Context context, AttributeSet attributeSet) {
        int i;
        int i2 = 0;
        this.a = 0;
        this.b = true;
        this.k = -1;
        this.l = -1;
        this.A = new C0084e3(this);
        this.F = 0.5f;
        this.H = -1.0f;
        this.K = true;
        this.L = 4;
        this.Q = 0.1f;
        this.W = new ArrayList();
        this.Z = -1;
        this.c0 = new SparseIntArray();
        this.d0 = new C0044c3(this, i2);
        this.h = context.getResources().getDimensionPixelSize(R.dimen.mtrl_min_touch_target_size);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, AbstractC0191jd.a);
        if (obtainStyledAttributes.hasValue(3)) {
            this.j = E9.B(context, obtainStyledAttributes, 3);
        }
        if (obtainStyledAttributes.hasValue(21)) {
            this.y = C0495ze.b(context, attributeSet, R.attr.bottomSheetStyle, R.style.Widget_Design_BottomSheet_Modal).a();
        }
        C0495ze c0495ze = this.y;
        if (c0495ze != null) {
            C0092eb c0092eb = new C0092eb(c0495ze);
            this.i = c0092eb;
            c0092eb.h(context);
            ColorStateList colorStateList = this.j;
            if (colorStateList != null) {
                this.i.j(colorStateList);
            } else {
                TypedValue typedValue = new TypedValue();
                context.getTheme().resolveAttribute(android.R.attr.colorBackground, typedValue, true);
                this.i.setTint(typedValue.data);
            }
        }
        ValueAnimator ofFloat = ValueAnimator.ofFloat(s(), 1.0f);
        this.B = ofFloat;
        ofFloat.setDuration(500L);
        this.B.addUpdateListener(new C0004a3(i2, this));
        this.H = obtainStyledAttributes.getDimension(2, -1.0f);
        if (obtainStyledAttributes.hasValue(0)) {
            this.k = obtainStyledAttributes.getDimensionPixelSize(0, -1);
        }
        if (obtainStyledAttributes.hasValue(1)) {
            this.l = obtainStyledAttributes.getDimensionPixelSize(1, -1);
        }
        TypedValue peekValue = obtainStyledAttributes.peekValue(9);
        if (peekValue != null && (i = peekValue.data) == -1) {
            A(i);
        } else {
            A(obtainStyledAttributes.getDimensionPixelSize(9, -1));
        }
        boolean z = obtainStyledAttributes.getBoolean(8, false);
        if (this.I != z) {
            this.I = z;
            if (!z && this.L == 5) {
                B(4);
            }
            F();
        }
        this.n = obtainStyledAttributes.getBoolean(13, false);
        boolean z2 = obtainStyledAttributes.getBoolean(6, true);
        if (this.b != z2) {
            this.b = z2;
            if (this.U != null) {
                r();
            }
            C((this.b && this.L == 6) ? 3 : this.L);
            G(this.L, true);
            F();
        }
        this.J = obtainStyledAttributes.getBoolean(12, false);
        this.K = obtainStyledAttributes.getBoolean(4, true);
        this.a = obtainStyledAttributes.getInt(10, 0);
        float f = obtainStyledAttributes.getFloat(7, 0.5f);
        if (f > 0.0f && f < 1.0f) {
            this.F = f;
            if (this.U != null) {
                this.E = (int) ((1.0f - f) * this.T);
            }
            TypedValue peekValue2 = obtainStyledAttributes.peekValue(5);
            if (peekValue2 != null && peekValue2.type == 16) {
                int i3 = peekValue2.data;
                if (i3 >= 0) {
                    this.C = i3;
                    G(this.L, true);
                } else {
                    throw new IllegalArgumentException("offset must be greater than or equal to 0");
                }
            } else {
                int dimensionPixelOffset = obtainStyledAttributes.getDimensionPixelOffset(5, 0);
                if (dimensionPixelOffset >= 0) {
                    this.C = dimensionPixelOffset;
                    G(this.L, true);
                } else {
                    throw new IllegalArgumentException("offset must be greater than or equal to 0");
                }
            }
            this.d = obtainStyledAttributes.getInt(11, 500);
            this.o = obtainStyledAttributes.getBoolean(17, false);
            this.p = obtainStyledAttributes.getBoolean(18, false);
            this.q = obtainStyledAttributes.getBoolean(19, false);
            this.r = obtainStyledAttributes.getBoolean(20, true);
            this.s = obtainStyledAttributes.getBoolean(14, false);
            this.t = obtainStyledAttributes.getBoolean(15, false);
            this.u = obtainStyledAttributes.getBoolean(16, false);
            this.f9x = obtainStyledAttributes.getBoolean(23, true);
            obtainStyledAttributes.recycle();
            this.c = ViewConfiguration.get(context).getScaledMaximumFlingVelocity();
            return;
        }
        throw new IllegalArgumentException("ratio must be a float value between 0 and 1");
    }
}
