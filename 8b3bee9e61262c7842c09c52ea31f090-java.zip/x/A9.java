package x;

import android.content.ClipDescription;
import android.net.Uri;

/* loaded from: classes.dex */
public interface A9 {
    ClipDescription a();

    void b();

    Uri c();

    Object d();

    Uri e();
}
