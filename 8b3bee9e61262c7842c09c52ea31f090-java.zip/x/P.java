package x;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.content.res.ColorStateList;
import android.view.View;
import androidx.appcompat.widget.ActionBarOverlayLayout;
import com.google.android.material.behavior.HideBottomViewOnScrollBehavior;
import java.util.ArrayList;
import org.conscrypt.ct.CTConstants;

/* loaded from: classes.dex */
public final class P extends AnimatorListenerAdapter {
    public final /* synthetic */ int a;
    public final /* synthetic */ Object b;

    public /* synthetic */ P(int i, Object obj) {
        this.a = i;
        this.b = obj;
    }

    @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
    public void onAnimationCancel(Animator animator) {
        switch (this.a) {
            case 0:
                ActionBarOverlayLayout actionBarOverlayLayout = (ActionBarOverlayLayout) this.b;
                actionBarOverlayLayout.w = null;
                actionBarOverlayLayout.j = false;
                return;
            case 5:
                ((Ch) this.b).b();
                return;
            default:
                super.onAnimationCancel(animator);
                return;
        }
    }

    @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
    public final void onAnimationEnd(Animator animator) {
        switch (this.a) {
            case 0:
                ActionBarOverlayLayout actionBarOverlayLayout = (ActionBarOverlayLayout) this.b;
                actionBarOverlayLayout.w = null;
                actionBarOverlayLayout.j = false;
                return;
            case 1:
                M0 m0 = (M0) this.b;
                ArrayList arrayList = new ArrayList(m0.e);
                int size = arrayList.size();
                for (int i = 0; i < size; i++) {
                    ColorStateList colorStateList = ((Wa) arrayList.get(i)).b.o;
                    if (colorStateList != null) {
                        m0.setTintList(colorStateList);
                    }
                }
                return;
            case 2:
                C0047c6 c0047c6 = (C0047c6) this.b;
                c0047c6.q();
                c0047c6.r.start();
                return;
            case CTConstants.CERTIFICATE_LENGTH_BYTES /* 3 */:
                ((HideBottomViewOnScrollBehavior) this.b).h = null;
                return;
            case 4:
                ((AbstractC0270ng) this.b).m();
                animator.removeListener(this);
                return;
            default:
                ((Ch) this.b).a();
                return;
        }
    }

    @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
    public void onAnimationStart(Animator animator) {
        switch (this.a) {
            case 1:
                M0 m0 = (M0) this.b;
                ArrayList arrayList = new ArrayList(m0.e);
                int size = arrayList.size();
                for (int i = 0; i < size; i++) {
                    Ya ya = ((Wa) arrayList.get(i)).b;
                    ColorStateList colorStateList = ya.o;
                    if (colorStateList != null) {
                        m0.setTint(colorStateList.getColorForState(ya.s, colorStateList.getDefaultColor()));
                    }
                }
                return;
            case 5:
                ((Ch) this.b).c();
                return;
            default:
                super.onAnimationStart(animator);
                return;
        }
    }

    public P(Ch ch, View view) {
        this.a = 5;
        this.b = ch;
    }
}
