package x;

import android.content.Context;
import android.content.Intent;
import android.net.VpnService;
import android.provider.Settings;
import android.widget.TextView;
import java.util.concurrent.ThreadPoolExecutor;

/* renamed from: x.o6, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final /* synthetic */ class RunnableC0279o6 implements Runnable {
    public final /* synthetic */ int a;
    public final /* synthetic */ Object b;
    public final /* synthetic */ Object c;
    public final /* synthetic */ Object d;

    public /* synthetic */ RunnableC0279o6(Object obj, Object obj2, Object obj3, int i) {
        this.a = i;
        this.b = obj;
        this.c = obj2;
        this.d = obj3;
    }

    @Override // java.lang.Runnable
    public final void run() {
        String concat;
        switch (this.a) {
            case 0:
                C0317q6 c0317q6 = (C0317q6) this.b;
                E9 e9 = (E9) this.c;
                ThreadPoolExecutor threadPoolExecutor = (ThreadPoolExecutor) this.d;
                c0317q6.getClass();
                try {
                    N7 s = E9.s(c0317q6.a);
                    if (s != null) {
                        M7 m7 = (M7) ((InterfaceC0241m6) s.b);
                        synchronized (m7.d) {
                            m7.f = threadPoolExecutor;
                        }
                        ((InterfaceC0241m6) s.b).a(new C0298p6(e9, threadPoolExecutor));
                        return;
                    }
                    throw new RuntimeException("EmojiCompat font provider not available on this device.");
                } catch (Throwable th) {
                    e9.Q(th);
                    threadPoolExecutor.shutdown();
                    return;
                }
            default:
                String str = (String) this.c;
                vpn.team09.hax.b bVar = (vpn.team09.hax.b) this.b;
                bVar.N = false;
                bVar.B.setEnabled(true);
                bVar.B.setText("INICIAR");
                F2 f2 = (F2) this.d;
                if (!f2.a) {
                    bVar.O = false;
                    bVar.r(false);
                    TextView textView = bVar.D;
                    StringBuilder sb = new StringBuilder();
                    String str2 = f2.b;
                    if (str2.isEmpty()) {
                        str2 = "ACESSO NEGADO";
                    }
                    sb.append(str2);
                    sb.append(" · ");
                    sb.append(f2.c);
                    textView.setText(sb.toString());
                    return;
                }
                try {
                    bVar.P.G(str, f2);
                    bVar.O = true;
                    bVar.C.setEnabled(false);
                    bVar.E.setVisibility(0);
                    bVar.r(f2.f);
                    String str3 = f2.e;
                    if (str3.isEmpty()) {
                        concat = "sem vencimento informado";
                    } else {
                        concat = "validade ".concat(str3);
                    }
                    bVar.D.setText("Acesso confirmado · " + concat);
                    Context context = E7.b;
                    if (context != null && Settings.canDrawOverlays(context)) {
                        if (bVar.O) {
                            Intent prepare = VpnService.prepare(bVar);
                            if (prepare != null) {
                                bVar.U.H0(prepare);
                                return;
                            } else {
                                bVar.v();
                                return;
                            }
                        }
                        return;
                    }
                    bVar.t();
                    return;
                } catch (Exception unused) {
                    bVar.D.setText("A key foi aceita, mas não foi possível salvar o login.");
                    return;
                }
        }
    }
}
