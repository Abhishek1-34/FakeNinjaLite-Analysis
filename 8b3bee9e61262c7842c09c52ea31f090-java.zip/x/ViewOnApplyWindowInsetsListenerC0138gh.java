package x;

import android.os.Build;
import android.view.View;
import android.view.WindowInsets;
import java.util.WeakHashMap;

/* renamed from: x.gh, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class ViewOnApplyWindowInsetsListenerC0138gh implements View.OnApplyWindowInsetsListener {
    public wi a = null;
    public final /* synthetic */ View b;
    public final /* synthetic */ InterfaceC0093ec c;

    public ViewOnApplyWindowInsetsListenerC0138gh(View view, InterfaceC0093ec interfaceC0093ec) {
        this.b = view;
        this.c = interfaceC0093ec;
    }

    @Override // android.view.View.OnApplyWindowInsetsListener
    public WindowInsets onApplyWindowInsets(View view, WindowInsets windowInsets) {
        wi g = wi.g(view, windowInsets);
        int i = Build.VERSION.SDK_INT;
        InterfaceC0093ec interfaceC0093ec = this.c;
        if (i < 30) {
            AbstractC0158hh.a(windowInsets, this.b);
            if (g.equals(this.a)) {
                return interfaceC0093ec.m(view, g).f();
            }
        }
        this.a = g;
        wi m = interfaceC0093ec.m(view, g);
        if (i >= 30) {
            return m.f();
        }
        WeakHashMap weakHashMap = AbstractC0309ph.a;
        AbstractC0118fh.c(view);
        return m.f();
    }
}
