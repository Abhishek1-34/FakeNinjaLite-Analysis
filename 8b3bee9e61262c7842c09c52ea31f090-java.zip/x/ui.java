package x;

import android.os.Build;
import android.view.View;
import java.util.Objects;

/* loaded from: classes.dex */
public class ui {
    public static final wi b;
    public final wi a;

    static {
        oi kiVar;
        int i = Build.VERSION.SDK_INT;
        if (i >= 30) {
            kiVar = new ni();
        } else if (i >= 29) {
            kiVar = new mi();
        } else {
            kiVar = new ki();
        }
        b = kiVar.b().a.a().a.b().a.c();
    }

    public ui(wi wiVar) {
        this.a = wiVar;
    }

    public wi a() {
        return this.a;
    }

    public wi b() {
        return this.a;
    }

    public wi c() {
        return this.a;
    }

    public void d(View view) {
    }

    public M5 e() {
        return null;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof ui)) {
            return false;
        }
        ui uiVar = (ui) obj;
        if (n() == uiVar.n() && m() == uiVar.m() && Objects.equals(j(), uiVar.j()) && Objects.equals(h(), uiVar.h()) && Objects.equals(e(), uiVar.e())) {
            return true;
        }
        return false;
    }

    public C9 f(int i) {
        return C9.e;
    }

    public C9 g() {
        return j();
    }

    public C9 h() {
        return C9.e;
    }

    public int hashCode() {
        return Objects.hash(Boolean.valueOf(n()), Boolean.valueOf(m()), j(), h(), e());
    }

    public C9 i() {
        return j();
    }

    public C9 j() {
        return C9.e;
    }

    public C9 k() {
        return j();
    }

    public wi l(int i, int i2, int i3, int i4) {
        return b;
    }

    public boolean m() {
        return false;
    }

    public boolean n() {
        return false;
    }

    public void o(C9[] c9Arr) {
    }

    public void p(wi wiVar) {
    }

    public void q(C9 c9) {
    }
}
