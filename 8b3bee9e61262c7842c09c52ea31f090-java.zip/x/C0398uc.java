package x;

import android.os.SystemClock;
import android.util.Log;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.security.SecureRandom;
import java.util.Arrays;

/* renamed from: x.uc, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0398uc {
    public final String a;
    public final String b;
    public final int c;
    public final String d;
    public final int e;
    public final int f;
    public final long g;
    public volatile Socket h;
    public volatile InputStream i;
    public volatile OutputStream j;
    public volatile long k;
    public volatile long l;
    public volatile long m = SystemClock.elapsedRealtime();
    public volatile boolean n;
    public volatile boolean o;
    public final /* synthetic */ C0436wc p;

    public C0398uc(C0436wc c0436wc, String str, String str2, int i, String str3, int i2, long j, int i3) {
        this.p = c0436wc;
        this.a = str;
        this.b = str2;
        this.c = i;
        this.d = str3;
        this.e = i2;
        this.f = i3;
        this.k = C0436wc.b(j, 1L);
        long nextInt = new SecureRandom().nextInt() & 4294967295L;
        this.g = nextInt;
        this.l = C0436wc.b(nextInt, 1L);
    }

    public final void a() {
        if (this.o) {
            return;
        }
        this.o = true;
        Yb.d("close", "TCP", this.a);
        Socket socket = this.h;
        if (socket != null) {
            try {
                socket.close();
            } catch (IOException unused) {
            }
        }
    }

    public final void b() {
        int read;
        byte[] bArr = new byte[16384];
        InputStream inputStream = this.i;
        if (inputStream == null) {
            return;
        }
        while (true) {
            try {
                int i = 0;
                if (!this.p.e.get() || this.o || (read = inputStream.read(bArr)) < 0) {
                    break;
                }
                if (read != 0) {
                    while (i < read && this.p.e.get() && !this.o) {
                        int min = Math.min(this.f, read - i);
                        int i2 = i + min;
                        byte[] copyOfRange = Arrays.copyOfRange(bArr, i, i2);
                        synchronized (this) {
                            this.p.k(this.d, this.e, this.b, this.c, this.l, this.k, 24, copyOfRange, 0);
                            Yb.f("S2C", 6, copyOfRange.length);
                            this.l = C0436wc.b(this.l, min);
                            C0436wc.c(copyOfRange, this.e);
                            this.m = SystemClock.elapsedRealtime();
                        }
                        Z6.c.incrementAndGet();
                        i = i2;
                    }
                }
            } catch (IOException unused) {
                if (!this.o && this.p.e.get()) {
                    Log.d("ProjectX-Packet", "Fluxo TCP encerrado: " + this.a);
                    return;
                }
                return;
            }
        }
        synchronized (this) {
            try {
                if (!this.o) {
                    this.p.k(this.d, this.e, this.b, this.c, this.l, this.k, 17, new byte[0], 0);
                    this.l = C0436wc.b(this.l, 1L);
                }
            } finally {
            }
        }
    }

    public final synchronized void c() {
        if (this.n && !this.o) {
            this.m = SystemClock.elapsedRealtime();
            this.p.k(this.d, this.e, this.b, this.c, this.g, this.k, 18, new byte[0], 1360);
            Yb.f("S2C", 6, 0);
        }
    }
}
