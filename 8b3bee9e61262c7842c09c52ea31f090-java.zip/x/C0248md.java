package x;

import java.io.Serializable;

/* renamed from: x.md, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0248md extends AbstractC0267nd implements Serializable {
    @Override // x.AbstractC0267nd
    public final int a() {
        return AbstractC0267nd.b.a();
    }
}
