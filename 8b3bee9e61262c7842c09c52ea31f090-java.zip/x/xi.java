package x;

import android.view.View;
import android.view.Window;

/* loaded from: classes.dex */
public class xi extends AbstractC0171ib {
    public final Window l;

    public xi(Window window, C0107f6 c0107f6) {
        this.l = window;
    }

    @Override // x.AbstractC0171ib
    public final void T(boolean z) {
        if (z) {
            Window window = this.l;
            window.clearFlags(67108864);
            window.addFlags(Integer.MIN_VALUE);
            View decorView = window.getDecorView();
            decorView.setSystemUiVisibility(8192 | decorView.getSystemUiVisibility());
            return;
        }
        a0(8192);
    }

    public final void a0(int i) {
        View decorView = this.l.getDecorView();
        decorView.setSystemUiVisibility((~i) & decorView.getSystemUiVisibility());
    }
}
