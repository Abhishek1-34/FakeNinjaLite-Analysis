package x;

import android.os.Parcel;
import android.os.Parcelable;
import java.util.ArrayList;

/* renamed from: x.u8, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0394u8 implements Parcelable {
    public static final Parcelable.Creator<C0394u8> CREATOR = new C0197k0(7);
    public ArrayList a;
    public ArrayList b;
    public M2[] c;
    public int d;
    public String e;
    public ArrayList f;
    public ArrayList g;
    public ArrayList h;

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i) {
        parcel.writeStringList(this.a);
        parcel.writeStringList(this.b);
        parcel.writeTypedArray(this.c, i);
        parcel.writeInt(this.d);
        parcel.writeString(this.e);
        parcel.writeStringList(this.f);
        parcel.writeTypedList(this.g);
        parcel.writeTypedList(this.h);
    }
}
