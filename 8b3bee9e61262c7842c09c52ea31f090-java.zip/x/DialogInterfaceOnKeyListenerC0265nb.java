package x;

import android.content.DialogInterface;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;

/* renamed from: x.nb, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class DialogInterfaceOnKeyListenerC0265nb implements DialogInterface.OnKeyListener, DialogInterface.OnClickListener, DialogInterface.OnDismissListener, Bb {
    public SubMenuC0363sf a;
    public G0 b;
    public C0207ka c;

    @Override // x.Bb
    public final void b(MenuC0246mb menuC0246mb, boolean z) {
        G0 g0;
        if ((z || menuC0246mb == this.a) && (g0 = this.b) != null) {
            g0.dismiss();
        }
    }

    @Override // android.content.DialogInterface.OnClickListener
    public final void onClick(DialogInterface dialogInterface, int i) {
        C0207ka c0207ka = this.c;
        if (c0207ka.f == null) {
            c0207ka.f = new C0188ja(c0207ka);
        }
        this.a.q(c0207ka.f.getItem(i), null, 0);
    }

    @Override // android.content.DialogInterface.OnDismissListener
    public final void onDismiss(DialogInterface dialogInterface) {
        this.c.b(this.a, true);
    }

    @Override // android.content.DialogInterface.OnKeyListener
    public final boolean onKey(DialogInterface dialogInterface, int i, KeyEvent keyEvent) {
        Window window;
        View decorView;
        KeyEvent.DispatcherState keyDispatcherState;
        View decorView2;
        KeyEvent.DispatcherState keyDispatcherState2;
        SubMenuC0363sf subMenuC0363sf = this.a;
        if (i == 82 || i == 4) {
            if (keyEvent.getAction() == 0 && keyEvent.getRepeatCount() == 0) {
                Window window2 = this.b.getWindow();
                if (window2 != null && (decorView2 = window2.getDecorView()) != null && (keyDispatcherState2 = decorView2.getKeyDispatcherState()) != null) {
                    keyDispatcherState2.startTracking(keyEvent, this);
                    return true;
                }
            } else if (keyEvent.getAction() == 1 && !keyEvent.isCanceled() && (window = this.b.getWindow()) != null && (decorView = window.getDecorView()) != null && (keyDispatcherState = decorView.getKeyDispatcherState()) != null && keyDispatcherState.isTracking(keyEvent)) {
                subMenuC0363sf.c(true);
                dialogInterface.dismiss();
                return true;
            }
        }
        return subMenuC0363sf.performShortcut(i, keyEvent, 0);
    }

    @Override // x.Bb
    public final boolean v(MenuC0246mb menuC0246mb) {
        return false;
    }
}
