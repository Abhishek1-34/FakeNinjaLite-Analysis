package x;

import android.text.Editable;

/* loaded from: classes.dex */
public final class K6 extends Of {
    public final /* synthetic */ N6 a;

    public K6(N6 n6) {
        this.a = n6;
    }

    @Override // android.text.TextWatcher
    public final void afterTextChanged(Editable editable) {
        this.a.b().a();
    }

    @Override // x.Of, android.text.TextWatcher
    public final void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        this.a.b().b();
    }
}
