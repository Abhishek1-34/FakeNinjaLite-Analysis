package x;

import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;

/* loaded from: classes.dex */
public abstract class N0 {
    public static final LinearInterpolator a = new LinearInterpolator();
    public static final C0223l7 b = new Ca(C0223l7.d);
    public static final C0223l7 c = new C0223l7();
    public static final C0223l7 d = new Ca(C0223l7.e);

    /* JADX WARN: Type inference failed for: r0v1, types: [x.Ca, x.l7] */
    /* JADX WARN: Type inference failed for: r0v3, types: [x.Ca, x.l7] */
    static {
        new DecelerateInterpolator();
    }

    public static float a(float f, float f2, float f3) {
        return ((f2 - f) * f3) + f;
    }

    public static float b(float f, float f2, float f3, float f4, float f5) {
        if (f5 <= f3) {
            return f;
        }
        if (f5 >= f4) {
            return f2;
        }
        return a(f, f2, (f5 - f3) / (f4 - f3));
    }

    public static int c(int i, int i2, float f) {
        return Math.round(f * (i2 - i)) + i;
    }
}
