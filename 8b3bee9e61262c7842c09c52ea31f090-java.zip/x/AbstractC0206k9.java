package x;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.view.WindowManager;
import android.widget.TextView;

/* renamed from: x.k9, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0206k9 {
    public static final Handler a = new Handler(Looper.getMainLooper());
    public static Context b;
    public static WindowManager c;
    public static WindowManager.LayoutParams d;
    public static TextView e;
    public static volatile boolean f;
    public static volatile boolean g;

    public static void a(boolean z) {
        f = z;
        Context context = b;
        if (context != null) {
            context.getSharedPreferences("proxy_read", 0).edit().putBoolean("ghost_on", z).apply();
        }
        if (!z) {
            Oc.j(false);
        }
        a.post(new RunnableC0443x0(17));
    }

    public static void b() {
        int i;
        int i2;
        int i3;
        String str;
        if (e == null) {
            return;
        }
        boolean z = Oc.c;
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setShape(1);
        if (z) {
            i = 42;
            i2 = 200;
            i3 = 104;
        } else {
            i = 23;
            i2 = 30;
            i3 = 20;
        }
        gradientDrawable.setColor(Color.rgb(i3, i, i2));
        gradientDrawable.setStroke(2, Color.rgb(115, 190, 255));
        e.setBackground(gradientDrawable);
        TextView textView = e;
        if (z) {
            str = "GHOST\nON";
        } else {
            str = "GHOST\nOFF";
        }
        textView.setText(str);
    }
}
