package x;

import java.util.LinkedHashMap;

/* renamed from: x.qe, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0325qe extends AbstractC0422vh {
    public final LinkedHashMap c = new LinkedHashMap();
}
