package x;

/* loaded from: classes.dex */
public interface E4 {
}
