package x;

/* renamed from: x.i, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0159i {
    public static final C0159i b = new Object();
    public C0159i a;
}
