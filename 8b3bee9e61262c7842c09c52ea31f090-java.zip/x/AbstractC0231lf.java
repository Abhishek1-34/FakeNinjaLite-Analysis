package x;

/* renamed from: x.lf, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0231lf extends AbstractC0112fb {
}
