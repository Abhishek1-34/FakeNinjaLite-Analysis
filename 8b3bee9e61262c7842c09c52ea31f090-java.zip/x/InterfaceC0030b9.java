package x;

/* renamed from: x.b9, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public interface InterfaceC0030b9 {
}
