package x;

import android.R;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.res.TypedArray;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.KeyEvent;
import android.view.View;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import androidx.appcompat.widget.ActionBarContainer;
import androidx.appcompat.widget.ActionBarContextView;
import androidx.appcompat.widget.ActionBarOverlayLayout;
import androidx.appcompat.widget.Toolbar;
import java.util.ArrayList;
import java.util.WeakHashMap;

/* renamed from: x.ci, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0059ci extends E9 implements S {
    public static final AccelerateInterpolator Q = new AccelerateInterpolator();
    public static final DecelerateInterpolator R = new DecelerateInterpolator();
    public C0039bi A;
    public C0039bi B;
    public F1 C;
    public boolean D;
    public final ArrayList E;
    public int F;
    public boolean G;
    public boolean H;
    public boolean I;
    public boolean J;
    public Bh K;
    public boolean L;
    public boolean M;
    public final C0019ai N;
    public final C0019ai O;
    public final B P;
    public Context s;
    public Context t;
    public ActionBarOverlayLayout u;
    public ActionBarContainer v;
    public InterfaceC0066d5 w;

    /* renamed from: x, reason: collision with root package name */
    public ActionBarContextView f21x;
    public final View y;
    public boolean z;

    public C0059ci(Activity activity, boolean z) {
        new ArrayList();
        this.E = new ArrayList();
        this.F = 0;
        this.G = true;
        this.J = true;
        this.N = new C0019ai(this, 0);
        this.O = new C0019ai(this, 1);
        this.P = new B(29, this);
        View decorView = activity.getWindow().getDecorView();
        J0(decorView);
        if (z) {
            return;
        }
        this.y = decorView.findViewById(R.id.content);
    }

    public final void H0(boolean z) {
        Ah i;
        Ah ah;
        long j;
        if (z) {
            if (!this.I) {
                this.I = true;
                ActionBarOverlayLayout actionBarOverlayLayout = this.u;
                if (actionBarOverlayLayout != null) {
                    actionBarOverlayLayout.setShowingForActionMode(true);
                }
                M0(false);
            }
        } else if (this.I) {
            this.I = false;
            ActionBarOverlayLayout actionBarOverlayLayout2 = this.u;
            if (actionBarOverlayLayout2 != null) {
                actionBarOverlayLayout2.setShowingForActionMode(false);
            }
            M0(false);
        }
        if (this.v.isLaidOut()) {
            if (z) {
                C0057cg c0057cg = (C0057cg) this.w;
                i = AbstractC0309ph.a(c0057cg.a);
                i.a(0.0f);
                i.c(100L);
                i.d(new C0037bg(c0057cg, 4));
                ah = this.f21x.i(200L, 0);
            } else {
                C0057cg c0057cg2 = (C0057cg) this.w;
                Ah a = AbstractC0309ph.a(c0057cg2.a);
                a.a(1.0f);
                a.c(200L);
                a.d(new C0037bg(c0057cg2, 0));
                i = this.f21x.i(100L, 8);
                ah = a;
            }
            Bh bh = new Bh();
            ArrayList arrayList = bh.a;
            arrayList.add(i);
            View view = (View) i.a.get();
            if (view != null) {
                j = view.animate().getDuration();
            } else {
                j = 0;
            }
            View view2 = (View) ah.a.get();
            if (view2 != null) {
                view2.animate().setStartDelay(j);
            }
            arrayList.add(ah);
            bh.b();
            return;
        }
        if (z) {
            ((C0057cg) this.w).a.setVisibility(4);
            this.f21x.setVisibility(0);
        } else {
            ((C0057cg) this.w).a.setVisibility(0);
            this.f21x.setVisibility(8);
        }
    }

    public final Context I0() {
        if (this.t == null) {
            TypedValue typedValue = new TypedValue();
            this.s.getTheme().resolveAttribute(org.conscrypt.R.attr.actionBarWidgetTheme, typedValue, true);
            int i = typedValue.resourceId;
            if (i != 0) {
                this.t = new ContextThemeWrapper(this.s, i);
            } else {
                this.t = this.s;
            }
        }
        return this.t;
    }

    public final void J0(View view) {
        String str;
        InterfaceC0066d5 wrapper;
        boolean z;
        ActionBarOverlayLayout actionBarOverlayLayout = (ActionBarOverlayLayout) view.findViewById(org.conscrypt.R.id.decor_content_parent);
        this.u = actionBarOverlayLayout;
        if (actionBarOverlayLayout != null) {
            actionBarOverlayLayout.setActionBarVisibilityCallback(this);
        }
        KeyEvent.Callback findViewById = view.findViewById(org.conscrypt.R.id.action_bar);
        if (findViewById instanceof InterfaceC0066d5) {
            wrapper = (InterfaceC0066d5) findViewById;
        } else if (findViewById instanceof Toolbar) {
            wrapper = ((Toolbar) findViewById).getWrapper();
        } else {
            if (findViewById != null) {
                str = findViewById.getClass().getSimpleName();
            } else {
                str = "null";
            }
            throw new IllegalStateException("Can't make a decor toolbar out of ".concat(str));
        }
        this.w = wrapper;
        this.f21x = (ActionBarContextView) view.findViewById(org.conscrypt.R.id.action_context_bar);
        ActionBarContainer actionBarContainer = (ActionBarContainer) view.findViewById(org.conscrypt.R.id.action_bar_container);
        this.v = actionBarContainer;
        InterfaceC0066d5 interfaceC0066d5 = this.w;
        if (interfaceC0066d5 != null && this.f21x != null && actionBarContainer != null) {
            Context context = ((C0057cg) interfaceC0066d5).a.getContext();
            this.s = context;
            if ((((C0057cg) this.w).b & 4) != 0) {
                z = true;
            } else {
                z = false;
            }
            if (z) {
                this.z = true;
            }
            int i = context.getApplicationInfo().targetSdkVersion;
            this.w.getClass();
            L0(context.getResources().getBoolean(org.conscrypt.R.bool.abc_action_bar_embed_tabs));
            TypedArray obtainStyledAttributes = this.s.obtainStyledAttributes(null, AbstractC0210kd.a, org.conscrypt.R.attr.actionBarStyle, 0);
            if (obtainStyledAttributes.getBoolean(14, false)) {
                ActionBarOverlayLayout actionBarOverlayLayout2 = this.u;
                if (actionBarOverlayLayout2.g) {
                    this.M = true;
                    actionBarOverlayLayout2.setHideOnContentScrollEnabled(true);
                } else {
                    throw new IllegalStateException("Action bar must be in overlay mode (Window.FEATURE_OVERLAY_ACTION_BAR) to enable hide on content scroll");
                }
            }
            int dimensionPixelSize = obtainStyledAttributes.getDimensionPixelSize(12, 0);
            if (dimensionPixelSize != 0) {
                ActionBarContainer actionBarContainer2 = this.v;
                WeakHashMap weakHashMap = AbstractC0309ph.a;
                AbstractC0158hh.k(actionBarContainer2, dimensionPixelSize);
            }
            obtainStyledAttributes.recycle();
            return;
        }
        throw new IllegalStateException(C0059ci.class.getSimpleName().concat(" can only be used with a compatible window decor layout"));
    }

    public final void K0(boolean z) {
        int i;
        if (!this.z) {
            if (z) {
                i = 4;
            } else {
                i = 0;
            }
            C0057cg c0057cg = (C0057cg) this.w;
            int i2 = c0057cg.b;
            this.z = true;
            c0057cg.a((i & 4) | (i2 & (-5)));
        }
    }

    public final void L0(boolean z) {
        if (!z) {
            ((C0057cg) this.w).getClass();
            this.v.setTabContainer(null);
        } else {
            this.v.setTabContainer(null);
            ((C0057cg) this.w).getClass();
        }
        this.w.getClass();
        ((C0057cg) this.w).a.setCollapsible(false);
        this.u.setHasNonEmbeddedTabs(false);
    }

    public final void M0(boolean z) {
        boolean z2;
        boolean z3 = this.H;
        if (this.I || !z3) {
            z2 = true;
        } else {
            z2 = false;
        }
        View view = this.y;
        Y5 y5 = null;
        B b = this.P;
        if (z2) {
            if (!this.J) {
                this.J = true;
                Bh bh = this.K;
                if (bh != null) {
                    bh.a();
                }
                this.v.setVisibility(0);
                int i = this.F;
                C0019ai c0019ai = this.O;
                if (i == 0 && (this.L || z)) {
                    this.v.setTranslationY(0.0f);
                    float f = -this.v.getHeight();
                    if (z) {
                        this.v.getLocationInWindow(new int[]{0, 0});
                        f -= r12[1];
                    }
                    this.v.setTranslationY(f);
                    Bh bh2 = new Bh();
                    Ah a = AbstractC0309ph.a(this.v);
                    a.e(0.0f);
                    View view2 = (View) a.a.get();
                    if (view2 != null) {
                        if (b != null) {
                            y5 = new Y5(b, view2);
                        }
                        view2.animate().setUpdateListener(y5);
                    }
                    boolean z4 = bh2.e;
                    ArrayList arrayList = bh2.a;
                    if (!z4) {
                        arrayList.add(a);
                    }
                    if (this.G && view != null) {
                        view.setTranslationY(f);
                        Ah a2 = AbstractC0309ph.a(view);
                        a2.e(0.0f);
                        if (!bh2.e) {
                            arrayList.add(a2);
                        }
                    }
                    DecelerateInterpolator decelerateInterpolator = R;
                    boolean z5 = bh2.e;
                    if (!z5) {
                        bh2.c = decelerateInterpolator;
                    }
                    if (!z5) {
                        bh2.b = 250L;
                    }
                    if (!z5) {
                        bh2.d = c0019ai;
                    }
                    this.K = bh2;
                    bh2.b();
                } else {
                    this.v.setAlpha(1.0f);
                    this.v.setTranslationY(0.0f);
                    if (this.G && view != null) {
                        view.setTranslationY(0.0f);
                    }
                    c0019ai.a();
                }
                ActionBarOverlayLayout actionBarOverlayLayout = this.u;
                if (actionBarOverlayLayout != null) {
                    WeakHashMap weakHashMap = AbstractC0309ph.a;
                    AbstractC0118fh.c(actionBarOverlayLayout);
                    return;
                }
                return;
            }
            return;
        }
        if (this.J) {
            this.J = false;
            Bh bh3 = this.K;
            if (bh3 != null) {
                bh3.a();
            }
            int i2 = this.F;
            C0019ai c0019ai2 = this.N;
            if (i2 == 0 && (this.L || z)) {
                this.v.setAlpha(1.0f);
                this.v.setTransitioning(true);
                Bh bh4 = new Bh();
                float f2 = -this.v.getHeight();
                if (z) {
                    this.v.getLocationInWindow(new int[]{0, 0});
                    f2 -= r12[1];
                }
                Ah a3 = AbstractC0309ph.a(this.v);
                a3.e(f2);
                View view3 = (View) a3.a.get();
                if (view3 != null) {
                    if (b != null) {
                        y5 = new Y5(b, view3);
                    }
                    view3.animate().setUpdateListener(y5);
                }
                boolean z6 = bh4.e;
                ArrayList arrayList2 = bh4.a;
                if (!z6) {
                    arrayList2.add(a3);
                }
                if (this.G && view != null) {
                    Ah a4 = AbstractC0309ph.a(view);
                    a4.e(f2);
                    if (!bh4.e) {
                        arrayList2.add(a4);
                    }
                }
                AccelerateInterpolator accelerateInterpolator = Q;
                boolean z7 = bh4.e;
                if (!z7) {
                    bh4.c = accelerateInterpolator;
                }
                if (!z7) {
                    bh4.b = 250L;
                }
                if (!z7) {
                    bh4.d = c0019ai2;
                }
                this.K = bh4;
                bh4.b();
                return;
            }
            c0019ai2.a();
        }
    }

    public C0059ci(Dialog dialog) {
        new ArrayList();
        this.E = new ArrayList();
        this.F = 0;
        this.G = true;
        this.J = true;
        this.N = new C0019ai(this, 0);
        this.O = new C0019ai(this, 1);
        this.P = new B(29, this);
        J0(dialog.getWindow().getDecorView());
    }
}
