package x;

import android.view.View;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import org.conscrypt.BuildConfig;
import org.conscrypt.ct.CTConstants;

/* loaded from: classes.dex */
public class A4 {
    public int A;
    public float B;
    public final int[] C;
    public float D;
    public boolean E;
    public boolean F;
    public int G;
    public int H;
    public final C0239m4 I;
    public final C0239m4 J;
    public final C0239m4 K;
    public final C0239m4 L;
    public final C0239m4 M;
    public final C0239m4 N;
    public final C0239m4 O;
    public final C0239m4 P;
    public final C0239m4[] Q;
    public final ArrayList R;
    public final boolean[] S;
    public A4 T;
    public int U;
    public int V;
    public float W;
    public int X;
    public int Y;
    public int Z;
    public int a0;
    public C0465y3 b;
    public int b0;
    public C0465y3 c;
    public int c0;
    public float d0;
    public float e0;
    public View f0;
    public int g0;
    public String h0;
    public int i0;
    public String j;
    public int j0;
    public boolean k;
    public final float[] k0;
    public boolean l;
    public final A4[] l0;
    public boolean m;
    public final A4[] m0;
    public boolean n;
    public int n0;
    public int o;
    public int o0;
    public int p;
    public final int[] p0;
    public int q;
    public int r;
    public int s;
    public final int[] t;
    public int u;
    public int v;
    public float w;

    /* renamed from: x, reason: collision with root package name */
    public int f14x;
    public int y;
    public float z;
    public boolean a = false;
    public C0357s9 d = null;
    public C0038bh e = null;
    public final boolean[] f = {true, true};
    public boolean g = true;
    public int h = -1;
    public int i = -1;

    public A4() {
        new HashMap();
        this.k = false;
        this.l = false;
        this.m = false;
        this.n = false;
        this.o = -1;
        this.p = -1;
        this.q = 0;
        this.r = 0;
        this.s = 0;
        this.t = new int[2];
        this.u = 0;
        this.v = 0;
        this.w = 1.0f;
        this.f14x = 0;
        this.y = 0;
        this.z = 1.0f;
        this.A = -1;
        this.B = 1.0f;
        this.C = new int[]{Integer.MAX_VALUE, Integer.MAX_VALUE};
        this.D = Float.NaN;
        this.E = false;
        this.F = false;
        this.G = 0;
        this.H = 0;
        C0239m4 c0239m4 = new C0239m4(this, 2);
        this.I = c0239m4;
        C0239m4 c0239m42 = new C0239m4(this, 3);
        this.J = c0239m42;
        C0239m4 c0239m43 = new C0239m4(this, 4);
        this.K = c0239m43;
        C0239m4 c0239m44 = new C0239m4(this, 5);
        this.L = c0239m44;
        C0239m4 c0239m45 = new C0239m4(this, 6);
        this.M = c0239m45;
        C0239m4 c0239m46 = new C0239m4(this, 8);
        this.N = c0239m46;
        C0239m4 c0239m47 = new C0239m4(this, 9);
        this.O = c0239m47;
        C0239m4 c0239m48 = new C0239m4(this, 7);
        this.P = c0239m48;
        this.Q = new C0239m4[]{c0239m4, c0239m43, c0239m42, c0239m44, c0239m45, c0239m48};
        ArrayList arrayList = new ArrayList();
        this.R = arrayList;
        this.S = new boolean[2];
        this.p0 = new int[]{1, 1};
        this.T = null;
        this.U = 0;
        this.V = 0;
        this.W = 0.0f;
        this.X = -1;
        this.Y = 0;
        this.Z = 0;
        this.a0 = 0;
        this.d0 = 0.5f;
        this.e0 = 0.5f;
        this.g0 = 0;
        this.h0 = null;
        this.i0 = 0;
        this.j0 = 0;
        this.k0 = new float[]{-1.0f, -1.0f};
        this.l0 = new A4[]{null, null};
        this.m0 = new A4[]{null, null};
        this.n0 = -1;
        this.o0 = -1;
        arrayList.add(c0239m4);
        arrayList.add(c0239m42);
        arrayList.add(c0239m43);
        arrayList.add(c0239m44);
        arrayList.add(c0239m46);
        arrayList.add(c0239m47);
        arrayList.add(c0239m48);
        arrayList.add(c0239m45);
    }

    public static void G(int i, int i2, String str, StringBuilder sb) {
        if (i == i2) {
            return;
        }
        sb.append(str);
        sb.append(" :   ");
        sb.append(i);
        sb.append(",\n");
    }

    public static void H(StringBuilder sb, String str, float f, float f2) {
        if (f == f2) {
            return;
        }
        sb.append(str);
        sb.append(" :   ");
        sb.append(f);
        sb.append(",\n");
    }

    public static void o(StringBuilder sb, String str, int i, int i2, int i3, int i4, int i5, float f, int i6) {
        String str2;
        sb.append(str);
        sb.append(" :  {\n");
        if (i6 == 1) {
            str2 = "FIXED";
        } else if (i6 == 2) {
            str2 = "WRAP_CONTENT";
        } else if (i6 == 3) {
            str2 = "MATCH_CONSTRAINT";
        } else {
            if (i6 != 4) {
                throw null;
            }
            str2 = "MATCH_PARENT";
        }
        if (!"FIXED".equals(str2)) {
            sb.append("      behavior");
            sb.append(" :   ");
            sb.append(str2);
            sb.append(",\n");
        }
        G(i, 0, "      size", sb);
        G(i2, 0, "      min", sb);
        G(i3, Integer.MAX_VALUE, "      max", sb);
        G(i4, 0, "      matchMin", sb);
        G(i5, 0, "      matchDef", sb);
        H(sb, "      matchPercent", f, 1.0f);
        sb.append("    },\n");
    }

    public static void p(StringBuilder sb, String str, C0239m4 c0239m4) {
        if (c0239m4.f == null) {
            return;
        }
        sb.append("    ");
        sb.append(str);
        sb.append(" : [ '");
        sb.append(c0239m4.f);
        sb.append("'");
        if (c0239m4.h != Integer.MIN_VALUE || c0239m4.g != 0) {
            sb.append(",");
            sb.append(c0239m4.g);
            if (c0239m4.h != Integer.MIN_VALUE) {
                sb.append(",");
                sb.append(c0239m4.h);
                sb.append(",");
            }
        }
        sb.append(" ] ,\n");
    }

    public boolean A() {
        if (!this.k && (!this.I.c || !this.K.c)) {
            return false;
        }
        return true;
    }

    public boolean B() {
        if (!this.l && (!this.J.c || !this.L.c)) {
            return false;
        }
        return true;
    }

    public void C() {
        this.I.j();
        this.J.j();
        this.K.j();
        this.L.j();
        this.M.j();
        this.N.j();
        this.O.j();
        this.P.j();
        this.T = null;
        this.D = Float.NaN;
        this.U = 0;
        this.V = 0;
        this.W = 0.0f;
        this.X = -1;
        this.Y = 0;
        this.Z = 0;
        this.a0 = 0;
        this.b0 = 0;
        this.c0 = 0;
        this.d0 = 0.5f;
        this.e0 = 0.5f;
        int[] iArr = this.p0;
        iArr[0] = 1;
        iArr[1] = 1;
        this.f0 = null;
        this.g0 = 0;
        this.i0 = 0;
        this.j0 = 0;
        float[] fArr = this.k0;
        fArr[0] = -1.0f;
        fArr[1] = -1.0f;
        this.o = -1;
        this.p = -1;
        int[] iArr2 = this.C;
        iArr2[0] = Integer.MAX_VALUE;
        iArr2[1] = Integer.MAX_VALUE;
        this.r = 0;
        this.s = 0;
        this.w = 1.0f;
        this.z = 1.0f;
        this.v = Integer.MAX_VALUE;
        this.y = Integer.MAX_VALUE;
        this.u = 0;
        this.f14x = 0;
        this.A = -1;
        this.B = 1.0f;
        boolean[] zArr = this.f;
        zArr[0] = true;
        zArr[1] = true;
        this.F = false;
        boolean[] zArr2 = this.S;
        zArr2[0] = false;
        zArr2[1] = false;
        this.g = true;
        int[] iArr3 = this.t;
        iArr3[0] = 0;
        iArr3[1] = 0;
        this.h = -1;
        this.i = -1;
    }

    public final void D() {
        A4 a4 = this.T;
        if (a4 != null && (a4 instanceof B4)) {
            ((B4) a4).getClass();
        }
        ArrayList arrayList = this.R;
        int size = arrayList.size();
        for (int i = 0; i < size; i++) {
            ((C0239m4) arrayList.get(i)).j();
        }
    }

    public final void E() {
        this.k = false;
        this.l = false;
        this.m = false;
        this.n = false;
        ArrayList arrayList = this.R;
        int size = arrayList.size();
        for (int i = 0; i < size; i++) {
            C0239m4 c0239m4 = (C0239m4) arrayList.get(i);
            c0239m4.c = false;
            c0239m4.b = 0;
        }
    }

    public void F(C0294p2 c0294p2) {
        this.I.k();
        this.J.k();
        this.K.k();
        this.L.k();
        this.M.k();
        this.P.k();
        this.N.k();
        this.O.k();
    }

    public final void I(int i) {
        boolean z;
        this.a0 = i;
        if (i > 0) {
            z = true;
        } else {
            z = false;
        }
        this.E = z;
    }

    public final void J(int i, int i2) {
        if (this.k) {
            return;
        }
        this.I.l(i);
        this.K.l(i2);
        this.Y = i;
        this.U = i2 - i;
        this.k = true;
    }

    public final void K(int i, int i2) {
        if (this.l) {
            return;
        }
        this.J.l(i);
        this.L.l(i2);
        this.Z = i;
        this.V = i2 - i;
        if (this.E) {
            this.M.l(i + this.a0);
        }
        this.l = true;
    }

    public final void L(int i) {
        this.V = i;
        int i2 = this.c0;
        if (i < i2) {
            this.V = i2;
        }
    }

    public final void M(int i) {
        this.p0[0] = i;
    }

    public final void N(int i) {
        this.p0[1] = i;
    }

    public final void O(int i) {
        this.U = i;
        int i2 = this.b0;
        if (i < i2) {
            this.U = i2;
        }
    }

    public void P(boolean z, boolean z2) {
        int i;
        int i2;
        C0357s9 c0357s9 = this.d;
        boolean z3 = z & c0357s9.g;
        C0038bh c0038bh = this.e;
        boolean z4 = z2 & c0038bh.g;
        int i3 = c0357s9.h.g;
        int i4 = c0038bh.h.g;
        int i5 = c0357s9.i.g;
        int i6 = c0038bh.i.g;
        int i7 = i6 - i4;
        if (i5 - i3 < 0 || i7 < 0 || i3 == Integer.MIN_VALUE || i3 == Integer.MAX_VALUE || i4 == Integer.MIN_VALUE || i4 == Integer.MAX_VALUE || i5 == Integer.MIN_VALUE || i5 == Integer.MAX_VALUE || i6 == Integer.MIN_VALUE || i6 == Integer.MAX_VALUE) {
            i5 = 0;
            i6 = 0;
            i3 = 0;
            i4 = 0;
        }
        int i8 = i5 - i3;
        int i9 = i6 - i4;
        if (z3) {
            this.Y = i3;
        }
        if (z4) {
            this.Z = i4;
        }
        if (this.g0 == 8) {
            this.U = 0;
            this.V = 0;
            return;
        }
        int[] iArr = this.p0;
        if (z3) {
            if (iArr[0] == 1 && i8 < (i2 = this.U)) {
                i8 = i2;
            }
            this.U = i8;
            int i10 = this.b0;
            if (i8 < i10) {
                this.U = i10;
            }
        }
        if (z4) {
            if (iArr[1] == 1 && i9 < (i = this.V)) {
                i9 = i;
            }
            this.V = i9;
            int i11 = this.c0;
            if (i9 < i11) {
                this.V = i11;
            }
        }
    }

    public void Q(C0170ia c0170ia, boolean z) {
        int i;
        int i2;
        C0038bh c0038bh;
        C0357s9 c0357s9;
        C0239m4 c0239m4 = this.I;
        c0170ia.getClass();
        int n = C0170ia.n(c0239m4);
        int n2 = C0170ia.n(this.J);
        int n3 = C0170ia.n(this.K);
        int n4 = C0170ia.n(this.L);
        if (z && (c0357s9 = this.d) != null) {
            C0486z5 c0486z5 = c0357s9.h;
            if (c0486z5.j) {
                C0486z5 c0486z52 = c0357s9.i;
                if (c0486z52.j) {
                    n = c0486z5.g;
                    n3 = c0486z52.g;
                }
            }
        }
        if (z && (c0038bh = this.e) != null) {
            C0486z5 c0486z53 = c0038bh.h;
            if (c0486z53.j) {
                C0486z5 c0486z54 = c0038bh.i;
                if (c0486z54.j) {
                    n2 = c0486z53.g;
                    n4 = c0486z54.g;
                }
            }
        }
        int i3 = n4 - n2;
        if (n3 - n < 0 || i3 < 0 || n == Integer.MIN_VALUE || n == Integer.MAX_VALUE || n2 == Integer.MIN_VALUE || n2 == Integer.MAX_VALUE || n3 == Integer.MIN_VALUE || n3 == Integer.MAX_VALUE || n4 == Integer.MIN_VALUE || n4 == Integer.MAX_VALUE) {
            n = 0;
            n2 = 0;
            n3 = 0;
            n4 = 0;
        }
        int i4 = n3 - n;
        int i5 = n4 - n2;
        this.Y = n;
        this.Z = n2;
        if (this.g0 == 8) {
            this.U = 0;
            this.V = 0;
            return;
        }
        int[] iArr = this.p0;
        int i6 = iArr[0];
        if (i6 == 1 && i4 < (i2 = this.U)) {
            i4 = i2;
        }
        if (iArr[1] == 1 && i5 < (i = this.V)) {
            i5 = i;
        }
        this.U = i4;
        this.V = i5;
        int i7 = this.c0;
        if (i5 < i7) {
            this.V = i7;
        }
        int i8 = this.b0;
        if (i4 < i8) {
            this.U = i8;
        }
        int i9 = this.v;
        if (i9 > 0 && i6 == 3) {
            this.U = Math.min(this.U, i9);
        }
        int i10 = this.y;
        if (i10 > 0 && iArr[1] == 3) {
            this.V = Math.min(this.V, i10);
        }
        int i11 = this.U;
        if (i4 != i11) {
            this.h = i11;
        }
        int i12 = this.V;
        if (i5 != i12) {
            this.i = i12;
        }
    }

    public final void a(B4 b4, C0170ia c0170ia, HashSet hashSet, int i, boolean z) {
        if (z) {
            if (!hashSet.contains(this)) {
                return;
            }
            E9.k(b4, c0170ia, this);
            hashSet.remove(this);
            b(c0170ia, b4.W(64));
        }
        if (i == 0) {
            HashSet hashSet2 = this.I.a;
            if (hashSet2 != null) {
                Iterator it = hashSet2.iterator();
                while (it.hasNext()) {
                    ((C0239m4) it.next()).d.a(b4, c0170ia, hashSet, i, true);
                }
            }
            HashSet hashSet3 = this.K.a;
            if (hashSet3 != null) {
                Iterator it2 = hashSet3.iterator();
                while (it2.hasNext()) {
                    ((C0239m4) it2.next()).d.a(b4, c0170ia, hashSet, i, true);
                }
                return;
            }
            return;
        }
        HashSet hashSet4 = this.J.a;
        if (hashSet4 != null) {
            Iterator it3 = hashSet4.iterator();
            while (it3.hasNext()) {
                ((C0239m4) it3.next()).d.a(b4, c0170ia, hashSet, i, true);
            }
        }
        HashSet hashSet5 = this.L.a;
        if (hashSet5 != null) {
            Iterator it4 = hashSet5.iterator();
            while (it4.hasNext()) {
                ((C0239m4) it4.next()).d.a(b4, c0170ia, hashSet, i, true);
            }
        }
        HashSet hashSet6 = this.M.a;
        if (hashSet6 != null) {
            Iterator it5 = hashSet6.iterator();
            while (it5.hasNext()) {
                ((C0239m4) it5.next()).d.a(b4, c0170ia, hashSet, i, true);
            }
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:101:0x028b  */
    /* JADX WARN: Removed duplicated region for block: B:104:0x0295  */
    /* JADX WARN: Removed duplicated region for block: B:107:0x02a7  */
    /* JADX WARN: Removed duplicated region for block: B:110:0x02b2  */
    /* JADX WARN: Removed duplicated region for block: B:113:0x02cd  */
    /* JADX WARN: Removed duplicated region for block: B:17:0x005e  */
    /* JADX WARN: Removed duplicated region for block: B:180:0x0402  */
    /* JADX WARN: Removed duplicated region for block: B:185:0x0411  */
    /* JADX WARN: Removed duplicated region for block: B:191:0x0424  */
    /* JADX WARN: Removed duplicated region for block: B:195:0x042d  */
    /* JADX WARN: Removed duplicated region for block: B:198:0x0447  */
    /* JADX WARN: Removed duplicated region for block: B:208:0x0469  */
    /* JADX WARN: Removed duplicated region for block: B:219:0x055b  */
    /* JADX WARN: Removed duplicated region for block: B:235:0x05d1  */
    /* JADX WARN: Removed duplicated region for block: B:238:0x05d7  */
    /* JADX WARN: Removed duplicated region for block: B:260:0x0654  */
    /* JADX WARN: Removed duplicated region for block: B:264:0x06ad  */
    /* JADX WARN: Removed duplicated region for block: B:269:0x0712  */
    /* JADX WARN: Removed duplicated region for block: B:273:0x070a  */
    /* JADX WARN: Removed duplicated region for block: B:274:0x0657  */
    /* JADX WARN: Removed duplicated region for block: B:288:0x05d3  */
    /* JADX WARN: Removed duplicated region for block: B:293:0x05bd  */
    /* JADX WARN: Removed duplicated region for block: B:294:0x04b0  */
    /* JADX WARN: Removed duplicated region for block: B:298:0x04c7  */
    /* JADX WARN: Removed duplicated region for block: B:301:0x04d6  */
    /* JADX WARN: Removed duplicated region for block: B:305:0x04f8  */
    /* JADX WARN: Removed duplicated region for block: B:307:0x04fb  */
    /* JADX WARN: Removed duplicated region for block: B:308:0x04e0  */
    /* JADX WARN: Removed duplicated region for block: B:309:0x04d0  */
    /* JADX WARN: Removed duplicated region for block: B:311:0x042f  */
    /* JADX WARN: Removed duplicated region for block: B:315:0x040c  */
    /* JADX WARN: Removed duplicated region for block: B:342:0x03eb  */
    /* JADX WARN: Removed duplicated region for block: B:343:0x02b4  */
    /* JADX WARN: Removed duplicated region for block: B:344:0x02aa  */
    /* JADX WARN: Removed duplicated region for block: B:348:0x0280  */
    /* JADX WARN: Removed duplicated region for block: B:351:0x0097  */
    /* JADX WARN: Removed duplicated region for block: B:371:0x00f6  */
    /* JADX WARN: Removed duplicated region for block: B:72:0x020e  */
    /* JADX WARN: Type inference failed for: r10v24 */
    /* JADX WARN: Type inference failed for: r10v25 */
    /* JADX WARN: Type inference failed for: r10v27 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public void b(C0170ia c0170ia, boolean z) {
        boolean z2;
        boolean z3;
        int i;
        boolean[] zArr;
        boolean z4;
        A4 a4;
        A4 a42;
        C0239m4 c0239m4;
        boolean[] zArr2;
        boolean z5;
        boolean z6;
        int i2;
        int i3;
        int i4;
        int i5;
        int i6;
        boolean z7;
        int i7;
        boolean z8;
        float f;
        int[] iArr;
        int i8;
        int i9;
        int i10;
        int i11;
        boolean z9;
        int i12;
        boolean z10;
        char c;
        boolean z11;
        boolean z12;
        int i13;
        C0239m4 c0239m42;
        boolean z13;
        boolean z14;
        int i14;
        int[] iArr2;
        C0239m4 c0239m43;
        C0239m4 c0239m44;
        C0239m4 c0239m45;
        Ve ve;
        Ve ve2;
        Ve ve3;
        Ve ve4;
        Ve ve5;
        int[] iArr3;
        int i15;
        int i16;
        int i17;
        A4 a43;
        C0170ia c0170ia2;
        Ve ve6;
        Ve ve7;
        Ve ve8;
        int i18;
        int i19;
        Ve ve9;
        Ve ve10;
        C0170ia c0170ia3;
        boolean z15;
        Ve ve11;
        boolean z16;
        int i20;
        A4 a44;
        Ve ve12;
        A4 a45;
        Ve ve13;
        boolean z17;
        C0357s9 c0357s9;
        C0486z5 c0486z5;
        int i21;
        boolean x2;
        boolean y;
        boolean z18;
        C0357s9 c0357s92;
        C0038bh c0038bh;
        boolean z19;
        boolean z20;
        ?? r10;
        boolean z21;
        C0239m4 c0239m46 = this.I;
        Ve k = c0170ia.k(c0239m46);
        C0239m4 c0239m47 = this.K;
        Ve k2 = c0170ia.k(c0239m47);
        C0239m4 c0239m48 = this.J;
        Ve k3 = c0170ia.k(c0239m48);
        C0239m4 c0239m49 = this.L;
        Ve k4 = c0170ia.k(c0239m49);
        C0239m4 c0239m410 = this.M;
        Ve k5 = c0170ia.k(c0239m410);
        A4 a46 = this.T;
        if (a46 != null) {
            int[] iArr4 = a46.p0;
            if (iArr4[0] == 2) {
                r10 = 1;
                z20 = true;
            } else {
                z20 = false;
                r10 = 1;
            }
            if (iArr4[r10] == 2) {
                z21 = r10;
            } else {
                z21 = false;
            }
            int i22 = this.q;
            if (i22 != r10) {
                if (i22 != 2) {
                    if (i22 != 3) {
                        z2 = z21;
                        z3 = z20;
                    }
                } else {
                    z2 = z21;
                    z3 = false;
                }
            } else {
                z3 = z20;
                z2 = false;
            }
            i = this.g0;
            zArr = this.S;
            if (i == 8) {
                ArrayList arrayList = this.R;
                int size = arrayList.size();
                int i23 = 0;
                while (true) {
                    if (i23 < size) {
                        ArrayList arrayList2 = arrayList;
                        HashSet hashSet = ((C0239m4) arrayList.get(i23)).a;
                        if (hashSet != null && hashSet.size() > 0) {
                            break;
                        }
                        i23++;
                        arrayList = arrayList2;
                    } else if (!zArr[0] && !zArr[1]) {
                        return;
                    }
                }
            }
            z4 = this.k;
            if (!z4 || this.l) {
                if (z4) {
                    c0170ia.d(k, this.Y);
                    c0170ia.d(k2, this.Y + this.U);
                    if (z3 && (a42 = this.T) != null) {
                        B4 b4 = (B4) a42;
                        WeakReference weakReference = b4.H0;
                        if (weakReference == null || weakReference.get() == null || c0239m46.d() > ((C0239m4) b4.H0.get()).d()) {
                            b4.H0 = new WeakReference(c0239m46);
                        }
                        WeakReference weakReference2 = b4.J0;
                        if (weakReference2 == null || weakReference2.get() == null || c0239m47.d() > ((C0239m4) b4.J0.get()).d()) {
                            b4.J0 = new WeakReference(c0239m47);
                        }
                    }
                }
                if (this.l) {
                    c0170ia.d(k3, this.Z);
                    c0170ia.d(k4, this.Z + this.V);
                    HashSet hashSet2 = c0239m410.a;
                    if (hashSet2 != null && hashSet2.size() > 0) {
                        c0170ia.d(k5, this.Z + this.a0);
                    }
                    if (z2 && (a4 = this.T) != null) {
                        B4 b42 = (B4) a4;
                        WeakReference weakReference3 = b42.G0;
                        if (weakReference3 == null || weakReference3.get() == null || c0239m48.d() > ((C0239m4) b42.G0.get()).d()) {
                            b42.G0 = new WeakReference(c0239m48);
                        }
                        WeakReference weakReference4 = b42.I0;
                        if (weakReference4 == null || weakReference4.get() == null || c0239m49.d() > ((C0239m4) b42.I0.get()).d()) {
                            b42.I0 = new WeakReference(c0239m49);
                        }
                    }
                }
                if (this.k && this.l) {
                    this.k = false;
                    this.l = false;
                    return;
                }
            }
            boolean[] zArr3 = this.f;
            if (!z && (c0357s92 = this.d) != null && (c0038bh = this.e) != null) {
                zArr2 = zArr;
                C0486z5 c0486z52 = c0357s92.h;
                c0239m4 = c0239m410;
                if (c0486z52.j && c0357s92.i.j && c0038bh.h.j && c0038bh.i.j) {
                    c0170ia.d(k, c0486z52.g);
                    c0170ia.d(k2, this.d.i.g);
                    c0170ia.d(k3, this.e.h.g);
                    c0170ia.d(k4, this.e.i.g);
                    c0170ia.d(k5, this.e.k.g);
                    if (this.T != null) {
                        if (z3 && zArr3[0] && !x()) {
                            c0170ia.f(c0170ia.k(this.T.K), k2, 0, 8);
                        }
                        if (z2 && zArr3[1] && !y()) {
                            z19 = false;
                            c0170ia.f(c0170ia.k(this.T.L), k4, 0, 8);
                            this.k = z19;
                            this.l = z19;
                            return;
                        }
                    }
                    z19 = false;
                    this.k = z19;
                    this.l = z19;
                    return;
                }
            } else {
                c0239m4 = c0239m410;
                zArr2 = zArr;
            }
            if (this.T == null) {
                if (w(0)) {
                    ((B4) this.T).R(this, 0);
                    x2 = true;
                } else {
                    x2 = x();
                }
                if (w(1)) {
                    ((B4) this.T).R(this, 1);
                    y = true;
                } else {
                    y = y();
                }
                if (!x2 && z3 && this.g0 != 8 && c0239m46.f == null && c0239m47.f == null) {
                    z18 = x2;
                    c0170ia.f(c0170ia.k(this.T.K), k2, 0, 1);
                } else {
                    z18 = x2;
                }
                if (!y && z2 && this.g0 != 8 && c0239m48.f == null && c0239m49.f == null && c0239m4 == null) {
                    c0170ia.f(c0170ia.k(this.T.L), k4, 0, 1);
                }
                z5 = y;
                z6 = z18;
            } else {
                z5 = false;
                z6 = false;
            }
            i2 = this.U;
            i3 = this.b0;
            if (i2 >= i3) {
                i3 = i2;
            }
            i4 = this.V;
            i5 = this.c0;
            if (i4 >= i5) {
                i5 = i4;
            }
            int[] iArr5 = this.p0;
            i6 = iArr5[0];
            int i24 = i3;
            if (i6 == 3) {
                z7 = true;
            } else {
                z7 = false;
            }
            i7 = iArr5[1];
            int i25 = i5;
            if (i7 == 3) {
                z8 = true;
            } else {
                z8 = false;
            }
            int i26 = this.X;
            this.A = i26;
            f = this.W;
            this.B = f;
            int i27 = this.r;
            int i28 = this.s;
            if (f <= 0.0f) {
                iArr = iArr5;
                if (this.g0 != 8) {
                    if (i6 == 3 && i27 == 0) {
                        i27 = 3;
                    }
                    if (i7 == 3 && i28 == 0) {
                        i28 = 3;
                    }
                    if (i6 == 3 && i7 == 3 && i27 == 3 && i28 == 3) {
                        if (i26 == -1) {
                            if (z7 && !z8) {
                                this.A = 0;
                            } else if (!z7 && z8) {
                                this.A = 1;
                                if (i26 == -1) {
                                    this.B = 1.0f / f;
                                }
                            }
                        }
                        if (this.A == 0 && (!c0239m48.h() || !c0239m49.h())) {
                            this.A = 1;
                        } else if (this.A == 1 && (!c0239m46.h() || !c0239m47.h())) {
                            this.A = 0;
                        }
                        if (this.A == -1 && (!c0239m48.h() || !c0239m49.h() || !c0239m46.h() || !c0239m47.h())) {
                            if (c0239m48.h() && c0239m49.h()) {
                                this.A = 0;
                            } else if (c0239m46.h() && c0239m47.h()) {
                                this.B = 1.0f / this.B;
                                this.A = 1;
                            }
                        }
                        if (this.A == -1) {
                            int i29 = this.u;
                            if (i29 > 0 && this.f14x == 0) {
                                this.A = 0;
                            } else if (i29 == 0 && this.f14x > 0) {
                                this.B = 1.0f / this.B;
                                this.A = 1;
                            }
                        }
                    } else {
                        if (i6 == 3 && i27 == 3) {
                            this.A = 0;
                            i10 = (int) (f * i4);
                            if (i7 != 3) {
                                i9 = i28;
                                i11 = i25;
                                z9 = false;
                                i8 = 4;
                                int[] iArr6 = this.t;
                                iArr6[0] = i8;
                                iArr6[1] = i9;
                                if (z9) {
                                }
                                z10 = false;
                                if (!z9) {
                                }
                                c = 0;
                                z11 = false;
                                if (iArr[c] != 2) {
                                }
                                z12 = false;
                                if (!z12) {
                                }
                                c0239m42 = this.P;
                                z13 = !c0239m42.h();
                                z14 = zArr2[0];
                                boolean z22 = zArr2[1];
                                i14 = this.o;
                                iArr2 = this.C;
                                Ve ve14 = null;
                                if (i14 != 2) {
                                }
                                c0239m43 = c0239m49;
                                c0239m44 = c0239m42;
                                c0239m45 = c0239m4;
                                ve = k3;
                                ve2 = k5;
                                ve3 = k4;
                                ve4 = k2;
                                ve5 = k;
                                iArr3 = iArr2;
                                if (z) {
                                }
                                i18 = i17;
                                if (a43.p != 2) {
                                }
                                if (i19 == 0) {
                                }
                                ve9 = ve7;
                                ve10 = ve8;
                                if (!z9) {
                                }
                                if (c0239m44.h()) {
                                }
                                this.k = false;
                                this.l = false;
                            }
                            i8 = i27;
                            i9 = i28;
                            i11 = i25;
                            z9 = true;
                            int[] iArr62 = this.t;
                            iArr62[0] = i8;
                            iArr62[1] = i9;
                            if (z9) {
                            }
                            z10 = false;
                            if (!z9) {
                            }
                            c = 0;
                            z11 = false;
                            if (iArr[c] != 2) {
                            }
                            z12 = false;
                            if (!z12) {
                            }
                            c0239m42 = this.P;
                            z13 = !c0239m42.h();
                            z14 = zArr2[0];
                            boolean z222 = zArr2[1];
                            i14 = this.o;
                            iArr2 = this.C;
                            Ve ve142 = null;
                            if (i14 != 2) {
                            }
                            c0239m43 = c0239m49;
                            c0239m44 = c0239m42;
                            c0239m45 = c0239m4;
                            ve = k3;
                            ve2 = k5;
                            ve3 = k4;
                            ve4 = k2;
                            ve5 = k;
                            iArr3 = iArr2;
                            if (z) {
                            }
                            i18 = i17;
                            if (a43.p != 2) {
                            }
                            if (i19 == 0) {
                            }
                            ve9 = ve7;
                            ve10 = ve8;
                            if (!z9) {
                            }
                            if (c0239m44.h()) {
                            }
                            this.k = false;
                            this.l = false;
                        }
                        if (i7 == 3 && i28 == 3) {
                            this.A = 1;
                            if (i26 == -1) {
                                this.B = 1.0f / f;
                            }
                            i11 = (int) (this.B * i2);
                            i8 = i27;
                            if (i6 != 3) {
                                i10 = i24;
                                z9 = false;
                                i9 = 4;
                                int[] iArr622 = this.t;
                                iArr622[0] = i8;
                                iArr622[1] = i9;
                                if (z9) {
                                    int i30 = this.A;
                                    i12 = -1;
                                    if (i30 == 0 || i30 == -1) {
                                        z10 = true;
                                        if (!z9 && ((i21 = this.A) == 1 || i21 == i12)) {
                                            c = 0;
                                            z11 = true;
                                        } else {
                                            c = 0;
                                            z11 = false;
                                        }
                                        if (iArr[c] != 2 && (this instanceof B4)) {
                                            z12 = true;
                                        } else {
                                            z12 = false;
                                        }
                                        if (!z12) {
                                            i13 = 0;
                                        } else {
                                            i13 = i10;
                                        }
                                        c0239m42 = this.P;
                                        z13 = !c0239m42.h();
                                        z14 = zArr2[0];
                                        boolean z2222 = zArr2[1];
                                        i14 = this.o;
                                        iArr2 = this.C;
                                        Ve ve1422 = null;
                                        if (i14 != 2 && !this.k) {
                                            if (z && (c0357s9 = this.d) != null) {
                                                c0486z5 = c0357s9.h;
                                                if (c0486z5.j && c0357s9.i.j) {
                                                    if (!z) {
                                                        c0170ia.d(k, c0486z5.g);
                                                        c0170ia.d(k2, this.d.i.g);
                                                        if (this.T != null && z3 && zArr3[0] && !x()) {
                                                            c0170ia.f(c0170ia.k(this.T.K), k2, 0, 8);
                                                        }
                                                        ve4 = k2;
                                                        ve5 = k;
                                                        c0239m43 = c0239m49;
                                                        c0239m44 = c0239m42;
                                                        c0239m45 = c0239m4;
                                                        ve = k3;
                                                        ve2 = k5;
                                                        ve3 = k4;
                                                        iArr3 = iArr2;
                                                        if (z) {
                                                            a43 = this;
                                                            C0038bh c0038bh2 = a43.e;
                                                            if (c0038bh2 != null) {
                                                                C0486z5 c0486z53 = c0038bh2.h;
                                                                if (c0486z53.j && c0038bh2.i.j) {
                                                                    c0170ia2 = c0170ia;
                                                                    ve8 = ve;
                                                                    c0170ia2.d(ve8, c0486z53.g);
                                                                    ve7 = ve3;
                                                                    c0170ia2.d(ve7, a43.e.i.g);
                                                                    ve6 = ve2;
                                                                    c0170ia2.d(ve6, a43.e.k.g);
                                                                    A4 a47 = a43.T;
                                                                    if (a47 != null && !z5 && z2) {
                                                                        i17 = 1;
                                                                        if (zArr3[1]) {
                                                                            i15 = 8;
                                                                            i16 = 0;
                                                                            c0170ia2.f(c0170ia2.k(a47.L), ve7, 0, 8);
                                                                        } else {
                                                                            i15 = 8;
                                                                            i16 = 0;
                                                                        }
                                                                    } else {
                                                                        i15 = 8;
                                                                        i16 = 0;
                                                                        i17 = 1;
                                                                    }
                                                                    i18 = i16;
                                                                    if (a43.p != 2) {
                                                                        i19 = i16;
                                                                    } else {
                                                                        i19 = i18;
                                                                    }
                                                                    if (i19 == 0 && !a43.l) {
                                                                        if (iArr[i17] == 2 && (a43 instanceof B4)) {
                                                                            z15 = i17;
                                                                        } else {
                                                                            z15 = i16;
                                                                        }
                                                                        if (z15) {
                                                                            i11 = i16;
                                                                        }
                                                                        A4 a48 = a43.T;
                                                                        if (a48 != null) {
                                                                            ve11 = c0170ia2.k(a48.L);
                                                                        } else {
                                                                            ve11 = null;
                                                                        }
                                                                        A4 a49 = a43.T;
                                                                        if (a49 != null) {
                                                                            ve1422 = c0170ia2.k(a49.J);
                                                                        }
                                                                        int i31 = a43.a0;
                                                                        if (i31 > 0 || a43.g0 == i15) {
                                                                            C0239m4 c0239m411 = c0239m45;
                                                                            if (c0239m411.f != null) {
                                                                                c0170ia2.e(ve6, ve8, i31, i15);
                                                                                c0170ia2.e(ve6, c0170ia2.k(c0239m411.f), c0239m411.e(), i15);
                                                                                if (z2) {
                                                                                    c0170ia2.f(ve11, c0170ia2.k(c0239m43), i16, 5);
                                                                                }
                                                                                z16 = i16;
                                                                                boolean z23 = zArr3[i17];
                                                                                int i32 = iArr[i17];
                                                                                int i33 = a43.Z;
                                                                                int i34 = a43.c0;
                                                                                int i35 = iArr3[i17];
                                                                                float f2 = a43.e0;
                                                                                if (iArr[i16] != 3) {
                                                                                    i20 = i17;
                                                                                } else {
                                                                                    i20 = i16;
                                                                                }
                                                                                ve9 = ve7;
                                                                                ve10 = ve8;
                                                                                d(c0170ia, false, z2, z3, z23, ve1422, ve11, i32, z15, a43.J, a43.L, i33, i11, i34, i35, f2, z11, i20, z5, z6, z2222, i9, i8, a43.f14x, a43.y, a43.z, z16);
                                                                            } else if (a43.g0 == i15) {
                                                                                c0170ia2.e(ve6, ve8, c0239m411.e(), i15);
                                                                            } else {
                                                                                c0170ia2.e(ve6, ve8, i31, i15);
                                                                            }
                                                                        }
                                                                        z16 = z13;
                                                                        boolean z232 = zArr3[i17];
                                                                        int i322 = iArr[i17];
                                                                        int i332 = a43.Z;
                                                                        int i342 = a43.c0;
                                                                        int i352 = iArr3[i17];
                                                                        float f22 = a43.e0;
                                                                        if (iArr[i16] != 3) {
                                                                        }
                                                                        ve9 = ve7;
                                                                        ve10 = ve8;
                                                                        d(c0170ia, false, z2, z3, z232, ve1422, ve11, i322, z15, a43.J, a43.L, i332, i11, i342, i352, f22, z11, i20, z5, z6, z2222, i9, i8, a43.f14x, a43.y, a43.z, z16);
                                                                    } else {
                                                                        ve9 = ve7;
                                                                        ve10 = ve8;
                                                                    }
                                                                    if (!z9) {
                                                                        if (this.A == 1) {
                                                                            float f3 = this.B;
                                                                            C2 l = c0170ia.l();
                                                                            l.d.g(ve9, -1.0f);
                                                                            l.d.g(ve10, 1.0f);
                                                                            l.d.g(ve4, f3);
                                                                            l.d.g(ve5, -f3);
                                                                            c0170ia3 = c0170ia;
                                                                            c0170ia3.c(l);
                                                                        } else {
                                                                            c0170ia3 = c0170ia;
                                                                            float f4 = this.B;
                                                                            C2 l2 = c0170ia.l();
                                                                            l2.d.g(ve4, -1.0f);
                                                                            l2.d.g(ve5, 1.0f);
                                                                            l2.d.g(ve9, f4);
                                                                            l2.d.g(ve10, -f4);
                                                                            c0170ia3.c(l2);
                                                                        }
                                                                    } else {
                                                                        c0170ia3 = c0170ia;
                                                                    }
                                                                    if (c0239m44.h()) {
                                                                        C0239m4 c0239m412 = c0239m44;
                                                                        A4 a410 = c0239m412.f.d;
                                                                        float radians = (float) Math.toRadians(this.D + 90.0f);
                                                                        int e = c0239m412.e();
                                                                        Ve k6 = c0170ia3.k(i(2));
                                                                        Ve k7 = c0170ia3.k(i(3));
                                                                        Ve k8 = c0170ia3.k(i(4));
                                                                        Ve k9 = c0170ia3.k(i(5));
                                                                        Ve k10 = c0170ia3.k(a410.i(2));
                                                                        Ve k11 = c0170ia3.k(a410.i(3));
                                                                        Ve k12 = c0170ia3.k(a410.i(4));
                                                                        Ve k13 = c0170ia3.k(a410.i(5));
                                                                        C2 l3 = c0170ia.l();
                                                                        double d = radians;
                                                                        double d2 = e;
                                                                        float sin = (float) (Math.sin(d) * d2);
                                                                        l3.d.g(k11, 0.5f);
                                                                        l3.d.g(k13, 0.5f);
                                                                        l3.d.g(k7, -0.5f);
                                                                        l3.d.g(k9, -0.5f);
                                                                        l3.b = -sin;
                                                                        c0170ia3.c(l3);
                                                                        C2 l4 = c0170ia.l();
                                                                        float cos = (float) (Math.cos(d) * d2);
                                                                        l4.d.g(k10, 0.5f);
                                                                        l4.d.g(k12, 0.5f);
                                                                        l4.d.g(k6, -0.5f);
                                                                        l4.d.g(k8, -0.5f);
                                                                        l4.b = -cos;
                                                                        c0170ia3.c(l4);
                                                                    }
                                                                    this.k = false;
                                                                    this.l = false;
                                                                }
                                                            }
                                                            c0170ia2 = c0170ia;
                                                            ve6 = ve2;
                                                            ve7 = ve3;
                                                            ve8 = ve;
                                                            i15 = 8;
                                                            i16 = 0;
                                                            i17 = 1;
                                                        } else {
                                                            i15 = 8;
                                                            i16 = 0;
                                                            i17 = 1;
                                                            a43 = this;
                                                            c0170ia2 = c0170ia;
                                                            ve6 = ve2;
                                                            ve7 = ve3;
                                                            ve8 = ve;
                                                        }
                                                        i18 = i17;
                                                        if (a43.p != 2) {
                                                        }
                                                        if (i19 == 0) {
                                                        }
                                                        ve9 = ve7;
                                                        ve10 = ve8;
                                                        if (!z9) {
                                                        }
                                                        if (c0239m44.h()) {
                                                        }
                                                        this.k = false;
                                                        this.l = false;
                                                    }
                                                }
                                            }
                                            a44 = this.T;
                                            if (a44 == null) {
                                                ve12 = c0170ia.k(a44.K);
                                            } else {
                                                ve12 = null;
                                            }
                                            a45 = this.T;
                                            if (a45 == null) {
                                                ve13 = c0170ia.k(a45.I);
                                            } else {
                                                ve13 = null;
                                            }
                                            boolean z24 = zArr3[0];
                                            int i36 = iArr[0];
                                            int i37 = this.Y;
                                            int i38 = this.b0;
                                            int i39 = iArr2[0];
                                            float f5 = this.d0;
                                            if (iArr[1] != 3) {
                                                z17 = true;
                                            } else {
                                                z17 = false;
                                            }
                                            ve2 = k5;
                                            c0239m45 = c0239m4;
                                            ve3 = k4;
                                            iArr3 = iArr2;
                                            c0239m43 = c0239m49;
                                            ve = k3;
                                            ve4 = k2;
                                            c0239m44 = c0239m42;
                                            ve5 = k;
                                            d(c0170ia, true, z3, z2, z24, ve13, ve12, i36, z12, this.I, this.K, i37, i13, i38, i39, f5, z10, z17, z6, z5, z14, i8, i9, this.u, this.v, this.w, z13);
                                            if (z) {
                                            }
                                            i18 = i17;
                                            if (a43.p != 2) {
                                            }
                                            if (i19 == 0) {
                                            }
                                            ve9 = ve7;
                                            ve10 = ve8;
                                            if (!z9) {
                                            }
                                            if (c0239m44.h()) {
                                            }
                                            this.k = false;
                                            this.l = false;
                                        }
                                        c0239m43 = c0239m49;
                                        c0239m44 = c0239m42;
                                        c0239m45 = c0239m4;
                                        ve = k3;
                                        ve2 = k5;
                                        ve3 = k4;
                                        ve4 = k2;
                                        ve5 = k;
                                        iArr3 = iArr2;
                                        if (z) {
                                        }
                                        i18 = i17;
                                        if (a43.p != 2) {
                                        }
                                        if (i19 == 0) {
                                        }
                                        ve9 = ve7;
                                        ve10 = ve8;
                                        if (!z9) {
                                        }
                                        if (c0239m44.h()) {
                                        }
                                        this.k = false;
                                        this.l = false;
                                    }
                                } else {
                                    i12 = -1;
                                }
                                z10 = false;
                                if (!z9) {
                                }
                                c = 0;
                                z11 = false;
                                if (iArr[c] != 2) {
                                }
                                z12 = false;
                                if (!z12) {
                                }
                                c0239m42 = this.P;
                                z13 = !c0239m42.h();
                                z14 = zArr2[0];
                                boolean z22222 = zArr2[1];
                                i14 = this.o;
                                iArr2 = this.C;
                                Ve ve14222 = null;
                                if (i14 != 2) {
                                    if (z) {
                                        c0486z5 = c0357s9.h;
                                        if (c0486z5.j) {
                                            if (!z) {
                                            }
                                        }
                                    }
                                    a44 = this.T;
                                    if (a44 == null) {
                                    }
                                    a45 = this.T;
                                    if (a45 == null) {
                                    }
                                    boolean z242 = zArr3[0];
                                    int i362 = iArr[0];
                                    int i372 = this.Y;
                                    int i382 = this.b0;
                                    int i392 = iArr2[0];
                                    float f52 = this.d0;
                                    if (iArr[1] != 3) {
                                    }
                                    ve2 = k5;
                                    c0239m45 = c0239m4;
                                    ve3 = k4;
                                    iArr3 = iArr2;
                                    c0239m43 = c0239m49;
                                    ve = k3;
                                    ve4 = k2;
                                    c0239m44 = c0239m42;
                                    ve5 = k;
                                    d(c0170ia, true, z3, z2, z242, ve13, ve12, i362, z12, this.I, this.K, i372, i13, i382, i392, f52, z10, z17, z6, z5, z14, i8, i9, this.u, this.v, this.w, z13);
                                    if (z) {
                                    }
                                    i18 = i17;
                                    if (a43.p != 2) {
                                    }
                                    if (i19 == 0) {
                                    }
                                    ve9 = ve7;
                                    ve10 = ve8;
                                    if (!z9) {
                                    }
                                    if (c0239m44.h()) {
                                    }
                                    this.k = false;
                                    this.l = false;
                                }
                                c0239m43 = c0239m49;
                                c0239m44 = c0239m42;
                                c0239m45 = c0239m4;
                                ve = k3;
                                ve2 = k5;
                                ve3 = k4;
                                ve4 = k2;
                                ve5 = k;
                                iArr3 = iArr2;
                                if (z) {
                                }
                                i18 = i17;
                                if (a43.p != 2) {
                                }
                                if (i19 == 0) {
                                }
                                ve9 = ve7;
                                ve10 = ve8;
                                if (!z9) {
                                }
                                if (c0239m44.h()) {
                                }
                                this.k = false;
                                this.l = false;
                            }
                            i9 = i28;
                            i10 = i24;
                            z9 = true;
                            int[] iArr6222 = this.t;
                            iArr6222[0] = i8;
                            iArr6222[1] = i9;
                            if (z9) {
                            }
                            z10 = false;
                            if (!z9) {
                            }
                            c = 0;
                            z11 = false;
                            if (iArr[c] != 2) {
                            }
                            z12 = false;
                            if (!z12) {
                            }
                            c0239m42 = this.P;
                            z13 = !c0239m42.h();
                            z14 = zArr2[0];
                            boolean z222222 = zArr2[1];
                            i14 = this.o;
                            iArr2 = this.C;
                            Ve ve142222 = null;
                            if (i14 != 2) {
                            }
                            c0239m43 = c0239m49;
                            c0239m44 = c0239m42;
                            c0239m45 = c0239m4;
                            ve = k3;
                            ve2 = k5;
                            ve3 = k4;
                            ve4 = k2;
                            ve5 = k;
                            iArr3 = iArr2;
                            if (z) {
                            }
                            i18 = i17;
                            if (a43.p != 2) {
                            }
                            if (i19 == 0) {
                            }
                            ve9 = ve7;
                            ve10 = ve8;
                            if (!z9) {
                            }
                            if (c0239m44.h()) {
                            }
                            this.k = false;
                            this.l = false;
                        }
                    }
                    i8 = i27;
                    i9 = i28;
                    i10 = i24;
                    i11 = i25;
                    z9 = true;
                    int[] iArr62222 = this.t;
                    iArr62222[0] = i8;
                    iArr62222[1] = i9;
                    if (z9) {
                    }
                    z10 = false;
                    if (!z9) {
                    }
                    c = 0;
                    z11 = false;
                    if (iArr[c] != 2) {
                    }
                    z12 = false;
                    if (!z12) {
                    }
                    c0239m42 = this.P;
                    z13 = !c0239m42.h();
                    z14 = zArr2[0];
                    boolean z2222222 = zArr2[1];
                    i14 = this.o;
                    iArr2 = this.C;
                    Ve ve1422222 = null;
                    if (i14 != 2) {
                    }
                    c0239m43 = c0239m49;
                    c0239m44 = c0239m42;
                    c0239m45 = c0239m4;
                    ve = k3;
                    ve2 = k5;
                    ve3 = k4;
                    ve4 = k2;
                    ve5 = k;
                    iArr3 = iArr2;
                    if (z) {
                    }
                    i18 = i17;
                    if (a43.p != 2) {
                    }
                    if (i19 == 0) {
                    }
                    ve9 = ve7;
                    ve10 = ve8;
                    if (!z9) {
                    }
                    if (c0239m44.h()) {
                    }
                    this.k = false;
                    this.l = false;
                }
            } else {
                iArr = iArr5;
            }
            i8 = i27;
            i9 = i28;
            i10 = i24;
            i11 = i25;
            z9 = false;
            int[] iArr622222 = this.t;
            iArr622222[0] = i8;
            iArr622222[1] = i9;
            if (z9) {
            }
            z10 = false;
            if (!z9) {
            }
            c = 0;
            z11 = false;
            if (iArr[c] != 2) {
            }
            z12 = false;
            if (!z12) {
            }
            c0239m42 = this.P;
            z13 = !c0239m42.h();
            z14 = zArr2[0];
            boolean z22222222 = zArr2[1];
            i14 = this.o;
            iArr2 = this.C;
            Ve ve14222222 = null;
            if (i14 != 2) {
            }
            c0239m43 = c0239m49;
            c0239m44 = c0239m42;
            c0239m45 = c0239m4;
            ve = k3;
            ve2 = k5;
            ve3 = k4;
            ve4 = k2;
            ve5 = k;
            iArr3 = iArr2;
            if (z) {
            }
            i18 = i17;
            if (a43.p != 2) {
            }
            if (i19 == 0) {
            }
            ve9 = ve7;
            ve10 = ve8;
            if (!z9) {
            }
            if (c0239m44.h()) {
            }
            this.k = false;
            this.l = false;
        }
        z2 = false;
        z3 = false;
        i = this.g0;
        zArr = this.S;
        if (i == 8) {
        }
        z4 = this.k;
        if (!z4) {
        }
        if (z4) {
        }
        if (this.l) {
        }
        if (this.k) {
            this.k = false;
            this.l = false;
            return;
        }
        boolean[] zArr32 = this.f;
        if (!z) {
        }
        c0239m4 = c0239m410;
        zArr2 = zArr;
        if (this.T == null) {
        }
        i2 = this.U;
        i3 = this.b0;
        if (i2 >= i3) {
        }
        i4 = this.V;
        i5 = this.c0;
        if (i4 >= i5) {
        }
        int[] iArr52 = this.p0;
        i6 = iArr52[0];
        int i242 = i3;
        if (i6 == 3) {
        }
        i7 = iArr52[1];
        int i252 = i5;
        if (i7 == 3) {
        }
        int i262 = this.X;
        this.A = i262;
        f = this.W;
        this.B = f;
        int i272 = this.r;
        int i282 = this.s;
        if (f <= 0.0f) {
        }
        i8 = i272;
        i9 = i282;
        i10 = i242;
        i11 = i252;
        z9 = false;
        int[] iArr6222222 = this.t;
        iArr6222222[0] = i8;
        iArr6222222[1] = i9;
        if (z9) {
        }
        z10 = false;
        if (!z9) {
        }
        c = 0;
        z11 = false;
        if (iArr[c] != 2) {
        }
        z12 = false;
        if (!z12) {
        }
        c0239m42 = this.P;
        z13 = !c0239m42.h();
        z14 = zArr2[0];
        boolean z222222222 = zArr2[1];
        i14 = this.o;
        iArr2 = this.C;
        Ve ve142222222 = null;
        if (i14 != 2) {
        }
        c0239m43 = c0239m49;
        c0239m44 = c0239m42;
        c0239m45 = c0239m4;
        ve = k3;
        ve2 = k5;
        ve3 = k4;
        ve4 = k2;
        ve5 = k;
        iArr3 = iArr2;
        if (z) {
        }
        i18 = i17;
        if (a43.p != 2) {
        }
        if (i19 == 0) {
        }
        ve9 = ve7;
        ve10 = ve8;
        if (!z9) {
        }
        if (c0239m44.h()) {
        }
        this.k = false;
        this.l = false;
    }

    public boolean c() {
        if (this.g0 != 8) {
            return true;
        }
        return false;
    }

    /* JADX WARN: Removed duplicated region for block: B:131:0x03ac A[ADDED_TO_REGION] */
    /* JADX WARN: Removed duplicated region for block: B:135:0x03b9  */
    /* JADX WARN: Removed duplicated region for block: B:145:0x041e  */
    /* JADX WARN: Removed duplicated region for block: B:153:0x042f  */
    /* JADX WARN: Removed duplicated region for block: B:163:0x0455 A[ADDED_TO_REGION] */
    /* JADX WARN: Removed duplicated region for block: B:172:0x046f  */
    /* JADX WARN: Removed duplicated region for block: B:202:0x04bc  */
    /* JADX WARN: Removed duplicated region for block: B:209:0x04cf A[ADDED_TO_REGION] */
    /* JADX WARN: Removed duplicated region for block: B:220:0x0451  */
    /* JADX WARN: Removed duplicated region for block: B:222:0x0402  */
    /* JADX WARN: Removed duplicated region for block: B:292:0x0506  */
    /* JADX WARN: Removed duplicated region for block: B:44:0x01ac  */
    /* JADX WARN: Removed duplicated region for block: B:82:0x04f0 A[ADDED_TO_REGION] */
    /* JADX WARN: Removed duplicated region for block: B:92:? A[ADDED_TO_REGION, RETURN, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void d(C0170ia c0170ia, boolean z, boolean z2, boolean z3, boolean z4, Ve ve, Ve ve2, int i, boolean z5, C0239m4 c0239m4, C0239m4 c0239m42, int i2, int i3, int i4, int i5, float f, boolean z6, boolean z7, boolean z8, boolean z9, boolean z10, int i6, int i7, int i8, int i9, float f2, boolean z11) {
        boolean z12;
        boolean z13;
        int i10;
        boolean z14;
        int i11;
        int i12;
        int i13;
        boolean z15;
        boolean z16;
        Ve k;
        Ve k2;
        Ve ve3;
        Ve ve4;
        Ve ve5;
        Ve ve6;
        boolean z17;
        int i14;
        char c;
        int i15;
        C0239m4 c0239m43;
        Ve ve7;
        int i16;
        boolean z18;
        Ve ve8;
        boolean z19;
        boolean z20;
        int i17;
        int i18;
        Ve ve9;
        int i19;
        boolean z21;
        int i20;
        boolean z22;
        C0239m4 c0239m44;
        Ve ve10;
        Ve ve11;
        boolean z23;
        int i21;
        A4 a4;
        boolean z24;
        int i22;
        A4 a42;
        A4 a43;
        Ve ve12;
        Ve ve13;
        boolean z25;
        boolean z26;
        Ve ve14;
        Ve ve15;
        A4 a44;
        int i23;
        int i24;
        HashSet hashSet;
        int i25;
        int i26;
        int i27;
        int i28;
        boolean z27;
        boolean z28;
        boolean z29;
        int i29;
        int i30;
        Ve ve16;
        int i31;
        int i32 = i8;
        int i33 = i9;
        Ve k3 = c0170ia.k(c0239m4);
        Ve k4 = c0170ia.k(c0239m42);
        Ve k5 = c0170ia.k(c0239m4.f);
        Ve k6 = c0170ia.k(c0239m42.f);
        boolean h = c0239m4.h();
        boolean h2 = c0239m42.h();
        boolean h3 = this.P.h();
        int i34 = h2 ? (h ? 1 : 0) + 1 : h ? 1 : 0;
        if (h3) {
            i34++;
        }
        int i35 = i34;
        int i36 = z6 ? 3 : i6;
        int j = Ue.j(i);
        boolean z30 = (j == 0 || j == 1 || j != 2 || i36 == 4) ? false : true;
        int i37 = this.h;
        if (i37 == -1 || !z) {
            i37 = i3;
            z12 = z30;
        } else {
            this.h = -1;
            z12 = false;
        }
        int i38 = this.i;
        if (i38 == -1 || z) {
            z13 = z12;
        } else {
            this.i = -1;
            i37 = i38;
            z13 = false;
        }
        int i39 = i37;
        if (this.g0 == 8) {
            i10 = 0;
            z13 = false;
        } else {
            i10 = i39;
        }
        if (z11) {
            if (!h && !h2 && !h3) {
                c0170ia.d(k3, i2);
            } else if (h && !h2) {
                z14 = h3;
                i11 = 8;
                c0170ia.e(k3, k5, c0239m4.e(), 8);
            }
            z14 = h3;
            i11 = 8;
        } else {
            z14 = h3;
            i11 = 8;
        }
        if (z13) {
            if (i35 == 2 || z6 || !(i36 == 1 || i36 == 0)) {
                if (i32 == -2) {
                    i32 = i10;
                }
                if (i33 == -2) {
                    i33 = i10;
                }
                if (i10 > 0 && i36 != 1) {
                    i10 = 0;
                }
                if (i32 > 0) {
                    c0170ia.f(k4, k3, i32, 8);
                    i10 = Math.max(i10, i32);
                }
                if (i33 > 0) {
                    if (!z2 || i36 != 1) {
                        c0170ia.g(k4, k3, i33, 8);
                    }
                    i10 = Math.min(i10, i33);
                }
                if (i36 == 1) {
                    if (z2) {
                        c0170ia.e(k4, k3, i10, 8);
                    } else if (z8) {
                        c0170ia.e(k4, k3, i10, 5);
                        c0170ia.g(k4, k3, i10, 8);
                    } else {
                        c0170ia.e(k4, k3, i10, 5);
                        c0170ia.g(k4, k3, i10, 8);
                    }
                } else if (i36 == 2) {
                    int i40 = c0239m4.e;
                    if (i40 != 3 && i40 != 5) {
                        k = c0170ia.k(this.T.i(2));
                        k2 = c0170ia.k(this.T.i(4));
                    } else {
                        k = c0170ia.k(this.T.i(3));
                        k2 = c0170ia.k(this.T.i(5));
                    }
                    C2 l = c0170ia.l();
                    i12 = i35;
                    l.d.g(k4, -1.0f);
                    l.d.g(k3, 1.0f);
                    l.d.g(k2, f2);
                    l.d.g(k, -f2);
                    c0170ia.c(l);
                    z16 = z4;
                    i13 = i32;
                    z15 = z2 ? false : z13;
                } else {
                    i12 = i35;
                    i13 = i32;
                    z15 = z13;
                    z16 = true;
                }
            } else {
                int max = Math.max(i32, i10);
                if (i33 > 0) {
                    max = Math.min(i33, max);
                }
                c0170ia.e(k4, k3, max, 8);
                z16 = z4;
                i12 = i35;
                z15 = false;
                i13 = i32;
            }
            if (z11) {
                ve3 = ve;
                ve4 = ve2;
                ve5 = k4;
                ve6 = k3;
                z17 = z16;
                i14 = i12;
                c = 1;
                i15 = 2;
            } else if (z8) {
                ve3 = ve;
                ve4 = ve2;
                ve5 = k4;
                ve6 = k3;
                z17 = z16;
                i14 = i12;
                i15 = 2;
                c = 1;
            } else {
                if (!h && !h2 && !z14) {
                    c0239m44 = c0239m42;
                    ve15 = k4;
                    z23 = z16;
                    ve14 = k6;
                } else if (!h || h2) {
                    if (h || !h2) {
                        ve7 = k6;
                        if (h && h2) {
                            A4 a45 = c0239m4.f.d;
                            A4 a46 = c0239m42.f.d;
                            A4 a47 = this.T;
                            int i41 = 6;
                            if (!z15) {
                                i16 = i36;
                                z18 = true;
                                if (k5.f && ve7.f) {
                                    c0170ia.b(k3, k5, c0239m4.e(), f, ve7, k4, c0239m42.e(), 8);
                                    if (z2 && z16) {
                                        if (c0239m42.f != null) {
                                            i19 = c0239m42.e();
                                            ve9 = ve2;
                                        } else {
                                            ve9 = ve2;
                                            i19 = 0;
                                        }
                                        if (ve7 != ve9) {
                                            c0170ia.f(ve9, k4, i19, 5);
                                            return;
                                        }
                                        return;
                                    }
                                    return;
                                }
                                ve8 = ve2;
                                z19 = true;
                                z20 = true;
                                i17 = 6;
                                i18 = 5;
                            } else {
                                if (i36 != 0) {
                                    if (i36 == 2) {
                                        if ((a45 instanceof P2) || (a46 instanceof P2)) {
                                            i16 = i36;
                                            i17 = 6;
                                            i18 = 5;
                                            z18 = true;
                                            z19 = true;
                                            z20 = true;
                                            z21 = false;
                                            i20 = 4;
                                        } else {
                                            i16 = i36;
                                            i17 = 6;
                                            i18 = 5;
                                            z18 = true;
                                            z19 = true;
                                            z20 = true;
                                            z21 = false;
                                            i20 = 5;
                                        }
                                    } else if (i36 == 1) {
                                        i16 = i36;
                                        i17 = 6;
                                        i18 = 8;
                                        z18 = true;
                                        z19 = true;
                                        z20 = true;
                                        z21 = false;
                                        i20 = 4;
                                    } else if (i36 == 3) {
                                        i16 = i36;
                                        if (this.A == -1) {
                                            if (z9) {
                                                ve8 = ve2;
                                                i18 = 8;
                                                z18 = true;
                                                z19 = true;
                                                z20 = true;
                                                z21 = true;
                                                i17 = z2 ? 5 : 4;
                                            } else {
                                                ve8 = ve2;
                                                i18 = 8;
                                                z18 = true;
                                                z19 = true;
                                                z20 = true;
                                                z21 = true;
                                                i17 = 8;
                                            }
                                        } else if (z6) {
                                            if (i7 != 2) {
                                                z18 = true;
                                                if (i7 != 1) {
                                                    i18 = 8;
                                                    i27 = 5;
                                                    i20 = i27;
                                                    z19 = z18;
                                                    z20 = z19;
                                                    z21 = z20;
                                                    i17 = 6;
                                                }
                                            } else {
                                                z18 = true;
                                            }
                                            i18 = 5;
                                            i27 = 4;
                                            i20 = i27;
                                            z19 = z18;
                                            z20 = z19;
                                            z21 = z20;
                                            i17 = 6;
                                        } else {
                                            z18 = true;
                                            if (i33 > 0) {
                                                ve8 = ve2;
                                                z19 = true;
                                                z20 = true;
                                                z21 = true;
                                                i17 = 6;
                                                i18 = 5;
                                            } else {
                                                if (i33 != 0 || i13 != 0) {
                                                    ve8 = ve2;
                                                    z19 = true;
                                                    z20 = true;
                                                    z21 = true;
                                                    i17 = 6;
                                                    i18 = 5;
                                                } else if (z9) {
                                                    i18 = (a45 == a47 || a46 == a47) ? 5 : 4;
                                                    ve8 = ve2;
                                                    z19 = true;
                                                    z20 = true;
                                                    z21 = true;
                                                    i17 = 6;
                                                } else {
                                                    ve8 = ve2;
                                                    z19 = true;
                                                    z20 = true;
                                                    z21 = true;
                                                    i17 = 6;
                                                    i18 = 5;
                                                    i20 = 8;
                                                    if (z20 || k5 != ve7 || a45 == a47) {
                                                        z22 = z18;
                                                    } else {
                                                        z20 = false;
                                                        z22 = false;
                                                    }
                                                    if (z19) {
                                                        if (z15 || z7 || z9 || k5 != ve || ve7 != ve8) {
                                                            z25 = z2;
                                                            i25 = i17;
                                                            i26 = i18;
                                                        } else {
                                                            z25 = false;
                                                            i26 = 8;
                                                            z22 = false;
                                                            i25 = 8;
                                                        }
                                                        a42 = a46;
                                                        c0239m44 = c0239m42;
                                                        z23 = z16;
                                                        a43 = a45;
                                                        i21 = i13;
                                                        ve10 = ve7;
                                                        i22 = 4;
                                                        z24 = true;
                                                        ve12 = k5;
                                                        a4 = a47;
                                                        ve11 = k4;
                                                        ve13 = k3;
                                                        c0170ia.b(k3, k5, c0239m4.e(), f, ve7, k4, c0239m42.e(), i25);
                                                        i18 = i26;
                                                    } else {
                                                        c0239m44 = c0239m42;
                                                        ve10 = ve7;
                                                        ve11 = k4;
                                                        z23 = z16;
                                                        i21 = i13;
                                                        a4 = a47;
                                                        z24 = z18;
                                                        i22 = 4;
                                                        a42 = a46;
                                                        a43 = a45;
                                                        ve12 = k5;
                                                        ve13 = k3;
                                                        z25 = z2;
                                                    }
                                                    z26 = z22;
                                                    if (this.g0 != 8 && ((hashSet = c0239m44.a) == null || hashSet.size() <= 0)) {
                                                        return;
                                                    }
                                                    ve14 = ve10;
                                                    if (z20) {
                                                        if (z25 && ve12 != ve14 && !z15 && ((a43 instanceof P2) || (a42 instanceof P2))) {
                                                            i18 = 6;
                                                        }
                                                        c0170ia.f(ve13, ve12, c0239m4.e(), i18);
                                                        ve15 = ve11;
                                                        c0170ia.g(ve15, ve14, -c0239m42.e(), i18);
                                                    } else {
                                                        ve15 = ve11;
                                                    }
                                                    if (z25 || !z10 || (a43 instanceof P2) || (a42 instanceof P2)) {
                                                        a44 = a4;
                                                    } else {
                                                        a44 = a4;
                                                        if (a42 != a44) {
                                                            i18 = 6;
                                                            i23 = 6;
                                                            z26 = z24;
                                                            if (z26) {
                                                                if (z21 && (!z9 || z3)) {
                                                                    if (a43 != a44 && a42 != a44) {
                                                                        i41 = i23;
                                                                    }
                                                                    if ((a43 instanceof C0263n9) || (a42 instanceof C0263n9)) {
                                                                        i41 = 5;
                                                                    }
                                                                    if ((a43 instanceof P2) || (a42 instanceof P2)) {
                                                                        i41 = 5;
                                                                    }
                                                                    i23 = Math.max(z9 ? 5 : i41, i23);
                                                                }
                                                                int i42 = i23;
                                                                if (z25) {
                                                                    i42 = Math.min(i18, i42);
                                                                    if (z6 && !z9 && (a43 == a44 || a42 == a44)) {
                                                                        i42 = i22;
                                                                    }
                                                                }
                                                                c0170ia.e(ve13, ve12, c0239m4.e(), i42);
                                                                c0170ia.e(ve15, ve14, -c0239m42.e(), i42);
                                                            }
                                                            if (z25) {
                                                                Ve ve17 = ve12;
                                                                int e = ve == ve17 ? c0239m4.e() : 0;
                                                                if (ve17 != ve) {
                                                                    c0170ia.f(ve13, ve, e, 5);
                                                                }
                                                            }
                                                            if (z25 && z15 && i4 == 0 && i21 == 0) {
                                                                if (!z15 && i16 == 3) {
                                                                    c0170ia.f(ve15, ve13, 0, 8);
                                                                } else {
                                                                    i24 = 5;
                                                                    c0170ia.f(ve15, ve13, 0, 5);
                                                                }
                                                            }
                                                            i24 = 5;
                                                        }
                                                    }
                                                    i23 = i20;
                                                    if (z26) {
                                                    }
                                                    if (z25) {
                                                    }
                                                    if (z25) {
                                                        if (!z15) {
                                                        }
                                                        i24 = 5;
                                                        c0170ia.f(ve15, ve13, 0, 5);
                                                    }
                                                    i24 = 5;
                                                }
                                                i20 = 4;
                                                if (z20) {
                                                }
                                                z22 = z18;
                                                if (z19) {
                                                }
                                                z26 = z22;
                                                if (this.g0 != 8) {
                                                }
                                                ve14 = ve10;
                                                if (z20) {
                                                }
                                                if (z25) {
                                                }
                                                a44 = a4;
                                                i23 = i20;
                                                if (z26) {
                                                }
                                                if (z25) {
                                                }
                                                if (z25) {
                                                }
                                                i24 = 5;
                                            }
                                        }
                                        i20 = 5;
                                        if (z20) {
                                        }
                                        z22 = z18;
                                        if (z19) {
                                        }
                                        z26 = z22;
                                        if (this.g0 != 8) {
                                        }
                                        ve14 = ve10;
                                        if (z20) {
                                        }
                                        if (z25) {
                                        }
                                        a44 = a4;
                                        i23 = i20;
                                        if (z26) {
                                        }
                                        if (z25) {
                                        }
                                        if (z25) {
                                        }
                                        i24 = 5;
                                    } else {
                                        i16 = i36;
                                        z18 = true;
                                        ve8 = ve2;
                                        i17 = 6;
                                        i18 = 5;
                                        z19 = false;
                                        z20 = false;
                                    }
                                    i30 = i24;
                                    if (z25 || !z23) {
                                        return;
                                    }
                                    if (c0239m44.f != null) {
                                        i31 = c0239m42.e();
                                        ve16 = ve2;
                                    } else {
                                        ve16 = ve2;
                                        i31 = 0;
                                    }
                                    if (ve14 != ve16) {
                                        c0170ia.f(ve16, ve15, i31, i30);
                                        return;
                                    }
                                    return;
                                }
                                if (i33 != 0 || i13 != 0) {
                                    i28 = 5;
                                    z27 = true;
                                    z28 = false;
                                    z29 = true;
                                    i29 = 5;
                                } else if (k5.f && ve7.f) {
                                    c0170ia.e(k3, k5, c0239m4.e(), 8);
                                    c0170ia.e(k4, ve7, -c0239m42.e(), 8);
                                    return;
                                } else {
                                    i28 = 8;
                                    z27 = false;
                                    z28 = true;
                                    z29 = false;
                                    i29 = 8;
                                }
                                if ((a45 instanceof P2) || (a46 instanceof P2)) {
                                    i18 = i28;
                                    i17 = 6;
                                    z20 = z29;
                                    z18 = true;
                                    i20 = 4;
                                } else {
                                    i18 = i28;
                                    z20 = z29;
                                    i20 = i29;
                                    z18 = true;
                                    i17 = 6;
                                }
                                z21 = z28;
                                z19 = z27;
                                i16 = i36;
                                ve8 = ve2;
                                if (z20) {
                                }
                                z22 = z18;
                                if (z19) {
                                }
                                z26 = z22;
                                if (this.g0 != 8) {
                                }
                                ve14 = ve10;
                                if (z20) {
                                }
                                if (z25) {
                                }
                                a44 = a4;
                                i23 = i20;
                                if (z26) {
                                }
                                if (z25) {
                                }
                                if (z25) {
                                }
                                i24 = 5;
                                i30 = i24;
                                if (z25) {
                                    return;
                                } else {
                                    return;
                                }
                            }
                            z21 = false;
                            i20 = 4;
                            if (z20) {
                            }
                            z22 = z18;
                            if (z19) {
                            }
                            z26 = z22;
                            if (this.g0 != 8) {
                            }
                            ve14 = ve10;
                            if (z20) {
                            }
                            if (z25) {
                            }
                            a44 = a4;
                            i23 = i20;
                            if (z26) {
                            }
                            if (z25) {
                            }
                            if (z25) {
                            }
                            i24 = 5;
                            i30 = i24;
                            if (z25) {
                            }
                        }
                    } else {
                        ve7 = k6;
                        c0170ia.e(k4, ve7, -c0239m42.e(), 8);
                        if (z2) {
                            c0170ia.f(k3, ve, 0, 5);
                            c0239m44 = c0239m42;
                            i24 = 5;
                            ve14 = ve7;
                            ve15 = k4;
                            z23 = z16;
                            z25 = z2;
                            i30 = i24;
                            if (z25) {
                            }
                        }
                    }
                    c0239m44 = c0239m42;
                    ve14 = ve7;
                    ve15 = k4;
                    z23 = z16;
                } else {
                    c0239m44 = c0239m42;
                    ve15 = k4;
                    z23 = z16;
                    i30 = (z2 && (c0239m4.f.d instanceof P2)) ? 8 : 5;
                    ve14 = k6;
                    z25 = z2;
                    if (z25) {
                    }
                }
                i24 = 5;
                z25 = z2;
                i30 = i24;
                if (z25) {
                }
            }
            if (i14 >= i15 && z2 && z17) {
                c0170ia.f(ve6, ve3, 0, 8);
                C0239m4 c0239m45 = this.M;
                char c2 = (z || c0239m45.f == null) ? c : (char) 0;
                if (!z && (c0239m43 = c0239m45.f) != null) {
                    A4 a48 = c0239m43.d;
                    if (a48.W != 0.0f) {
                        int[] iArr = a48.p0;
                        if (iArr[0] == 3 && iArr[c] == 3) {
                            c2 = c;
                        }
                    }
                    c2 = 0;
                }
                if (c2 != 0) {
                    c0170ia.f(ve4, ve5, 0, 8);
                    return;
                }
                return;
            }
            return;
        }
        if (z5) {
            c0170ia.e(k4, k3, 0, 3);
            if (i4 > 0) {
                c0170ia.f(k4, k3, i4, 8);
            }
            if (i5 < Integer.MAX_VALUE) {
                c0170ia.g(k4, k3, i5, 8);
            }
        } else {
            c0170ia.e(k4, k3, i10, i11);
        }
        z16 = z4;
        i12 = i35;
        i13 = i32;
        z15 = z13;
        if (z11) {
        }
        if (i14 >= i15) {
        }
    }

    public final void e(int i, A4 a4, int i2, int i3) {
        boolean z;
        if (i == 7) {
            if (i2 == 7) {
                C0239m4 i4 = i(2);
                C0239m4 i5 = i(4);
                C0239m4 i6 = i(3);
                C0239m4 i7 = i(5);
                boolean z2 = true;
                if ((i4 != null && i4.h()) || (i5 != null && i5.h())) {
                    z = false;
                } else {
                    e(2, a4, 2, 0);
                    e(4, a4, 4, 0);
                    z = true;
                }
                if ((i6 != null && i6.h()) || (i7 != null && i7.h())) {
                    z2 = false;
                } else {
                    e(3, a4, 3, 0);
                    e(5, a4, 5, 0);
                }
                if (z && z2) {
                    i(7).a(a4.i(7), 0);
                    return;
                } else if (z) {
                    i(8).a(a4.i(8), 0);
                    return;
                } else {
                    if (z2) {
                        i(9).a(a4.i(9), 0);
                        return;
                    }
                    return;
                }
            }
            if (i2 != 2 && i2 != 4) {
                if (i2 == 3 || i2 == 5) {
                    e(3, a4, i2, 0);
                    e(5, a4, i2, 0);
                    i(7).a(a4.i(i2), 0);
                    return;
                }
                return;
            }
            e(2, a4, i2, 0);
            e(4, a4, i2, 0);
            i(7).a(a4.i(i2), 0);
            return;
        }
        if (i == 8 && (i2 == 2 || i2 == 4)) {
            C0239m4 i8 = i(2);
            C0239m4 i9 = a4.i(i2);
            C0239m4 i10 = i(4);
            i8.a(i9, 0);
            i10.a(i9, 0);
            i(8).a(i9, 0);
            return;
        }
        if (i == 9 && (i2 == 3 || i2 == 5)) {
            C0239m4 i11 = a4.i(i2);
            i(3).a(i11, 0);
            i(5).a(i11, 0);
            i(9).a(i11, 0);
            return;
        }
        if (i == 8 && i2 == 8) {
            i(2).a(a4.i(2), 0);
            i(4).a(a4.i(4), 0);
            i(8).a(a4.i(i2), 0);
            return;
        }
        if (i == 9 && i2 == 9) {
            i(3).a(a4.i(3), 0);
            i(5).a(a4.i(5), 0);
            i(9).a(a4.i(i2), 0);
            return;
        }
        C0239m4 i12 = i(i);
        C0239m4 i13 = a4.i(i2);
        if (i12.i(i13)) {
            if (i == 6) {
                C0239m4 i14 = i(3);
                C0239m4 i15 = i(5);
                if (i14 != null) {
                    i14.j();
                }
                if (i15 != null) {
                    i15.j();
                }
            } else if (i != 3 && i != 5) {
                if (i == 2 || i == 4) {
                    C0239m4 i16 = i(7);
                    if (i16.f != i13) {
                        i16.j();
                    }
                    C0239m4 f = i(i).f();
                    C0239m4 i17 = i(8);
                    if (i17.h()) {
                        f.j();
                        i17.j();
                    }
                }
            } else {
                C0239m4 i18 = i(6);
                if (i18 != null) {
                    i18.j();
                }
                C0239m4 i19 = i(7);
                if (i19.f != i13) {
                    i19.j();
                }
                C0239m4 f2 = i(i).f();
                C0239m4 i20 = i(9);
                if (i20.h()) {
                    f2.j();
                    i20.j();
                }
            }
            i12.a(i13, i3);
        }
    }

    public final void f(C0239m4 c0239m4, C0239m4 c0239m42, int i) {
        if (c0239m4.d == this) {
            e(c0239m4.e, c0239m42.d, c0239m42.e, i);
        }
    }

    public final void g(C0170ia c0170ia) {
        c0170ia.k(this.I);
        c0170ia.k(this.J);
        c0170ia.k(this.K);
        c0170ia.k(this.L);
        if (this.a0 > 0) {
            c0170ia.k(this.M);
        }
    }

    /* JADX WARN: Type inference failed for: r0v2, types: [x.Wh, x.bh] */
    /* JADX WARN: Type inference failed for: r0v3, types: [x.Wh, x.s9] */
    public final void h() {
        if (this.d == null) {
            ?? wh = new Wh(this);
            wh.h.e = 4;
            wh.i.e = 5;
            wh.f = 0;
            this.d = wh;
        }
        if (this.e == null) {
            ?? wh2 = new Wh(this);
            C0486z5 c0486z5 = new C0486z5(wh2);
            wh2.k = c0486z5;
            wh2.l = null;
            wh2.h.e = 6;
            wh2.i.e = 7;
            c0486z5.e = 8;
            wh2.f = 1;
            this.e = wh2;
        }
    }

    public C0239m4 i(int i) {
        switch (Ue.j(i)) {
            case 0:
                return null;
            case 1:
                return this.I;
            case 2:
                return this.J;
            case CTConstants.CERTIFICATE_LENGTH_BYTES /* 3 */:
                return this.K;
            case 4:
                return this.L;
            case 5:
                return this.M;
            case 6:
                return this.P;
            case 7:
                return this.N;
            case CTConstants.TIMESTAMP_LENGTH /* 8 */:
                return this.O;
            default:
                throw new AssertionError(Ue.i(i));
        }
    }

    public final int j(int i) {
        int[] iArr = this.p0;
        if (i == 0) {
            return iArr[0];
        }
        if (i != 1) {
            return 0;
        }
        return iArr[1];
    }

    public final int k() {
        if (this.g0 == 8) {
            return 0;
        }
        return this.V;
    }

    public final A4 l(int i) {
        C0239m4 c0239m4;
        C0239m4 c0239m42;
        if (i == 0) {
            C0239m4 c0239m43 = this.K;
            C0239m4 c0239m44 = c0239m43.f;
            if (c0239m44 != null && c0239m44.f == c0239m43) {
                return c0239m44.d;
            }
            return null;
        }
        if (i == 1 && (c0239m42 = (c0239m4 = this.L).f) != null && c0239m42.f == c0239m4) {
            return c0239m42.d;
        }
        return null;
    }

    public final A4 m(int i) {
        C0239m4 c0239m4;
        C0239m4 c0239m42;
        if (i == 0) {
            C0239m4 c0239m43 = this.I;
            C0239m4 c0239m44 = c0239m43.f;
            if (c0239m44 != null && c0239m44.f == c0239m43) {
                return c0239m44.d;
            }
            return null;
        }
        if (i == 1 && (c0239m42 = (c0239m4 = this.J).f) != null && c0239m42.f == c0239m4) {
            return c0239m42.d;
        }
        return null;
    }

    public void n(StringBuilder sb) {
        sb.append("  " + this.j + ":{\n");
        StringBuilder sb2 = new StringBuilder("    actualWidth:");
        sb2.append(this.U);
        sb.append(sb2.toString());
        sb.append("\n");
        sb.append("    actualHeight:" + this.V);
        sb.append("\n");
        sb.append("    actualLeft:" + this.Y);
        sb.append("\n");
        sb.append("    actualTop:" + this.Z);
        sb.append("\n");
        p(sb, "left", this.I);
        p(sb, "top", this.J);
        p(sb, "right", this.K);
        p(sb, "bottom", this.L);
        p(sb, "baseline", this.M);
        p(sb, "centerX", this.N);
        p(sb, "centerY", this.O);
        int i = this.U;
        int i2 = this.b0;
        int[] iArr = this.C;
        int i3 = iArr[0];
        int i4 = this.u;
        int i5 = this.r;
        float f = this.w;
        int[] iArr2 = this.p0;
        int i6 = iArr2[0];
        float[] fArr = this.k0;
        float f2 = fArr[0];
        o(sb, "    width", i, i2, i3, i4, i5, f, i6);
        int i7 = this.V;
        int i8 = this.c0;
        int i9 = iArr[1];
        int i10 = this.f14x;
        int i11 = this.s;
        float f3 = this.z;
        int i12 = iArr2[1];
        float f4 = fArr[1];
        o(sb, "    height", i7, i8, i9, i10, i11, f3, i12);
        float f5 = this.W;
        int i13 = this.X;
        if (f5 != 0.0f) {
            sb.append("    dimensionRatio");
            sb.append(" :  [");
            sb.append(f5);
            sb.append(",");
            sb.append(i13);
            sb.append(BuildConfig.FLAVOR);
            sb.append("],\n");
        }
        H(sb, "    horizontalBias", this.d0, 0.5f);
        H(sb, "    verticalBias", this.e0, 0.5f);
        G(this.i0, 0, "    horizontalChainStyle", sb);
        G(this.j0, 0, "    verticalChainStyle", sb);
        sb.append("  }");
    }

    public final int q() {
        if (this.g0 == 8) {
            return 0;
        }
        return this.U;
    }

    public final int r() {
        A4 a4 = this.T;
        if (a4 != null && (a4 instanceof B4)) {
            return ((B4) a4).x0 + this.Y;
        }
        return this.Y;
    }

    public final int s() {
        A4 a4 = this.T;
        if (a4 != null && (a4 instanceof B4)) {
            return ((B4) a4).y0 + this.Z;
        }
        return this.Z;
    }

    public final boolean t(int i) {
        int i2;
        int i3;
        int i4;
        int i5;
        int i6;
        if (i == 0) {
            if (this.I.f != null) {
                i5 = 1;
            } else {
                i5 = 0;
            }
            if (this.K.f != null) {
                i6 = 1;
            } else {
                i6 = 0;
            }
            if (i5 + i6 >= 2) {
                return false;
            }
            return true;
        }
        if (this.J.f != null) {
            i2 = 1;
        } else {
            i2 = 0;
        }
        if (this.L.f != null) {
            i3 = 1;
        } else {
            i3 = 0;
        }
        int i7 = i2 + i3;
        if (this.M.f != null) {
            i4 = 1;
        } else {
            i4 = 0;
        }
        if (i7 + i4 >= 2) {
            return false;
        }
        return true;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        String str = BuildConfig.FLAVOR;
        sb.append(BuildConfig.FLAVOR);
        if (this.h0 != null) {
            str = "id: " + this.h0 + " ";
        }
        sb.append(str);
        sb.append("(");
        sb.append(this.Y);
        sb.append(", ");
        sb.append(this.Z);
        sb.append(") - (");
        sb.append(this.U);
        sb.append(" x ");
        sb.append(this.V);
        sb.append(")");
        return sb.toString();
    }

    public final boolean u(int i, int i2) {
        C0239m4 c0239m4;
        C0239m4 c0239m42;
        C0239m4 c0239m43;
        C0239m4 c0239m44;
        if (i == 0) {
            C0239m4 c0239m45 = this.I;
            C0239m4 c0239m46 = c0239m45.f;
            if (c0239m46 != null && c0239m46.c && (c0239m44 = (c0239m43 = this.K).f) != null && c0239m44.c) {
                if ((c0239m44.d() - c0239m43.e()) - (c0239m45.e() + c0239m45.f.d()) >= i2) {
                    return true;
                }
                return false;
            }
        } else {
            C0239m4 c0239m47 = this.J;
            C0239m4 c0239m48 = c0239m47.f;
            if (c0239m48 != null && c0239m48.c && (c0239m42 = (c0239m4 = this.L).f) != null && c0239m42.c) {
                if ((c0239m42.d() - c0239m4.e()) - (c0239m47.e() + c0239m47.f.d()) >= i2) {
                    return true;
                }
                return false;
            }
        }
        return false;
    }

    public final void v(int i, int i2, int i3, int i4, A4 a4) {
        i(i).b(a4.i(i2), i3, i4, true);
    }

    public final boolean w(int i) {
        C0239m4 c0239m4;
        C0239m4 c0239m42;
        int i2 = i * 2;
        C0239m4[] c0239m4Arr = this.Q;
        C0239m4 c0239m43 = c0239m4Arr[i2];
        C0239m4 c0239m44 = c0239m43.f;
        if (c0239m44 != null && c0239m44.f != c0239m43 && (c0239m42 = (c0239m4 = c0239m4Arr[i2 + 1]).f) != null && c0239m42.f == c0239m4) {
            return true;
        }
        return false;
    }

    public final boolean x() {
        C0239m4 c0239m4 = this.I;
        C0239m4 c0239m42 = c0239m4.f;
        if (c0239m42 == null || c0239m42.f != c0239m4) {
            C0239m4 c0239m43 = this.K;
            C0239m4 c0239m44 = c0239m43.f;
            if (c0239m44 != null && c0239m44.f == c0239m43) {
                return true;
            }
            return false;
        }
        return true;
    }

    public final boolean y() {
        C0239m4 c0239m4 = this.J;
        C0239m4 c0239m42 = c0239m4.f;
        if (c0239m42 == null || c0239m42.f != c0239m4) {
            C0239m4 c0239m43 = this.L;
            C0239m4 c0239m44 = c0239m43.f;
            if (c0239m44 != null && c0239m44.f == c0239m43) {
                return true;
            }
            return false;
        }
        return true;
    }

    public final boolean z() {
        if (this.g && this.g0 != 8) {
            return true;
        }
        return false;
    }
}
