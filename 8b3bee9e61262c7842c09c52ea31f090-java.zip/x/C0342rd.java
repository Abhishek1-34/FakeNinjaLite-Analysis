package x;

import android.database.Observable;

/* renamed from: x.rd, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0342rd extends Observable {
    public final boolean a() {
        return !((Observable) this).mObservers.isEmpty();
    }
}
