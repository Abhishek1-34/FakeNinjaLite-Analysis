package x;

import android.content.ClipData;
import android.content.ClipDescription;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;

/* renamed from: x.b6, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final /* synthetic */ class C0027b6 {
    public final /* synthetic */ Object a;

    public /* synthetic */ C0027b6(Object obj) {
        this.a = obj;
    }

    public boolean a(B b, int i, Bundle bundle) {
        F4 f4;
        int i2 = Build.VERSION.SDK_INT;
        if (i2 >= 25 && (i & 1) != 0) {
            try {
                ((A9) b.b).b();
                Parcelable parcelable = (Parcelable) ((A9) b.b).d();
                if (bundle == null) {
                    bundle = new Bundle();
                } else {
                    bundle = new Bundle(bundle);
                }
                bundle.putParcelable("androidx.core.view.extra.INPUT_CONTENT_INFO", parcelable);
            } catch (Exception e) {
                Log.w("InputConnectionCompat", "Can't insert content from IME; requestPermission() failed", e);
                return false;
            }
        }
        ClipDescription a = ((A9) b.b).a();
        A9 a9 = (A9) b.b;
        ClipData clipData = new ClipData(a, new ClipData.Item(a9.e()));
        if (i2 >= 31) {
            f4 = new B(clipData, 2);
        } else {
            G4 g4 = new G4();
            g4.b = clipData;
            g4.c = 2;
            f4 = g4;
        }
        f4.d(a9.c());
        f4.a(bundle);
        if (AbstractC0309ph.h((C0463y1) this.a, f4.k()) != null) {
            return false;
        }
        return true;
    }
}
