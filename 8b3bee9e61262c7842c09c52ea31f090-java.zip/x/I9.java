package x;

/* loaded from: classes.dex */
public interface I9 {
}
