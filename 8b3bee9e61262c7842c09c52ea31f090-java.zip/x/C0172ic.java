package x;

import android.window.BackEvent;
import android.window.OnBackAnimationCallback;

/* renamed from: x.ic, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0172ic implements OnBackAnimationCallback {
    public final /* synthetic */ R8 a;
    public final /* synthetic */ R8 b;
    public final /* synthetic */ G8 c;
    public final /* synthetic */ G8 d;

    public C0172ic(R8 r8, R8 r82, G8 g8, G8 g82) {
        this.a = r8;
        this.b = r82;
        this.c = g8;
        this.d = g82;
    }

    public final void onBackCancelled() {
        this.d.a();
    }

    public final void onBackInvoked() {
        this.c.a();
    }

    public final void onBackProgressed(BackEvent backEvent) {
        E9.o(backEvent, "backEvent");
        this.b.b(new K2(backEvent));
    }

    public final void onBackStarted(BackEvent backEvent) {
        E9.o(backEvent, "backEvent");
        this.a.b(new K2(backEvent));
    }
}
