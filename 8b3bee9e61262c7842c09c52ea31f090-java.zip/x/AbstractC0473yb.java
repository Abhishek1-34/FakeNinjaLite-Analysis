package x;

import android.widget.PopupWindow;

/* renamed from: x.yb, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0473yb {
    public static void a(PopupWindow popupWindow, boolean z) {
        popupWindow.setTouchModal(z);
    }
}
