package x;

import android.R;

/* renamed from: x.gd, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0134gd {
    public static final int[] a = {R.attr.color, R.attr.alpha, 16844359, org.conscrypt.R.attr.alpha, org.conscrypt.R.attr.lStar};
    public static final int[] b = {org.conscrypt.R.attr.fontProviderAuthority, org.conscrypt.R.attr.fontProviderCerts, org.conscrypt.R.attr.fontProviderFallbackQuery, org.conscrypt.R.attr.fontProviderFetchStrategy, org.conscrypt.R.attr.fontProviderFetchTimeout, org.conscrypt.R.attr.fontProviderPackage, org.conscrypt.R.attr.fontProviderQuery, org.conscrypt.R.attr.fontProviderSystemFontFamily};
    public static final int[] c = {R.attr.font, R.attr.fontWeight, R.attr.fontStyle, R.attr.ttcIndex, R.attr.fontVariationSettings, org.conscrypt.R.attr.font, org.conscrypt.R.attr.fontStyle, org.conscrypt.R.attr.fontVariationSettings, org.conscrypt.R.attr.fontWeight, org.conscrypt.R.attr.ttcIndex};
    public static final int[] d = {R.attr.startColor, R.attr.endColor, R.attr.type, R.attr.centerX, R.attr.centerY, R.attr.gradientRadius, R.attr.tileMode, R.attr.centerColor, R.attr.startX, R.attr.startY, R.attr.endX, R.attr.endY};
    public static final int[] e = {R.attr.color, R.attr.offset};
}
