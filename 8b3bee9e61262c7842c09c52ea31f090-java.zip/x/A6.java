package x;

import android.text.InputFilter;
import android.text.method.PasswordTransformationMethod;
import android.text.method.TransformationMethod;
import android.util.SparseArray;
import android.widget.TextView;

/* loaded from: classes.dex */
public final class A6 extends E9 {
    public final TextView s;
    public final C0430w6 t;
    public boolean u = true;

    public A6(TextView textView) {
        this.s = textView;
        this.t = new C0430w6(textView);
    }

    @Override // x.E9
    public final InputFilter[] F(InputFilter[] inputFilterArr) {
        if (!this.u) {
            SparseArray sparseArray = new SparseArray(1);
            for (int i = 0; i < inputFilterArr.length; i++) {
                InputFilter inputFilter = inputFilterArr[i];
                if (inputFilter instanceof C0430w6) {
                    sparseArray.put(i, inputFilter);
                }
            }
            if (sparseArray.size() != 0) {
                int length = inputFilterArr.length;
                InputFilter[] inputFilterArr2 = new InputFilter[inputFilterArr.length - sparseArray.size()];
                int i2 = 0;
                for (int i3 = 0; i3 < length; i3++) {
                    if (sparseArray.indexOfKey(i3) < 0) {
                        inputFilterArr2[i2] = inputFilterArr[i3];
                        i2++;
                    }
                }
                return inputFilterArr2;
            }
            return inputFilterArr;
        }
        int length2 = inputFilterArr.length;
        int i4 = 0;
        while (true) {
            C0430w6 c0430w6 = this.t;
            if (i4 < length2) {
                if (inputFilterArr[i4] != c0430w6) {
                    i4++;
                } else {
                    return inputFilterArr;
                }
            } else {
                InputFilter[] inputFilterArr3 = new InputFilter[inputFilterArr.length + 1];
                System.arraycopy(inputFilterArr, 0, inputFilterArr3, 0, length2);
                inputFilterArr3[length2] = c0430w6;
                return inputFilterArr3;
            }
        }
    }

    @Override // x.E9
    public final boolean J() {
        return this.u;
    }

    @Override // x.E9
    public final void j0(boolean z) {
        if (z) {
            TextView textView = this.s;
            textView.setTransformationMethod(z0(textView.getTransformationMethod()));
        }
    }

    @Override // x.E9
    public final void k0(boolean z) {
        this.u = z;
        TextView textView = this.s;
        textView.setTransformationMethod(z0(textView.getTransformationMethod()));
        textView.setFilters(F(textView.getFilters()));
    }

    @Override // x.E9
    public final TransformationMethod z0(TransformationMethod transformationMethod) {
        if (this.u) {
            if (!(transformationMethod instanceof E6) && !(transformationMethod instanceof PasswordTransformationMethod)) {
                return new E6(transformationMethod);
            }
            return transformationMethod;
        }
        if (transformationMethod instanceof E6) {
            return ((E6) transformationMethod).a;
        }
        return transformationMethod;
    }
}
