package x;

/* loaded from: classes.dex */
public final class Z9 {
    public T9 a;
    public W9 b;

    public final void a(Y9 y9, S9 s9) {
        T9 a = s9.a();
        T9 t9 = this.a;
        E9.o(t9, "state1");
        if (a.compareTo(t9) < 0) {
            t9 = a;
        }
        this.a = t9;
        this.b.b(y9, s9);
        this.a = a;
    }
}
