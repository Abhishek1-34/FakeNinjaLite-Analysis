package x;

/* loaded from: classes.dex */
public interface Me {
    boolean a();

    void dismiss();

    X5 e();

    void i();
}
