package x;

import java.util.ArrayList;

/* renamed from: x.s9, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0357s9 extends Wh {
    public static final int[] k = new int[2];

    public static void m(int[] iArr, int i, int i2, int i3, int i4, float f, int i5) {
        int i6 = i2 - i;
        int i7 = i4 - i3;
        if (i5 != -1) {
            if (i5 != 0) {
                if (i5 == 1) {
                    iArr[0] = i6;
                    iArr[1] = (int) ((i6 * f) + 0.5f);
                    return;
                }
                return;
            }
            iArr[0] = (int) ((i7 * f) + 0.5f);
            iArr[1] = i7;
            return;
        }
        int i8 = (int) ((i7 * f) + 0.5f);
        int i9 = (int) ((i6 / f) + 0.5f);
        if (i8 <= i6) {
            iArr[0] = i8;
            iArr[1] = i7;
        } else if (i9 <= i7) {
            iArr[0] = i6;
            iArr[1] = i9;
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:107:0x0244, code lost:
    
        if (r3 != 1) goto L128;
     */
    @Override // x.InterfaceC0448x5
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void a(InterfaceC0448x5 interfaceC0448x5) {
        boolean z;
        boolean z2;
        boolean z3;
        boolean z4;
        float f;
        float f2;
        float f3;
        int i;
        if (Ue.j(this.j) != 3) {
            K5 k5 = this.e;
            boolean z5 = k5.j;
            C0486z5 c0486z5 = this.h;
            C0486z5 c0486z52 = this.i;
            if (!z5 && this.d == 3) {
                A4 a4 = this.b;
                int i2 = a4.r;
                if (i2 != 2) {
                    if (i2 == 3) {
                        int i3 = a4.s;
                        if (i3 != 0 && i3 != 3) {
                            int i4 = a4.X;
                            if (i4 != -1) {
                                if (i4 != 0) {
                                    if (i4 != 1) {
                                        i = 0;
                                        k5.d(i);
                                    } else {
                                        f = a4.e.e.g;
                                        f2 = a4.W;
                                    }
                                } else {
                                    f3 = a4.e.e.g / a4.W;
                                    i = (int) (f3 + 0.5f);
                                    k5.d(i);
                                }
                            } else {
                                f = a4.e.e.g;
                                f2 = a4.W;
                            }
                            f3 = f * f2;
                            i = (int) (f3 + 0.5f);
                            k5.d(i);
                        } else {
                            C0038bh c0038bh = a4.e;
                            C0486z5 c0486z53 = c0038bh.h;
                            C0486z5 c0486z54 = c0038bh.i;
                            if (a4.I.f != null) {
                                z = true;
                            } else {
                                z = false;
                            }
                            if (a4.J.f != null) {
                                z2 = true;
                            } else {
                                z2 = false;
                            }
                            if (a4.K.f != null) {
                                z3 = true;
                            } else {
                                z3 = false;
                            }
                            if (a4.L.f != null) {
                                z4 = true;
                            } else {
                                z4 = false;
                            }
                            int i5 = a4.X;
                            if (z && z2 && z3 && z4) {
                                float f4 = a4.W;
                                boolean z6 = c0486z53.j;
                                int[] iArr = k;
                                if (z6 && c0486z54.j) {
                                    if (c0486z5.c && c0486z52.c) {
                                        m(iArr, ((C0486z5) c0486z5.l.get(0)).g + c0486z5.f, ((C0486z5) c0486z52.l.get(0)).g - c0486z52.f, c0486z53.g + c0486z53.f, c0486z54.g - c0486z54.f, f4, i5);
                                        k5.d(iArr[0]);
                                        this.b.e.e.d(iArr[1]);
                                        return;
                                    }
                                    return;
                                }
                                boolean z7 = c0486z5.j;
                                ArrayList arrayList = c0486z53.l;
                                if (z7 && c0486z52.j) {
                                    if (c0486z53.c && c0486z54.c) {
                                        m(iArr, c0486z5.g + c0486z5.f, c0486z52.g - c0486z52.f, ((C0486z5) arrayList.get(0)).g + c0486z53.f, ((C0486z5) c0486z54.l.get(0)).g - c0486z54.f, f4, i5);
                                        k5.d(iArr[0]);
                                        this.b.e.e.d(iArr[1]);
                                    } else {
                                        return;
                                    }
                                }
                                if (c0486z5.c && c0486z52.c && c0486z53.c && c0486z54.c) {
                                    m(iArr, ((C0486z5) c0486z5.l.get(0)).g + c0486z5.f, ((C0486z5) c0486z52.l.get(0)).g - c0486z52.f, ((C0486z5) arrayList.get(0)).g + c0486z53.f, ((C0486z5) c0486z54.l.get(0)).g - c0486z54.f, f4, i5);
                                    k5.d(iArr[0]);
                                    this.b.e.e.d(iArr[1]);
                                } else {
                                    return;
                                }
                            } else if (z && z3) {
                                if (c0486z5.c && c0486z52.c) {
                                    float f5 = a4.W;
                                    int i6 = ((C0486z5) c0486z5.l.get(0)).g + c0486z5.f;
                                    int i7 = ((C0486z5) c0486z52.l.get(0)).g - c0486z52.f;
                                    if (i5 != -1 && i5 != 0) {
                                        if (i5 == 1) {
                                            int g = g(i7 - i6, 0);
                                            int i8 = (int) ((g / f5) + 0.5f);
                                            int g2 = g(i8, 1);
                                            if (i8 != g2) {
                                                g = (int) ((g2 * f5) + 0.5f);
                                            }
                                            k5.d(g);
                                            this.b.e.e.d(g2);
                                        }
                                    } else {
                                        int g3 = g(i7 - i6, 0);
                                        int i9 = (int) ((g3 * f5) + 0.5f);
                                        int g4 = g(i9, 1);
                                        if (i9 != g4) {
                                            g3 = (int) ((g4 / f5) + 0.5f);
                                        }
                                        k5.d(g3);
                                        this.b.e.e.d(g4);
                                    }
                                } else {
                                    return;
                                }
                            } else if (z2 && z4) {
                                if (c0486z53.c && c0486z54.c) {
                                    float f6 = a4.W;
                                    int i10 = ((C0486z5) c0486z53.l.get(0)).g + c0486z53.f;
                                    int i11 = ((C0486z5) c0486z54.l.get(0)).g - c0486z54.f;
                                    if (i5 != -1) {
                                        if (i5 == 0) {
                                            int g5 = g(i11 - i10, 1);
                                            int i12 = (int) ((g5 * f6) + 0.5f);
                                            int g6 = g(i12, 0);
                                            if (i12 != g6) {
                                                g5 = (int) ((g6 / f6) + 0.5f);
                                            }
                                            k5.d(g6);
                                            this.b.e.e.d(g5);
                                        }
                                    }
                                    int g7 = g(i11 - i10, 1);
                                    int i13 = (int) ((g7 / f6) + 0.5f);
                                    int g8 = g(i13, 0);
                                    if (i13 != g8) {
                                        g7 = (int) ((g8 * f6) + 0.5f);
                                    }
                                    k5.d(g8);
                                    this.b.e.e.d(g7);
                                } else {
                                    return;
                                }
                            }
                        }
                    }
                } else {
                    A4 a42 = a4.T;
                    if (a42 != null) {
                        if (a42.d.e.j) {
                            k5.d((int) ((r3.g * a4.w) + 0.5f));
                        }
                    }
                }
            }
            if (c0486z5.c && c0486z52.c) {
                if (c0486z5.j && c0486z52.j && k5.j) {
                    return;
                }
                if (!k5.j && this.d == 3) {
                    A4 a43 = this.b;
                    if (a43.r == 0 && !a43.x()) {
                        C0486z5 c0486z55 = (C0486z5) c0486z5.l.get(0);
                        C0486z5 c0486z56 = (C0486z5) c0486z52.l.get(0);
                        int i14 = c0486z55.g + c0486z5.f;
                        int i15 = c0486z56.g + c0486z52.f;
                        c0486z5.d(i14);
                        c0486z52.d(i15);
                        k5.d(i15 - i14);
                        return;
                    }
                }
                if (!k5.j && this.d == 3 && this.a == 1 && c0486z5.l.size() > 0 && c0486z52.l.size() > 0) {
                    C0486z5 c0486z57 = (C0486z5) c0486z5.l.get(0);
                    int min = Math.min((((C0486z5) c0486z52.l.get(0)).g + c0486z52.f) - (c0486z57.g + c0486z5.f), k5.m);
                    A4 a44 = this.b;
                    int i16 = a44.v;
                    int max = Math.max(a44.u, min);
                    if (i16 > 0) {
                        max = Math.min(i16, max);
                    }
                    k5.d(max);
                }
                if (!k5.j) {
                    return;
                }
                C0486z5 c0486z58 = (C0486z5) c0486z5.l.get(0);
                C0486z5 c0486z59 = (C0486z5) c0486z52.l.get(0);
                int i17 = c0486z58.g;
                int i18 = c0486z5.f + i17;
                int i19 = c0486z59.g;
                int i20 = c0486z52.f + i19;
                float f7 = this.b.d0;
                if (c0486z58 == c0486z59) {
                    f7 = 0.5f;
                } else {
                    i17 = i18;
                    i19 = i20;
                }
                c0486z5.d((int) ((((i19 - i17) - k5.g) * f7) + i17 + 0.5f));
                c0486z52.d(c0486z5.g + k5.g);
                return;
            }
            return;
        }
        A4 a45 = this.b;
        l(a45.I, a45.K, 0);
    }

    @Override // x.Wh
    public final void d() {
        A4 a4;
        A4 a42;
        int i;
        A4 a43;
        A4 a44;
        int i2;
        A4 a45 = this.b;
        boolean z = a45.a;
        K5 k5 = this.e;
        if (z) {
            k5.d(a45.q());
        }
        boolean z2 = k5.j;
        C0486z5 c0486z5 = this.i;
        C0486z5 c0486z52 = this.h;
        if (!z2) {
            A4 a46 = this.b;
            int i3 = a46.p0[0];
            this.d = i3;
            if (i3 != 3) {
                if (i3 == 4 && (a44 = a46.T) != null && ((i2 = a44.p0[0]) == 1 || i2 == 4)) {
                    int q = (a44.q() - this.b.I.e()) - this.b.K.e();
                    Wh.b(c0486z52, a44.d.h, this.b.I.e());
                    Wh.b(c0486z5, a44.d.i, -this.b.K.e());
                    k5.d(q);
                    return;
                }
                if (i3 == 1) {
                    k5.d(a46.q());
                }
            }
        } else if (this.d == 4 && (a42 = (a4 = this.b).T) != null && ((i = a42.p0[0]) == 1 || i == 4)) {
            Wh.b(c0486z52, a42.d.h, a4.I.e());
            Wh.b(c0486z5, a42.d.i, -this.b.K.e());
            return;
        }
        if (k5.j) {
            A4 a47 = this.b;
            if (a47.a) {
                C0239m4[] c0239m4Arr = a47.Q;
                C0239m4 c0239m4 = c0239m4Arr[0];
                C0239m4 c0239m42 = c0239m4.f;
                if (c0239m42 != null && c0239m4Arr[1].f != null) {
                    if (a47.x()) {
                        c0486z52.f = this.b.Q[0].e();
                        c0486z5.f = -this.b.Q[1].e();
                        return;
                    }
                    C0486z5 h = Wh.h(this.b.Q[0]);
                    if (h != null) {
                        Wh.b(c0486z52, h, this.b.Q[0].e());
                    }
                    C0486z5 h2 = Wh.h(this.b.Q[1]);
                    if (h2 != null) {
                        Wh.b(c0486z5, h2, -this.b.Q[1].e());
                    }
                    c0486z52.b = true;
                    c0486z5.b = true;
                    return;
                }
                if (c0239m42 != null) {
                    C0486z5 h3 = Wh.h(c0239m4);
                    if (h3 != null) {
                        Wh.b(c0486z52, h3, this.b.Q[0].e());
                        Wh.b(c0486z5, c0486z52, k5.g);
                        return;
                    }
                    return;
                }
                C0239m4 c0239m43 = c0239m4Arr[1];
                if (c0239m43.f != null) {
                    C0486z5 h4 = Wh.h(c0239m43);
                    if (h4 != null) {
                        Wh.b(c0486z5, h4, -this.b.Q[1].e());
                        Wh.b(c0486z52, c0486z5, -k5.g);
                        return;
                    }
                    return;
                }
                if (!(a47 instanceof AbstractC0338r9) && a47.T != null && a47.i(7).f == null) {
                    A4 a48 = this.b;
                    Wh.b(c0486z52, a48.T.d.h, a48.r());
                    Wh.b(c0486z5, c0486z52, k5.g);
                    return;
                }
                return;
            }
        }
        if (this.d == 3) {
            A4 a49 = this.b;
            int i4 = a49.r;
            if (i4 != 2) {
                if (i4 == 3) {
                    if (a49.s == 3) {
                        c0486z52.a = this;
                        c0486z5.a = this;
                        C0038bh c0038bh = a49.e;
                        c0038bh.h.a = this;
                        c0038bh.i.a = this;
                        k5.a = this;
                        if (a49.y()) {
                            k5.l.add(this.b.e.e);
                            this.b.e.e.k.add(k5);
                            C0038bh c0038bh2 = this.b.e;
                            c0038bh2.e.a = this;
                            k5.l.add(c0038bh2.h);
                            k5.l.add(this.b.e.i);
                            this.b.e.h.k.add(k5);
                            this.b.e.i.k.add(k5);
                        } else if (this.b.x()) {
                            this.b.e.e.l.add(k5);
                            k5.k.add(this.b.e.e);
                        } else {
                            this.b.e.e.l.add(k5);
                        }
                    } else {
                        K5 k52 = a49.e.e;
                        k5.l.add(k52);
                        k52.k.add(k5);
                        this.b.e.h.k.add(k5);
                        this.b.e.i.k.add(k5);
                        k5.b = true;
                        k5.k.add(c0486z52);
                        k5.k.add(c0486z5);
                        c0486z52.l.add(k5);
                        c0486z5.l.add(k5);
                    }
                }
            } else {
                A4 a410 = a49.T;
                if (a410 != null) {
                    K5 k53 = a410.e.e;
                    k5.l.add(k53);
                    k53.k.add(k5);
                    k5.b = true;
                    k5.k.add(c0486z52);
                    k5.k.add(c0486z5);
                }
            }
        }
        A4 a411 = this.b;
        C0239m4[] c0239m4Arr2 = a411.Q;
        C0239m4 c0239m44 = c0239m4Arr2[0];
        C0239m4 c0239m45 = c0239m44.f;
        if (c0239m45 != null && c0239m4Arr2[1].f != null) {
            if (a411.x()) {
                c0486z52.f = this.b.Q[0].e();
                c0486z5.f = -this.b.Q[1].e();
                return;
            }
            C0486z5 h5 = Wh.h(this.b.Q[0]);
            C0486z5 h6 = Wh.h(this.b.Q[1]);
            if (h5 != null) {
                h5.b(this);
            }
            if (h6 != null) {
                h6.b(this);
            }
            this.j = 4;
            return;
        }
        if (c0239m45 != null) {
            C0486z5 h7 = Wh.h(c0239m44);
            if (h7 != null) {
                Wh.b(c0486z52, h7, this.b.Q[0].e());
                c(c0486z5, c0486z52, 1, k5);
                return;
            }
            return;
        }
        C0239m4 c0239m46 = c0239m4Arr2[1];
        if (c0239m46.f != null) {
            C0486z5 h8 = Wh.h(c0239m46);
            if (h8 != null) {
                Wh.b(c0486z5, h8, -this.b.Q[1].e());
                c(c0486z52, c0486z5, -1, k5);
                return;
            }
            return;
        }
        if (!(a411 instanceof AbstractC0338r9) && (a43 = a411.T) != null) {
            Wh.b(c0486z52, a43.d.h, a411.r());
            c(c0486z5, c0486z52, 1, k5);
        }
    }

    @Override // x.Wh
    public final void e() {
        C0486z5 c0486z5 = this.h;
        if (c0486z5.j) {
            this.b.Y = c0486z5.g;
        }
    }

    @Override // x.Wh
    public final void f() {
        this.c = null;
        this.h.c();
        this.i.c();
        this.e.c();
        this.g = false;
    }

    @Override // x.Wh
    public final boolean k() {
        if (this.d != 3 || this.b.r == 0) {
            return true;
        }
        return false;
    }

    public final void n() {
        this.g = false;
        C0486z5 c0486z5 = this.h;
        c0486z5.c();
        c0486z5.j = false;
        C0486z5 c0486z52 = this.i;
        c0486z52.c();
        c0486z52.j = false;
        this.e.j = false;
    }

    public final String toString() {
        return "HorizontalRun " + this.b.h0;
    }
}
