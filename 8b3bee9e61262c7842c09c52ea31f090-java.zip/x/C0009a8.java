package x;

/* renamed from: x.a8, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0009a8 {
    public final /* synthetic */ AbstractComponentCallbacksC0089e8 a;

    public C0009a8(AbstractComponentCallbacksC0089e8 abstractComponentCallbacksC0089e8) {
        this.a = abstractComponentCallbacksC0089e8;
    }

    public final void a() {
        AbstractComponentCallbacksC0089e8 abstractComponentCallbacksC0089e8 = this.a;
        abstractComponentCallbacksC0089e8.P.a();
        AbstractC0124g3.m(abstractComponentCallbacksC0089e8);
    }
}
