package x;

import androidx.core.widget.NestedScrollView;

/* loaded from: classes.dex */
public abstract class Rb {
    public static void a(NestedScrollView nestedScrollView, float f) {
        try {
            nestedScrollView.setFrameContentVelocity(f);
        } catch (LinkageError unused) {
        }
    }
}
