package x;

import android.view.View;

/* renamed from: x.jh, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0195jh {
    public static int a(View view) {
        return view.getImportantForAutofill();
    }

    public static void b(View view, int i) {
        view.setImportantForAutofill(i);
    }
}
