package x;

import android.content.res.TypedArray;
import android.util.SparseArray;

/* loaded from: classes.dex */
public final class M6 {
    public final SparseArray a = new SparseArray();
    public final N6 b;
    public final int c;
    public final int d;

    public M6(N6 n6, C0294p2 c0294p2) {
        this.b = n6;
        TypedArray typedArray = (TypedArray) c0294p2.b;
        this.c = typedArray.getResourceId(28, 0);
        this.d = typedArray.getResourceId(52, 0);
    }
}
