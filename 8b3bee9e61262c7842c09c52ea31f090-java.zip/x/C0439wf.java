package x;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.os.Build;
import android.util.Log;
import android.view.InflateException;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;

/* renamed from: x.wf, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0439wf {
    public CharSequence A;
    public CharSequence B;
    public final /* synthetic */ C0458xf E;
    public final Menu a;
    public boolean h;
    public int i;
    public int j;
    public CharSequence k;
    public CharSequence l;
    public int m;
    public char n;
    public int o;
    public char p;
    public int q;
    public int r;
    public boolean s;
    public boolean t;
    public boolean u;
    public int v;
    public int w;

    /* renamed from: x, reason: collision with root package name */
    public String f37x;
    public String y;
    public ActionProviderVisibilityListenerC0322qb z;
    public ColorStateList C = null;
    public PorterDuff.Mode D = null;
    public int b = 0;
    public int c = 0;
    public int d = 0;
    public int e = 0;
    public boolean f = true;
    public boolean g = true;

    public C0439wf(C0458xf c0458xf, Menu menu) {
        this.E = c0458xf;
        this.a = menu;
    }

    public final Object a(String str, Class[] clsArr, Object[] objArr) {
        try {
            Constructor<?> constructor = Class.forName(str, false, this.E.c.getClassLoader()).getConstructor(clsArr);
            constructor.setAccessible(true);
            return constructor.newInstance(objArr);
        } catch (Exception e) {
            Log.w("SupportMenuInflater", "Cannot instantiate class: " + str, e);
            return null;
        }
    }

    public final void b(MenuItem menuItem) {
        boolean z;
        MenuItem enabled = menuItem.setChecked(this.s).setVisible(this.t).setEnabled(this.u);
        boolean z2 = false;
        if (this.r >= 1) {
            z = true;
        } else {
            z = false;
        }
        enabled.setCheckable(z).setTitleCondensed(this.l).setIcon(this.m);
        int i = this.v;
        if (i >= 0) {
            menuItem.setShowAsAction(i);
        }
        String str = this.y;
        C0458xf c0458xf = this.E;
        if (str != null) {
            if (!c0458xf.c.isRestricted()) {
                if (c0458xf.d == null) {
                    c0458xf.d = C0458xf.a(c0458xf.c);
                }
                Object obj = c0458xf.d;
                String str2 = this.y;
                MenuItemOnMenuItemClickListenerC0420vf menuItemOnMenuItemClickListenerC0420vf = new MenuItemOnMenuItemClickListenerC0420vf();
                menuItemOnMenuItemClickListenerC0420vf.b = obj;
                Class<?> cls = obj.getClass();
                try {
                    menuItemOnMenuItemClickListenerC0420vf.c = cls.getMethod(str2, MenuItemOnMenuItemClickListenerC0420vf.d);
                    menuItem.setOnMenuItemClickListener(menuItemOnMenuItemClickListenerC0420vf);
                } catch (Exception e) {
                    InflateException inflateException = new InflateException("Couldn't resolve menu item onClick handler " + str2 + " in class " + cls.getName());
                    inflateException.initCause(e);
                    throw inflateException;
                }
            } else {
                throw new IllegalStateException("The android:onClick attribute cannot be used within a restricted context");
            }
        }
        if (this.r >= 2) {
            if (menuItem instanceof C0303pb) {
                C0303pb c0303pb = (C0303pb) menuItem;
                c0303pb.f29x = (c0303pb.f29x & (-5)) | 4;
            } else if (menuItem instanceof MenuItemC0378tb) {
                MenuItemC0378tb menuItemC0378tb = (MenuItemC0378tb) menuItem;
                try {
                    Method method = menuItemC0378tb.d;
                    InterfaceMenuItemC0477yf interfaceMenuItemC0477yf = menuItemC0378tb.c;
                    if (method == null) {
                        menuItemC0378tb.d = interfaceMenuItemC0477yf.getClass().getDeclaredMethod("setExclusiveCheckable", Boolean.TYPE);
                    }
                    menuItemC0378tb.d.invoke(interfaceMenuItemC0477yf, Boolean.TRUE);
                } catch (Exception e2) {
                    Log.w("MenuItemWrapper", "Error while calling setExclusiveCheckable", e2);
                }
            }
        }
        String str3 = this.f37x;
        if (str3 != null) {
            menuItem.setActionView((View) a(str3, C0458xf.e, c0458xf.a));
            z2 = true;
        }
        int i2 = this.w;
        if (i2 > 0) {
            if (!z2) {
                menuItem.setActionView(i2);
            } else {
                Log.w("SupportMenuInflater", "Ignoring attribute 'itemActionViewLayout'. Action view already specified.");
            }
        }
        ActionProviderVisibilityListenerC0322qb actionProviderVisibilityListenerC0322qb = this.z;
        if (actionProviderVisibilityListenerC0322qb != null) {
            if (menuItem instanceof InterfaceMenuItemC0477yf) {
                ((InterfaceMenuItemC0477yf) menuItem).b(actionProviderVisibilityListenerC0322qb);
            } else {
                Log.w("MenuItemCompat", "setActionProvider: item does not implement SupportMenuItem; ignoring");
            }
        }
        CharSequence charSequence = this.A;
        boolean z3 = menuItem instanceof InterfaceMenuItemC0477yf;
        if (z3) {
            ((InterfaceMenuItemC0477yf) menuItem).setContentDescription(charSequence);
        } else if (Build.VERSION.SDK_INT >= 26) {
            K4.i(menuItem, charSequence);
        }
        CharSequence charSequence2 = this.B;
        if (z3) {
            ((InterfaceMenuItemC0477yf) menuItem).setTooltipText(charSequence2);
        } else if (Build.VERSION.SDK_INT >= 26) {
            K4.q(menuItem, charSequence2);
        }
        char c = this.n;
        int i3 = this.o;
        if (z3) {
            ((InterfaceMenuItemC0477yf) menuItem).setAlphabeticShortcut(c, i3);
        } else if (Build.VERSION.SDK_INT >= 26) {
            K4.g(menuItem, c, i3);
        }
        char c2 = this.p;
        int i4 = this.q;
        if (z3) {
            ((InterfaceMenuItemC0477yf) menuItem).setNumericShortcut(c2, i4);
        } else if (Build.VERSION.SDK_INT >= 26) {
            K4.m(menuItem, c2, i4);
        }
        PorterDuff.Mode mode = this.D;
        if (mode != null) {
            if (z3) {
                ((InterfaceMenuItemC0477yf) menuItem).setIconTintMode(mode);
            } else if (Build.VERSION.SDK_INT >= 26) {
                K4.l(menuItem, mode);
            }
        }
        ColorStateList colorStateList = this.C;
        if (colorStateList != null) {
            if (z3) {
                ((InterfaceMenuItemC0477yf) menuItem).setIconTintList(colorStateList);
            } else if (Build.VERSION.SDK_INT >= 26) {
                K4.k(menuItem, colorStateList);
            }
        }
    }
}
