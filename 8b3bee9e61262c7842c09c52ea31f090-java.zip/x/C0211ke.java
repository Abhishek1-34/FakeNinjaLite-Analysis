package x;

import java.util.Iterator;

/* renamed from: x.ke, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0211ke extends AbstractC0268ne implements Iterator {
    public C0230le a;
    public C0230le b;
    public final /* synthetic */ int c;

    public C0211ke(C0230le c0230le, C0230le c0230le2, int i) {
        this.c = i;
        this.a = c0230le2;
        this.b = c0230le;
    }

    @Override // x.AbstractC0268ne
    public final void a(C0230le c0230le) {
        C0230le c0230le2;
        C0230le c0230le3 = null;
        if (this.a == c0230le && c0230le == this.b) {
            this.b = null;
            this.a = null;
        }
        C0230le c0230le4 = this.a;
        if (c0230le4 == c0230le) {
            switch (this.c) {
                case 0:
                    c0230le2 = c0230le4.d;
                    break;
                default:
                    c0230le2 = c0230le4.c;
                    break;
            }
            this.a = c0230le2;
        }
        C0230le c0230le5 = this.b;
        if (c0230le5 == c0230le) {
            C0230le c0230le6 = this.a;
            if (c0230le5 != c0230le6 && c0230le6 != null) {
                c0230le3 = b(c0230le5);
            }
            this.b = c0230le3;
        }
    }

    public final C0230le b(C0230le c0230le) {
        switch (this.c) {
            case 0:
                return c0230le.c;
            default:
                return c0230le.d;
        }
    }

    @Override // java.util.Iterator
    public final boolean hasNext() {
        if (this.b != null) {
            return true;
        }
        return false;
    }

    @Override // java.util.Iterator
    public final Object next() {
        C0230le c0230le;
        C0230le c0230le2 = this.b;
        C0230le c0230le3 = this.a;
        if (c0230le2 != c0230le3 && c0230le3 != null) {
            c0230le = b(c0230le2);
        } else {
            c0230le = null;
        }
        this.b = c0230le;
        return c0230le2;
    }
}
