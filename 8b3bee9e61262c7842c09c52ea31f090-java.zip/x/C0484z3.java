package x;

import android.graphics.PointF;
import android.graphics.Rect;
import android.util.Property;
import android.view.View;
import androidx.appcompat.widget.SwitchCompat;
import org.conscrypt.ct.CTConstants;

/* renamed from: x.z3, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0484z3 extends Property {
    public final /* synthetic */ int a;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ C0484z3(Class cls, String str, int i) {
        super(cls, str);
        this.a = i;
    }

    @Override // android.util.Property
    public final Object get(Object obj) {
        switch (this.a) {
            case 0:
                return null;
            case 1:
                return null;
            case 2:
                return null;
            case CTConstants.CERTIFICATE_LENGTH_BYTES /* 3 */:
                return null;
            case 4:
                return null;
            case 5:
                return Float.valueOf(((SwitchCompat) obj).z);
            case 6:
                return Float.valueOf(Hh.a.C((View) obj));
            default:
                return ((View) obj).getClipBounds();
        }
    }

    @Override // android.util.Property
    public final void set(Object obj, Object obj2) {
        switch (this.a) {
            case 0:
                C3 c3 = (C3) obj;
                PointF pointF = (PointF) obj2;
                c3.getClass();
                c3.a = Math.round(pointF.x);
                int round = Math.round(pointF.y);
                c3.b = round;
                int i = c3.f + 1;
                c3.f = i;
                if (i == c3.g) {
                    Hh.a(c3.e, c3.a, round, c3.c, c3.d);
                    c3.f = 0;
                    c3.g = 0;
                    return;
                }
                return;
            case 1:
                C3 c32 = (C3) obj;
                PointF pointF2 = (PointF) obj2;
                c32.getClass();
                c32.c = Math.round(pointF2.x);
                int round2 = Math.round(pointF2.y);
                c32.d = round2;
                int i2 = c32.g + 1;
                c32.g = i2;
                if (c32.f == i2) {
                    Hh.a(c32.e, c32.a, c32.b, c32.c, round2);
                    c32.f = 0;
                    c32.g = 0;
                    return;
                }
                return;
            case 2:
                View view = (View) obj;
                PointF pointF3 = (PointF) obj2;
                Hh.a(view, view.getLeft(), view.getTop(), Math.round(pointF3.x), Math.round(pointF3.y));
                return;
            case CTConstants.CERTIFICATE_LENGTH_BYTES /* 3 */:
                View view2 = (View) obj;
                PointF pointF4 = (PointF) obj2;
                Hh.a(view2, Math.round(pointF4.x), Math.round(pointF4.y), view2.getRight(), view2.getBottom());
                return;
            case 4:
                View view3 = (View) obj;
                PointF pointF5 = (PointF) obj2;
                int round3 = Math.round(pointF5.x);
                int round4 = Math.round(pointF5.y);
                Hh.a(view3, round3, round4, view3.getWidth() + round3, view3.getHeight() + round4);
                return;
            case 5:
                ((SwitchCompat) obj).setThumbPosition(((Float) obj2).floatValue());
                return;
            case 6:
                float floatValue = ((Float) obj2).floatValue();
                Hh.a.V((View) obj, floatValue);
                return;
            default:
                ((View) obj).setClipBounds((Rect) obj2);
                return;
        }
    }
}
