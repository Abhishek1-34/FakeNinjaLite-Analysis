package x;

import android.graphics.RectF;
import java.util.Arrays;

/* loaded from: classes.dex */
public final class Rd implements T4 {
    public final float a;

    public Rd(float f) {
        this.a = f;
    }

    @Override // x.T4
    public final float a(RectF rectF) {
        return Math.min(rectF.width(), rectF.height()) * this.a;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if ((obj instanceof Rd) && this.a == ((Rd) obj).a) {
            return true;
        }
        return false;
    }

    public final int hashCode() {
        return Arrays.hashCode(new Object[]{Float.valueOf(this.a)});
    }
}
