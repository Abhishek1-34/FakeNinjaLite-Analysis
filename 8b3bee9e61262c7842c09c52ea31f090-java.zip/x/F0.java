package x;

import android.R;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.ContextThemeWrapper;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AlertController$RecycleListView;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import java.util.ArrayList;
import java.util.Collections;

/* loaded from: classes.dex */
public final class F0 implements M {
    public final int a;
    public final Object b;

    public F0(Context context) {
        int h = G0.h(context, 0);
        this.b = new B0(new ContextThemeWrapper(context, G0.h(context, h)));
        this.a = h;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r7v1, types: [android.widget.ListAdapter] */
    /* JADX WARN: Type inference failed for: r7v3 */
    /* JADX WARN: Type inference failed for: r7v4 */
    public G0 a() {
        int i;
        B0 b0 = (B0) this.b;
        G0 g0 = new G0(b0.a, this.a);
        View view = b0.e;
        E0 e0 = g0.f;
        if (view != null) {
            e0.n = view;
        } else {
            CharSequence charSequence = b0.d;
            if (charSequence != null) {
                e0.d = charSequence;
                TextView textView = e0.l;
                if (textView != null) {
                    textView.setText(charSequence);
                }
            }
            Drawable drawable = b0.c;
            if (drawable != null) {
                e0.j = drawable;
                ImageView imageView = e0.k;
                if (imageView != null) {
                    imageView.setVisibility(0);
                    e0.k.setImageDrawable(drawable);
                }
            }
        }
        if (b0.g != null) {
            AlertController$RecycleListView alertController$RecycleListView = (AlertController$RecycleListView) b0.b.inflate(e0.r, (ViewGroup) null);
            if (b0.i) {
                i = e0.s;
            } else {
                i = e0.t;
            }
            Object obj = b0.g;
            ?? r7 = obj;
            if (obj == null) {
                r7 = new ArrayAdapter(b0.a, i, R.id.text1, (Object[]) null);
            }
            e0.o = r7;
            e0.p = b0.j;
            if (b0.h != null) {
                alertController$RecycleListView.setOnItemClickListener(new A0(b0, e0));
            }
            if (b0.i) {
                alertController$RecycleListView.setChoiceMode(1);
            }
            e0.e = alertController$RecycleListView;
        }
        g0.setCancelable(true);
        g0.setCanceledOnTouchOutside(true);
        g0.setOnCancelListener(null);
        g0.setOnDismissListener(null);
        DialogInterfaceOnKeyListenerC0265nb dialogInterfaceOnKeyListenerC0265nb = b0.f;
        if (dialogInterfaceOnKeyListenerC0265nb != null) {
            g0.setOnKeyListener(dialogInterfaceOnKeyListenerC0265nb);
        }
        return g0;
    }

    @Override // x.M
    public boolean j(View view) {
        ((BottomSheetBehavior) this.b).B(this.a);
        return true;
    }

    public F0() {
        this.a = 1;
        this.b = Collections.singletonList(null);
    }

    public F0(ArrayList arrayList) {
        this.a = 0;
        this.b = arrayList;
    }

    public F0(BottomSheetBehavior bottomSheetBehavior, int i) {
        this.b = bottomSheetBehavior;
        this.a = i;
    }
}
