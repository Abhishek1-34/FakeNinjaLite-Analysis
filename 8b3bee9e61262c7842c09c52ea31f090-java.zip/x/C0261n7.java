package x;

import androidx.recyclerview.widget.RecyclerView;

/* renamed from: x.n7, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0261n7 extends Bd {
    public final /* synthetic */ C0299p7 a;

    public C0261n7(C0299p7 c0299p7) {
        this.a = c0299p7;
    }

    @Override // x.Bd
    public final void b(RecyclerView recyclerView, int i, int i2) {
        boolean z;
        boolean z2;
        int computeHorizontalScrollOffset = recyclerView.computeHorizontalScrollOffset();
        int computeVerticalScrollOffset = recyclerView.computeVerticalScrollOffset();
        C0299p7 c0299p7 = this.a;
        int computeVerticalScrollRange = c0299p7.s.computeVerticalScrollRange();
        int i3 = c0299p7.r;
        int i4 = computeVerticalScrollRange - i3;
        int i5 = c0299p7.a;
        if (i4 > 0 && i3 >= i5) {
            z = true;
        } else {
            z = false;
        }
        c0299p7.t = z;
        int computeHorizontalScrollRange = c0299p7.s.computeHorizontalScrollRange();
        int i6 = c0299p7.q;
        if (computeHorizontalScrollRange - i6 > 0 && i6 >= i5) {
            z2 = true;
        } else {
            z2 = false;
        }
        c0299p7.u = z2;
        boolean z3 = c0299p7.t;
        if (!z3 && !z2) {
            if (c0299p7.v != 0) {
                c0299p7.f(0);
                return;
            }
            return;
        }
        if (z3) {
            float f = i3;
            c0299p7.l = (int) ((((f / 2.0f) + computeVerticalScrollOffset) * f) / computeVerticalScrollRange);
            c0299p7.k = Math.min(i3, (i3 * i3) / computeVerticalScrollRange);
        }
        if (c0299p7.u) {
            float f2 = computeHorizontalScrollOffset;
            float f3 = i6;
            c0299p7.o = (int) ((((f3 / 2.0f) + f2) * f3) / computeHorizontalScrollRange);
            c0299p7.n = Math.min(i6, (i6 * i6) / computeHorizontalScrollRange);
        }
        int i7 = c0299p7.v;
        if (i7 == 0 || i7 == 1) {
            c0299p7.f(1);
        }
    }
}
