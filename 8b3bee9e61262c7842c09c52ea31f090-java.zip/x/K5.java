package x;

import java.util.Iterator;

/* loaded from: classes.dex */
public class K5 extends C0486z5 {
    public int m;

    public K5(Wh wh) {
        super(wh);
        if (wh instanceof C0357s9) {
            this.e = 2;
        } else {
            this.e = 3;
        }
    }

    @Override // x.C0486z5
    public final void d(int i) {
        if (this.j) {
            return;
        }
        this.j = true;
        this.g = i;
        Iterator it = this.k.iterator();
        while (it.hasNext()) {
            InterfaceC0448x5 interfaceC0448x5 = (InterfaceC0448x5) it.next();
            interfaceC0448x5.a(interfaceC0448x5);
        }
    }
}
