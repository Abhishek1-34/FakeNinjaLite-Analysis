package x;

import android.widget.LinearLayout;

/* renamed from: x.ba, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public class C0031ba extends LinearLayout.LayoutParams {
}
