package x;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;

/* renamed from: x.sf, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class SubMenuC0363sf extends MenuC0246mb implements SubMenu {
    public final C0303pb A;
    public final MenuC0246mb z;

    public SubMenuC0363sf(Context context, MenuC0246mb menuC0246mb, C0303pb c0303pb) {
        super(context);
        this.z = menuC0246mb;
        this.A = c0303pb;
    }

    @Override // x.MenuC0246mb
    public final boolean d(C0303pb c0303pb) {
        return this.z.d(c0303pb);
    }

    @Override // x.MenuC0246mb
    public final boolean e(MenuC0246mb menuC0246mb, MenuItem menuItem) {
        if (!super.e(menuC0246mb, menuItem) && !this.z.e(menuC0246mb, menuItem)) {
            return false;
        }
        return true;
    }

    @Override // x.MenuC0246mb
    public final boolean f(C0303pb c0303pb) {
        return this.z.f(c0303pb);
    }

    @Override // android.view.SubMenu
    public final MenuItem getItem() {
        return this.A;
    }

    @Override // x.MenuC0246mb
    public final String j() {
        int i;
        C0303pb c0303pb = this.A;
        if (c0303pb != null) {
            i = c0303pb.a;
        } else {
            i = 0;
        }
        if (i == 0) {
            return null;
        }
        return Ue.d("android:menu:actionviewstates:", i);
    }

    @Override // x.MenuC0246mb
    public final MenuC0246mb k() {
        return this.z.k();
    }

    @Override // x.MenuC0246mb
    public final boolean m() {
        return this.z.m();
    }

    @Override // x.MenuC0246mb
    public final boolean n() {
        return this.z.n();
    }

    @Override // x.MenuC0246mb
    public final boolean o() {
        return this.z.o();
    }

    @Override // x.MenuC0246mb, android.view.Menu
    public final void setGroupDividerEnabled(boolean z) {
        this.z.setGroupDividerEnabled(z);
    }

    @Override // android.view.SubMenu
    public final SubMenu setHeaderIcon(Drawable drawable) {
        u(0, null, 0, drawable, null);
        return this;
    }

    @Override // android.view.SubMenu
    public final SubMenu setHeaderTitle(CharSequence charSequence) {
        u(0, charSequence, 0, null, null);
        return this;
    }

    @Override // android.view.SubMenu
    public final SubMenu setHeaderView(View view) {
        u(0, null, 0, null, view);
        return this;
    }

    @Override // android.view.SubMenu
    public final SubMenu setIcon(Drawable drawable) {
        this.A.setIcon(drawable);
        return this;
    }

    @Override // x.MenuC0246mb, android.view.Menu
    public final void setQwertyMode(boolean z) {
        this.z.setQwertyMode(z);
    }

    @Override // android.view.SubMenu
    public final SubMenu setHeaderIcon(int i) {
        u(0, null, i, null, null);
        return this;
    }

    @Override // android.view.SubMenu
    public final SubMenu setHeaderTitle(int i) {
        u(i, null, 0, null, null);
        return this;
    }

    @Override // android.view.SubMenu
    public final SubMenu setIcon(int i) {
        this.A.setIcon(i);
        return this;
    }
}
