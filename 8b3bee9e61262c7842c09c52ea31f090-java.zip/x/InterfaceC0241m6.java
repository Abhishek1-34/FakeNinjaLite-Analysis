package x;

/* renamed from: x.m6, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public interface InterfaceC0241m6 {
    void a(E9 e9);
}
