package x;

import android.app.Application;
import android.graphics.Typeface;
import android.util.Log;
import android.view.View;
import com.google.android.material.behavior.SwipeDismissBehavior;
import java.lang.reflect.Method;
import java.util.WeakHashMap;
import org.conscrypt.ct.CTConstants;

/* renamed from: x.a0, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class RunnableC0001a0 implements Runnable {
    public final /* synthetic */ int a;
    public final Object b;
    public final /* synthetic */ Object c;

    public /* synthetic */ RunnableC0001a0(Object obj, int i, Object obj2) {
        this.a = i;
        this.b = obj;
        this.c = obj2;
    }

    @Override // java.lang.Runnable
    public final void run() {
        InterfaceC0208kb interfaceC0208kb;
        Object obj = this.b;
        Object obj2 = this.c;
        switch (this.a) {
            case 0:
                C0041c0 c0041c0 = (C0041c0) obj2;
                MenuC0246mb menuC0246mb = c0041c0.c;
                if (menuC0246mb != null && (interfaceC0208kb = menuC0246mb.e) != null) {
                    interfaceC0208kb.t(menuC0246mb);
                }
                View view = (View) c0041c0.h;
                if (view != null && view.getWindowToken() != null) {
                    Y y = (Y) obj;
                    if (!y.b()) {
                        if (y.e != null) {
                            y.d(0, 0, false, false);
                        }
                    }
                    c0041c0.s = y;
                }
                c0041c0.u = null;
                return;
            case 1:
                ((C0160i0) obj).a = obj2;
                return;
            case 2:
                ((Application) obj).unregisterActivityLifecycleCallbacks((C0160i0) obj2);
                return;
            case CTConstants.CERTIFICATE_LENGTH_BYTES /* 3 */:
                try {
                    Method method = AbstractC0178j0.d;
                    if (method != null) {
                        method.invoke(obj, obj2, Boolean.FALSE, "AppCompat recreation");
                    } else {
                        AbstractC0178j0.e.invoke(obj, obj2, Boolean.FALSE);
                    }
                    return;
                } catch (RuntimeException e) {
                    if (e.getClass() == RuntimeException.class && e.getMessage() != null && e.getMessage().startsWith("Unable to stop")) {
                        throw e;
                    }
                    return;
                } catch (Throwable th) {
                    Log.e("ActivityRecreator", "Exception while invoking performStopActivity", th);
                    return;
                }
            case 4:
                AbstractC0112fb abstractC0112fb = (AbstractC0112fb) ((B) obj).b;
                if (abstractC0112fb != null) {
                    abstractC0112fb.z((Typeface) obj2);
                    return;
                }
                return;
            case 5:
                ((P7) obj).a(obj2);
                return;
            default:
                C0346rh c0346rh = ((SwipeDismissBehavior) obj2).a;
                if (c0346rh != null && c0346rh.f()) {
                    WeakHashMap weakHashMap = AbstractC0309ph.a;
                    ((View) obj).postOnAnimation(this);
                    return;
                }
                return;
        }
    }

    public RunnableC0001a0(SwipeDismissBehavior swipeDismissBehavior, View view, boolean z) {
        this.a = 6;
        this.c = swipeDismissBehavior;
        this.b = view;
    }

    public RunnableC0001a0(C0041c0 c0041c0, Y y) {
        this.a = 0;
        this.c = c0041c0;
        this.b = y;
    }
}
