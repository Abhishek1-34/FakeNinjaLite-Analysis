package x;

/* renamed from: x.j9, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public interface InterfaceC0187j9 {
}
