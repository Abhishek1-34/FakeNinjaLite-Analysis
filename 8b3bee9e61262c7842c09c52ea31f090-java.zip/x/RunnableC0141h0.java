package x;

import android.accessibilityservice.GestureDescription;
import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.graphics.Path;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Handler;
import android.os.SystemClock;
import android.os.Trace;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import com.google.android.material.carousel.CarouselLayoutManager;
import com.google.android.material.sidesheet.SideSheetBehavior;
import com.google.android.material.textfield.TextInputLayout;
import java.io.IOException;
import java.lang.reflect.Method;
import java.net.DatagramPacket;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.nio.MappedByteBuffer;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import org.conscrypt.FileClientSessionCache;
import org.conscrypt.ct.CTConstants;

/* renamed from: x.h0, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final /* synthetic */ class RunnableC0141h0 implements Runnable {
    public final /* synthetic */ int a;
    public final /* synthetic */ Object b;

    public /* synthetic */ RunnableC0141h0(int i, Object obj) {
        this.a = i;
        this.b = obj;
    }

    private final void a() {
        C0436wc c0436wc;
        C0398uc c0398uc = (C0398uc) this.b;
        Socket socket = new Socket();
        try {
            try {
                if (!c0398uc.p.a.protect(socket)) {
                    Yb.h("Proteção do socket TCP não confirmada; continuando fora da VPN " + c0398uc.a);
                }
                socket.setTcpNoDelay(true);
                socket.setKeepAlive(true);
                socket.setSendBufferSize(262144);
                socket.setReceiveBufferSize(262144);
                socket.connect(new InetSocketAddress(c0398uc.d, c0398uc.e), 12000);
                Yb.h("TCP conectado " + c0398uc.a);
                synchronized (c0398uc) {
                    if (!c0398uc.o && c0398uc.p.e.get()) {
                        c0398uc.h = socket;
                        c0398uc.i = socket.getInputStream();
                        c0398uc.j = socket.getOutputStream();
                        c0398uc.n = true;
                        c0398uc.c();
                        c0398uc.b();
                        try {
                            socket.close();
                        } catch (IOException unused) {
                        }
                        c0398uc.a();
                        c0436wc = c0398uc.p;
                    }
                    try {
                        socket.close();
                    } catch (IOException unused2) {
                    }
                    c0398uc.a();
                    c0436wc = c0398uc.p;
                }
            } catch (IOException e) {
                if (!c0398uc.o && c0398uc.p.e.get()) {
                    Yb.c("Falha na conexão TCP " + c0398uc.a, e);
                    c0398uc.p.k(c0398uc.d, c0398uc.e, c0398uc.b, c0398uc.c, c0398uc.g, c0398uc.k, 20, new byte[0], 0);
                }
                try {
                    socket.close();
                } catch (IOException unused3) {
                }
                c0398uc.a();
                c0436wc = c0398uc.p;
            }
            c0436wc.i.remove(c0398uc.a, c0398uc);
        } catch (Throwable th) {
            try {
                socket.close();
            } catch (IOException unused4) {
            }
            c0398uc.a();
            c0398uc.p.i.remove(c0398uc.a, c0398uc);
            throw th;
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r5v0 */
    /* JADX WARN: Type inference failed for: r5v1 */
    /* JADX WARN: Type inference failed for: r5v11 */
    /* JADX WARN: Type inference failed for: r5v2 */
    /* JADX WARN: Type inference failed for: r5v5 */
    /* JADX WARN: Type inference failed for: r5v6, types: [android.os.Handler] */
    /* JADX WARN: Type inference failed for: r5v7 */
    /* JADX WARN: Type inference failed for: r5v8 */
    /* JADX WARN: Type inference failed for: r6v3 */
    /* JADX WARN: Type inference failed for: r6v4 */
    /* JADX WARN: Type inference failed for: r6v7 */
    /* JADX WARN: Type inference failed for: r6v8, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r6v9 */
    /* JADX WARN: Type inference failed for: r7v0 */
    /* JADX WARN: Type inference failed for: r7v1 */
    /* JADX WARN: Type inference failed for: r7v4 */
    /* JADX WARN: Type inference failed for: r7v5, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r7v6 */
    @Override // java.lang.Runnable
    public final void run() {
        boolean z;
        Object obj;
        boolean z2;
        List<byte[]> emptyList;
        float[] fArr = null;
        int i = 2;
        ?? r5 = 1;
        r5 = 1;
        switch (this.a) {
            case 0:
                Activity activity = (Activity) this.b;
                if (!activity.isFinishing()) {
                    int i2 = Build.VERSION.SDK_INT;
                    if (i2 >= 28) {
                        Class cls = AbstractC0178j0.a;
                        activity.recreate();
                        return;
                    }
                    Class cls2 = AbstractC0178j0.a;
                    ?? r6 = 27;
                    ?? r7 = 26;
                    if (i2 != 26 && i2 != 27) {
                        z = false;
                    } else {
                        z = true;
                    }
                    Method method = AbstractC0178j0.f;
                    if ((!z || method != null) && (AbstractC0178j0.e != null || AbstractC0178j0.d != null)) {
                        try {
                            Object obj2 = AbstractC0178j0.c.get(activity);
                            if (obj2 != null && (obj = AbstractC0178j0.b.get(activity)) != null) {
                                Application application = activity.getApplication();
                                C0160i0 c0160i0 = new C0160i0(activity);
                                application.registerActivityLifecycleCallbacks(c0160i0);
                                Handler handler = AbstractC0178j0.g;
                                handler.post(new RunnableC0001a0(c0160i0, 1 == true ? 1 : 0, obj2));
                                if (i2 != 26 && i2 != 27) {
                                    r5 = 0;
                                }
                                try {
                                    if (r5 != 0) {
                                        try {
                                            Boolean bool = Boolean.FALSE;
                                            r5 = handler;
                                            r6 = c0160i0;
                                            r7 = application;
                                            method.invoke(obj, obj2, null, null, 0, bool, null, null, bool, bool);
                                        } catch (Throwable th) {
                                            th = th;
                                            Handler handler2 = handler;
                                            C0160i0 c0160i02 = c0160i0;
                                            Application application2 = application;
                                            handler2.post(new RunnableC0001a0(application2, i, c0160i02));
                                            throw th;
                                        }
                                    } else {
                                        r5 = handler;
                                        r6 = c0160i0;
                                        r7 = application;
                                        activity.recreate();
                                    }
                                    r5.post(new RunnableC0001a0((Object) r7, i, (Object) r6));
                                    return;
                                } catch (Throwable th2) {
                                    th = th2;
                                }
                            }
                        } catch (Throwable unused) {
                        }
                    }
                    activity.recreate();
                    return;
                }
                return;
            case 1:
                vpn.team09.hax.d dVar = (vpn.team09.hax.d) this.b;
                Handler handler3 = vpn.team09.hax.d.b;
                dVar.getClass();
                if (vpn.team09.hax.d.d && vpn.team09.hax.d.c == dVar && !vpn.team09.hax.d.e) {
                    Handler handler4 = Z6.a;
                    if (SystemClock.uptimeMillis() - Z6.t <= 180 && Float.isFinite(Z6.p) && Float.isFinite(Z6.q) && Float.isFinite(Z6.r) && Float.isFinite(Z6.s)) {
                        fArr = new float[]{Z6.r, Z6.s, Z6.p, Z6.q};
                    }
                    if (fArr == null) {
                        vpn.team09.hax.d.b.postDelayed(dVar.a, 32L);
                        return;
                    }
                    float f = fArr[2] - fArr[0];
                    float f2 = fArr[3] - fArr[1];
                    if (((float) Math.hypot(f, f2)) < 4.0f) {
                        vpn.team09.hax.d.b.postDelayed(dVar.a, 32L);
                        return;
                    }
                    float max = (AbstractC0481z0.h / 100.0f) / Math.max(1.0f, AbstractC0481z0.i * 0.62f);
                    float max2 = Math.max(-92.0f, Math.min(92.0f, f * max));
                    float max3 = Math.max(-76.0f, Math.min(76.0f, f2 * max));
                    if (Math.abs(max2) < 1.2f && Math.abs(max3) < 1.2f) {
                        vpn.team09.hax.d.b.postDelayed(dVar.a, 32L);
                        return;
                    }
                    Path path = new Path();
                    path.moveTo(fArr[0], fArr[1]);
                    path.lineTo(fArr[0] + max2, fArr[1] + max3);
                    GestureDescription build = new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(path, 0L, 26L)).build();
                    vpn.team09.hax.d.e = true;
                    C0424w0 c0424w0 = new C0424w0(dVar);
                    Handler handler5 = vpn.team09.hax.d.b;
                    if (!dVar.dispatchGesture(build, c0424w0, handler5)) {
                        vpn.team09.hax.d.e = false;
                        handler5.postDelayed(dVar.a, 40L);
                        return;
                    }
                    return;
                }
                return;
            case 2:
                ((CarouselLayoutManager) this.b).l0();
                return;
            case CTConstants.CERTIFICATE_LENGTH_BYTES /* 3 */:
                ((V3) this.b).t(true);
                return;
            case 4:
                ((R0) this.b).invalidateOptionsMenu();
                return;
            case 5:
                ExecutorC0145h4 executorC0145h4 = (ExecutorC0145h4) this.b;
                Runnable runnable = executorC0145h4.b;
                if (runnable != null) {
                    runnable.run();
                    executorC0145h4.b = null;
                    return;
                }
                return;
            case 6:
                DialogC0182j4.a((DialogC0182j4) this.b);
                return;
            case 7:
                C0047c6 c0047c6 = (C0047c6) this.b;
                boolean isPopupShowing = c0047c6.h.isPopupShowing();
                c0047c6.t(isPopupShowing);
                c0047c6.m = isPopupShowing;
                return;
            case CTConstants.TIMESTAMP_LENGTH /* 8 */:
                M7 m7 = (M7) this.b;
                synchronized (m7.d) {
                    try {
                        if (m7.h != null) {
                            try {
                                W7 c = m7.c();
                                int i3 = c.e;
                                if (i3 == 2) {
                                    synchronized (m7.d) {
                                    }
                                }
                                if (i3 == 0) {
                                    try {
                                        int i4 = AbstractC0175ig.a;
                                        Trace.beginSection("EmojiCompat.FontRequestEmojiCompatConfig.buildTypeface");
                                        C0107f6 c0107f6 = m7.c;
                                        Context context = m7.a;
                                        c0107f6.getClass();
                                        W7[] w7Arr = {c};
                                        AbstractC0171ib abstractC0171ib = AbstractC0478yg.a;
                                        AbstractC0112fb.a("TypefaceCompat.createFromFontInfo");
                                        try {
                                            Typeface n = AbstractC0478yg.a.n(context, w7Arr, 0);
                                            Trace.endSection();
                                            MappedByteBuffer w = AbstractC0112fb.w(m7.a, c.a);
                                            if (w != null && n != null) {
                                                try {
                                                    Trace.beginSection("EmojiCompat.MetadataRepo.create");
                                                    C0353s5 c0353s5 = new C0353s5(n, AbstractC0112fb.F(w));
                                                    Trace.endSection();
                                                    synchronized (m7.d) {
                                                        try {
                                                            E9 e9 = m7.h;
                                                            if (e9 != null) {
                                                                e9.R(c0353s5);
                                                            }
                                                        } finally {
                                                        }
                                                    }
                                                    m7.b();
                                                    return;
                                                } finally {
                                                    int i5 = AbstractC0175ig.a;
                                                }
                                            }
                                            throw new RuntimeException("Unable to open file.");
                                        } finally {
                                            Trace.endSection();
                                        }
                                    } finally {
                                    }
                                }
                                throw new RuntimeException("fetchFonts result is not OK. (" + i3 + ")");
                            } catch (Throwable th3) {
                                synchronized (m7.d) {
                                    try {
                                        E9 e92 = m7.h;
                                        if (e92 != null) {
                                            e92.Q(th3);
                                        }
                                        m7.b();
                                        return;
                                    } finally {
                                    }
                                }
                            }
                        }
                        return;
                    } finally {
                    }
                }
            case 9:
                a();
                return;
            case 10:
                C0417vc c0417vc = (C0417vc) this.b;
                byte[] bArr = new byte[65507];
                while (c0417vc.j.e.get() && !c0417vc.i) {
                    DatagramPacket datagramPacket = new DatagramPacket(bArr, 65507);
                    try {
                        c0417vc.g.receive(datagramPacket);
                        c0417vc.h = SystemClock.elapsedRealtime();
                        byte[] copyOfRange = Arrays.copyOfRange(datagramPacket.getData(), datagramPacket.getOffset(), datagramPacket.getOffset() + datagramPacket.getLength());
                        int i6 = c0417vc.e;
                        if (i6 >= 10000 && i6 < 10101) {
                            z2 = true;
                        } else {
                            z2 = false;
                        }
                        if (z2) {
                            C0436wc.h(c0417vc.a, copyOfRange, true);
                            copyOfRange = Oc.k(c0417vc.a, copyOfRange);
                        }
                        C0436wc.a(c0417vc.j, c0417vc.d, c0417vc.e, c0417vc.b, c0417vc.c, copyOfRange);
                        Yb.f("S2C", 17, copyOfRange.length);
                        Z6.c.incrementAndGet();
                        try {
                            int i7 = c0417vc.e;
                            if (i7 >= 10000 && i7 < 10101) {
                                emptyList = Jb.a(c0417vc.a);
                            } else {
                                emptyList = Collections.emptyList();
                            }
                            for (byte[] bArr2 : emptyList) {
                                if (bArr2 != null && bArr2.length >= 16 && bArr2.length <= 600) {
                                    C0436wc.a(c0417vc.j, c0417vc.d, c0417vc.e, c0417vc.b, c0417vc.c, bArr2);
                                }
                            }
                        } catch (Exception e) {
                            Log.d("ProjectX-Packet", "Pacote adicional inválido ignorado: " + c0417vc.a, e);
                        }
                    } catch (SocketTimeoutException unused2) {
                        if (SystemClock.elapsedRealtime() - c0417vc.h > 120000) {
                        }
                    } catch (IOException unused3) {
                        if (!c0417vc.i && c0417vc.j.e.get()) {
                            Log.d("ProjectX-Packet", "Fluxo UDP encerrado: " + c0417vc.a);
                        }
                    }
                }
                c0417vc.a();
                c0417vc.j.h.remove(c0417vc.a, c0417vc);
                return;
            case 11:
                Uc uc = (Uc) this.b;
                E9.o(uc, "this$0");
                int i8 = uc.b;
                androidx.lifecycle.a aVar = uc.f;
                if (i8 == 0) {
                    uc.c = true;
                    aVar.d(S9.ON_PAUSE);
                }
                if (uc.a == 0 && uc.c) {
                    aVar.d(S9.ON_STOP);
                    uc.d = true;
                    return;
                }
                return;
            case FileClientSessionCache.MAX_SIZE /* 12 */:
                ((AbstractC0229ld) this.b).m();
                return;
            case 13:
                C0084e3 c0084e3 = (C0084e3) this.b;
                c0084e3.c = false;
                SideSheetBehavior sideSheetBehavior = (SideSheetBehavior) c0084e3.e;
                C0346rh c0346rh = sideSheetBehavior.i;
                if (c0346rh != null && c0346rh.f()) {
                    c0084e3.a(c0084e3.b);
                    return;
                } else {
                    if (sideSheetBehavior.h == 2) {
                        sideSheetBehavior.r(c0084e3.b);
                        return;
                    }
                    return;
                }
            case 14:
                ((TextInputLayout) this.b).d.requestLayout();
                return;
            default:
                View view = (View) this.b;
                ((InputMethodManager) view.getContext().getSystemService(InputMethodManager.class)).showSoftInput(view, 1);
                return;
        }
    }
}
