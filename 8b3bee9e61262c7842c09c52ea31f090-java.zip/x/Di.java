package x;

import android.graphics.drawable.Drawable;

/* loaded from: classes.dex */
public abstract class Di extends Drawable implements Drawable.Callback, Ci {
    public abstract void a(Drawable drawable);
}
