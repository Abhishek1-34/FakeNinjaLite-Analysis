package x;

import java.util.LinkedHashMap;

/* loaded from: classes.dex */
public abstract class V4 {
    public final LinkedHashMap a = new LinkedHashMap();
}
