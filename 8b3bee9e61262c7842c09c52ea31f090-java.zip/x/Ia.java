package x;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

/* loaded from: classes.dex */
public abstract class Ia extends AbstractC0124g3 {
    public static int b0(int i) {
        if (i >= 0) {
            if (i < 3) {
                return i + 1;
            }
            if (i < 1073741824) {
                return (int) ((i / 0.75f) + 1.0f);
            }
            return Integer.MAX_VALUE;
        }
        return i;
    }

    public static Map c0(ArrayList arrayList) {
        I6 i6 = I6.a;
        int size = arrayList.size();
        if (size != 0) {
            if (size != 1) {
                LinkedHashMap linkedHashMap = new LinkedHashMap(b0(arrayList.size()));
                Iterator it = arrayList.iterator();
                while (it.hasNext()) {
                    Ac ac = (Ac) it.next();
                    linkedHashMap.put(ac.a, ac.b);
                }
                return linkedHashMap;
            }
            Ac ac2 = (Ac) arrayList.get(0);
            E9.o(ac2, "pair");
            Map singletonMap = Collections.singletonMap(ac2.a, ac2.b);
            E9.n(singletonMap, "singletonMap(pair.first, pair.second)");
            return singletonMap;
        }
        return i6;
    }
}
