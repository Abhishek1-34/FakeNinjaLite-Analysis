package x;

import android.os.Handler;
import android.os.Message;

/* loaded from: classes.dex */
public final class Q2 implements Handler.Callback {
    @Override // android.os.Handler.Callback
    public final boolean handleMessage(Message message) {
        int i = message.what;
        if (i != 0) {
            if (i != 1) {
                return false;
            }
            message.obj.getClass();
            throw new ClassCastException();
        }
        message.obj.getClass();
        throw new ClassCastException();
    }
}
