package x;

import android.view.DisplayCutout;
import android.view.WindowInsets;
import java.util.Objects;

/* loaded from: classes.dex */
public class ri extends qi {
    public ri(wi wiVar, WindowInsets windowInsets) {
        super(wiVar, windowInsets);
    }

    @Override // x.ui
    public wi a() {
        WindowInsets consumeDisplayCutout;
        consumeDisplayCutout = this.c.consumeDisplayCutout();
        return wi.g(null, consumeDisplayCutout);
    }

    @Override // x.ui
    public M5 e() {
        DisplayCutout displayCutout;
        displayCutout = this.c.getDisplayCutout();
        if (displayCutout == null) {
            return null;
        }
        return new M5(displayCutout);
    }

    @Override // x.pi, x.ui
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof ri)) {
            return false;
        }
        ri riVar = (ri) obj;
        if (Objects.equals(this.c, riVar.c) && Objects.equals(this.g, riVar.g)) {
            return true;
        }
        return false;
    }

    @Override // x.ui
    public int hashCode() {
        return this.c.hashCode();
    }
}
