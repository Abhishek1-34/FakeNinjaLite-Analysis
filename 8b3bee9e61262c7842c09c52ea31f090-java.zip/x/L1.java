package x;

/* loaded from: classes.dex */
public final class L1 extends Z7 {
    public final /* synthetic */ S1 j;
    public final /* synthetic */ V1 k;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public L1(V1 v1, V1 v12, S1 s1) {
        super(v12);
        this.k = v1;
        this.j = s1;
    }

    @Override // x.Z7
    public final Me b() {
        return this.j;
    }

    @Override // x.Z7
    public final boolean c() {
        V1 v1 = this.k;
        if (!v1.getInternalPopup().a()) {
            v1.f.f(v1.getTextDirection(), v1.getTextAlignment());
            return true;
        }
        return true;
    }
}
