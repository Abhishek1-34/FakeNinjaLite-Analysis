package x;

/* renamed from: x.oa, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class RunnableC0283oa implements Runnable {
    public final /* synthetic */ int a;
    public final /* synthetic */ C0358sa b;

    public /* synthetic */ RunnableC0283oa(C0358sa c0358sa, int i) {
        this.a = i;
        this.b = c0358sa;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.a) {
            case 0:
                X5 x5 = this.b.c;
                if (x5 != null) {
                    x5.setListSelectionHidden(true);
                    x5.requestLayout();
                    return;
                }
                return;
            default:
                C0358sa c0358sa = this.b;
                X5 x52 = c0358sa.c;
                if (x52 != null && x52.isAttachedToWindow() && c0358sa.c.getCount() > c0358sa.c.getChildCount() && c0358sa.c.getChildCount() <= c0358sa.m) {
                    c0358sa.z.setInputMethodMode(2);
                    c0358sa.i();
                    return;
                }
                return;
        }
    }
}
