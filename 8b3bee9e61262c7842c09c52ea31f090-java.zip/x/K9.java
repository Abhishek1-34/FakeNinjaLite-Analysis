package x;

import android.view.KeyEvent;

/* loaded from: classes.dex */
public interface K9 {
    boolean e(KeyEvent keyEvent);
}
