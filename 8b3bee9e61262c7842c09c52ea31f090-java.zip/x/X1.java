package x;

import android.graphics.Typeface;
import android.os.Build;
import android.widget.TextView;
import java.lang.ref.WeakReference;

/* loaded from: classes.dex */
public final class X1 extends AbstractC0112fb {
    public final /* synthetic */ int d;
    public final /* synthetic */ int e;
    public final /* synthetic */ WeakReference f;
    public final /* synthetic */ C0043c2 g;

    public X1(C0043c2 c0043c2, int i, int i2, WeakReference weakReference) {
        this.g = c0043c2;
        this.d = i;
        this.e = i2;
        this.f = weakReference;
    }

    @Override // x.AbstractC0112fb
    public final void y(int i) {
    }

    @Override // x.AbstractC0112fb
    public final void z(Typeface typeface) {
        int i;
        boolean z;
        if (Build.VERSION.SDK_INT >= 28 && (i = this.d) != -1) {
            if ((this.e & 2) != 0) {
                z = true;
            } else {
                z = false;
            }
            typeface = AbstractC0023b2.a(typeface, i, z);
        }
        C0043c2 c0043c2 = this.g;
        if (c0043c2.m) {
            c0043c2.l = typeface;
            TextView textView = (TextView) this.f.get();
            if (textView != null) {
                if (textView.isAttachedToWindow()) {
                    textView.post(new Y1(textView, typeface, c0043c2.j));
                } else {
                    textView.setTypeface(typeface, c0043c2.j);
                }
            }
        }
    }
}
