package x;

import android.content.Context;
import android.graphics.Rect;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityManager;
import android.view.accessibility.AccessibilityNodeInfo;
import com.google.android.material.chip.Chip;
import java.util.ArrayList;
import java.util.Collections;
import java.util.WeakHashMap;
import org.conscrypt.BuildConfig;
import org.conscrypt.R;

/* loaded from: classes.dex */
public final class J3 extends C0291p {
    public static final Rect o = new Rect(Integer.MAX_VALUE, Integer.MAX_VALUE, Integer.MIN_VALUE, Integer.MIN_VALUE);
    public static final C0107f6 p = new C0107f6(13);
    public static final C0107f6 q = new C0107f6(14);
    public final AccessibilityManager h;
    public final Chip i;
    public C0128g7 j;
    public final /* synthetic */ Chip n;
    public final Rect d = new Rect();
    public final Rect e = new Rect();
    public final Rect f = new Rect();
    public final int[] g = new int[2];
    public int k = Integer.MIN_VALUE;
    public int l = Integer.MIN_VALUE;
    public int m = Integer.MIN_VALUE;

    public J3(Chip chip, Chip chip2) {
        this.n = chip;
        if (chip2 != null) {
            this.i = chip2;
            this.h = (AccessibilityManager) chip2.getContext().getSystemService("accessibility");
            chip2.setFocusable(true);
            WeakHashMap weakHashMap = AbstractC0309ph.a;
            if (chip2.getImportantForAccessibility() == 0) {
                chip2.setImportantForAccessibility(1);
                return;
            }
            return;
        }
        throw new IllegalArgumentException("View may not be null");
    }

    @Override // x.C0291p
    public final B b(View view) {
        if (this.j == null) {
            this.j = new C0128g7(this);
        }
        return this.j;
    }

    @Override // x.C0291p
    public final void d(View view, C c) {
        View.AccessibilityDelegate accessibilityDelegate = this.a;
        AccessibilityNodeInfo accessibilityNodeInfo = c.a;
        accessibilityDelegate.onInitializeAccessibilityNodeInfo(view, accessibilityNodeInfo);
        Chip chip = this.n;
        accessibilityNodeInfo.setCheckable(chip.d());
        accessibilityNodeInfo.setClickable(chip.isClickable());
        accessibilityNodeInfo.setClassName(chip.getAccessibilityClassName());
        c.k(chip.getText());
    }

    public final boolean j(int i) {
        if (this.l != i) {
            return false;
        }
        this.l = Integer.MIN_VALUE;
        if (i == 1) {
            Chip chip = this.n;
            chip.m = false;
            chip.refreshDrawableState();
        }
        p(i, 8);
        return true;
    }

    public final C k(int i) {
        boolean z;
        Rect closeIconTouchBoundsInt;
        AccessibilityNodeInfo obtain = AccessibilityNodeInfo.obtain();
        C c = new C(obtain);
        obtain.setEnabled(true);
        obtain.setFocusable(true);
        obtain.setClassName("android.view.View");
        Rect rect = o;
        obtain.setBoundsInParent(rect);
        obtain.setBoundsInScreen(rect);
        Chip chip = this.i;
        obtain.setParent(chip);
        AccessibilityNodeInfo accessibilityNodeInfo = c.a;
        CharSequence charSequence = BuildConfig.FLAVOR;
        if (i == 1) {
            Chip chip2 = this.n;
            CharSequence closeIconContentDescription = chip2.getCloseIconContentDescription();
            if (closeIconContentDescription != null) {
                accessibilityNodeInfo.setContentDescription(closeIconContentDescription);
            } else {
                CharSequence text = chip2.getText();
                Context context = chip2.getContext();
                if (!TextUtils.isEmpty(text)) {
                    charSequence = text;
                }
                accessibilityNodeInfo.setContentDescription(context.getString(R.string.mtrl_chip_close_icon_content_description, charSequence).trim());
            }
            closeIconTouchBoundsInt = chip2.getCloseIconTouchBoundsInt();
            accessibilityNodeInfo.setBoundsInParent(closeIconTouchBoundsInt);
            c.b(C0442x.e);
            accessibilityNodeInfo.setEnabled(chip2.isEnabled());
        } else {
            accessibilityNodeInfo.setContentDescription(BuildConfig.FLAVOR);
            accessibilityNodeInfo.setBoundsInParent(Chip.w);
        }
        if (c.g() == null && obtain.getContentDescription() == null) {
            throw new RuntimeException("Callbacks must add text or a content description in populateNodeForVirtualViewId()");
        }
        Rect rect2 = this.e;
        c.f(rect2);
        if (!rect2.equals(rect)) {
            int actions = obtain.getActions();
            if ((actions & 64) == 0) {
                if ((actions & 128) == 0) {
                    obtain.setPackageName(chip.getContext().getPackageName());
                    c.b = i;
                    obtain.setSource(chip, i);
                    if (this.k == i) {
                        obtain.setAccessibilityFocused(true);
                        c.a(128);
                    } else {
                        obtain.setAccessibilityFocused(false);
                        c.a(64);
                    }
                    if (this.l == i) {
                        z = true;
                    } else {
                        z = false;
                    }
                    if (z) {
                        c.a(2);
                    } else if (obtain.isFocusable()) {
                        c.a(1);
                    }
                    obtain.setFocused(z);
                    int[] iArr = this.g;
                    chip.getLocationOnScreen(iArr);
                    Rect rect3 = this.d;
                    obtain.getBoundsInScreen(rect3);
                    if (rect3.equals(rect)) {
                        c.f(rect3);
                        rect3.offset(iArr[0] - chip.getScrollX(), iArr[1] - chip.getScrollY());
                    }
                    Rect rect4 = this.f;
                    if (chip.getLocalVisibleRect(rect4)) {
                        rect4.offset(iArr[0] - chip.getScrollX(), iArr[1] - chip.getScrollY());
                        if (rect3.intersect(rect4)) {
                            obtain.setBoundsInScreen(rect3);
                            if (!rect3.isEmpty() && chip.getWindowVisibility() == 0) {
                                Object parent = chip.getParent();
                                while (true) {
                                    if (parent instanceof View) {
                                        View view = (View) parent;
                                        if (view.getAlpha() <= 0.0f || view.getVisibility() != 0) {
                                            break;
                                        }
                                        parent = view.getParent();
                                    } else if (parent != null) {
                                        obtain.setVisibleToUser(true);
                                    }
                                }
                            }
                        }
                    }
                    return c;
                }
                throw new RuntimeException("Callbacks must not add ACTION_CLEAR_ACCESSIBILITY_FOCUS in populateNodeForVirtualViewId()");
            }
            throw new RuntimeException("Callbacks must not add ACTION_ACCESSIBILITY_FOCUS in populateNodeForVirtualViewId()");
        }
        throw new RuntimeException("Callbacks must set parent bounds in populateNodeForVirtualViewId()");
    }

    public final void l(ArrayList arrayList) {
        boolean z = false;
        arrayList.add(0);
        Rect rect = Chip.w;
        Chip chip = this.n;
        if (chip.c()) {
            L3 l3 = chip.e;
            if (l3 != null && l3.K) {
                z = true;
            }
            if (z && chip.h != null) {
                arrayList.add(1);
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:26:0x00bf  */
    /* JADX WARN: Removed duplicated region for block: B:32:0x0107  */
    /* JADX WARN: Removed duplicated region for block: B:70:0x00ee  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final boolean m(int i, Rect rect) {
        C c;
        int i2;
        int i3;
        boolean z;
        Object obj;
        C c2;
        int lastIndexOf;
        int i4;
        int i5;
        int i6;
        ArrayList arrayList = new ArrayList();
        l(arrayList);
        Ye ye = new Ye();
        for (int i7 = 0; i7 < arrayList.size(); i7++) {
            ye.c(((Integer) arrayList.get(i7)).intValue(), k(((Integer) arrayList.get(i7)).intValue()));
        }
        int i8 = this.l;
        int i9 = Integer.MIN_VALUE;
        if (i8 == Integer.MIN_VALUE) {
            c = null;
        } else {
            c = (C) ye.b(i8);
        }
        C0107f6 c0107f6 = p;
        C0107f6 c0107f62 = q;
        Chip chip = this.i;
        if (i != 1 && i != 2) {
            if (i != 17 && i != 33 && i != 66 && i != 130) {
                throw new IllegalArgumentException("direction must be one of {FOCUS_FORWARD, FOCUS_BACKWARD, FOCUS_UP, FOCUS_DOWN, FOCUS_LEFT, FOCUS_RIGHT}.");
            }
            Rect rect2 = new Rect();
            int i10 = this.l;
            if (i10 != Integer.MIN_VALUE) {
                n(i10).f(rect2);
            } else if (rect != null) {
                rect2.set(rect);
            } else {
                int width = chip.getWidth();
                int height = chip.getHeight();
                if (i != 17) {
                    if (i != 33) {
                        if (i != 66) {
                            if (i == 130) {
                                rect2.set(0, -1, width, -1);
                                i3 = -1;
                            } else {
                                throw new IllegalArgumentException("direction must be one of {FOCUS_UP, FOCUS_DOWN, FOCUS_LEFT, FOCUS_RIGHT}.");
                            }
                        } else {
                            rect2.set(-1, 0, -1, height);
                            i3 = -1;
                        }
                    } else {
                        i3 = -1;
                        rect2.set(0, height, width, height);
                    }
                } else {
                    i3 = -1;
                    rect2.set(width, 0, width, height);
                }
                Rect rect3 = new Rect(rect2);
                if (i == 17) {
                    if (i != 33) {
                        if (i != 66) {
                            if (i == 130) {
                                i2 = 0;
                                rect3.offset(0, -(rect2.height() + 1));
                            } else {
                                throw new IllegalArgumentException("direction must be one of {FOCUS_UP, FOCUS_DOWN, FOCUS_LEFT, FOCUS_RIGHT}.");
                            }
                        } else {
                            i2 = 0;
                            rect3.offset(-(rect2.width() + 1), 0);
                        }
                    } else {
                        i2 = 0;
                        rect3.offset(0, rect2.height() + 1);
                    }
                } else {
                    i2 = 0;
                    rect3.offset(rect2.width() + 1, 0);
                }
                c0107f62.getClass();
                i5 = ye.c;
                Rect rect4 = new Rect();
                c2 = null;
                for (i6 = i2; i6 < i5; i6++) {
                    C c3 = (C) ye.b[i6];
                    if (c3 != c) {
                        c0107f6.getClass();
                        c3.f(rect4);
                        if (E9.I(i, rect2, rect4)) {
                            if (E9.I(i, rect2, rect3) && !E9.d(i, rect2, rect4, rect3)) {
                                if (!E9.d(i, rect2, rect3, rect4)) {
                                    int L = E9.L(i, rect2, rect4);
                                    int M = E9.M(i, rect2, rect4);
                                    int i11 = (M * M) + (L * 13 * L);
                                    int L2 = E9.L(i, rect2, rect3);
                                    int M2 = E9.M(i, rect2, rect3);
                                    if (i11 >= (M2 * M2) + (L2 * 13 * L2)) {
                                    }
                                }
                            }
                            rect3.set(rect4);
                            c2 = c3;
                        }
                    }
                }
            }
            i3 = -1;
            Rect rect32 = new Rect(rect2);
            if (i == 17) {
            }
            c0107f62.getClass();
            i5 = ye.c;
            Rect rect42 = new Rect();
            c2 = null;
            while (i6 < i5) {
            }
        } else {
            i2 = 0;
            i3 = -1;
            WeakHashMap weakHashMap = AbstractC0309ph.a;
            if (chip.getLayoutDirection() == 1) {
                z = true;
            } else {
                z = false;
            }
            c0107f62.getClass();
            int i12 = ye.c;
            ArrayList arrayList2 = new ArrayList(i12);
            for (int i13 = 0; i13 < i12; i13++) {
                arrayList2.add((C) ye.b[i13]);
            }
            Collections.sort(arrayList2, new H7(c0107f6, z));
            if (i != 1) {
                if (i == 2) {
                    int size = arrayList2.size();
                    if (c == null) {
                        lastIndexOf = -1;
                    } else {
                        lastIndexOf = arrayList2.lastIndexOf(c);
                    }
                    int i14 = lastIndexOf + 1;
                    if (i14 < size) {
                        obj = arrayList2.get(i14);
                        c2 = (C) obj;
                    }
                    obj = null;
                    c2 = (C) obj;
                } else {
                    throw new IllegalArgumentException("direction must be one of {FOCUS_FORWARD, FOCUS_BACKWARD}.");
                }
            } else {
                int size2 = arrayList2.size();
                if (c != null) {
                    size2 = arrayList2.indexOf(c);
                }
                int i15 = size2 - 1;
                if (i15 >= 0) {
                    obj = arrayList2.get(i15);
                    c2 = (C) obj;
                }
                obj = null;
                c2 = (C) obj;
            }
        }
        C c4 = c2;
        if (c4 != null) {
            int i16 = ye.c;
            int i17 = i2;
            while (true) {
                if (i17 < i16) {
                    if (ye.b[i17] == c4) {
                        i4 = i17;
                        break;
                    }
                    i17++;
                } else {
                    i4 = i3;
                    break;
                }
            }
            i9 = ye.a[i4];
        }
        return o(i9);
    }

    public final C n(int i) {
        if (i == -1) {
            Chip chip = this.i;
            AccessibilityNodeInfo obtain = AccessibilityNodeInfo.obtain(chip);
            C c = new C(obtain);
            WeakHashMap weakHashMap = AbstractC0309ph.a;
            chip.onInitializeAccessibilityNodeInfo(obtain);
            ArrayList arrayList = new ArrayList();
            l(arrayList);
            if (obtain.getChildCount() > 0 && arrayList.size() > 0) {
                throw new RuntimeException("Views cannot have both real and virtual children");
            }
            int size = arrayList.size();
            for (int i2 = 0; i2 < size; i2++) {
                c.a.addChild(chip, ((Integer) arrayList.get(i2)).intValue());
            }
            return c;
        }
        return k(i);
    }

    public final boolean o(int i) {
        int i2;
        Chip chip = this.i;
        if ((!chip.isFocused() && !chip.requestFocus()) || (i2 = this.l) == i) {
            return false;
        }
        if (i2 != Integer.MIN_VALUE) {
            j(i2);
        }
        if (i == Integer.MIN_VALUE) {
            return false;
        }
        this.l = i;
        if (i == 1) {
            Chip chip2 = this.n;
            chip2.m = true;
            chip2.refreshDrawableState();
        }
        p(i, 8);
        return true;
    }

    public final void p(int i, int i2) {
        View view;
        ViewParent parent;
        AccessibilityEvent obtain;
        if (i == Integer.MIN_VALUE || !this.h.isEnabled() || (parent = (view = this.i).getParent()) == null) {
            return;
        }
        if (i != -1) {
            obtain = AccessibilityEvent.obtain(i2);
            C n = n(i);
            obtain.getText().add(n.g());
            AccessibilityNodeInfo accessibilityNodeInfo = n.a;
            obtain.setContentDescription(accessibilityNodeInfo.getContentDescription());
            obtain.setScrollable(accessibilityNodeInfo.isScrollable());
            obtain.setPassword(accessibilityNodeInfo.isPassword());
            obtain.setEnabled(accessibilityNodeInfo.isEnabled());
            obtain.setChecked(accessibilityNodeInfo.isChecked());
            if (obtain.getText().isEmpty() && obtain.getContentDescription() == null) {
                throw new RuntimeException("Callbacks must add text or a content description in populateEventForVirtualViewId()");
            }
            obtain.setClassName(accessibilityNodeInfo.getClassName());
            obtain.setSource(view, i);
            obtain.setPackageName(view.getContext().getPackageName());
        } else {
            obtain = AccessibilityEvent.obtain(i2);
            view.onInitializeAccessibilityEvent(obtain);
        }
        parent.requestSendAccessibilityEvent(view, obtain);
    }
}
