package x;

import android.animation.Animator;
import android.animation.ObjectAnimator;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Picture;
import android.graphics.RectF;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import java.util.HashMap;
import org.conscrypt.R;

/* renamed from: x.i7, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0167i7 extends AbstractC0270ng {
    public static final String[] B = {"android:visibility:visibility", "android:visibility:parent"};
    public final int A;

    public C0167i7(int i) {
        this();
        this.A = i;
    }

    public static void I(C0421vg c0421vg) {
        int visibility = c0421vg.b.getVisibility();
        HashMap hashMap = c0421vg.a;
        hashMap.put("android:visibility:visibility", Integer.valueOf(visibility));
        View view = c0421vg.b;
        hashMap.put("android:visibility:parent", view.getParent());
        int[] iArr = new int[2];
        view.getLocationOnScreen(iArr);
        hashMap.put("android:visibility:screenLocation", iArr);
    }

    public static float K(C0421vg c0421vg, float f) {
        Float f2;
        if (c0421vg != null && (f2 = (Float) c0421vg.a.get("android:fade:transitionAlpha")) != null) {
            return f2.floatValue();
        }
        return f;
    }

    /* JADX WARN: Removed duplicated region for block: B:12:0x0059 A[ADDED_TO_REGION] */
    /* JADX WARN: Removed duplicated region for block: B:32:0x008c  */
    /* JADX WARN: Removed duplicated region for block: B:36:0x0097  */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0035  */
    /* JADX WARN: Type inference failed for: r0v0, types: [java.lang.Object, x.Th] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static Th L(C0421vg c0421vg, C0421vg c0421vg2) {
        ?? obj = new Object();
        obj.a = false;
        obj.b = false;
        if (c0421vg != null) {
            HashMap hashMap = c0421vg.a;
            if (hashMap.containsKey("android:visibility:visibility")) {
                obj.c = ((Integer) hashMap.get("android:visibility:visibility")).intValue();
                obj.e = (ViewGroup) hashMap.get("android:visibility:parent");
                if (c0421vg2 != null) {
                    HashMap hashMap2 = c0421vg2.a;
                    if (hashMap2.containsKey("android:visibility:visibility")) {
                        obj.d = ((Integer) hashMap2.get("android:visibility:visibility")).intValue();
                        obj.f = (ViewGroup) hashMap2.get("android:visibility:parent");
                        if (c0421vg == null && c0421vg2 != null) {
                            int i = obj.c;
                            int i2 = obj.d;
                            if (i == i2 && obj.e == obj.f) {
                                return obj;
                            }
                            if (i != i2) {
                                if (i == 0) {
                                    obj.b = false;
                                    obj.a = true;
                                } else if (i2 == 0) {
                                    obj.b = true;
                                    obj.a = true;
                                }
                            } else if (obj.f == null) {
                                obj.b = false;
                                obj.a = true;
                            } else if (obj.e == null) {
                                obj.b = true;
                                obj.a = true;
                            }
                        } else if (c0421vg != null && obj.d == 0) {
                            obj.b = true;
                            obj.a = true;
                        } else if (c0421vg2 == null && obj.c == 0) {
                            obj.b = false;
                            obj.a = true;
                        }
                        return obj;
                    }
                }
                obj.d = -1;
                obj.f = null;
                if (c0421vg == null) {
                }
                if (c0421vg != null) {
                }
                if (c0421vg2 == null) {
                    obj.b = false;
                    obj.a = true;
                }
                return obj;
            }
        }
        obj.c = -1;
        obj.e = null;
        if (c0421vg2 != null) {
        }
        obj.d = -1;
        obj.f = null;
        if (c0421vg == null) {
        }
        if (c0421vg != null) {
        }
        if (c0421vg2 == null) {
        }
        return obj;
    }

    public final ObjectAnimator J(View view, float f, float f2) {
        if (f == f2) {
            return null;
        }
        Hh.a.V(view, f);
        ObjectAnimator ofFloat = ObjectAnimator.ofFloat(view, Hh.b, f2);
        C0148h7 c0148h7 = new C0148h7(view);
        ofFloat.addListener(c0148h7);
        o().a(c0148h7);
        return ofFloat;
    }

    @Override // x.AbstractC0270ng
    public final void d(C0421vg c0421vg) {
        I(c0421vg);
    }

    @Override // x.AbstractC0270ng
    public final void g(C0421vg c0421vg) {
        I(c0421vg);
        View view = c0421vg.b;
        Float f = (Float) view.getTag(R.id.transition_pause_alpha);
        if (f == null) {
            if (view.getVisibility() == 0) {
                f = Float.valueOf(Hh.a.C(view));
            } else {
                f = Float.valueOf(0.0f);
            }
        }
        c0421vg.a.put("android:fade:transitionAlpha", f);
    }

    /* JADX WARN: Code restructure failed: missing block: B:15:0x0047, code lost:
    
        if (L(n(r3, false), r(r3, false)).a != false) goto L20;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:63:0x009c  */
    /* JADX WARN: Removed duplicated region for block: B:79:0x01d1  */
    /* JADX WARN: Type inference failed for: r9v1 */
    /* JADX WARN: Type inference failed for: r9v2, types: [android.view.ViewGroup] */
    /* JADX WARN: Type inference failed for: r9v6 */
    @Override // x.AbstractC0270ng
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final Animator k(FrameLayout frameLayout, C0421vg c0421vg, C0421vg c0421vg2) {
        View view;
        boolean z;
        View view2;
        int i;
        View view3;
        View view4;
        boolean z2;
        ?? r9;
        int i2;
        Bitmap bitmap;
        int i3 = this.A;
        Th L = L(c0421vg, c0421vg2);
        if (!L.a || (L.e == null && L.f == null)) {
            return null;
        }
        boolean z3 = false;
        if (L.b) {
            if ((i3 & 1) == 1 && c0421vg2 != null) {
                View view5 = c0421vg2.b;
                if (c0421vg == null) {
                    View view6 = (View) view5.getParent();
                }
                Hh.a.getClass();
                return J(view5, K(c0421vg, 0.0f), 1.0f);
            }
            return null;
        }
        int i4 = L.d;
        if ((i3 & 2) == 2 && c0421vg != null) {
            if (c0421vg2 != null) {
                view = c0421vg2.b;
            } else {
                view = null;
            }
            View view7 = c0421vg.b;
            View view8 = (View) view7.getTag(R.id.save_overlay_view);
            if (view8 != null) {
                i = i4;
                z3 = true;
                view4 = null;
            } else {
                if (view != null && view.getParent() != null) {
                    if (i4 == 4 || view7 == view) {
                        view2 = view;
                        z = false;
                        view = null;
                        if (z) {
                        }
                        i = i4;
                        view3 = view2;
                        view8 = view;
                        view4 = view3;
                        z3 = false;
                    }
                } else if (view != null) {
                    z = false;
                    view2 = null;
                    if (z) {
                        if (view7.getParent() == null) {
                            i = i4;
                            view4 = view2;
                            view8 = view7;
                        } else if (view7.getParent() instanceof View) {
                            View view9 = (View) view7.getParent();
                            if (!L(r(view9, true), n(view9, true)).a) {
                                boolean z4 = AbstractC0402ug.a;
                                Matrix matrix = new Matrix();
                                matrix.setTranslate(-view9.getScrollX(), -view9.getScrollY());
                                Nh nh = Hh.a;
                                nh.b0(view7, matrix);
                                nh.c0(frameLayout, matrix);
                                RectF rectF = new RectF(0.0f, 0.0f, view7.getWidth(), view7.getHeight());
                                matrix.mapRect(rectF);
                                int round = Math.round(rectF.left);
                                int round2 = Math.round(rectF.top);
                                int round3 = Math.round(rectF.right);
                                int round4 = Math.round(rectF.bottom);
                                ImageView imageView = new ImageView(view7.getContext());
                                imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
                                boolean isAttachedToWindow = view7.isAttachedToWindow();
                                if (frameLayout != null && frameLayout.isAttachedToWindow()) {
                                    z2 = true;
                                } else {
                                    z2 = false;
                                }
                                if (!isAttachedToWindow) {
                                    if (!z2) {
                                        i = i4;
                                        view3 = view2;
                                        bitmap = null;
                                        if (bitmap != null) {
                                            imageView.setImageBitmap(bitmap);
                                        }
                                        imageView.measure(View.MeasureSpec.makeMeasureSpec(round3 - round, 1073741824), View.MeasureSpec.makeMeasureSpec(round4 - round2, 1073741824));
                                        imageView.layout(round, round2, round3, round4);
                                        view8 = imageView;
                                        view4 = view3;
                                        z3 = false;
                                    } else {
                                        ViewGroup viewGroup = (ViewGroup) view7.getParent();
                                        int indexOfChild = viewGroup.indexOfChild(view7);
                                        frameLayout.getOverlay().add(view7);
                                        r9 = viewGroup;
                                        view3 = view2;
                                        i2 = indexOfChild;
                                    }
                                } else {
                                    view3 = view2;
                                    r9 = 1;
                                    i2 = 0;
                                }
                                i = i4;
                                int round5 = Math.round(rectF.width());
                                int round6 = Math.round(rectF.height());
                                if (round5 > 0 && round6 > 0) {
                                    float min = Math.min(1.0f, 1048576.0f / (round5 * round6));
                                    int round7 = Math.round(round5 * min);
                                    int round8 = Math.round(round6 * min);
                                    matrix.postTranslate(-rectF.left, -rectF.top);
                                    matrix.postScale(min, min);
                                    if (AbstractC0402ug.a) {
                                        Picture picture = new Picture();
                                        Canvas beginRecording = picture.beginRecording(round7, round8);
                                        beginRecording.concat(matrix);
                                        view7.draw(beginRecording);
                                        picture.endRecording();
                                        bitmap = AbstractC0383tg.a(picture);
                                    } else {
                                        bitmap = Bitmap.createBitmap(round7, round8, Bitmap.Config.ARGB_8888);
                                        Canvas canvas = new Canvas(bitmap);
                                        canvas.concat(matrix);
                                        view7.draw(canvas);
                                    }
                                } else {
                                    bitmap = null;
                                }
                                if (!isAttachedToWindow) {
                                    frameLayout.getOverlay().remove(view7);
                                    r9.addView(view7, i2);
                                }
                                if (bitmap != null) {
                                }
                                imageView.measure(View.MeasureSpec.makeMeasureSpec(round3 - round, 1073741824), View.MeasureSpec.makeMeasureSpec(round4 - round2, 1073741824));
                                imageView.layout(round, round2, round3, round4);
                                view8 = imageView;
                                view4 = view3;
                                z3 = false;
                            } else {
                                i = i4;
                                view3 = view2;
                                int id = view9.getId();
                                if (view9.getParent() == null && id != -1) {
                                    frameLayout.findViewById(id);
                                }
                                view8 = view;
                                view4 = view3;
                                z3 = false;
                            }
                        }
                    }
                    i = i4;
                    view3 = view2;
                    view8 = view;
                    view4 = view3;
                    z3 = false;
                }
                z = true;
                view = null;
                view2 = null;
                if (z) {
                }
                i = i4;
                view3 = view2;
                view8 = view;
                view4 = view3;
                z3 = false;
            }
            if (view8 != null) {
                if (!z3) {
                    int[] iArr = (int[]) c0421vg.a.get("android:visibility:screenLocation");
                    int i5 = iArr[0];
                    int i6 = iArr[1];
                    int[] iArr2 = new int[2];
                    frameLayout.getLocationOnScreen(iArr2);
                    view8.offsetLeftAndRight((i5 - iArr2[0]) - view8.getLeft());
                    view8.offsetTopAndBottom((i6 - iArr2[1]) - view8.getTop());
                    frameLayout.getOverlay().add(view8);
                }
                Nh nh2 = Hh.a;
                nh2.getClass();
                ObjectAnimator J = J(view8, K(c0421vg, 1.0f), 0.0f);
                if (J == null) {
                    nh2.V(view8, K(c0421vg2, 1.0f));
                }
                if (!z3) {
                    if (J == null) {
                        frameLayout.getOverlay().remove(view8);
                        return J;
                    }
                    view7.setTag(R.id.save_overlay_view, view8);
                    Sh sh = new Sh(this, frameLayout, view8, view7);
                    J.addListener(sh);
                    J.addPauseListener(sh);
                    o().a(sh);
                    return J;
                }
                return J;
            }
            if (view4 != null) {
                int visibility = view4.getVisibility();
                Hh.b(view4, 0);
                Nh nh3 = Hh.a;
                nh3.getClass();
                ObjectAnimator J2 = J(view4, K(c0421vg, 1.0f), 0.0f);
                if (J2 == null) {
                    nh3.V(view4, K(c0421vg2, 1.0f));
                }
                if (J2 != null) {
                    Rh rh = new Rh(view4, i);
                    J2.addListener(rh);
                    o().a(rh);
                } else {
                    Hh.b(view4, visibility);
                }
                return J2;
            }
        }
        return null;
    }

    @Override // x.AbstractC0270ng
    public final String[] q() {
        return B;
    }

    @Override // x.AbstractC0270ng
    public final boolean s(C0421vg c0421vg, C0421vg c0421vg2) {
        if (c0421vg == null && c0421vg2 == null) {
            return false;
        }
        if (c0421vg != null && c0421vg2 != null && c0421vg2.a.containsKey("android:visibility:visibility") != c0421vg.a.containsKey("android:visibility:visibility")) {
            return false;
        }
        Th L = L(c0421vg, c0421vg2);
        if (!L.a) {
            return false;
        }
        if (L.c != 0 && L.d != 0) {
            return false;
        }
        return true;
    }

    public C0167i7() {
        this.A = 3;
    }
}
