package x;

import android.content.res.ColorStateList;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;

/* renamed from: x.db, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public class C0072db extends Drawable.ConstantState {
    public C0495ze a;
    public C0147h6 b;
    public ColorStateList c;
    public ColorStateList d;
    public ColorStateList e;
    public PorterDuff.Mode f;
    public Rect g;
    public final float h;
    public float i;
    public float j;
    public int k;
    public float l;
    public float m;
    public int n;
    public int o;
    public final Paint.Style p;

    public C0072db(C0495ze c0495ze) {
        this.c = null;
        this.d = null;
        this.e = null;
        this.f = PorterDuff.Mode.SRC_IN;
        this.g = null;
        this.h = 1.0f;
        this.i = 1.0f;
        this.k = 255;
        this.l = 0.0f;
        this.m = 0.0f;
        this.n = 0;
        this.o = 0;
        this.p = Paint.Style.FILL_AND_STROKE;
        this.a = c0495ze;
        this.b = null;
    }

    @Override // android.graphics.drawable.Drawable.ConstantState
    public final int getChangingConfigurations() {
        return 0;
    }

    @Override // android.graphics.drawable.Drawable.ConstantState
    public Drawable newDrawable() {
        C0092eb c0092eb = new C0092eb(this);
        c0092eb.e = true;
        return c0092eb;
    }

    public C0072db(C0072db c0072db) {
        this.c = null;
        this.d = null;
        this.e = null;
        this.f = PorterDuff.Mode.SRC_IN;
        this.g = null;
        this.h = 1.0f;
        this.i = 1.0f;
        this.k = 255;
        this.l = 0.0f;
        this.m = 0.0f;
        this.n = 0;
        this.o = 0;
        this.p = Paint.Style.FILL_AND_STROKE;
        this.a = c0072db.a;
        this.b = c0072db.b;
        this.j = c0072db.j;
        this.c = c0072db.c;
        this.d = c0072db.d;
        this.f = c0072db.f;
        this.e = c0072db.e;
        this.k = c0072db.k;
        this.h = c0072db.h;
        this.o = c0072db.o;
        this.i = c0072db.i;
        this.l = c0072db.l;
        this.m = c0072db.m;
        this.n = c0072db.n;
        this.p = c0072db.p;
        if (c0072db.g != null) {
            this.g = new Rect(c0072db.g);
        }
    }
}
