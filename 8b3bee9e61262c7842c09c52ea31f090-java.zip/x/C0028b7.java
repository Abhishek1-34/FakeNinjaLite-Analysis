package x;

/* renamed from: x.b7, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0028b7 {
    public float a;
    public float b;

    public C0028b7() {
    }

    public C0028b7(float f, float f2) {
        this.a = f;
        this.b = f2;
    }
}
