package x;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.view.WindowManager;
import android.widget.TextView;

/* renamed from: x.z0, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0481z0 {
    public static Context b;
    public static WindowManager c;
    public static TextView d;
    public static WindowManager.LayoutParams e;
    public static volatile boolean f;
    public static volatile boolean g;
    public static final Handler a = new Handler(Looper.getMainLooper());
    public static volatile int h = 38;
    public static volatile int i = 4;

    public static void a(Context context) {
        if (context == null) {
            return;
        }
        Context applicationContext = context.getApplicationContext();
        b = applicationContext;
        SharedPreferences sharedPreferences = applicationContext.getSharedPreferences("proxy_read", 0);
        sharedPreferences.getBoolean("aim_assist_on", false);
        f = false;
        h = Math.max(10, Math.min(100, sharedPreferences.getInt("aim_strength", 38)));
        i = Math.max(1, Math.min(10, sharedPreferences.getInt("aim_smoothing", 4)));
        a.post(new RunnableC0443x0(2));
    }

    public static void b() {
        TextView textView = d;
        WindowManager windowManager = c;
        d = null;
        c = null;
        e = null;
        if (textView != null && windowManager != null) {
            try {
                windowManager.removeViewImmediate(textView);
            } catch (RuntimeException unused) {
            }
        }
    }

    public static void c() {
        boolean z;
        int rgb;
        int rgb2;
        String str;
        TextView textView = d;
        if (textView == null) {
            return;
        }
        if (vpn.team09.hax.d.c != null) {
            z = true;
        } else {
            z = false;
        }
        boolean z2 = vpn.team09.hax.d.d;
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setShape(1);
        if (z2) {
            rgb = Color.rgb(229, 9, 20);
        } else {
            rgb = Color.rgb(15, 17, 22);
        }
        gradientDrawable.setColor(rgb);
        if (z) {
            rgb2 = Color.rgb(229, 9, 20);
        } else {
            rgb2 = Color.rgb(255, 185, 35);
        }
        gradientDrawable.setStroke(2, rgb2);
        textView.setBackground(gradientDrawable);
        if (!z) {
            str = "ATIVAR\nACESSO";
        } else if (z2) {
            str = "MIRA\nON";
        } else {
            str = "MIRA\nOFF";
        }
        textView.setText(str);
    }
}
