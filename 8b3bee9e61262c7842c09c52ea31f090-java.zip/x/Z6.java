package x;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.view.WindowManager;
import java.util.LinkedHashSet;
import java.util.concurrent.atomic.AtomicLong;
import org.conscrypt.BuildConfig;

/* loaded from: classes.dex */
public abstract class Z6 {
    public static volatile boolean e;
    public static volatile boolean f;
    public static volatile boolean g;
    public static volatile boolean h;
    public static volatile boolean i;
    public static volatile long t;
    public static Context u;
    public static WindowManager v;
    public static ChoreographerFrameCallbackC0048c7 w;
    public static final Handler a = new Handler(Looper.getMainLooper());
    public static final AtomicLong b = new AtomicLong();
    public static final AtomicLong c = new AtomicLong();
    public static volatile boolean d = false;
    public static volatile int j = 100;
    public static volatile int k = 0;
    public static volatile int l = 0;
    public static volatile int m = -1;
    public static volatile int n = 130;
    public static volatile int o = 0;

    /* renamed from: x, reason: collision with root package name */
    public static volatile int f20x = 1;
    public static volatile float p = Float.NaN;
    public static volatile float q = Float.NaN;
    public static volatile float r = Float.NaN;
    public static volatile float s = Float.NaN;

    public static void a() {
        p = Float.NaN;
        q = Float.NaN;
        r = Float.NaN;
        s = Float.NaN;
        t = 0L;
    }

    public static void b(Context context) {
        if (context == null) {
            return;
        }
        Context applicationContext = context.getApplicationContext();
        u = applicationContext;
        SharedPreferences sharedPreferences = applicationContext.getSharedPreferences("proxy_read", 0);
        d = sharedPreferences.getBoolean("radar_on", false);
        e = sharedPreferences.getBoolean("esp_on", false);
        f = sharedPreferences.getBoolean("aim_visual_on", false);
        g = sharedPreferences.getBoolean("fov_on", false);
        j = sharedPreferences.getInt("radar_size", 100);
        k = sharedPreferences.getInt("esp_offset_x", 0);
        l = sharedPreferences.getInt("esp_move_offset", 0);
        m = sharedPreferences.getInt("esp_color", 62975) | (-16777216);
        n = sharedPreferences.getInt("fov_size", 130);
        o = sharedPreferences.getInt("aim_position", 0);
        c();
    }

    public static void c() {
        boolean z;
        Context context = u;
        if (context != null && Settings.canDrawOverlays(context)) {
            z = true;
        } else {
            z = false;
        }
        h = z;
        d();
    }

    public static void d() {
        a.post(new RunnableC0443x0(4));
    }

    public static void e() {
        ChoreographerFrameCallbackC0048c7 choreographerFrameCallbackC0048c7 = w;
        WindowManager windowManager = v;
        w = null;
        v = null;
        if (choreographerFrameCallbackC0048c7 != null && windowManager != null) {
            try {
                windowManager.removeViewImmediate(choreographerFrameCallbackC0048c7);
            } catch (RuntimeException unused) {
            }
            Yb.h("Sobreposição do ESP/Radar removida da tela");
        }
    }

    public static void f() {
        b.set(0L);
        c.set(0L);
        synchronized (AbstractC0124g3.n) {
            AbstractC0124g3.o = BuildConfig.FLAVOR;
            AbstractC0124g3.p = 0L;
            AbstractC0124g3.q = 0L;
            AbstractC0124g3.r = 0L;
            AbstractC0124g3.s = 0L;
            AbstractC0124g3.t = 0L;
            AbstractC0124g3.u = 0L;
            AbstractC0124g3.S(SystemClock.uptimeMillis());
        }
        Y6.n.b();
        LinkedHashSet linkedHashSet = Ic.a;
        synchronized (Ic.class) {
            Ic.a.clear();
        }
    }
}
