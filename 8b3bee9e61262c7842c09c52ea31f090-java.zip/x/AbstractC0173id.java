package x;

import android.R;

/* renamed from: x.id, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0173id {
    public static final int[] a = {R.attr.orientation, R.attr.clipToPadding, R.attr.descendantFocusability, org.conscrypt.R.attr.fastScrollEnabled, org.conscrypt.R.attr.fastScrollHorizontalThumbDrawable, org.conscrypt.R.attr.fastScrollHorizontalTrackDrawable, org.conscrypt.R.attr.fastScrollVerticalThumbDrawable, org.conscrypt.R.attr.fastScrollVerticalTrackDrawable, org.conscrypt.R.attr.layoutManager, org.conscrypt.R.attr.reverseLayout, org.conscrypt.R.attr.spanCount, org.conscrypt.R.attr.stackFromEnd};
}
