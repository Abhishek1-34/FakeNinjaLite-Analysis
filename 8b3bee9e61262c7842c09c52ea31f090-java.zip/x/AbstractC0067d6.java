package x;

import android.widget.EdgeEffect;

/* renamed from: x.d6, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0067d6 {
    public static void a(EdgeEffect edgeEffect, float f, float f2) {
        edgeEffect.onPull(f, f2);
    }
}
