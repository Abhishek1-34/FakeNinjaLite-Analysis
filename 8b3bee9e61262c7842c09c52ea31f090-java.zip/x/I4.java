package x;

/* loaded from: classes.dex */
public final class I4 {
    public final H4 a;

    public I4(H4 h4) {
        this.a = h4;
    }

    public final String toString() {
        return this.a.toString();
    }
}
