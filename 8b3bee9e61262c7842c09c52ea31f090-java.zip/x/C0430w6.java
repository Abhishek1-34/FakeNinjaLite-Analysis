package x;

import android.text.InputFilter;
import android.text.Spanned;
import android.widget.TextView;

/* renamed from: x.w6, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0430w6 implements InputFilter {
    public final TextView a;
    public C0411v6 b;

    public C0430w6(TextView textView) {
        this.a = textView;
    }

    @Override // android.text.InputFilter
    public final CharSequence filter(CharSequence charSequence, int i, int i2, Spanned spanned, int i3, int i4) {
        TextView textView = this.a;
        if (textView.isInEditMode()) {
            return charSequence;
        }
        int b = C0260n6.a().b();
        if (b != 0) {
            if (b != 1) {
                if (b != 3) {
                    return charSequence;
                }
            } else {
                if ((i4 != 0 || i3 != 0 || spanned.length() != 0 || charSequence != textView.getText()) && charSequence != null) {
                    if (i != 0 || i2 != charSequence.length()) {
                        charSequence = charSequence.subSequence(i, i2);
                    }
                    return C0260n6.a().e(charSequence, 0, charSequence.length());
                }
                return charSequence;
            }
        }
        C0260n6 a = C0260n6.a();
        if (this.b == null) {
            this.b = new C0411v6(textView, this);
        }
        a.f(this.b);
        return charSequence;
    }
}
