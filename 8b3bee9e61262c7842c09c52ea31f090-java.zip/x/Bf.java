package x;

import android.os.Build;
import android.view.View;
import java.nio.ByteBuffer;

/* loaded from: classes.dex */
public abstract class Bf {
    public int a;
    public int b;
    public int c;
    public Object d;

    /* JADX WARN: Type inference failed for: r0v1, types: [x.jg, java.lang.Object] */
    public Bf() {
        if (C0194jg.a == null) {
            C0194jg.a = new Object();
        }
    }

    public int a(int i) {
        if (i < this.c) {
            return ((ByteBuffer) this.d).getShort(this.b + i);
        }
        return 0;
    }

    public abstract Object b(View view);

    public abstract void c(View view, Object obj);

    public void d(View view, Object obj) {
        Object tag;
        C0291p c0291p;
        if (Build.VERSION.SDK_INT >= this.b) {
            c(view, obj);
            return;
        }
        if (Build.VERSION.SDK_INT >= this.b) {
            tag = b(view);
        } else {
            tag = view.getTag(this.a);
            if (!((Class) this.d).isInstance(tag)) {
                tag = null;
            }
        }
        if (e(tag, obj)) {
            View.AccessibilityDelegate c = AbstractC0309ph.c(view);
            if (c == null) {
                c0291p = null;
            } else if (c instanceof C0272o) {
                c0291p = ((C0272o) c).a;
            } else {
                c0291p = new C0291p(c);
            }
            if (c0291p == null) {
                c0291p = new C0291p();
            }
            AbstractC0309ph.l(view, c0291p);
            view.setTag(this.a, obj);
            AbstractC0309ph.g(view, this.c);
        }
    }

    public abstract boolean e(Object obj, Object obj2);
}
