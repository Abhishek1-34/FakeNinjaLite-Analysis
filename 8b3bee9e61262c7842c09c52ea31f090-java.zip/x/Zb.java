package x;

import android.R;
import android.app.PendingIntent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import androidx.core.graphics.drawable.IconCompat;
import java.lang.reflect.InvocationTargetException;

/* loaded from: classes.dex */
public final class Zb {
    public final Bundle a;
    public IconCompat b;
    public final boolean c;
    public final boolean d;
    public final int e;
    public final CharSequence f;
    public final PendingIntent g;

    /* JADX WARN: Removed duplicated region for block: B:18:0x007a  */
    /* JADX WARN: Removed duplicated region for block: B:21:0x008a  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public Zb(PendingIntent pendingIntent) {
        IconCompat a = IconCompat.a(R.drawable.ic_menu_close_clear_cancel);
        Bundle bundle = new Bundle();
        this.d = true;
        this.b = a;
        int i = a.a;
        if (i == -1) {
            int i2 = Build.VERSION.SDK_INT;
            Object obj = a.b;
            if (i2 >= 28) {
                i = L5.j(obj);
            } else {
                try {
                    i = ((Integer) obj.getClass().getMethod("getType", null).invoke(obj, null)).intValue();
                } catch (IllegalAccessException e) {
                    Log.e("IconCompat", "Unable to get icon type " + obj, e);
                    i = -1;
                    if (i == 2) {
                    }
                    this.f = "Parar".length() > 5120 ? "Parar".subSequence(0, 5120) : "Parar";
                    this.g = pendingIntent;
                    this.a = bundle;
                    this.c = true;
                    this.d = true;
                } catch (NoSuchMethodException e2) {
                    Log.e("IconCompat", "Unable to get icon type " + obj, e2);
                    i = -1;
                    if (i == 2) {
                    }
                    this.f = "Parar".length() > 5120 ? "Parar".subSequence(0, 5120) : "Parar";
                    this.g = pendingIntent;
                    this.a = bundle;
                    this.c = true;
                    this.d = true;
                } catch (InvocationTargetException e3) {
                    Log.e("IconCompat", "Unable to get icon type " + obj, e3);
                    i = -1;
                    if (i == 2) {
                    }
                    this.f = "Parar".length() > 5120 ? "Parar".subSequence(0, 5120) : "Parar";
                    this.g = pendingIntent;
                    this.a = bundle;
                    this.c = true;
                    this.d = true;
                }
            }
        }
        if (i == 2) {
            this.e = a.b();
        }
        this.f = "Parar".length() > 5120 ? "Parar".subSequence(0, 5120) : "Parar";
        this.g = pendingIntent;
        this.a = bundle;
        this.c = true;
        this.d = true;
    }
}
