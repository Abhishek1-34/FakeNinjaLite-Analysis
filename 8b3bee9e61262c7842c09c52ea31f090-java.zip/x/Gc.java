package x;

/* loaded from: classes.dex */
public abstract class Gc {
    public static final Fc a;

    /* JADX WARN: Multi-variable type inference failed */
    static {
        Fc fc;
        try {
            Object newInstance = H9.class.newInstance();
            E9.n(newInstance, "forName(\"kotlin.internal…entations\").newInstance()");
            try {
                try {
                    fc = (Fc) newInstance;
                } catch (ClassCastException e) {
                    ClassLoader classLoader = newInstance.getClass().getClassLoader();
                    ClassLoader classLoader2 = Fc.class.getClassLoader();
                    if (!E9.c(classLoader, classLoader2)) {
                        throw new ClassNotFoundException("Instance class was loaded from a different classloader: " + classLoader + ", base type classloader: " + classLoader2, e);
                    }
                    throw e;
                }
            } catch (ClassNotFoundException unused) {
                Object newInstance2 = F9.class.newInstance();
                E9.n(newInstance2, "forName(\"kotlin.internal…entations\").newInstance()");
                try {
                    try {
                        fc = (Fc) newInstance2;
                    } catch (ClassNotFoundException unused2) {
                        fc = new Object();
                    }
                } catch (ClassCastException e2) {
                    ClassLoader classLoader3 = newInstance2.getClass().getClassLoader();
                    ClassLoader classLoader4 = Fc.class.getClassLoader();
                    if (!E9.c(classLoader3, classLoader4)) {
                        throw new ClassNotFoundException("Instance class was loaded from a different classloader: " + classLoader3 + ", base type classloader: " + classLoader4, e2);
                    }
                    throw e2;
                }
            }
        } catch (ClassNotFoundException unused3) {
            Object newInstance3 = Class.forName("kotlin.internal.JRE8PlatformImplementations").newInstance();
            E9.n(newInstance3, "forName(\"kotlin.internal…entations\").newInstance()");
            try {
                try {
                    fc = (Fc) newInstance3;
                } catch (ClassNotFoundException unused4) {
                    Object newInstance4 = Class.forName("kotlin.internal.JRE7PlatformImplementations").newInstance();
                    E9.n(newInstance4, "forName(\"kotlin.internal…entations\").newInstance()");
                    try {
                        fc = (Fc) newInstance4;
                    } catch (ClassCastException e3) {
                        ClassLoader classLoader5 = newInstance4.getClass().getClassLoader();
                        ClassLoader classLoader6 = Fc.class.getClassLoader();
                        if (!E9.c(classLoader5, classLoader6)) {
                            throw new ClassNotFoundException("Instance class was loaded from a different classloader: " + classLoader5 + ", base type classloader: " + classLoader6, e3);
                        }
                        throw e3;
                    }
                }
            } catch (ClassCastException e4) {
                ClassLoader classLoader7 = newInstance3.getClass().getClassLoader();
                ClassLoader classLoader8 = Fc.class.getClassLoader();
                if (!E9.c(classLoader7, classLoader8)) {
                    throw new ClassNotFoundException("Instance class was loaded from a different classloader: " + classLoader7 + ", base type classloader: " + classLoader8, e4);
                }
                throw e4;
            }
        }
        a = fc;
    }
}
