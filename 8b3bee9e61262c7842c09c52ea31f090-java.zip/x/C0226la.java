package x;

import android.view.View;
import android.widget.AdapterView;

/* renamed from: x.la, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0226la implements AdapterView.OnItemSelectedListener {
    public final /* synthetic */ C0358sa a;

    public C0226la(C0358sa c0358sa) {
        this.a = c0358sa;
    }

    @Override // android.widget.AdapterView.OnItemSelectedListener
    public final void onItemSelected(AdapterView adapterView, View view, int i, long j) {
        X5 x5;
        if (i != -1 && (x5 = this.a.c) != null) {
            x5.setListSelectionHidden(false);
        }
    }

    @Override // android.widget.AdapterView.OnItemSelectedListener
    public final void onNothingSelected(AdapterView adapterView) {
    }
}
