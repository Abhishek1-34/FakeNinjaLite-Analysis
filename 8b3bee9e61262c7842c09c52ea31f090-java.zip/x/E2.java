package x;

/* loaded from: classes.dex */
public abstract class E2 extends AbstractC0124g3 {
    public static void b0(int i, int i2, int i3, int[] iArr, int[] iArr2) {
        E9.o(iArr, "<this>");
        E9.o(iArr2, "destination");
        System.arraycopy(iArr, i2, iArr2, i, i3 - i2);
    }

    public static void c0(Object[] objArr, Object[] objArr2, int i, int i2, int i3) {
        E9.o(objArr, "<this>");
        E9.o(objArr2, "destination");
        System.arraycopy(objArr, i2, objArr2, i, i3 - i2);
    }

    public static /* synthetic */ void d0(Object[] objArr, Object[] objArr2, int i, int i2, int i3) {
        if ((i3 & 4) != 0) {
            i = 0;
        }
        c0(objArr, objArr2, 0, i, i2);
    }
}
