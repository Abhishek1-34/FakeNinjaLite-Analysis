package x;

/* loaded from: classes.dex */
public interface Db {
    void c(C0303pb c0303pb);

    C0303pb getItemData();
}
