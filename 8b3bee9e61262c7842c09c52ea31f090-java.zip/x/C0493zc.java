package x;

import java.util.Objects;

/* renamed from: x.zc, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0493zc {
    public final Long a;
    public final Integer b;

    public C0493zc(Long l, Integer num) {
        this.a = l;
        this.b = num;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof C0493zc)) {
            return false;
        }
        C0493zc c0493zc = (C0493zc) obj;
        if (this.a.equals(c0493zc.a) && this.b.equals(c0493zc.b)) {
            return true;
        }
        return false;
    }

    public final int hashCode() {
        return Objects.hash(this.a, this.b);
    }
}
