package x;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;

/* renamed from: x.y8, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0470y8 implements Parcelable {
    public static final Parcelable.Creator<C0470y8> CREATOR = new C0197k0(8);
    public final String a;
    public final String b;
    public final boolean c;
    public final int d;
    public final int e;
    public final String f;
    public final boolean g;
    public final boolean h;
    public final boolean i;
    public final Bundle j;
    public final boolean k;
    public final int l;
    public Bundle m;

    public C0470y8(AbstractComponentCallbacksC0089e8 abstractComponentCallbacksC0089e8) {
        this.a = abstractComponentCallbacksC0089e8.getClass().getName();
        this.b = abstractComponentCallbacksC0089e8.e;
        this.c = abstractComponentCallbacksC0089e8.m;
        this.d = abstractComponentCallbacksC0089e8.v;
        this.e = abstractComponentCallbacksC0089e8.w;
        this.f = abstractComponentCallbacksC0089e8.f22x;
        this.g = abstractComponentCallbacksC0089e8.A;
        this.h = abstractComponentCallbacksC0089e8.l;
        this.i = abstractComponentCallbacksC0089e8.z;
        this.j = abstractComponentCallbacksC0089e8.f;
        this.k = abstractComponentCallbacksC0089e8.y;
        this.l = abstractComponentCallbacksC0089e8.L.ordinal();
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder(128);
        sb.append("FragmentState{");
        sb.append(this.a);
        sb.append(" (");
        sb.append(this.b);
        sb.append(")}:");
        if (this.c) {
            sb.append(" fromLayout");
        }
        int i = this.e;
        if (i != 0) {
            sb.append(" id=0x");
            sb.append(Integer.toHexString(i));
        }
        String str = this.f;
        if (str != null && !str.isEmpty()) {
            sb.append(" tag=");
            sb.append(str);
        }
        if (this.g) {
            sb.append(" retainInstance");
        }
        if (this.h) {
            sb.append(" removing");
        }
        if (this.i) {
            sb.append(" detached");
        }
        if (this.k) {
            sb.append(" hidden");
        }
        return sb.toString();
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(this.a);
        parcel.writeString(this.b);
        parcel.writeInt(this.c ? 1 : 0);
        parcel.writeInt(this.d);
        parcel.writeInt(this.e);
        parcel.writeString(this.f);
        parcel.writeInt(this.g ? 1 : 0);
        parcel.writeInt(this.h ? 1 : 0);
        parcel.writeInt(this.i ? 1 : 0);
        parcel.writeBundle(this.j);
        parcel.writeInt(this.k ? 1 : 0);
        parcel.writeBundle(this.m);
        parcel.writeInt(this.l);
    }

    public C0470y8(Parcel parcel) {
        this.a = parcel.readString();
        this.b = parcel.readString();
        this.c = parcel.readInt() != 0;
        this.d = parcel.readInt();
        this.e = parcel.readInt();
        this.f = parcel.readString();
        this.g = parcel.readInt() != 0;
        this.h = parcel.readInt() != 0;
        this.i = parcel.readInt() != 0;
        this.j = parcel.readBundle();
        this.k = parcel.readInt() != 0;
        this.m = parcel.readBundle();
        this.l = parcel.readInt();
    }
}
