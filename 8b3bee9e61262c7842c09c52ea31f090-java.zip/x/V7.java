package x;

/* loaded from: classes.dex */
public final class V7 implements S7 {
    public final L7 a;
    public final L7 b;
    public final int c;
    public final int d;
    public final String e;

    public V7(L7 l7, L7 l72, int i, int i2, String str) {
        this.a = l7;
        this.b = l72;
        this.d = i;
        this.c = i2;
        this.e = str;
    }
}
