package x;

/* loaded from: classes.dex */
public final /* synthetic */ class Fa {
    public final /* synthetic */ vpn.team09.hax.b a;
}
