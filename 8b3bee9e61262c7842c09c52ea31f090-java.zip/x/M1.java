package x;

import android.view.View;
import android.view.ViewTreeObserver;
import java.util.ArrayList;
import java.util.Iterator;

/* loaded from: classes.dex */
public final class M1 implements ViewTreeObserver.OnGlobalLayoutListener {
    public final /* synthetic */ int a;
    public final /* synthetic */ Object b;

    public /* synthetic */ M1(int i, Object obj) {
        this.a = i;
        this.b = obj;
    }

    @Override // android.view.ViewTreeObserver.OnGlobalLayoutListener
    public final void onGlobalLayout() {
        switch (this.a) {
            case 0:
                V1 v1 = (V1) this.b;
                if (!v1.getInternalPopup().a()) {
                    v1.f.f(v1.getTextDirection(), v1.getTextAlignment());
                }
                ViewTreeObserver viewTreeObserver = v1.getViewTreeObserver();
                if (viewTreeObserver != null) {
                    viewTreeObserver.removeOnGlobalLayoutListener(this);
                    return;
                }
                return;
            case 1:
                S1 s1 = (S1) this.b;
                V1 v12 = s1.G;
                s1.getClass();
                if (v12.isAttachedToWindow() && v12.getGlobalVisibleRect(s1.E)) {
                    s1.s();
                    s1.i();
                    return;
                } else {
                    s1.dismiss();
                    return;
                }
            case 2:
                ViewOnKeyListenerC0427w3 viewOnKeyListenerC0427w3 = (ViewOnKeyListenerC0427w3) this.b;
                if (viewOnKeyListenerC0427w3.a()) {
                    ArrayList arrayList = viewOnKeyListenerC0427w3.h;
                    if (arrayList.size() > 0 && !((C0408v3) arrayList.get(0)).a.y) {
                        View view = viewOnKeyListenerC0427w3.o;
                        if (view != null && view.isShown()) {
                            Iterator it = arrayList.iterator();
                            while (it.hasNext()) {
                                ((C0408v3) it.next()).a.i();
                            }
                            return;
                        }
                        viewOnKeyListenerC0427w3.dismiss();
                        return;
                    }
                    return;
                }
                return;
            default:
                ViewOnKeyListenerC0156hf viewOnKeyListenerC0156hf = (ViewOnKeyListenerC0156hf) this.b;
                if (viewOnKeyListenerC0156hf.a()) {
                    Ab ab = viewOnKeyListenerC0156hf.h;
                    if (!ab.y) {
                        View view2 = viewOnKeyListenerC0156hf.m;
                        if (view2 != null && view2.isShown()) {
                            ab.i();
                            return;
                        } else {
                            viewOnKeyListenerC0156hf.dismiss();
                            return;
                        }
                    }
                    return;
                }
                return;
        }
    }
}
