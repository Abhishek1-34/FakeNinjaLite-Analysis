package x;

import java.util.ArrayList;

/* loaded from: classes.dex */
public final class G7 extends AbstractC0338r9 {
    public int A0;
    public V2 B0;
    public C0333r4 C0;
    public int D0;
    public int E0;
    public int F0;
    public int G0;
    public int H0;
    public int I0;
    public float J0;
    public float K0;
    public float L0;
    public float M0;
    public float N0;
    public float O0;
    public int P0;
    public int Q0;
    public int R0;
    public int S0;
    public int T0;
    public int U0;
    public int V0;
    public ArrayList W0;
    public A4[] X0;
    public A4[] Y0;
    public int[] Z0;
    public A4[] a1;
    public int b1;
    public int s0;
    public int t0;
    public int u0;
    public int v0;
    public int w0;
    public int x0;
    public boolean y0;
    public int z0;

    @Override // x.AbstractC0338r9
    public final void S() {
        for (int i = 0; i < this.r0; i++) {
            A4 a4 = this.q0[i];
            if (a4 != null) {
                a4.F = true;
            }
        }
    }

    public final int T(A4 a4, int i) {
        if (a4 == null) {
            return 0;
        }
        int[] iArr = a4.p0;
        if (iArr[1] == 3) {
            int i2 = a4.s;
            if (i2 == 0) {
                return 0;
            }
            if (i2 == 2) {
                int i3 = (int) (a4.z * i);
                if (i3 != a4.k()) {
                    a4.g = true;
                    V(iArr[0], a4.q(), 1, i3, a4);
                }
                return i3;
            }
            if (i2 == 1) {
                return a4.k();
            }
            if (i2 == 3) {
                return (int) ((a4.q() * a4.W) + 0.5f);
            }
        }
        return a4.k();
    }

    public final int U(A4 a4, int i) {
        if (a4 == null) {
            return 0;
        }
        int[] iArr = a4.p0;
        if (iArr[0] == 3) {
            int i2 = a4.r;
            if (i2 == 0) {
                return 0;
            }
            if (i2 == 2) {
                int i3 = (int) (a4.w * i);
                if (i3 != a4.q()) {
                    a4.g = true;
                    V(1, i3, iArr[1], a4.k(), a4);
                }
                return i3;
            }
            if (i2 == 1) {
                return a4.q();
            }
            if (i2 == 3) {
                return (int) ((a4.k() * a4.W) + 0.5f);
            }
        }
        return a4.q();
    }

    public final void V(int i, int i2, int i3, int i4, A4 a4) {
        C0333r4 c0333r4;
        A4 a42;
        while (true) {
            c0333r4 = this.C0;
            if (c0333r4 != null || (a42 = this.T) == null) {
                break;
            } else {
                this.C0 = ((B4) a42).u0;
            }
        }
        V2 v2 = this.B0;
        v2.a = i;
        v2.b = i3;
        v2.c = i2;
        v2.d = i4;
        c0333r4.b(a4, v2);
        a4.O(v2.e);
        a4.L(v2.f);
        a4.E = v2.h;
        a4.I(v2.g);
    }

    @Override // x.A4
    public final void b(C0170ia c0170ia, boolean z) {
        boolean z2;
        boolean z3;
        A4 a4;
        float f;
        int i;
        boolean z4;
        super.b(c0170ia, z);
        A4 a42 = this.T;
        if (a42 != null && ((B4) a42).v0) {
            z2 = true;
        } else {
            z2 = false;
        }
        int i2 = this.T0;
        ArrayList arrayList = this.W0;
        if (i2 != 0) {
            if (i2 != 1) {
                if (i2 != 2) {
                    if (i2 == 3) {
                        int size = arrayList.size();
                        for (int i3 = 0; i3 < size; i3++) {
                            F7 f7 = (F7) arrayList.get(i3);
                            if (i3 == size - 1) {
                                z4 = true;
                            } else {
                                z4 = false;
                            }
                            f7.b(i3, z2, z4);
                        }
                    }
                } else if (this.Z0 != null && this.Y0 != null && this.X0 != null) {
                    for (int i4 = 0; i4 < this.b1; i4++) {
                        this.a1[i4].D();
                    }
                    int[] iArr = this.Z0;
                    int i5 = iArr[0];
                    int i6 = iArr[1];
                    float f2 = this.J0;
                    A4 a43 = null;
                    int i7 = 0;
                    while (i7 < i5) {
                        if (z2) {
                            i = (i5 - i7) - 1;
                            f = 1.0f - this.J0;
                        } else {
                            f = f2;
                            i = i7;
                        }
                        A4 a44 = this.Y0[i];
                        if (a44 != null && a44.g0 != 8) {
                            C0239m4 c0239m4 = a44.I;
                            if (i7 == 0) {
                                a44.f(c0239m4, this.I, this.w0);
                                a44.i0 = this.D0;
                                a44.d0 = f;
                            }
                            if (i7 == i5 - 1) {
                                a44.f(a44.K, this.K, this.x0);
                            }
                            if (i7 > 0 && a43 != null) {
                                int i8 = this.P0;
                                C0239m4 c0239m42 = a43.K;
                                a44.f(c0239m4, c0239m42, i8);
                                a43.f(c0239m42, c0239m4, 0);
                            }
                            a43 = a44;
                        }
                        i7++;
                        f2 = f;
                    }
                    for (int i9 = 0; i9 < i6; i9++) {
                        A4 a45 = this.X0[i9];
                        if (a45 != null && a45.g0 != 8) {
                            C0239m4 c0239m43 = a45.J;
                            if (i9 == 0) {
                                a45.f(c0239m43, this.J, this.s0);
                                a45.j0 = this.E0;
                                a45.e0 = this.K0;
                            }
                            if (i9 == i6 - 1) {
                                a45.f(a45.L, this.L, this.t0);
                            }
                            if (i9 > 0 && a43 != null) {
                                int i10 = this.Q0;
                                C0239m4 c0239m44 = a43.L;
                                a45.f(c0239m43, c0239m44, i10);
                                a43.f(c0239m44, c0239m43, 0);
                            }
                            a43 = a45;
                        }
                    }
                    for (int i11 = 0; i11 < i5; i11++) {
                        for (int i12 = 0; i12 < i6; i12++) {
                            int i13 = (i12 * i5) + i11;
                            if (this.V0 == 1) {
                                i13 = (i11 * i6) + i12;
                            }
                            A4[] a4Arr = this.a1;
                            if (i13 < a4Arr.length && (a4 = a4Arr[i13]) != null && a4.g0 != 8) {
                                A4 a46 = this.Y0[i11];
                                A4 a47 = this.X0[i12];
                                if (a4 != a46) {
                                    a4.f(a4.I, a46.I, 0);
                                    a4.f(a4.K, a46.K, 0);
                                }
                                if (a4 != a47) {
                                    a4.f(a4.J, a47.J, 0);
                                    a4.f(a4.L, a47.L, 0);
                                }
                            }
                        }
                    }
                }
            } else {
                int size2 = arrayList.size();
                for (int i14 = 0; i14 < size2; i14++) {
                    F7 f72 = (F7) arrayList.get(i14);
                    if (i14 == size2 - 1) {
                        z3 = true;
                    } else {
                        z3 = false;
                    }
                    f72.b(i14, z2, z3);
                }
            }
        } else if (arrayList.size() > 0) {
            ((F7) arrayList.get(0)).b(0, z2, true);
        }
        this.y0 = false;
    }
}
