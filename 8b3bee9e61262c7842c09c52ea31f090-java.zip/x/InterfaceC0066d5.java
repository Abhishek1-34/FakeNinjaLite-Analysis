package x;

/* renamed from: x.d5, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public interface InterfaceC0066d5 {
}
