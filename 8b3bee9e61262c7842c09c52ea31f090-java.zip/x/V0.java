package x;

/* loaded from: classes.dex */
public interface V0 {
}
