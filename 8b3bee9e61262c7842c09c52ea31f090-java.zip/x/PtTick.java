package x;

/* loaded from: classes.dex */
public final class PtTick implements Runnable {
    public final ParticleView a;

    public PtTick(ParticleView particleView) {
        this.a = particleView;
    }

    @Override // java.lang.Runnable
    public final void run() {
        ParticleView particleView = this.a;
        if (particleView != null) {
            particleView.invalidate();
            particleView.b.postDelayed(particleView.c, 16L);
        }
    }
}
