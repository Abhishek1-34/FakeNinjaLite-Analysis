package x;

import android.view.View;
import androidx.recyclerview.widget.RecyclerView;
import java.util.Comparator;
import java.util.WeakHashMap;

/* loaded from: classes.dex */
public final class S4 implements Comparator {
    public final /* synthetic */ int a;

    public /* synthetic */ S4(int i) {
        this.a = i;
    }

    /* JADX WARN: Code restructure failed: missing block: B:15:0x0034, code lost:
    
        if (r3 == null) goto L18;
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x0036, code lost:
    
        r0 = 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x003f, code lost:
    
        if (r3 != false) goto L19;
     */
    @Override // java.util.Comparator
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final int compare(Object obj, Object obj2) {
        boolean z;
        boolean z2;
        int i = -1;
        switch (this.a) {
            case 0:
                WeakHashMap weakHashMap = AbstractC0309ph.a;
                float g = AbstractC0158hh.g((View) obj);
                float g2 = AbstractC0158hh.g((View) obj2);
                if (g > g2) {
                    return -1;
                }
                if (g < g2) {
                    return 1;
                }
                return 0;
            case 1:
                C0150h9 c0150h9 = (C0150h9) obj;
                C0150h9 c0150h92 = (C0150h9) obj2;
                RecyclerView recyclerView = c0150h9.d;
                if (recyclerView == null) {
                    z = true;
                } else {
                    z = false;
                }
                if (c0150h92.d == null) {
                    z2 = true;
                } else {
                    z2 = false;
                }
                if (z == z2) {
                    boolean z3 = c0150h9.a;
                    if (z3 == c0150h92.a) {
                        i = c0150h92.b - c0150h9.b;
                        if (i == 0) {
                            int i2 = c0150h9.c - c0150h92.c;
                            if (i2 == 0) {
                                return 0;
                            }
                            return i2;
                        }
                    }
                    return i;
                }
                break;
            case 2:
                return ((Ve) obj).b - ((Ve) obj2).b;
            default:
                return ((View) obj).getTop() - ((View) obj2).getTop();
        }
    }
}
