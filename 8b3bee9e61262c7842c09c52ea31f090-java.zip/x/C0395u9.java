package x;

import android.view.View;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.EditText;

/* renamed from: x.u9, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0395u9 extends View.AccessibilityDelegate {
    public final /* synthetic */ C0414v9 a;

    public C0395u9(C0414v9 c0414v9) {
        this.a = c0414v9;
    }

    @Override // android.view.View.AccessibilityDelegate
    public final void onInitializeAccessibilityNodeInfo(View view, AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(view, accessibilityNodeInfo);
        EditText editText = this.a.h.getEditText();
        if (editText != null) {
            accessibilityNodeInfo.setLabeledBy(editText);
        }
    }
}
