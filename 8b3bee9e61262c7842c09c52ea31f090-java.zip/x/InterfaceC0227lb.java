package x;

/* renamed from: x.lb, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public interface InterfaceC0227lb {
    boolean b(C0303pb c0303pb);
}
