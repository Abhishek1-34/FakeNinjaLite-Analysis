package x;

import android.content.SharedPreferences;
import android.widget.CompoundButton;
import com.google.android.material.chip.Chip;
import org.conscrypt.ct.CTConstants;

/* renamed from: x.r7, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final /* synthetic */ class C0336r7 implements CompoundButton.OnCheckedChangeListener {
    public final /* synthetic */ int a;
    public final /* synthetic */ Object b;

    public /* synthetic */ C0336r7(int i, Object obj) {
        this.a = i;
        this.b = obj;
    }

    @Override // android.widget.CompoundButton.OnCheckedChangeListener
    public final void onCheckedChanged(CompoundButton compoundButton, boolean z) {
        switch (this.a) {
            case 0:
                ((SharedPreferences) this.b).edit().putBoolean("aim_assist_on", z).apply();
                AbstractC0481z0.f = z;
                if (!z) {
                    vpn.team09.hax.d.a(false);
                }
                AbstractC0481z0.a.post(new RunnableC0443x0(2));
                Z6.c();
                return;
            case 1:
                ((SharedPreferences) this.b).edit().putBoolean("fov_on", z).apply();
                Z6.g = z;
                Z6.d();
                return;
            case 2:
                ((SharedPreferences) this.b).edit().putBoolean("radar_on", z).apply();
                Z6.d = z;
                Z6.d();
                return;
            case CTConstants.CERTIFICATE_LENGTH_BYTES /* 3 */:
                ((SharedPreferences) this.b).edit().putBoolean("esp_on", z).apply();
                Z6.e = z;
                Z6.d();
                return;
            case 4:
                ((SharedPreferences) this.b).edit().putBoolean("moco_on", z).apply();
                Jb.e(z);
                return;
            case 5:
                ((SharedPreferences) this.b).edit().putBoolean("freeze", z).apply();
                F8.f = z;
                if (!z) {
                    E8.g(false);
                }
                F8.a();
                return;
            case 6:
                ((SharedPreferences) this.b).edit().putBoolean("autoFreeze", z).apply();
                E8.f(z);
                if (z) {
                    E8.e(z);
                    return;
                }
                return;
            case 7:
                ((SharedPreferences) this.b).edit().putBoolean("scopeFreeze", z).apply();
                E8.h(z);
                if (z) {
                    E8.e(z);
                    return;
                }
                return;
            case CTConstants.TIMESTAMP_LENGTH /* 8 */:
                ((SharedPreferences) this.b).edit().putBoolean("aim_visual_on", z).apply();
                Z6.f = z;
                Z6.d();
                return;
            default:
                CompoundButton.OnCheckedChangeListener onCheckedChangeListener = ((Chip) this.b).i;
                if (onCheckedChangeListener != null) {
                    onCheckedChangeListener.onCheckedChanged(compoundButton, z);
                    return;
                }
                return;
        }
    }
}
