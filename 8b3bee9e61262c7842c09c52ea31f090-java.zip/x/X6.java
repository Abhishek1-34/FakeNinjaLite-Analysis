package x;

import java.util.ArrayList;

/* loaded from: classes.dex */
public final class X6 {
    public final W6 a;
    public final ArrayList b;
    public final float c;
    public final float d;
    public final float e;
    public final float f;
    public final boolean g;
    public final float h;
    public final float i;
    public final float j;
    public final long k;

    public X6(W6 w6, ArrayList arrayList, float f, float f2, float f3, float f4, boolean z, float f5, float f6, float f7, long j) {
        this.a = w6;
        this.b = arrayList;
        this.c = f;
        this.d = f2;
        this.e = f3;
        this.f = f4;
        this.g = z;
        this.h = f5;
        this.i = f6;
        this.j = f7;
        this.k = j;
    }
}
