package x;

import org.conscrypt.R;

/* renamed from: x.fd, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0114fd {
    public static final int[] a = {R.attr.keylines, R.attr.statusBarBackground};
    public static final int[] b = {android.R.attr.layout_gravity, R.attr.layout_anchor, R.attr.layout_anchorGravity, R.attr.layout_behavior, R.attr.layout_dodgeInsetEdges, R.attr.layout_insetEdge, R.attr.layout_keyline};
}
