package x;

import android.animation.ValueAnimator;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.textfield.TextInputLayout;

/* renamed from: x.a3, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0004a3 implements ValueAnimator.AnimatorUpdateListener {
    public final /* synthetic */ int a;
    public final /* synthetic */ Object b;

    public /* synthetic */ C0004a3(int i, Object obj) {
        this.a = i;
        this.b = obj;
    }

    @Override // android.animation.ValueAnimator.AnimatorUpdateListener
    public final void onAnimationUpdate(ValueAnimator valueAnimator) {
        switch (this.a) {
            case 0:
                float floatValue = ((Float) valueAnimator.getAnimatedValue()).floatValue();
                C0092eb c0092eb = ((BottomSheetBehavior) this.b).i;
                if (c0092eb != null) {
                    C0072db c0072db = c0092eb.a;
                    if (c0072db.i != floatValue) {
                        c0072db.i = floatValue;
                        c0092eb.e = true;
                        c0092eb.invalidateSelf();
                        return;
                    }
                    return;
                }
                return;
            case 1:
                int floatValue2 = (int) (((Float) valueAnimator.getAnimatedValue()).floatValue() * 255.0f);
                C0299p7 c0299p7 = (C0299p7) this.b;
                c0299p7.c.setAlpha(floatValue2);
                c0299p7.d.setAlpha(floatValue2);
                c0299p7.s.invalidate();
                return;
            default:
                ((TextInputLayout) this.b).v0.k(((Float) valueAnimator.getAnimatedValue()).floatValue());
                return;
        }
    }
}
