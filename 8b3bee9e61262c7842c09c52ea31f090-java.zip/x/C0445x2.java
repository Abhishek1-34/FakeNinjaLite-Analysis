package x;

import java.util.Iterator;
import java.util.NoSuchElementException;

/* renamed from: x.x2, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0445x2 implements Iterator {
    public int a;
    public int b;
    public boolean c;
    public final /* synthetic */ int d;
    public final /* synthetic */ Object e;

    public C0445x2(int i) {
        this.a = i;
    }

    @Override // java.util.Iterator
    public final boolean hasNext() {
        if (this.b < this.a) {
            return true;
        }
        return false;
    }

    @Override // java.util.Iterator
    public final Object next() {
        Object f;
        if (hasNext()) {
            int i = this.b;
            switch (this.d) {
                case 0:
                    f = ((B2) this.e).f(i);
                    break;
                case 1:
                    f = ((B2) this.e).i(i);
                    break;
                default:
                    f = ((D2) this.e).b[i];
                    break;
            }
            this.b++;
            this.c = true;
            return f;
        }
        throw new NoSuchElementException();
    }

    @Override // java.util.Iterator
    public final void remove() {
        if (this.c) {
            int i = this.b - 1;
            this.b = i;
            switch (this.d) {
                case 0:
                    ((B2) this.e).g(i);
                    break;
                case 1:
                    ((B2) this.e).g(i);
                    break;
                default:
                    ((D2) this.e).a(i);
                    break;
            }
            this.a--;
            this.c = false;
            return;
        }
        throw new IllegalStateException("Call next() before removing an element.");
    }

    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    public C0445x2(D2 d2) {
        this(d2.c);
        this.d = 2;
        this.e = d2;
    }

    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    public C0445x2(B2 b2, int i) {
        this(b2.c);
        this.d = i;
        switch (i) {
            case 1:
                this.e = b2;
                this(b2.c);
                return;
            default:
                this.e = b2;
                return;
        }
    }
}
