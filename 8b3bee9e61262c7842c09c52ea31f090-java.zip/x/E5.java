package x;

import android.app.Dialog;
import android.content.DialogInterface;

/* loaded from: classes.dex */
public final class E5 implements DialogInterface.OnCancelListener {
    public final /* synthetic */ H5 a;

    public E5(H5 h5) {
        this.a = h5;
    }

    @Override // android.content.DialogInterface.OnCancelListener
    public final void onCancel(DialogInterface dialogInterface) {
        H5 h5 = this.a;
        Dialog dialog = h5.c0;
        if (dialog != null) {
            h5.onCancel(dialog);
        }
    }
}
