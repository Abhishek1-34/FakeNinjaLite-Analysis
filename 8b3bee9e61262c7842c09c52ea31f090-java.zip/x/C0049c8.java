package x;

import android.view.View;

/* renamed from: x.c8, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0049c8 {
    public boolean a;
    public int b;
    public int c;
    public int d;
    public int e;
    public int f;
    public Object g;
    public Object h;
    public Object i;
    public float j;
    public View k;
}
