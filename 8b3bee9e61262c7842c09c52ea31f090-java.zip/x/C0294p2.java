package x;

import android.app.Notification;
import android.content.ClipDescription;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Icon;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Trace;
import android.text.Editable;
import android.text.Selection;
import android.text.TextPaint;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import androidx.core.graphics.drawable.IconCompat;
import androidx.recyclerview.widget.RecyclerView;
import java.lang.reflect.InvocationTargetException;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.WeakHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import org.conscrypt.PSKKeyManager;
import org.conscrypt.R;
import org.conscrypt.ct.CTConstants;

/* renamed from: x.p2, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0294p2 implements A9 {
    public static volatile C0294p2 e;
    public static final Object f = new Object();
    public static C0294p2 g;
    public final /* synthetic */ int a;
    public Object b;
    public Object c;
    public Object d;

    public /* synthetic */ C0294p2() {
        this.a = 2;
    }

    public static boolean h(Editable editable, KeyEvent keyEvent, boolean z) {
        Fg[] fgArr;
        if (!KeyEvent.metaStateHasNoModifiers(keyEvent.getMetaState())) {
            return false;
        }
        int selectionStart = Selection.getSelectionStart(editable);
        int selectionEnd = Selection.getSelectionEnd(editable);
        if (selectionStart != -1 && selectionEnd != -1 && selectionStart == selectionEnd && (fgArr = (Fg[]) editable.getSpans(selectionStart, selectionEnd, Fg.class)) != null && fgArr.length > 0) {
            for (Fg fg : fgArr) {
                int spanStart = editable.getSpanStart(fg);
                int spanEnd = editable.getSpanEnd(fg);
                if ((z && spanStart == selectionStart) || ((!z && spanEnd == selectionStart) || (selectionStart > spanStart && selectionStart < spanEnd))) {
                    editable.delete(spanStart, spanEnd);
                    return true;
                }
            }
        }
        return false;
    }

    public static C0294p2 r(Context context) {
        if (e == null) {
            synchronized (f) {
                try {
                    if (e == null) {
                        e = new C0294p2(context);
                    }
                } finally {
                }
            }
        }
        return e;
    }

    public static C0294p2 y(Context context, AttributeSet attributeSet, int[] iArr, int i) {
        return new C0294p2(context, context.obtainStyledAttributes(attributeSet, iArr, i, 0));
    }

    public void A() {
        ((TypedArray) this.b).recycle();
    }

    public void B(B4 b4, int i, int i2, int i3) {
        b4.getClass();
        int i4 = b4.b0;
        int i5 = b4.c0;
        b4.b0 = 0;
        b4.c0 = 0;
        b4.O(i2);
        b4.L(i3);
        if (i4 < 0) {
            b4.b0 = 0;
        } else {
            b4.b0 = i4;
        }
        if (i5 < 0) {
            b4.c0 = 0;
        } else {
            b4.c0 = i5;
        }
        B4 b42 = (B4) this.d;
        b42.t0 = i;
        b42.U();
    }

    public void C(View view) {
        if (((ArrayList) this.d).remove(view)) {
            C0305pd c0305pd = (C0305pd) this.b;
            Md I = RecyclerView.I(view);
            if (I != null) {
                int i = I.p;
                RecyclerView recyclerView = c0305pd.a;
                if (recyclerView.L()) {
                    I.q = i;
                    recyclerView.p0.add(I);
                } else {
                    WeakHashMap weakHashMap = AbstractC0309ph.a;
                    I.a.setImportantForAccessibility(i);
                }
                I.p = 0;
            }
        }
    }

    public void D(B4 b4) {
        ArrayList arrayList = (ArrayList) this.b;
        arrayList.clear();
        int size = b4.q0.size();
        for (int i = 0; i < size; i++) {
            A4 a4 = (A4) b4.q0.get(i);
            int[] iArr = a4.p0;
            if (iArr[0] == 3 || iArr[1] == 3) {
                arrayList.add(a4);
            }
        }
        b4.s0.b = true;
    }

    @Override // x.A9
    public ClipDescription a() {
        return (ClipDescription) this.c;
    }

    @Override // x.A9
    public void b() {
    }

    @Override // x.A9
    public Uri c() {
        return (Uri) this.d;
    }

    @Override // x.A9
    public Object d() {
        return null;
    }

    @Override // x.A9
    public Uri e() {
        return (Uri) this.b;
    }

    public void f(View view, int i, boolean z) {
        int s;
        RecyclerView recyclerView = ((C0305pd) this.b).a;
        if (i < 0) {
            s = recyclerView.getChildCount();
        } else {
            s = s(i);
        }
        ((G3) this.c).e(s, z);
        if (z) {
            w(view);
        }
        recyclerView.addView(view, s);
        RecyclerView.I(view);
    }

    public void g(View view, int i, ViewGroup.LayoutParams layoutParams, boolean z) {
        int s;
        RecyclerView recyclerView = ((C0305pd) this.b).a;
        if (i < 0) {
            s = recyclerView.getChildCount();
        } else {
            s = s(i);
        }
        ((G3) this.c).e(s, z);
        if (z) {
            w(view);
        }
        Md I = RecyclerView.I(view);
        if (I != null) {
            if (!I.k() && !I.p()) {
                throw new IllegalArgumentException("Called attach on a child which is not detached: " + I + recyclerView.y());
            }
            I.j &= -257;
        }
        recyclerView.attachViewToParent(view, s, layoutParams);
    }

    public void i(int i) {
        Md I;
        int s = s(i);
        ((G3) this.c).f(s);
        RecyclerView recyclerView = ((C0305pd) this.b).a;
        View childAt = recyclerView.getChildAt(s);
        if (childAt != null && (I = RecyclerView.I(childAt)) != null) {
            if (I.k() && !I.p()) {
                throw new IllegalArgumentException("called detach on an already detached child " + I + recyclerView.y());
            }
            I.a(PSKKeyManager.MAX_KEY_LENGTH_BYTES);
        }
        recyclerView.detachViewFromParent(s);
    }

    public void j(Bundle bundle) {
        HashSet hashSet;
        String string = ((Context) this.d).getString(R.string.androidx_startup);
        if (bundle != null) {
            try {
                HashSet hashSet2 = new HashSet();
                Iterator<String> it = bundle.keySet().iterator();
                while (true) {
                    boolean hasNext = it.hasNext();
                    hashSet = (HashSet) this.c;
                    if (!hasNext) {
                        break;
                    }
                    String next = it.next();
                    if (string.equals(bundle.getString(next, null))) {
                        Class<?> cls = Class.forName(next);
                        if (InterfaceC0433w9.class.isAssignableFrom(cls)) {
                            hashSet.add(cls);
                        }
                    }
                }
                Iterator it2 = hashSet.iterator();
                while (it2.hasNext()) {
                    k((Class) it2.next(), hashSet2);
                }
            } catch (ClassNotFoundException e2) {
                throw new RuntimeException(e2);
            }
        }
    }

    public Object k(Class cls, HashSet hashSet) {
        Object obj;
        if (AbstractC0112fb.u()) {
            try {
                AbstractC0112fb.a(cls.getSimpleName());
            } catch (Throwable th) {
                Trace.endSection();
                throw th;
            }
        }
        if (!hashSet.contains(cls)) {
            HashMap hashMap = (HashMap) this.b;
            if (!hashMap.containsKey(cls)) {
                hashSet.add(cls);
                try {
                    InterfaceC0433w9 interfaceC0433w9 = (InterfaceC0433w9) cls.getDeclaredConstructor(null).newInstance(null);
                    List<Class> a = interfaceC0433w9.a();
                    if (!a.isEmpty()) {
                        for (Class cls2 : a) {
                            if (!hashMap.containsKey(cls2)) {
                                k(cls2, hashSet);
                            }
                        }
                    }
                    obj = interfaceC0433w9.b((Context) this.d);
                    hashSet.remove(cls);
                    hashMap.put(cls, obj);
                } catch (Throwable th2) {
                    throw new RuntimeException(th2);
                }
            } else {
                obj = hashMap.get(cls);
            }
            Trace.endSection();
            return obj;
        }
        throw new IllegalStateException("Cannot initialize " + cls.getName() + ". Cycle detected.");
    }

    public View l(int i) {
        return ((C0305pd) this.b).a.getChildAt(s(i));
    }

    public int m() {
        return ((C0305pd) this.b).a.getChildCount() - ((ArrayList) this.d).size();
    }

    public ColorStateList n(int i) {
        int resourceId;
        ColorStateList A;
        TypedArray typedArray = (TypedArray) this.b;
        if (typedArray.hasValue(i) && (resourceId = typedArray.getResourceId(i, 0)) != 0 && (A = E9.A((Context) this.d, resourceId)) != null) {
            return A;
        }
        return typedArray.getColorStateList(i);
    }

    public Drawable o(int i) {
        int resourceId;
        TypedArray typedArray = (TypedArray) this.b;
        if (typedArray.hasValue(i) && (resourceId = typedArray.getResourceId(i, 0)) != 0) {
            return AbstractC0124g3.r((Context) this.d, resourceId);
        }
        return typedArray.getDrawable(i);
    }

    public Drawable p(int i) {
        int resourceId;
        Drawable d;
        if (((TypedArray) this.b).hasValue(i) && (resourceId = ((TypedArray) this.b).getResourceId(i, 0)) != 0) {
            C0425w1 a = C0425w1.a();
            Context context = (Context) this.d;
            synchronized (a) {
                d = a.a.d(context, resourceId, true);
            }
            return d;
        }
        return null;
    }

    public Typeface q(int i, int i2, X1 x1) {
        int resourceId = ((TypedArray) this.b).getResourceId(i, 0);
        if (resourceId == 0) {
            return null;
        }
        if (((TypedValue) this.c) == null) {
            this.c = new TypedValue();
        }
        TypedValue typedValue = (TypedValue) this.c;
        ThreadLocal threadLocal = AbstractC0095ee.a;
        Context context = (Context) this.d;
        if (context.isRestricted()) {
            return null;
        }
        return AbstractC0095ee.b(context, resourceId, typedValue, i2, x1, true, false);
    }

    public int s(int i) {
        if (i < 0) {
            return -1;
        }
        int childCount = ((C0305pd) this.b).a.getChildCount();
        int i2 = i;
        while (i2 < childCount) {
            G3 g3 = (G3) this.c;
            int b = i - (i2 - g3.b(i2));
            if (b == 0) {
                while (g3.d(i2)) {
                    i2++;
                }
                return i2;
            }
            i2 += b;
        }
        return -1;
    }

    public View t(int i) {
        return ((C0305pd) this.b).a.getChildAt(i);
    }

    public String toString() {
        switch (this.a) {
            case CTConstants.CERTIFICATE_LENGTH_BYTES /* 3 */:
                return ((G3) this.c).toString() + ", hidden list:" + ((ArrayList) this.d).size();
            default:
                return super.toString();
        }
    }

    public int u() {
        return ((C0305pd) this.b).a.getChildCount();
    }

    public boolean v(CharSequence charSequence, int i, int i2, Eg eg) {
        int i3;
        if ((eg.c & 3) == 0) {
            C0106f5 c0106f5 = (C0106f5) this.d;
            Gb c = eg.c();
            int a = c.a(8);
            if (a != 0) {
                ((ByteBuffer) c.d).getShort(a + c.a);
            }
            c0106f5.getClass();
            ThreadLocal threadLocal = C0106f5.b;
            if (threadLocal.get() == null) {
                threadLocal.set(new StringBuilder());
            }
            StringBuilder sb = (StringBuilder) threadLocal.get();
            sb.setLength(0);
            while (i < i2) {
                sb.append(charSequence.charAt(i));
                i++;
            }
            TextPaint textPaint = c0106f5.a;
            String sb2 = sb.toString();
            int i4 = AbstractC0474yc.a;
            boolean hasGlyph = textPaint.hasGlyph(sb2);
            int i5 = eg.c & 4;
            if (hasGlyph) {
                i3 = i5 | 2;
            } else {
                i3 = i5 | 1;
            }
            eg.c = i3;
        }
        if ((eg.c & 3) == 2) {
            return true;
        }
        return false;
    }

    public void w(View view) {
        ((ArrayList) this.d).add(view);
        C0305pd c0305pd = (C0305pd) this.b;
        Md I = RecyclerView.I(view);
        if (I != null) {
            int i = I.q;
            View view2 = I.a;
            if (i != -1) {
                I.p = i;
            } else {
                WeakHashMap weakHashMap = AbstractC0309ph.a;
                I.p = view2.getImportantForAccessibility();
            }
            RecyclerView recyclerView = c0305pd.a;
            if (recyclerView.L()) {
                I.q = 4;
                recyclerView.p0.add(I);
            } else {
                WeakHashMap weakHashMap2 = AbstractC0309ph.a;
                view2.setImportantForAccessibility(4);
            }
        }
    }

    public boolean x(int i, C0333r4 c0333r4, A4 a4) {
        boolean z;
        boolean z2;
        boolean z3;
        boolean z4;
        int[] iArr = a4.p0;
        int i2 = iArr[0];
        V2 v2 = (V2) this.c;
        v2.a = i2;
        v2.b = iArr[1];
        v2.c = a4.q();
        v2.d = a4.k();
        v2.i = false;
        v2.j = i;
        if (v2.a == 3) {
            z = true;
        } else {
            z = false;
        }
        if (v2.b == 3) {
            z2 = true;
        } else {
            z2 = false;
        }
        if (z && a4.W > 0.0f) {
            z3 = true;
        } else {
            z3 = false;
        }
        if (z2 && a4.W > 0.0f) {
            z4 = true;
        } else {
            z4 = false;
        }
        int[] iArr2 = a4.t;
        if (z3 && iArr2[0] == 4) {
            v2.a = 1;
        }
        if (z4 && iArr2[1] == 4) {
            v2.b = 1;
        }
        c0333r4.b(a4, v2);
        a4.O(v2.e);
        a4.L(v2.f);
        a4.E = v2.h;
        a4.I(v2.g);
        v2.j = 0;
        return v2.i;
    }

    public Object z(CharSequence charSequence, int i, int i2, int i3, boolean z, InterfaceC0468y6 interfaceC0468y6) {
        int i4;
        Ib ib;
        char c;
        C0487z6 c0487z6 = new C0487z6((Ib) ((C0353s5) this.c).c);
        int codePointAt = Character.codePointAt(charSequence, i);
        boolean z2 = true;
        int i5 = 0;
        int i6 = i;
        loop0: while (true) {
            i4 = i6;
            while (i6 < i2 && i5 < i3 && z2) {
                SparseArray sparseArray = c0487z6.c.a;
                if (sparseArray == null) {
                    ib = null;
                } else {
                    ib = (Ib) sparseArray.get(codePointAt);
                }
                if (c0487z6.a != 2) {
                    if (ib == null) {
                        c0487z6.a();
                        c = 1;
                    } else {
                        c0487z6.a = 2;
                        c0487z6.c = ib;
                        c0487z6.f = 1;
                        c = 2;
                    }
                } else {
                    if (ib != null) {
                        c0487z6.c = ib;
                        c0487z6.f++;
                    } else {
                        if (codePointAt == 65038) {
                            c0487z6.a();
                        } else if (codePointAt != 65039) {
                            Ib ib2 = c0487z6.c;
                            if (ib2.b != null) {
                                if (c0487z6.f == 1) {
                                    if (c0487z6.b()) {
                                        c0487z6.d = c0487z6.c;
                                        c0487z6.a();
                                    } else {
                                        c0487z6.a();
                                    }
                                } else {
                                    c0487z6.d = ib2;
                                    c0487z6.a();
                                }
                                c = 3;
                            } else {
                                c0487z6.a();
                            }
                        }
                        c = 1;
                    }
                    c = 2;
                }
                c0487z6.e = codePointAt;
                if (c != 1) {
                    if (c != 2) {
                        if (c == 3) {
                            if (z || !v(charSequence, i4, i6, c0487z6.d.b)) {
                                z2 = interfaceC0468y6.u(charSequence, i4, i6, c0487z6.d.b);
                                i5++;
                            }
                        }
                    } else {
                        int charCount = Character.charCount(codePointAt) + i6;
                        if (charCount < i2) {
                            codePointAt = Character.codePointAt(charSequence, charCount);
                        }
                        i6 = charCount;
                    }
                } else {
                    i6 = Character.charCount(Character.codePointAt(charSequence, i4)) + i4;
                    if (i6 < i2) {
                        codePointAt = Character.codePointAt(charSequence, i6);
                    }
                }
            }
        }
        if (c0487z6.a == 2 && c0487z6.c.b != null && ((c0487z6.f > 1 || c0487z6.b()) && i5 < i3 && z2 && (z || !v(charSequence, i4, i6, c0487z6.c.b)))) {
            interfaceC0468y6.u(charSequence, i4, i6, c0487z6.c.b);
        }
        return interfaceC0468y6.f();
    }

    public C0294p2(C0305pd c0305pd) {
        this.a = 3;
        this.b = c0305pd;
        this.c = new G3();
        this.d = new ArrayList();
    }

    public C0294p2(Uri uri, ClipDescription clipDescription, Uri uri2) {
        this.a = 5;
        this.b = uri;
        this.c = clipDescription;
        this.d = uri2;
    }

    public C0294p2(Runnable runnable) {
        this.a = 6;
        this.d = new CopyOnWriteArrayList();
        this.b = new HashMap();
        this.c = runnable;
    }

    public C0294p2(Context context, TypedArray typedArray) {
        this.a = 8;
        this.d = context;
        this.b = typedArray;
    }

    public C0294p2(Context context, LocationManager locationManager) {
        this.a = 9;
        this.c = new Object();
        this.d = context;
        this.b = locationManager;
    }

    /* JADX WARN: Failed to find 'out' block for switch in B:27:0x0104. Please report as an issue. */
    /* JADX WARN: Removed duplicated region for block: B:34:0x0266  */
    /* JADX WARN: Removed duplicated region for block: B:37:0x026f  */
    /* JADX WARN: Removed duplicated region for block: B:40:0x0294  */
    /* JADX WARN: Removed duplicated region for block: B:43:0x02b1  */
    /* JADX WARN: Removed duplicated region for block: B:46:0x02b8  */
    /* JADX WARN: Removed duplicated region for block: B:49:0x02bf  */
    /* JADX WARN: Removed duplicated region for block: B:52:0x02c2 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:53:0x029a  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public C0294p2(C0013ac c0013ac) {
        Bundle bundle;
        int i;
        ArrayList arrayList;
        Notification notification;
        String str;
        Iterator it;
        char c;
        Icon icon;
        Bundle bundle2;
        Bundle bundle3;
        String str2;
        ColorStateList colorStateList;
        PorterDuff.Mode mode;
        int i2;
        this.a = 7;
        new ArrayList();
        this.d = new Bundle();
        this.c = c0013ac;
        Uh uh = c0013ac.a;
        int i3 = Build.VERSION.SDK_INT;
        String str3 = c0013ac.k;
        int i4 = 26;
        if (i3 >= 26) {
            this.b = K4.a(uh, str3);
        } else {
            this.b = new Notification.Builder(c0013ac.a);
        }
        Notification notification2 = c0013ac.m;
        char c2 = 2;
        ((Notification.Builder) this.b).setWhen(notification2.when).setSmallIcon(notification2.icon, notification2.iconLevel).setContent(notification2.contentView).setTicker(notification2.tickerText, null).setVibrate(notification2.vibrate).setLights(notification2.ledARGB, notification2.ledOnMS, notification2.ledOffMS).setOngoing((notification2.flags & 2) != 0).setOnlyAlertOnce((notification2.flags & 8) != 0).setAutoCancel((notification2.flags & 16) != 0).setDefaults(notification2.defaults).setContentTitle(c0013ac.e).setContentText(c0013ac.f).setContentInfo(null).setContentIntent(c0013ac.g).setDeleteIntent(notification2.deleteIntent).setFullScreenIntent(null, (notification2.flags & 128) != 0).setNumber(0).setProgress(0, 0, false);
        ((Notification.Builder) this.b).setLargeIcon((Icon) null);
        ((Notification.Builder) this.b).setSubText(null).setUsesChronometer(false).setPriority(0);
        Iterator it2 = c0013ac.b.iterator();
        while (it2.hasNext()) {
            Zb zb = (Zb) it2.next();
            int i5 = Build.VERSION.SDK_INT;
            if (zb.b == null && (i2 = zb.e) != 0) {
                zb.b = IconCompat.a(i2);
            }
            IconCompat iconCompat = zb.b;
            if (iconCompat != null) {
                int i6 = iconCompat.a;
                switch (i6) {
                    case -1:
                        notification = notification2;
                        str = str3;
                        it = it2;
                        c = c2;
                        icon = (Icon) iconCompat.b;
                        break;
                    case 0:
                    default:
                        throw new IllegalArgumentException("Unknown type");
                    case 1:
                        notification = notification2;
                        str = str3;
                        it = it2;
                        c = c2;
                        icon = Icon.createWithBitmap((Bitmap) iconCompat.b);
                        colorStateList = iconCompat.g;
                        if (colorStateList != null) {
                            icon.setTintList(colorStateList);
                        }
                        mode = iconCompat.h;
                        if (mode != IconCompat.k) {
                            icon.setTintMode(mode);
                            break;
                        }
                        break;
                    case 2:
                        notification = notification2;
                        str = str3;
                        it = it2;
                        if (i6 == -1) {
                            Object obj = iconCompat.b;
                            if (i5 >= 28) {
                                str2 = L5.c(obj);
                            } else {
                                try {
                                    str2 = (String) obj.getClass().getMethod("getResPackage", null).invoke(obj, null);
                                } catch (IllegalAccessException e2) {
                                    Log.e("IconCompat", "Unable to get icon package", e2);
                                    str2 = null;
                                    c = 2;
                                    icon = Icon.createWithResource(str2, iconCompat.e);
                                    colorStateList = iconCompat.g;
                                    if (colorStateList != null) {
                                    }
                                    mode = iconCompat.h;
                                    if (mode != IconCompat.k) {
                                    }
                                    Notification.Action.Builder builder = new Notification.Action.Builder(icon, zb.f, zb.g);
                                    bundle2 = zb.a;
                                    if (bundle2 == null) {
                                    }
                                    boolean z = zb.c;
                                    bundle3.putBoolean("android.support.allowGeneratedReplies", z);
                                    builder.setAllowGeneratedReplies(z);
                                    bundle3.putInt("android.support.action.semanticAction", 0);
                                    if (i5 >= 28) {
                                    }
                                    if (i5 >= 29) {
                                    }
                                    if (i5 < 31) {
                                    }
                                    bundle3.putBoolean("android.support.action.showsUserInterface", zb.d);
                                    builder.addExtras(bundle3);
                                    ((Notification.Builder) this.b).addAction(builder.build());
                                    c2 = c;
                                    it2 = it;
                                    str3 = str;
                                    notification2 = notification;
                                    i4 = 26;
                                } catch (NoSuchMethodException e3) {
                                    Log.e("IconCompat", "Unable to get icon package", e3);
                                    str2 = null;
                                    c = 2;
                                    icon = Icon.createWithResource(str2, iconCompat.e);
                                    colorStateList = iconCompat.g;
                                    if (colorStateList != null) {
                                    }
                                    mode = iconCompat.h;
                                    if (mode != IconCompat.k) {
                                    }
                                    Notification.Action.Builder builder2 = new Notification.Action.Builder(icon, zb.f, zb.g);
                                    bundle2 = zb.a;
                                    if (bundle2 == null) {
                                    }
                                    boolean z2 = zb.c;
                                    bundle3.putBoolean("android.support.allowGeneratedReplies", z2);
                                    builder2.setAllowGeneratedReplies(z2);
                                    bundle3.putInt("android.support.action.semanticAction", 0);
                                    if (i5 >= 28) {
                                    }
                                    if (i5 >= 29) {
                                    }
                                    if (i5 < 31) {
                                    }
                                    bundle3.putBoolean("android.support.action.showsUserInterface", zb.d);
                                    builder2.addExtras(bundle3);
                                    ((Notification.Builder) this.b).addAction(builder2.build());
                                    c2 = c;
                                    it2 = it;
                                    str3 = str;
                                    notification2 = notification;
                                    i4 = 26;
                                } catch (InvocationTargetException e4) {
                                    Log.e("IconCompat", "Unable to get icon package", e4);
                                    str2 = null;
                                    c = 2;
                                    icon = Icon.createWithResource(str2, iconCompat.e);
                                    colorStateList = iconCompat.g;
                                    if (colorStateList != null) {
                                    }
                                    mode = iconCompat.h;
                                    if (mode != IconCompat.k) {
                                    }
                                    Notification.Action.Builder builder22 = new Notification.Action.Builder(icon, zb.f, zb.g);
                                    bundle2 = zb.a;
                                    if (bundle2 == null) {
                                    }
                                    boolean z22 = zb.c;
                                    bundle3.putBoolean("android.support.allowGeneratedReplies", z22);
                                    builder22.setAllowGeneratedReplies(z22);
                                    bundle3.putInt("android.support.action.semanticAction", 0);
                                    if (i5 >= 28) {
                                    }
                                    if (i5 >= 29) {
                                    }
                                    if (i5 < 31) {
                                    }
                                    bundle3.putBoolean("android.support.action.showsUserInterface", zb.d);
                                    builder22.addExtras(bundle3);
                                    ((Notification.Builder) this.b).addAction(builder22.build());
                                    c2 = c;
                                    it2 = it;
                                    str3 = str;
                                    notification2 = notification;
                                    i4 = 26;
                                }
                            }
                            c = 2;
                        } else {
                            c = 2;
                            if (i6 == 2) {
                                String str4 = iconCompat.j;
                                if (str4 != null && !TextUtils.isEmpty(str4)) {
                                    str2 = iconCompat.j;
                                } else {
                                    str2 = ((String) iconCompat.b).split(":", -1)[0];
                                }
                            } else {
                                throw new IllegalStateException("called getResPackage() on " + iconCompat);
                            }
                        }
                        icon = Icon.createWithResource(str2, iconCompat.e);
                        colorStateList = iconCompat.g;
                        if (colorStateList != null) {
                        }
                        mode = iconCompat.h;
                        if (mode != IconCompat.k) {
                        }
                        break;
                    case CTConstants.CERTIFICATE_LENGTH_BYTES /* 3 */:
                        notification = notification2;
                        str = str3;
                        it = it2;
                        icon = Icon.createWithData((byte[]) iconCompat.b, iconCompat.e, iconCompat.f);
                        c = 2;
                        colorStateList = iconCompat.g;
                        if (colorStateList != null) {
                        }
                        mode = iconCompat.h;
                        if (mode != IconCompat.k) {
                        }
                        break;
                    case 4:
                        notification = notification2;
                        str = str3;
                        it = it2;
                        icon = Icon.createWithContentUri((String) iconCompat.b);
                        c = 2;
                        colorStateList = iconCompat.g;
                        if (colorStateList != null) {
                        }
                        mode = iconCompat.h;
                        if (mode != IconCompat.k) {
                        }
                        break;
                    case 5:
                        if (i5 >= i4) {
                            icon = K4.b((Bitmap) iconCompat.b);
                            notification = notification2;
                            str = str3;
                            it = it2;
                            c = c2;
                            colorStateList = iconCompat.g;
                            if (colorStateList != null) {
                            }
                            mode = iconCompat.h;
                            if (mode != IconCompat.k) {
                            }
                        } else {
                            Bitmap bitmap = (Bitmap) iconCompat.b;
                            int min = (int) (Math.min(bitmap.getWidth(), bitmap.getHeight()) * 0.6666667f);
                            Bitmap createBitmap = Bitmap.createBitmap(min, min, Bitmap.Config.ARGB_8888);
                            Canvas canvas = new Canvas(createBitmap);
                            Paint paint = new Paint(3);
                            float f2 = min * 0.5f;
                            it = it2;
                            paint.setColor(-16777216);
                            str = str3;
                            Shader.TileMode tileMode = Shader.TileMode.CLAMP;
                            BitmapShader bitmapShader = new BitmapShader(bitmap, tileMode, tileMode);
                            Matrix matrix = new Matrix();
                            notification = notification2;
                            matrix.setTranslate((-(bitmap.getWidth() - min)) / 2.0f, (-(bitmap.getHeight() - min)) / 2.0f);
                            bitmapShader.setLocalMatrix(matrix);
                            paint.setShader(bitmapShader);
                            canvas.drawCircle(f2, f2, f2 * 0.9166667f, paint);
                            canvas.setBitmap(null);
                            icon = Icon.createWithBitmap(createBitmap);
                            c = 2;
                            colorStateList = iconCompat.g;
                            if (colorStateList != null) {
                            }
                            mode = iconCompat.h;
                            if (mode != IconCompat.k) {
                            }
                        }
                        break;
                    case 6:
                        if (i5 >= 30) {
                            icon = AbstractC0461y.a(iconCompat.c());
                            notification = notification2;
                            str = str3;
                            it = it2;
                            c = c2;
                            colorStateList = iconCompat.g;
                            if (colorStateList != null) {
                            }
                            mode = iconCompat.h;
                            if (mode != IconCompat.k) {
                            }
                        } else {
                            throw new IllegalArgumentException("Context is required to resolve the file uri of the icon: " + iconCompat.c());
                        }
                        break;
                }
            } else {
                notification = notification2;
                str = str3;
                it = it2;
                c = c2;
                icon = null;
            }
            Notification.Action.Builder builder222 = new Notification.Action.Builder(icon, zb.f, zb.g);
            bundle2 = zb.a;
            if (bundle2 == null) {
                bundle3 = new Bundle(bundle2);
            } else {
                bundle3 = new Bundle();
            }
            boolean z222 = zb.c;
            bundle3.putBoolean("android.support.allowGeneratedReplies", z222);
            builder222.setAllowGeneratedReplies(z222);
            bundle3.putInt("android.support.action.semanticAction", 0);
            if (i5 >= 28) {
                L5.m(builder222);
            }
            if (i5 >= 29) {
                AbstractC0350s2.f(builder222);
            }
            if (i5 < 31) {
                AbstractC0033bc.a(builder222);
            }
            bundle3.putBoolean("android.support.action.showsUserInterface", zb.d);
            builder222.addExtras(bundle3);
            ((Notification.Builder) this.b).addAction(builder222.build());
            c2 = c;
            it2 = it;
            str3 = str;
            notification2 = notification;
            i4 = 26;
        }
        Notification notification3 = notification2;
        String str5 = str3;
        Bundle bundle4 = c0013ac.j;
        if (bundle4 != null) {
            ((Bundle) this.d).putAll(bundle4);
        }
        int i7 = Build.VERSION.SDK_INT;
        ((Notification.Builder) this.b).setShowWhen(c0013ac.h);
        ((Notification.Builder) this.b).setLocalOnly(false);
        ((Notification.Builder) this.b).setGroup(null);
        ((Notification.Builder) this.b).setSortKey(null);
        ((Notification.Builder) this.b).setGroupSummary(false);
        ((Notification.Builder) this.b).setCategory(c0013ac.i);
        ((Notification.Builder) this.b).setColor(0);
        ((Notification.Builder) this.b).setVisibility(0);
        ((Notification.Builder) this.b).setPublicVersion(null);
        ((Notification.Builder) this.b).setSound(notification3.sound, notification3.audioAttributes);
        ArrayList arrayList2 = c0013ac.n;
        ArrayList arrayList3 = c0013ac.c;
        if (i7 < 28) {
            if (arrayList3 == null) {
                arrayList = null;
            } else {
                arrayList = new ArrayList(arrayList3.size());
                Iterator it3 = arrayList3.iterator();
                if (it3.hasNext()) {
                    it3.next().getClass();
                    throw new ClassCastException();
                }
            }
            if (arrayList != null) {
                if (arrayList2 == null) {
                    arrayList2 = arrayList;
                } else {
                    D2 d2 = new D2(arrayList2.size() + arrayList.size());
                    d2.addAll(arrayList);
                    d2.addAll(arrayList2);
                    arrayList2 = new ArrayList(d2);
                }
            }
        }
        if (arrayList2 != null && !arrayList2.isEmpty()) {
            Iterator it4 = arrayList2.iterator();
            while (it4.hasNext()) {
                ((Notification.Builder) this.b).addPerson((String) it4.next());
            }
        }
        ArrayList arrayList4 = c0013ac.d;
        if (arrayList4.size() > 0) {
            if (c0013ac.j == null) {
                c0013ac.j = new Bundle();
            }
            Bundle bundle5 = c0013ac.j.getBundle("android.car.EXTENSIONS");
            bundle5 = bundle5 == null ? new Bundle() : bundle5;
            Bundle bundle6 = new Bundle(bundle5);
            Bundle bundle7 = new Bundle();
            for (int i8 = 0; i8 < arrayList4.size(); i8++) {
                String num = Integer.toString(i8);
                Zb zb2 = (Zb) arrayList4.get(i8);
                Bundle bundle8 = new Bundle();
                if (zb2.b == null && (i = zb2.e) != 0) {
                    zb2.b = IconCompat.a(i);
                }
                IconCompat iconCompat2 = zb2.b;
                bundle8.putInt("icon", iconCompat2 != null ? iconCompat2.b() : 0);
                bundle8.putCharSequence("title", zb2.f);
                bundle8.putParcelable("actionIntent", zb2.g);
                Bundle bundle9 = zb2.a;
                if (bundle9 != null) {
                    bundle = new Bundle(bundle9);
                } else {
                    bundle = new Bundle();
                }
                bundle.putBoolean("android.support.allowGeneratedReplies", zb2.c);
                bundle8.putBundle("extras", bundle);
                bundle8.putParcelableArray("remoteInputs", null);
                bundle8.putBoolean("showsUserInterface", zb2.d);
                bundle8.putInt("semanticAction", 0);
                bundle7.putBundle(num, bundle8);
            }
            bundle5.putBundle("invisible_actions", bundle7);
            bundle6.putBundle("invisible_actions", bundle7);
            if (c0013ac.j == null) {
                c0013ac.j = new Bundle();
            }
            c0013ac.j.putBundle("android.car.EXTENSIONS", bundle5);
            ((Bundle) this.d).putBundle("android.car.EXTENSIONS", bundle6);
        }
        int i9 = Build.VERSION.SDK_INT;
        ((Notification.Builder) this.b).setExtras(c0013ac.j);
        ((Notification.Builder) this.b).setRemoteInputHistory(null);
        if (i9 >= 26) {
            K4.h((Notification.Builder) this.b);
            K4.n((Notification.Builder) this.b);
            K4.o((Notification.Builder) this.b);
            K4.p((Notification.Builder) this.b);
            K4.j((Notification.Builder) this.b);
            if (!TextUtils.isEmpty(str5)) {
                ((Notification.Builder) this.b).setSound(null).setDefaults(0).setLights(0, 0, 0).setVibrate(null);
            }
        }
        if (i9 >= 28) {
            Iterator it5 = arrayList3.iterator();
            if (it5.hasNext()) {
                it5.next().getClass();
                throw new ClassCastException();
            }
        }
        if (i9 >= 29) {
            AbstractC0350s2.d((Notification.Builder) this.b, c0013ac.l);
            AbstractC0350s2.e((Notification.Builder) this.b);
        }
    }

    public C0294p2(Context context) {
        this.a = 0;
        this.d = context.getApplicationContext();
        this.c = new HashSet();
        this.b = new HashMap();
    }

    public C0294p2(B4 b4) {
        this.a = 1;
        this.b = new ArrayList();
        this.c = new Object();
        this.d = b4;
    }

    public C0294p2(C0353s5 c0353s5, C0107f6 c0107f6, C0106f5 c0106f5, Set set) {
        this.a = 4;
        this.b = c0107f6;
        this.c = c0353s5;
        this.d = c0106f5;
        if (set.isEmpty()) {
            return;
        }
        Iterator it = set.iterator();
        while (it.hasNext()) {
            int[] iArr = (int[]) it.next();
            String str = new String(iArr, 0, iArr.length);
            z(str, 0, str.length(), 1, true, new B(13, str));
        }
    }
}
