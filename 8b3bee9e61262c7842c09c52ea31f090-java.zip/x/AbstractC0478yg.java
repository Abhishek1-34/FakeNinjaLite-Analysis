package x;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.Trace;
import android.util.Log;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

/* renamed from: x.yg, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0478yg {
    public static final AbstractC0171ib a;
    public static final Da b;

    static {
        AbstractC0112fb.a("TypefaceCompat static init");
        int i = Build.VERSION.SDK_INT;
        if (i >= 29) {
            a = new AbstractC0171ib();
        } else if (i >= 28) {
            a = new Bg();
        } else if (i >= 26) {
            a = new Bg();
        } else {
            Method method = Ag.n;
            if (method == null) {
                Log.w("TypefaceCompatApi24Impl", "Unable to collect necessary private methods.Fallback to legacy implementation.");
            }
            if (method != null) {
                a = new AbstractC0171ib();
            } else {
                a = new AbstractC0171ib();
            }
        }
        b = new Da(16);
        Trace.endSection();
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x002e, code lost:
    
        if (r5.equals(r6) == false) goto L15;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static Typeface a(Context context, S7 s7, Resources resources, int i, String str, int i2, int i3, AbstractC0112fb abstractC0112fb, boolean z) {
        Typeface m;
        Typeface typeface;
        List unmodifiableList;
        Handler handler;
        int i4 = 4;
        int i5 = 1;
        int i6 = 0;
        int i7 = -3;
        if (s7 instanceof V7) {
            V7 v7 = (V7) s7;
            String str2 = v7.e;
            if (str2 != null && !str2.isEmpty()) {
                typeface = Typeface.create(str2, 0);
                Typeface create = Typeface.create(Typeface.DEFAULT, 0);
                if (typeface != null) {
                }
            }
            typeface = null;
            if (typeface != null) {
                if (abstractC0112fb != null) {
                    new Handler(Looper.getMainLooper()).post(new RunnableC0042c1(abstractC0112fb, 2, typeface));
                }
                return typeface;
            }
            boolean z2 = !z ? abstractC0112fb != null : v7.d != 0;
            int i8 = z ? v7.c : -1;
            Handler handler2 = new Handler(Looper.getMainLooper());
            B b2 = new B(28);
            b2.b = abstractC0112fb;
            L7 l7 = v7.b;
            if (l7 != null) {
                Object[] objArr = {v7.a, l7};
                ArrayList arrayList = new ArrayList(2);
                for (int i9 = 0; i9 < 2; i9++) {
                    Object obj = objArr[i9];
                    Objects.requireNonNull(obj);
                    arrayList.add(obj);
                }
                unmodifiableList = Collections.unmodifiableList(arrayList);
            } else {
                Object[] objArr2 = {v7.a};
                ArrayList arrayList2 = new ArrayList(1);
                Object obj2 = objArr2[0];
                Objects.requireNonNull(obj2);
                arrayList2.add(obj2);
                unmodifiableList = Collections.unmodifiableList(arrayList2);
            }
            List list = unmodifiableList;
            Xd xd = new Xd(handler2);
            F1 f1 = new F1(b2, 5, xd);
            if (z2) {
                if (list.size() <= 1) {
                    L7 l72 = (L7) list.get(0);
                    Da da = R7.a;
                    ArrayList arrayList3 = new ArrayList(1);
                    Object obj3 = new Object[]{l72}[0];
                    Objects.requireNonNull(obj3);
                    arrayList3.add(obj3);
                    String a2 = R7.a(Collections.unmodifiableList(arrayList3), i3);
                    Typeface typeface2 = (Typeface) R7.a.f(a2);
                    if (typeface2 != null) {
                        xd.execute(new RunnableC0001a0(b2, i4, typeface2));
                        m = typeface2;
                    } else if (i8 == -1) {
                        ArrayList arrayList4 = new ArrayList(1);
                        Object obj4 = new Object[]{l72}[0];
                        Objects.requireNonNull(obj4);
                        arrayList4.add(obj4);
                        Q7 b3 = R7.b(a2, context, Collections.unmodifiableList(arrayList4), i3);
                        f1.H(b3);
                        m = b3.a;
                    } else {
                        try {
                            try {
                                Q7 q7 = (Q7) R7.b.submit(new O7(a2, context, l72, i3, 0)).get(i8, TimeUnit.MILLISECONDS);
                                f1.H(q7);
                                m = q7.a;
                            } catch (InterruptedException e) {
                                throw e;
                            } catch (ExecutionException e2) {
                                throw new RuntimeException(e2);
                            } catch (TimeoutException unused) {
                                throw new InterruptedException("timeout");
                            }
                        } catch (InterruptedException unused2) {
                            ((Xd) f1.c).execute(new RunnableC0181j3((B) f1.b, i7, i6));
                        }
                    }
                } else {
                    throw new IllegalArgumentException("Fallbacks with blocking fetches are not supported for performance reasons");
                }
            } else {
                String a3 = R7.a(list, i3);
                Typeface typeface3 = (Typeface) R7.a.f(a3);
                if (typeface3 != null) {
                    xd.execute(new RunnableC0001a0(b2, i4, typeface3));
                    m = typeface3;
                } else {
                    P7 p7 = new P7(i6, f1);
                    synchronized (R7.c) {
                        try {
                            Pe pe = R7.d;
                            ArrayList arrayList5 = (ArrayList) pe.get(a3);
                            if (arrayList5 != null) {
                                arrayList5.add(p7);
                            } else {
                                ArrayList arrayList6 = new ArrayList();
                                arrayList6.add(p7);
                                pe.put(a3, arrayList6);
                                O7 o7 = new O7(a3, context, list, i3, 1);
                                ThreadPoolExecutor threadPoolExecutor = R7.b;
                                P7 p72 = new P7(i5, a3);
                                if (Looper.myLooper() == null) {
                                    handler = new Handler(Looper.getMainLooper());
                                } else {
                                    handler = new Handler();
                                }
                                RunnableC0297p5 runnableC0297p5 = new RunnableC0297p5();
                                runnableC0297p5.b = o7;
                                runnableC0297p5.c = p72;
                                runnableC0297p5.d = handler;
                                threadPoolExecutor.execute(runnableC0297p5);
                            }
                        } finally {
                        }
                    }
                    m = null;
                }
            }
        } else {
            m = a.m(context, (T7) s7, resources, i3);
            if (abstractC0112fb != null) {
                if (m != null) {
                    new Handler(Looper.getMainLooper()).post(new RunnableC0042c1(abstractC0112fb, 2, m));
                } else {
                    abstractC0112fb.b(-3);
                }
            }
        }
        if (m != null) {
            b.j(b(resources, i, str, i2, i3), m);
        }
        return m;
    }

    public static String b(Resources resources, int i, String str, int i2, int i3) {
        return resources.getResourcePackageName(i) + '-' + str + '-' + i2 + '-' + i + '-' + i3;
    }
}
