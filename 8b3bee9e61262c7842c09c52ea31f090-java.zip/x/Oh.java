package x;

import android.graphics.Matrix;
import android.view.View;

/* loaded from: classes.dex */
public final class Oh extends Nh {
    @Override // x.AbstractC0171ib
    public final float C(View view) {
        float transitionAlpha;
        transitionAlpha = view.getTransitionAlpha();
        return transitionAlpha;
    }

    @Override // x.AbstractC0171ib
    public final void V(View view, float f) {
        view.setTransitionAlpha(f);
    }

    @Override // x.Nh, x.AbstractC0171ib
    public final void W(View view, int i) {
        view.setTransitionVisibility(i);
    }

    @Override // x.Nh
    public final void a0(View view, int i, int i2, int i3, int i4) {
        view.setLeftTopRightBottom(i, i2, i3, i4);
    }

    @Override // x.Nh
    public final void b0(View view, Matrix matrix) {
        view.transformMatrixToGlobal(matrix);
    }

    @Override // x.Nh
    public final void c0(View view, Matrix matrix) {
        view.transformMatrixToLocal(matrix);
    }
}
