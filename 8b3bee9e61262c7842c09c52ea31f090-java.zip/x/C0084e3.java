package x;

import android.view.View;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.sidesheet.SideSheetBehavior;
import java.lang.ref.WeakReference;
import java.util.WeakHashMap;

/* renamed from: x.e3, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0084e3 {
    public final /* synthetic */ int a;
    public int b;
    public boolean c;
    public final Runnable d;
    public final /* synthetic */ M4 e;

    public C0084e3(SideSheetBehavior sideSheetBehavior) {
        this.a = 1;
        this.e = sideSheetBehavior;
        this.d = new RunnableC0141h0(13, this);
    }

    public final void a(int i) {
        Runnable runnable = this.d;
        M4 m4 = this.e;
        switch (this.a) {
            case 0:
                BottomSheetBehavior bottomSheetBehavior = (BottomSheetBehavior) m4;
                WeakReference weakReference = bottomSheetBehavior.U;
                if (weakReference != null && weakReference.get() != null) {
                    this.b = i;
                    if (!this.c) {
                        WeakHashMap weakHashMap = AbstractC0309ph.a;
                        ((View) bottomSheetBehavior.U.get()).postOnAnimation((I2) runnable);
                        this.c = true;
                        return;
                    }
                    return;
                }
                return;
            default:
                SideSheetBehavior sideSheetBehavior = (SideSheetBehavior) m4;
                WeakReference weakReference2 = sideSheetBehavior.p;
                if (weakReference2 != null && weakReference2.get() != null) {
                    this.b = i;
                    if (!this.c) {
                        WeakHashMap weakHashMap2 = AbstractC0309ph.a;
                        ((View) sideSheetBehavior.p.get()).postOnAnimation((RunnableC0141h0) runnable);
                        this.c = true;
                        return;
                    }
                    return;
                }
                return;
        }
    }

    public C0084e3(BottomSheetBehavior bottomSheetBehavior) {
        this.a = 0;
        this.e = bottomSheetBehavior;
        this.d = new I2(1, this);
    }
}
