package x;

import android.view.MotionEvent;
import android.view.View;

/* loaded from: classes.dex */
public final class R2 implements View.OnTouchListener {
    @Override // android.view.View.OnTouchListener
    public final boolean onTouch(View view, MotionEvent motionEvent) {
        return true;
    }
}
