package x;

import android.app.Activity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;

/* renamed from: x.i4, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractActivityC0164i4 extends Activity implements Y9, K9 {
    public final androidx.lifecycle.a a = new androidx.lifecycle.a(this);

    @Override // android.app.Activity, android.view.Window.Callback
    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        E9.o(keyEvent, "event");
        View decorView = getWindow().getDecorView();
        E9.n(decorView, "window.decorView");
        if (E9.v(decorView, keyEvent)) {
            return true;
        }
        return E9.w(this, decorView, this, keyEvent);
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public final boolean dispatchKeyShortcutEvent(KeyEvent keyEvent) {
        E9.o(keyEvent, "event");
        View decorView = getWindow().getDecorView();
        E9.n(decorView, "window.decorView");
        if (E9.v(decorView, keyEvent)) {
            return true;
        }
        return super.dispatchKeyShortcutEvent(keyEvent);
    }

    @Override // x.K9
    public final boolean e(KeyEvent keyEvent) {
        E9.o(keyEvent, "event");
        return super.dispatchKeyEvent(keyEvent);
    }

    @Override // android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        int i = Ud.b;
        Sd.b(this);
    }

    @Override // android.app.Activity
    public void onSaveInstanceState(Bundle bundle) {
        E9.o(bundle, "outState");
        this.a.g();
        super.onSaveInstanceState(bundle);
    }
}
