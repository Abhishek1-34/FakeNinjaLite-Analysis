package x;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.LinkProperties;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.VpnService;
import android.os.Build;
import android.os.Handler;
import android.os.ParcelFileDescriptor;
import android.system.OsConstants;
import android.util.Log;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.concurrent.atomic.AtomicBoolean;
import org.conscrypt.R;

/* loaded from: classes.dex */
public abstract class Uh extends VpnService {
    public static final AtomicBoolean c = new AtomicBoolean(false);
    public static volatile String d = "VPN desativada";
    public ParcelFileDescriptor a;
    public C0436wc b;

    public static void b(ConnectivityManager connectivityManager, Network network, LinkedHashSet linkedHashSet) {
        NetworkCapabilities networkCapabilities;
        LinkProperties linkProperties;
        if (network != null && (networkCapabilities = connectivityManager.getNetworkCapabilities(network)) != null && !networkCapabilities.hasTransport(4) && networkCapabilities.hasCapability(12) && (linkProperties = connectivityManager.getLinkProperties(network)) != null) {
            linkedHashSet.addAll(linkProperties.getDnsServers());
        }
    }

    public final int a(VpnService.Builder builder, String str) {
        try {
            getPackageManager().getApplicationInfo(str, 0);
            builder.addAllowedApplication(str);
            return 1;
        } catch (PackageManager.NameNotFoundException unused) {
            Yb.h("Pacote do jogo não instalado: ".concat(str));
            return 0;
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:15:0x0037  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void c(VpnService.Builder builder) {
        LinkedHashSet linkedHashSet = new LinkedHashSet();
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(ConnectivityManager.class);
        int i = 0;
        if (connectivityManager != null) {
            Network activeNetwork = connectivityManager.getActiveNetwork();
            b(connectivityManager, activeNetwork, linkedHashSet);
            for (Network network : connectivityManager.getAllNetworks()) {
                if (!network.equals(activeNetwork)) {
                    b(connectivityManager, network, linkedHashSet);
                }
            }
        }
        Iterator it = linkedHashSet.iterator();
        while (it.hasNext()) {
            InetAddress inetAddress = (InetAddress) it.next();
            if (inetAddress instanceof Inet4Address) {
                try {
                    builder.addDnsServer(inetAddress);
                    i++;
                } catch (IllegalArgumentException unused) {
                }
                if (i == 3) {
                    break;
                }
            }
            while (it.hasNext()) {
            }
        }
        if (i == 0) {
            builder.addDnsServer("8.8.8.8");
            builder.addDnsServer("1.1.1.1");
            Yb.h("DNS alternativo: 8.8.8.8 e 1.1.1.1");
        }
    }

    public final synchronized void d() {
        this.b = null;
        ParcelFileDescriptor parcelFileDescriptor = this.a;
        this.a = null;
        if (parcelFileDescriptor != null) {
            try {
                parcelFileDescriptor.close();
            } catch (IOException unused) {
            }
        }
        c.set(false);
        Z6.i = false;
        Z6.a();
        Z6.a.post(new RunnableC0443x0(3));
        F8.g = false;
        E8.g(false);
        F8.a.post(new RunnableC0443x0(15));
        AbstractC0481z0.g = false;
        vpn.team09.hax.d.a(false);
        AbstractC0481z0.a.post(new RunnableC0443x0(0));
        AbstractC0206k9.g = false;
        Oc.j(false);
        AbstractC0206k9.a.post(new RunnableC0443x0(17));
        f(false, "VPN interrompida");
        stopForeground(1);
        stopSelf();
    }

    public final synchronized void e(String str) {
        try {
            C0436wc c0436wc = this.b;
            this.b = null;
            if (c0436wc != null) {
                c0436wc.i();
            }
            ParcelFileDescriptor parcelFileDescriptor = this.a;
            this.a = null;
            if (parcelFileDescriptor != null) {
                try {
                    parcelFileDescriptor.close();
                } catch (IOException unused) {
                }
            }
            c.set(false);
            Z6.i = false;
            Z6.a();
            Z6.a.post(new RunnableC0443x0(3));
            F8.g = false;
            E8.g(false);
            F8.a.post(new RunnableC0443x0(15));
            AbstractC0481z0.g = false;
            vpn.team09.hax.d.a(false);
            AbstractC0481z0.a.post(new RunnableC0443x0(0));
            AbstractC0206k9.g = false;
            Oc.j(false);
            AbstractC0206k9.a.post(new RunnableC0443x0(17));
            f(false, str);
            stopForeground(1);
        } catch (Throwable th) {
            throw th;
        }
    }

    public final void f(boolean z, String str) {
        d = str;
        sendBroadcast(new Intent("vpn.team09.hax.VPN_STATUS").setPackage(getPackageName()).putExtra("status", str).putExtra("running", z));
    }

    @Override // android.app.Service
    public final void onDestroy() {
        e("VPN interrompida");
        super.onDestroy();
    }

    @Override // android.net.VpnService
    public final void onRevoke() {
        e("A permissão da VPN foi revogada");
        super.onRevoke();
    }

    /* JADX WARN: Type inference failed for: r5v2, types: [java.lang.Object, x.ac] */
    @Override // android.app.Service
    public final int onStartCommand(Intent intent, int i, int i2) {
        String action;
        Notification build;
        String message;
        int a;
        boolean z;
        ParcelFileDescriptor establish;
        String str;
        StringBuilder sb = new StringBuilder("Ação de início da VPN=");
        if (intent == null) {
            action = "nula";
        } else {
            action = intent.getAction();
        }
        sb.append(action);
        Yb.h(sb.toString());
        if (intent != null && "vpn.team09.hax.STOP_VPN".equals(intent.getAction())) {
            e("VPN desativada");
            stopSelf();
            return 2;
        }
        NotificationManager notificationManager = (NotificationManager) getSystemService(NotificationManager.class);
        int i3 = Build.VERSION.SDK_INT;
        if (i3 >= 26) {
            AbstractC0347s.e();
            NotificationChannel b = AbstractC0347s.b(getString(R.string.channel_name));
            b.setShowBadge(false);
            notificationManager.createNotificationChannel(b);
        }
        PendingIntent activity = PendingIntent.getActivity(this, 0, new Intent(this, (Class<?>) vpn.team09.hax.b.class), 201326592);
        PendingIntent service = PendingIntent.getService(this, 1, new Intent(this, (Class<?>) vpn.team09.hax.c.class).setAction("vpn.team09.hax.STOP_VPN"), 201326592);
        ?? obj = new Object();
        ArrayList arrayList = new ArrayList();
        obj.b = arrayList;
        obj.c = new ArrayList();
        obj.d = new ArrayList();
        obj.h = true;
        Notification notification = new Notification();
        obj.m = notification;
        obj.a = this;
        obj.k = "projectx_vpn_proxy";
        notification.when = System.currentTimeMillis();
        notification.audioStreamType = -1;
        obj.n = new ArrayList();
        obj.l = true;
        notification.icon = android.R.drawable.stat_notify_sync_noanim;
        String string = getString(R.string.notif_title);
        CharSequence charSequence = string;
        if (string != null) {
            int length = string.length();
            charSequence = string;
            if (length > 5120) {
                charSequence = string.subSequence(0, 5120);
            }
        }
        obj.e = charSequence;
        String string2 = getString(R.string.notif_text);
        CharSequence charSequence2 = string2;
        if (string2 != null) {
            int length2 = string2.length();
            charSequence2 = string2;
            if (length2 > 5120) {
                charSequence2 = string2.subSequence(0, 5120);
            }
        }
        obj.f = charSequence2;
        obj.g = activity;
        obj.m.flags |= 10;
        obj.i = "service";
        arrayList.add(new Zb(service));
        C0294p2 c0294p2 = new C0294p2((C0013ac) obj);
        ((C0013ac) c0294p2.c).getClass();
        Notification.Builder builder = (Notification.Builder) c0294p2.b;
        if (i3 >= 26) {
            build = builder.build();
        } else {
            build = builder.build();
        }
        startForeground(1, build);
        if (!vpn.team09.hax.q.a) {
            if (vpn.team09.hax.q.b) {
                Yb.c("Mecanismo nativo indisponível: " + vpn.team09.hax.q.d, null);
            }
            Yb.h("Mecanismo Java da VPN ativo; módulo nativo desativado ou indisponível");
        }
        AtomicBoolean atomicBoolean = c;
        if (!atomicBoolean.get()) {
            synchronized (this) {
                if (!atomicBoolean.get() && this.a == null) {
                    f(false, "Criando a interface VPN…");
                    try {
                        VpnService.Builder blocking = new VpnService.Builder(this).setSession(getString(R.string.vpn_session)).setMtu(1500).addAddress("10.111.0.2", 32).addRoute("0.0.0.0", 0).setBlocking(true);
                        if (i3 >= 29) {
                            blocking.setMetered(false);
                        }
                        try {
                            blocking.allowFamily(OsConstants.AF_INET6);
                        } catch (RuntimeException e) {
                            Log.w("ProjectX-VPN", "Não foi possível liberar o IPv6 fora da VPN", e);
                        }
                        c(blocking);
                        a = a(blocking, "com.dts.freefireth") + a(blocking, "com.dts.freefiremax");
                        if (a == 0) {
                            z = true;
                        } else {
                            z = false;
                        }
                        if (a == 0) {
                            try {
                                blocking.addDisallowedApplication(getPackageName());
                                Yb.h("Jogo conhecido não encontrado; captura completa ativada, exceto o Project X");
                            } catch (RuntimeException e2) {
                                Yb.c("Falha ao ativar a captura completa da VPN", e2);
                            }
                        }
                        establish = blocking.establish();
                        this.a = establish;
                    } catch (Exception e3) {
                        Log.e("ProjectX-VPN", "Não foi possível ativar a VPN", e3);
                        StringBuilder sb2 = new StringBuilder("Não foi possível ativar a VPN: ");
                        if (e3.getMessage() == null) {
                            message = e3.getClass().getSimpleName();
                        } else {
                            message = e3.getMessage();
                        }
                        sb2.append(message);
                        e(sb2.toString());
                        stopSelf();
                        Yb.c("Falha ao estabelecer a VPN", e3);
                    }
                    if (establish != null) {
                        C0436wc c0436wc = new C0436wc(this, new FileInputStream(this.a.getFileDescriptor()), new FileOutputStream(this.a.getFileDescriptor()));
                        this.b = c0436wc;
                        c.set(true);
                        Z6.f();
                        Jb.d();
                        E8.c();
                        C0110f9.k.j();
                        Z6.b(this);
                        Z6.i = true;
                        Z6.d();
                        Handler handler = F8.a;
                        F8.b = getApplicationContext();
                        F8.a();
                        F8.g = true;
                        F8.a();
                        AbstractC0481z0.a(this);
                        AbstractC0481z0.g = true;
                        AbstractC0481z0.a.post(new RunnableC0443x0(2));
                        Handler handler2 = AbstractC0206k9.a;
                        Context applicationContext = getApplicationContext();
                        AbstractC0206k9.b = applicationContext;
                        AbstractC0206k9.f = applicationContext.getSharedPreferences("proxy_read", 0).getBoolean("ghost_on", false);
                        Handler handler3 = AbstractC0206k9.a;
                        handler3.post(new RunnableC0443x0(17));
                        AbstractC0206k9.g = true;
                        handler3.post(new RunnableC0443x0(17));
                        E7.h();
                        if (z) {
                            str = "VPN ativa · todos os aplicativos";
                        } else {
                            str = "VPN ativa · " + a + " aplicativo(s)";
                        }
                        f(true, str);
                        Yb.h("VPN estabelecida: aplicativos=" + a + " capturaCompleta=" + z + " MTU=1500 IPv6=fora-da-VPN");
                        new Thread(new RunnableC0042c1(this, 3, c0436wc), "crg-packet-engine").start();
                    } else {
                        throw new IOException("O Android não concedeu a interface VPN");
                    }
                }
            }
        }
        return 1;
    }
}
