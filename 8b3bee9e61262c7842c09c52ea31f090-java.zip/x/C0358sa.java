package x;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Handler;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.PopupWindow;
import java.lang.reflect.Method;

/* renamed from: x.sa, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public class C0358sa implements Me {
    public static final Method A;
    public static final Method B;
    public final Context a;
    public ListAdapter b;
    public X5 c;
    public int f;
    public int g;
    public boolean i;
    public boolean j;
    public boolean k;
    public C0302pa n;
    public View o;
    public AdapterView.OnItemClickListener p;
    public AdapterView.OnItemSelectedListener q;
    public final Handler v;

    /* renamed from: x, reason: collision with root package name */
    public Rect f31x;
    public boolean y;
    public final E1 z;
    public final int d = -2;
    public int e = -2;
    public final int h = 1002;
    public int l = 0;
    public final int m = Integer.MAX_VALUE;
    public final RunnableC0283oa r = new RunnableC0283oa(this, 1);
    public final ViewOnTouchListenerC0339ra s = new ViewOnTouchListenerC0339ra(0, this);
    public final C0321qa t = new C0321qa(this);
    public final RunnableC0283oa u = new RunnableC0283oa(this, 0);
    public final Rect w = new Rect();

    static {
        if (Build.VERSION.SDK_INT <= 28) {
            try {
                A = PopupWindow.class.getDeclaredMethod("setClipToScreenEnabled", Boolean.TYPE);
            } catch (NoSuchMethodException unused) {
                Log.i("ListPopupWindow", "Could not find method setClipToScreenEnabled() on PopupWindow. Oh well.");
            }
            try {
                B = PopupWindow.class.getDeclaredMethod("setEpicenterBounds", Rect.class);
            } catch (NoSuchMethodException unused2) {
                Log.i("ListPopupWindow", "Could not find method setEpicenterBounds(Rect) on PopupWindow. Oh well.");
            }
        }
    }

    /* JADX WARN: Type inference failed for: r1v9, types: [x.E1, android.widget.PopupWindow] */
    public C0358sa(Context context, AttributeSet attributeSet, int i) {
        Drawable drawable;
        int resourceId;
        this.a = context;
        this.v = new Handler(context.getMainLooper());
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, AbstractC0210kd.o, i, 0);
        this.f = obtainStyledAttributes.getDimensionPixelOffset(0, 0);
        int dimensionPixelOffset = obtainStyledAttributes.getDimensionPixelOffset(1, 0);
        this.g = dimensionPixelOffset;
        if (dimensionPixelOffset != 0) {
            this.i = true;
        }
        obtainStyledAttributes.recycle();
        ?? popupWindow = new PopupWindow(context, attributeSet, i, 0);
        TypedArray obtainStyledAttributes2 = context.obtainStyledAttributes(attributeSet, AbstractC0210kd.s, i, 0);
        if (obtainStyledAttributes2.hasValue(2)) {
            popupWindow.setOverlapAnchor(obtainStyledAttributes2.getBoolean(2, false));
        }
        if (obtainStyledAttributes2.hasValue(0) && (resourceId = obtainStyledAttributes2.getResourceId(0, 0)) != 0) {
            drawable = AbstractC0124g3.r(context, resourceId);
        } else {
            drawable = obtainStyledAttributes2.getDrawable(0);
        }
        popupWindow.setBackgroundDrawable(drawable);
        obtainStyledAttributes2.recycle();
        this.z = popupWindow;
        popupWindow.setInputMethodMode(1);
    }

    @Override // x.Me
    public final boolean a() {
        return this.z.isShowing();
    }

    public final void c(int i) {
        this.f = i;
    }

    public final int d() {
        return this.f;
    }

    @Override // x.Me
    public final void dismiss() {
        E1 e1 = this.z;
        e1.dismiss();
        e1.setContentView(null);
        this.c = null;
        this.v.removeCallbacks(this.r);
    }

    @Override // x.Me
    public final X5 e() {
        return this.c;
    }

    @Override // x.Me
    public final void i() {
        int i;
        boolean z;
        int makeMeasureSpec;
        int i2;
        int i3;
        boolean z2;
        X5 x5;
        int i4;
        int i5;
        X5 x52 = this.c;
        E1 e1 = this.z;
        Context context = this.a;
        if (x52 == null) {
            X5 q = q(context, !this.y);
            this.c = q;
            q.setAdapter(this.b);
            this.c.setOnItemClickListener(this.p);
            this.c.setFocusable(true);
            this.c.setFocusableInTouchMode(true);
            this.c.setOnItemSelectedListener(new C0226la(this));
            this.c.setOnScrollListener(this.t);
            AdapterView.OnItemSelectedListener onItemSelectedListener = this.q;
            if (onItemSelectedListener != null) {
                this.c.setOnItemSelectedListener(onItemSelectedListener);
            }
            e1.setContentView(this.c);
        }
        Drawable background = e1.getBackground();
        int i6 = 0;
        Rect rect = this.w;
        if (background != null) {
            background.getPadding(rect);
            int i7 = rect.top;
            i = rect.bottom + i7;
            if (!this.i) {
                this.g = -i7;
            }
        } else {
            rect.setEmpty();
            i = 0;
        }
        if (e1.getInputMethodMode() == 2) {
            z = true;
        } else {
            z = false;
        }
        int a = AbstractC0245ma.a(e1, this.o, this.g, z);
        int i8 = this.d;
        if (i8 == -1) {
            i3 = a + i;
        } else {
            int i9 = this.e;
            if (i9 != -2) {
                if (i9 != -1) {
                    makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(i9, 1073741824);
                } else {
                    makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(context.getResources().getDisplayMetrics().widthPixels - (rect.left + rect.right), 1073741824);
                }
            } else {
                makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(context.getResources().getDisplayMetrics().widthPixels - (rect.left + rect.right), Integer.MIN_VALUE);
            }
            int a2 = this.c.a(makeMeasureSpec, a);
            if (a2 > 0) {
                i2 = this.c.getPaddingBottom() + this.c.getPaddingTop() + i;
            } else {
                i2 = 0;
            }
            i3 = a2 + i2;
        }
        if (this.z.getInputMethodMode() == 2) {
            z2 = true;
        } else {
            z2 = false;
        }
        e1.setWindowLayoutType(this.h);
        if (e1.isShowing()) {
            if (!this.o.isAttachedToWindow()) {
                return;
            }
            int i10 = this.e;
            if (i10 == -1) {
                i10 = -1;
            } else if (i10 == -2) {
                i10 = this.o.getWidth();
            }
            if (i8 == -1) {
                if (z2) {
                    i8 = i3;
                } else {
                    i8 = -1;
                }
                if (z2) {
                    if (this.e == -1) {
                        i5 = -1;
                    } else {
                        i5 = 0;
                    }
                    e1.setWidth(i5);
                    e1.setHeight(0);
                } else {
                    if (this.e == -1) {
                        i6 = -1;
                    }
                    e1.setWidth(i6);
                    e1.setHeight(-1);
                }
            } else if (i8 == -2) {
                i8 = i3;
            }
            e1.setOutsideTouchable(true);
            View view = this.o;
            int i11 = this.f;
            int i12 = this.g;
            if (i10 < 0) {
                i10 = -1;
            }
            if (i8 < 0) {
                i4 = -1;
            } else {
                i4 = i8;
            }
            e1.update(view, i11, i12, i10, i4);
            return;
        }
        int i13 = this.e;
        if (i13 == -1) {
            i13 = -1;
        } else if (i13 == -2) {
            i13 = this.o.getWidth();
        }
        if (i8 == -1) {
            i8 = -1;
        } else if (i8 == -2) {
            i8 = i3;
        }
        e1.setWidth(i13);
        e1.setHeight(i8);
        if (Build.VERSION.SDK_INT <= 28) {
            Method method = A;
            if (method != null) {
                try {
                    method.invoke(e1, Boolean.TRUE);
                } catch (Exception unused) {
                    Log.i("ListPopupWindow", "Could not call setClipToScreenEnabled() on PopupWindow. Oh well.");
                }
            }
        } else {
            AbstractC0264na.b(e1, true);
        }
        e1.setOutsideTouchable(true);
        e1.setTouchInterceptor(this.s);
        if (this.k) {
            e1.setOverlapAnchor(this.j);
        }
        if (Build.VERSION.SDK_INT <= 28) {
            Method method2 = B;
            if (method2 != null) {
                try {
                    method2.invoke(e1, this.f31x);
                } catch (Exception e) {
                    Log.e("ListPopupWindow", "Could not invoke setEpicenterBounds on PopupWindow", e);
                }
            }
        } else {
            AbstractC0264na.a(e1, this.f31x);
        }
        e1.showAsDropDown(this.o, this.f, this.g, this.l);
        this.c.setSelection(-1);
        if ((!this.y || this.c.isInTouchMode()) && (x5 = this.c) != null) {
            x5.setListSelectionHidden(true);
            x5.requestLayout();
        }
        if (!this.y) {
            this.v.post(this.u);
        }
    }

    public final int j() {
        if (!this.i) {
            return 0;
        }
        return this.g;
    }

    public final void k(Drawable drawable) {
        this.z.setBackgroundDrawable(drawable);
    }

    public final void l(int i) {
        this.g = i;
        this.i = true;
    }

    public final Drawable m() {
        return this.z.getBackground();
    }

    public void o(ListAdapter listAdapter) {
        C0302pa c0302pa = this.n;
        if (c0302pa == null) {
            this.n = new C0302pa(this);
        } else {
            ListAdapter listAdapter2 = this.b;
            if (listAdapter2 != null) {
                listAdapter2.unregisterDataSetObserver(c0302pa);
            }
        }
        this.b = listAdapter;
        if (listAdapter != null) {
            listAdapter.registerDataSetObserver(this.n);
        }
        X5 x5 = this.c;
        if (x5 != null) {
            x5.setAdapter(this.b);
        }
    }

    public X5 q(Context context, boolean z) {
        return new X5(context, z);
    }

    public final void r(int i) {
        Drawable background = this.z.getBackground();
        if (background != null) {
            Rect rect = this.w;
            background.getPadding(rect);
            this.e = rect.left + rect.right + i;
            return;
        }
        this.e = i;
    }
}
