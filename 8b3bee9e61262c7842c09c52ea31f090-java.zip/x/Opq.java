package x;

import android.view.View;
import android.view.WindowManager;
import android.widget.SeekBar;

/* loaded from: classes.dex */
public final class Opq implements SeekBar.OnSeekBarChangeListener {
    @Override // android.widget.SeekBar.OnSeekBarChangeListener
    public final void onProgressChanged(SeekBar seekBar, int i, boolean z) {
        WindowManager.LayoutParams layoutParams;
        float f = i / 100.0f;
        View view = E7.f;
        if (view != null) {
            view.setAlpha(f);
            WindowManager windowManager = E7.c;
            if (windowManager == null || (layoutParams = E7.g) == null) {
                return;
            }
            windowManager.updateViewLayout(view, layoutParams);
        }
    }

    @Override // android.widget.SeekBar.OnSeekBarChangeListener
    public final void onStartTrackingTouch(SeekBar seekBar) {
    }

    @Override // android.widget.SeekBar.OnSeekBarChangeListener
    public final void onStopTrackingTouch(SeekBar seekBar) {
    }
}
