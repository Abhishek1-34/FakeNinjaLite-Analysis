package x;

import android.graphics.Rect;
import android.view.View;

/* renamed from: x.k6, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0203k6 {
    public int a;
    public final Object b;
    public final Object c;

    public AbstractC0203k6(AbstractC0475yd abstractC0475yd) {
        this.a = Integer.MIN_VALUE;
        this.c = new Rect();
        this.b = abstractC0475yd;
    }

    public static AbstractC0203k6 a(AbstractC0475yd abstractC0475yd, int i) {
        if (i != 0) {
            if (i == 1) {
                return new C0323qc(abstractC0475yd, 1);
            }
            throw new IllegalArgumentException("invalid orientation");
        }
        return new C0323qc(abstractC0475yd, 0);
    }

    public abstract int b(View view);

    public abstract int c(View view);

    public abstract int d(View view);

    public abstract int e(View view);

    public abstract int f();

    public abstract int g();

    public abstract int h();

    public abstract int i();

    public abstract int j();

    public abstract int k();

    public abstract int l();

    public int m() {
        if (Integer.MIN_VALUE == this.a) {
            return 0;
        }
        return l() - this.a;
    }

    public abstract int n(View view);

    public abstract int o(View view);

    public abstract void p(int i);

    public AbstractC0203k6(InterfaceC0241m6 interfaceC0241m6) {
        this.a = 0;
        this.c = new C0106f5();
        this.b = interfaceC0241m6;
    }
}
