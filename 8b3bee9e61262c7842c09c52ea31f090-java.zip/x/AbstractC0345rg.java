package x;

import android.widget.FrameLayout;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import org.conscrypt.R;

/* renamed from: x.rg, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0345rg {
    public static final J2 a;
    public static final ThreadLocal b;
    public static final ArrayList c;

    /* JADX WARN: Type inference failed for: r0v0, types: [x.ng, x.J2] */
    static {
        ?? abstractC0270ng = new AbstractC0270ng();
        abstractC0270ng.A = new ArrayList();
        abstractC0270ng.D = false;
        abstractC0270ng.E = 0;
        abstractC0270ng.B = false;
        abstractC0270ng.I(new C0167i7(2));
        abstractC0270ng.I(new AbstractC0270ng());
        abstractC0270ng.I(new C0167i7(1));
        a = abstractC0270ng;
        b = new ThreadLocal();
        c = new ArrayList();
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v6, types: [android.view.ViewTreeObserver$OnPreDrawListener, java.lang.Object, android.view.View$OnAttachStateChangeListener, x.qg] */
    public static void a(FrameLayout frameLayout, AbstractC0270ng abstractC0270ng) {
        ArrayList arrayList = c;
        if (!arrayList.contains(frameLayout) && frameLayout.isLaidOut()) {
            arrayList.add(frameLayout);
            if (abstractC0270ng == null) {
                abstractC0270ng = a;
            }
            AbstractC0270ng clone = abstractC0270ng.clone();
            ArrayList arrayList2 = (ArrayList) b().get(frameLayout);
            if (arrayList2 != null && arrayList2.size() > 0) {
                Iterator it = arrayList2.iterator();
                while (it.hasNext()) {
                    ((AbstractC0270ng) it.next()).w(frameLayout);
                }
            }
            clone.h(frameLayout, true);
            if (frameLayout.getTag(R.id.transition_current_scene) == null) {
                frameLayout.setTag(R.id.transition_current_scene, null);
                ?? obj = new Object();
                obj.a = clone;
                obj.b = frameLayout;
                frameLayout.addOnAttachStateChangeListener(obj);
                frameLayout.getViewTreeObserver().addOnPreDrawListener(obj);
                return;
            }
            throw new ClassCastException();
        }
    }

    /* JADX WARN: Type inference failed for: r1v2, types: [x.B2, java.lang.Object, x.Pe] */
    public static B2 b() {
        B2 b2;
        ThreadLocal threadLocal = b;
        WeakReference weakReference = (WeakReference) threadLocal.get();
        if (weakReference != null && (b2 = (B2) weakReference.get()) != null) {
            return b2;
        }
        ?? pe = new Pe(0);
        threadLocal.set(new WeakReference(pe));
        return pe;
    }
}
