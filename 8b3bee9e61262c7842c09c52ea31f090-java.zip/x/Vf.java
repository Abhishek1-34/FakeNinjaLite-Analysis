package x;

import android.view.MenuItem;
import androidx.appcompat.widget.Toolbar;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;

/* loaded from: classes.dex */
public final class Vf implements InterfaceC0101f0, InterfaceC0208kb {
    public final /* synthetic */ Toolbar a;

    public /* synthetic */ Vf(Toolbar toolbar) {
        this.a = toolbar;
    }

    @Override // x.InterfaceC0208kb
    public boolean i(MenuC0246mb menuC0246mb, MenuItem menuItem) {
        this.a.getClass();
        return false;
    }

    @Override // x.InterfaceC0208kb
    public void t(MenuC0246mb menuC0246mb) {
        Toolbar toolbar = this.a;
        C0041c0 c0041c0 = toolbar.a.t;
        if (c0041c0 == null || !c0041c0.i()) {
            Iterator it = ((CopyOnWriteArrayList) toolbar.G.d).iterator();
            while (it.hasNext()) {
                ((C0262n8) it.next()).a.s();
            }
        }
    }
}
