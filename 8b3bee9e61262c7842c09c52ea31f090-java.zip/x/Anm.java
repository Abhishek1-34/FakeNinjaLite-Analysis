package x;

import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.Drawable;
import android.view.View;

/* loaded from: classes.dex */
public final class Anm {
    public static void a(View view) {
        if (view != null) {
            Drawable background = view.getBackground();
            if (background instanceof AnimationDrawable) {
                ((AnimationDrawable) background).start();
            }
        }
    }
}
