package x;

import android.view.View;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import java.util.WeakHashMap;

/* renamed from: x.zh, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0498zh extends M4 {
    public C0012ab a;

    @Override // x.M4
    public boolean g(CoordinatorLayout coordinatorLayout, View view, int i) {
        r(coordinatorLayout, view, i);
        if (this.a == null) {
            this.a = new C0012ab(view);
        }
        C0012ab c0012ab = this.a;
        View view2 = (View) c0012ab.a;
        c0012ab.b = view2.getTop();
        c0012ab.c = view2.getLeft();
        C0012ab c0012ab2 = this.a;
        View view3 = (View) c0012ab2.a;
        int top = 0 - (view3.getTop() - c0012ab2.b);
        WeakHashMap weakHashMap = AbstractC0309ph.a;
        view3.offsetTopAndBottom(top);
        view3.offsetLeftAndRight(0 - (view3.getLeft() - c0012ab2.c));
        return true;
    }

    public void r(CoordinatorLayout coordinatorLayout, View view, int i) {
        coordinatorLayout.q(view, i);
    }
}
