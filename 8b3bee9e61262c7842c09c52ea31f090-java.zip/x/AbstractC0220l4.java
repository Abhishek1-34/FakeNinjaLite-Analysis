package x;

import android.os.Handler;
import android.os.Looper;

/* renamed from: x.l4, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0220l4 {
    public static Handler a(Looper looper) {
        Handler createAsync;
        createAsync = Handler.createAsync(looper);
        return createAsync;
    }
}
