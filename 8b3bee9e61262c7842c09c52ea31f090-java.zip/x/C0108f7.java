package x;

/* renamed from: x.f7, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0108f7 {
    public final long a;
    public final int b;

    public /* synthetic */ C0108f7(long j, int i) {
        this.a = j;
        this.b = i;
    }
}
