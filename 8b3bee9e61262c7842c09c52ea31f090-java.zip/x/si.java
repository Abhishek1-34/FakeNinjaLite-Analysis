package x;

import android.graphics.Insets;
import android.view.WindowInsets;

/* loaded from: classes.dex */
public class si extends ri {
    public C9 n;
    public C9 o;
    public C9 p;

    public si(wi wiVar, WindowInsets windowInsets) {
        super(wiVar, windowInsets);
        this.n = null;
        this.o = null;
        this.p = null;
    }

    @Override // x.ui
    public C9 g() {
        Insets mandatorySystemGestureInsets;
        if (this.o == null) {
            mandatorySystemGestureInsets = this.c.getMandatorySystemGestureInsets();
            this.o = C9.c(mandatorySystemGestureInsets);
        }
        return this.o;
    }

    @Override // x.ui
    public C9 i() {
        Insets systemGestureInsets;
        if (this.n == null) {
            systemGestureInsets = this.c.getSystemGestureInsets();
            this.n = C9.c(systemGestureInsets);
        }
        return this.n;
    }

    @Override // x.ui
    public C9 k() {
        Insets tappableElementInsets;
        if (this.p == null) {
            tappableElementInsets = this.c.getTappableElementInsets();
            this.p = C9.c(tappableElementInsets);
        }
        return this.p;
    }

    @Override // x.pi, x.ui
    public wi l(int i, int i2, int i3, int i4) {
        WindowInsets inset;
        inset = this.c.inset(i, i2, i3, i4);
        return wi.g(null, inset);
    }

    @Override // x.qi, x.ui
    public void q(C9 c9) {
    }
}
