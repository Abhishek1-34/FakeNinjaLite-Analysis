package x;

import android.os.Trace;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.Collections;
import java.util.concurrent.TimeUnit;

/* renamed from: x.i9, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class RunnableC0169i9 implements Runnable {
    public static final ThreadLocal e = new ThreadLocal();
    public static final S4 f = new S4(1);
    public ArrayList a;
    public long b;
    public long c;
    public ArrayList d;

    public static Md c(RecyclerView recyclerView, int i, long j) {
        int u = recyclerView.e.u();
        for (int i2 = 0; i2 < u; i2++) {
            Md I = RecyclerView.I(recyclerView.e.t(i2));
            if (I.c == i && !I.g()) {
                return null;
            }
        }
        Ed ed = recyclerView.b;
        try {
            recyclerView.P();
            Md i3 = ed.i(j, i);
            if (i3 != null) {
                if (i3.f() && !i3.g()) {
                    ed.f(i3.a);
                } else {
                    ed.a(i3, false);
                }
            }
            recyclerView.Q(false);
            return i3;
        } catch (Throwable th) {
            recyclerView.Q(false);
            throw th;
        }
    }

    public final void a(RecyclerView recyclerView, int i, int i2) {
        if (recyclerView.p && this.b == 0) {
            this.b = recyclerView.getNanoTime();
            recyclerView.post(this);
        }
        C0130g9 c0130g9 = recyclerView.b0;
        c0130g9.a = i;
        c0130g9.b = i2;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final void b(long j) {
        C0150h9 c0150h9;
        RecyclerView recyclerView;
        long j2;
        RecyclerView recyclerView2;
        C0150h9 c0150h92;
        boolean z;
        ArrayList arrayList = this.a;
        int size = arrayList.size();
        int i = 0;
        for (int i2 = 0; i2 < size; i2++) {
            RecyclerView recyclerView3 = (RecyclerView) arrayList.get(i2);
            if (recyclerView3.getWindowVisibility() == 0) {
                C0130g9 c0130g9 = recyclerView3.b0;
                c0130g9.b(recyclerView3, false);
                i += c0130g9.c;
            }
        }
        ArrayList arrayList2 = this.d;
        arrayList2.ensureCapacity(i);
        int i3 = 0;
        for (int i4 = 0; i4 < size; i4++) {
            RecyclerView recyclerView4 = (RecyclerView) arrayList.get(i4);
            if (recyclerView4.getWindowVisibility() == 0) {
                C0130g9 c0130g92 = recyclerView4.b0;
                int abs = Math.abs(c0130g92.b) + Math.abs(c0130g92.a);
                for (int i5 = 0; i5 < c0130g92.c * 2; i5 += 2) {
                    if (i3 >= arrayList2.size()) {
                        Object obj = new Object();
                        arrayList2.add(obj);
                        c0150h92 = obj;
                    } else {
                        c0150h92 = (C0150h9) arrayList2.get(i3);
                    }
                    int[] iArr = (int[]) c0130g92.d;
                    int i6 = iArr[i5 + 1];
                    if (i6 <= abs) {
                        z = true;
                    } else {
                        z = false;
                    }
                    c0150h92.a = z;
                    c0150h92.b = abs;
                    c0150h92.c = i6;
                    c0150h92.d = recyclerView4;
                    c0150h92.e = iArr[i5];
                    i3++;
                }
            }
        }
        Collections.sort(arrayList2, f);
        for (int i7 = 0; i7 < arrayList2.size() && (recyclerView = (c0150h9 = (C0150h9) arrayList2.get(i7)).d) != null; i7++) {
            if (c0150h9.a) {
                j2 = Long.MAX_VALUE;
            } else {
                j2 = j;
            }
            Md c = c(recyclerView, c0150h9.e, j2);
            if (c != null && c.b != null && c.f() && !c.g() && (recyclerView2 = (RecyclerView) c.b.get()) != null) {
                if (recyclerView2.y && recyclerView2.e.u() != 0) {
                    AbstractC0399ud abstractC0399ud = recyclerView2.H;
                    if (abstractC0399ud != null) {
                        abstractC0399ud.e();
                    }
                    AbstractC0475yd abstractC0475yd = recyclerView2.l;
                    Ed ed = recyclerView2.b;
                    if (abstractC0475yd != null) {
                        abstractC0475yd.g0(ed);
                        recyclerView2.l.h0(ed);
                    }
                    ed.a.clear();
                    ed.d();
                }
                C0130g9 c0130g93 = recyclerView2.b0;
                c0130g93.b(recyclerView2, true);
                if (c0130g93.c != 0) {
                    try {
                        int i8 = AbstractC0175ig.a;
                        Trace.beginSection("RV Nested Prefetch");
                        Jd jd = recyclerView2.c0;
                        AbstractC0324qd abstractC0324qd = recyclerView2.k;
                        jd.d = 1;
                        jd.e = abstractC0324qd.a();
                        jd.g = false;
                        jd.h = false;
                        jd.i = false;
                        for (int i9 = 0; i9 < c0130g93.c * 2; i9 += 2) {
                            c(recyclerView2, ((int[]) c0130g93.d)[i9], j);
                        }
                        Trace.endSection();
                        c0150h9.a = false;
                        c0150h9.b = 0;
                        c0150h9.c = 0;
                        c0150h9.d = null;
                        c0150h9.e = 0;
                    } catch (Throwable th) {
                        int i10 = AbstractC0175ig.a;
                        Trace.endSection();
                        throw th;
                    }
                }
            }
            c0150h9.a = false;
            c0150h9.b = 0;
            c0150h9.c = 0;
            c0150h9.d = null;
            c0150h9.e = 0;
        }
    }

    @Override // java.lang.Runnable
    public final void run() {
        try {
            int i = AbstractC0175ig.a;
            Trace.beginSection("RV Prefetch");
            ArrayList arrayList = this.a;
            if (arrayList.isEmpty()) {
                this.b = 0L;
                Trace.endSection();
                return;
            }
            int size = arrayList.size();
            long j = 0;
            for (int i2 = 0; i2 < size; i2++) {
                RecyclerView recyclerView = (RecyclerView) arrayList.get(i2);
                if (recyclerView.getWindowVisibility() == 0) {
                    j = Math.max(recyclerView.getDrawingTime(), j);
                }
            }
            if (j == 0) {
                this.b = 0L;
                Trace.endSection();
            } else {
                b(TimeUnit.MILLISECONDS.toNanos(j) + this.c);
                this.b = 0L;
                Trace.endSection();
            }
        } catch (Throwable th) {
            this.b = 0L;
            int i3 = AbstractC0175ig.a;
            Trace.endSection();
            throw th;
        }
    }
}
