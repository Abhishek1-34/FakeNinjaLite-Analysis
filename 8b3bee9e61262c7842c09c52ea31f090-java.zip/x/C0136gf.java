package x;

import android.content.Context;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import androidx.appcompat.widget.ActionBarContextView;
import java.lang.ref.WeakReference;

/* renamed from: x.gf, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0136gf extends AbstractC0121g0 implements InterfaceC0208kb {
    public Context c;
    public ActionBarContextView d;
    public F1 e;
    public WeakReference f;
    public boolean g;
    public MenuC0246mb h;

    @Override // x.AbstractC0121g0
    public final void a() {
        if (this.g) {
            return;
        }
        this.g = true;
        this.e.F(this);
    }

    @Override // x.AbstractC0121g0
    public final View b() {
        WeakReference weakReference = this.f;
        if (weakReference != null) {
            return (View) weakReference.get();
        }
        return null;
    }

    @Override // x.AbstractC0121g0
    public final MenuC0246mb c() {
        return this.h;
    }

    @Override // x.AbstractC0121g0
    public final MenuInflater d() {
        return new C0458xf(this.d.getContext());
    }

    @Override // x.AbstractC0121g0
    public final CharSequence e() {
        return this.d.getSubtitle();
    }

    @Override // x.AbstractC0121g0
    public final CharSequence f() {
        return this.d.getTitle();
    }

    @Override // x.AbstractC0121g0
    public final void g() {
        this.e.G(this, this.h);
    }

    @Override // x.AbstractC0121g0
    public final boolean h() {
        return this.d.s;
    }

    @Override // x.InterfaceC0208kb
    public final boolean i(MenuC0246mb menuC0246mb, MenuItem menuItem) {
        return ((C0353s5) this.e.b).k(this, menuItem);
    }

    @Override // x.AbstractC0121g0
    public final void j(View view) {
        WeakReference weakReference;
        this.d.setCustomView(view);
        if (view != null) {
            weakReference = new WeakReference(view);
        } else {
            weakReference = null;
        }
        this.f = weakReference;
    }

    @Override // x.AbstractC0121g0
    public final void k(int i) {
        l(this.c.getString(i));
    }

    @Override // x.AbstractC0121g0
    public final void l(CharSequence charSequence) {
        this.d.setSubtitle(charSequence);
    }

    @Override // x.AbstractC0121g0
    public final void m(int i) {
        n(this.c.getString(i));
    }

    @Override // x.AbstractC0121g0
    public final void n(CharSequence charSequence) {
        this.d.setTitle(charSequence);
    }

    @Override // x.AbstractC0121g0
    public final void o(boolean z) {
        this.b = z;
        this.d.setTitleOptional(z);
    }

    @Override // x.InterfaceC0208kb
    public final void t(MenuC0246mb menuC0246mb) {
        g();
        C0041c0 c0041c0 = this.d.d;
        if (c0041c0 != null) {
            c0041c0.l();
        }
    }
}
