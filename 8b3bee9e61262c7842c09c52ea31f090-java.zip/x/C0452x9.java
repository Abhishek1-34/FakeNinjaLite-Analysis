package x;

import android.os.Build;
import android.os.Bundle;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputConnectionWrapper;
import android.view.inputmethod.InputContentInfo;

/* renamed from: x.x9, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0452x9 extends InputConnectionWrapper {
    public final /* synthetic */ C0027b6 a;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0452x9(InputConnection inputConnection, C0027b6 c0027b6) {
        super(inputConnection, false);
        this.a = c0027b6;
    }

    @Override // android.view.inputmethod.InputConnectionWrapper, android.view.inputmethod.InputConnection
    public final boolean commitContent(InputContentInfo inputContentInfo, int i, Bundle bundle) {
        B b = null;
        if (inputContentInfo != null && Build.VERSION.SDK_INT >= 25) {
            b = new B(16, new C0490z9(inputContentInfo));
        }
        if (this.a.a(b, i, bundle)) {
            return true;
        }
        return super.commitContent(inputContentInfo, i, bundle);
    }
}
