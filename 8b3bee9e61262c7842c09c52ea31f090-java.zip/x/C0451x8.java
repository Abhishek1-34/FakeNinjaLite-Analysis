package x;

/* renamed from: x.x8, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0451x8 extends RuntimeException {
    public final AbstractComponentCallbacksC0089e8 a;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0451x8(AbstractComponentCallbacksC0089e8 abstractComponentCallbacksC0089e8, String str) {
        super(str);
        E9.o(abstractComponentCallbacksC0089e8, "fragment");
        this.a = abstractComponentCallbacksC0089e8;
    }
}
