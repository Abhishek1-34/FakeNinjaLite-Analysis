package x;

/* loaded from: classes.dex */
public abstract class Ae {
    public static final Be a = new Be();
}
