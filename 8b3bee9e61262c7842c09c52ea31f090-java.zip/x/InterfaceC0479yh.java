package x;

/* renamed from: x.yh, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public interface InterfaceC0479yh {
    C0460xh c();
}
