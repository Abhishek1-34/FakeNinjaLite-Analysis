package x;

/* loaded from: classes.dex */
public class H9 extends F9 {
    @Override // x.Fc
    public final AbstractC0267nd a() {
        Integer num = G9.a;
        if (num != null && num.intValue() < 34) {
            return new C0204k7();
        }
        return new AbstractC0267nd();
    }
}
