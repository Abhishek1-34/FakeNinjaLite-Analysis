package x;

import android.view.View;
import android.view.ViewGroup;
import androidx.constraintlayout.widget.ConstraintLayout;
import org.conscrypt.PSKKeyManager;

/* renamed from: x.r4, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0333r4 {
    public final ConstraintLayout a;
    public int b;
    public int c;
    public int d;
    public int e;
    public int f;
    public int g;
    public final /* synthetic */ ConstraintLayout h;

    public C0333r4(ConstraintLayout constraintLayout, ConstraintLayout constraintLayout2) {
        this.h = constraintLayout;
        this.a = constraintLayout2;
    }

    public static boolean a(int i, int i2, int i3) {
        if (i == i2) {
            return true;
        }
        int mode = View.MeasureSpec.getMode(i);
        int mode2 = View.MeasureSpec.getMode(i2);
        int size = View.MeasureSpec.getSize(i2);
        if (mode2 == 1073741824 && ((mode == Integer.MIN_VALUE || mode == 0) && i3 == size)) {
            return true;
        }
        return false;
    }

    /* JADX WARN: Code restructure failed: missing block: B:163:0x00ed, code lost:
    
        if (r10 == 2) goto L75;
     */
    /* JADX WARN: Removed duplicated region for block: B:148:0x01a2  */
    /* JADX WARN: Removed duplicated region for block: B:149:0x019d  */
    /* JADX WARN: Removed duplicated region for block: B:179:0x0123  */
    /* JADX WARN: Removed duplicated region for block: B:21:0x00b5  */
    /* JADX WARN: Removed duplicated region for block: B:52:0x019b  */
    /* JADX WARN: Removed duplicated region for block: B:54:0x01a0  */
    /* JADX WARN: Removed duplicated region for block: B:72:0x01ce A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:73:0x01cf  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void b(A4 a4, V2 v2) {
        int makeMeasureSpec;
        int i;
        int j;
        int makeMeasureSpec2;
        B4 b4;
        boolean z;
        boolean z2;
        boolean z3;
        boolean z4;
        boolean z5;
        boolean z6;
        int i2;
        int i3;
        int i4;
        int i5;
        boolean z7;
        int baseline;
        int i6;
        boolean z8;
        boolean z9;
        boolean z10;
        boolean z11;
        int i7;
        boolean z12;
        int i8;
        boolean z13;
        boolean z14;
        int i9;
        if (a4 == null) {
            return;
        }
        if (a4.g0 == 8) {
            v2.e = 0;
            v2.f = 0;
            v2.g = 0;
            return;
        }
        if (a4.T == null) {
            return;
        }
        Le le = ConstraintLayout.p;
        ConstraintLayout constraintLayout = this.h;
        constraintLayout.getClass();
        int i10 = v2.a;
        int i11 = v2.b;
        int i12 = v2.c;
        int i13 = v2.d;
        int i14 = this.b + this.c;
        int i15 = this.d;
        View view = a4.f0;
        int j2 = Ue.j(i10);
        C0239m4 c0239m4 = a4.K;
        C0239m4 c0239m42 = a4.I;
        if (j2 != 0) {
            if (j2 != 1) {
                if (j2 != 2) {
                    if (j2 != 3) {
                        i = 0;
                    } else {
                        int i16 = this.f;
                        if (c0239m42 != null) {
                            i9 = c0239m42.g;
                        } else {
                            i9 = 0;
                        }
                        if (c0239m4 != null) {
                            i9 += c0239m4.g;
                        }
                        i = ViewGroup.getChildMeasureSpec(i16, i15 + i9, -1);
                    }
                    j = Ue.j(i11);
                    if (j == 0) {
                        if (j != 1) {
                            if (j != 2) {
                                if (j != 3) {
                                    makeMeasureSpec2 = 0;
                                } else {
                                    int i17 = this.g;
                                    if (c0239m42 != null) {
                                        i8 = a4.J.g;
                                    } else {
                                        i8 = 0;
                                    }
                                    if (c0239m4 != null) {
                                        i8 += a4.L.g;
                                    }
                                    makeMeasureSpec2 = ViewGroup.getChildMeasureSpec(i17, i14 + i8, -1);
                                }
                            } else {
                                makeMeasureSpec2 = ViewGroup.getChildMeasureSpec(this.g, i14, -2);
                                if (a4.s == 1) {
                                    z11 = true;
                                } else {
                                    z11 = false;
                                }
                                int i18 = v2.j;
                                if (i18 != 1) {
                                    i7 = 2;
                                } else {
                                    i7 = 2;
                                }
                                if (view.getMeasuredWidth() == a4.q()) {
                                    z12 = true;
                                } else {
                                    z12 = false;
                                }
                                if (v2.j == i7 || !z11 || ((z11 && z12) || a4.B())) {
                                    makeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(a4.k(), 1073741824);
                                }
                            }
                        } else {
                            makeMeasureSpec2 = ViewGroup.getChildMeasureSpec(this.g, i14, -2);
                        }
                    } else {
                        makeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(i13, 1073741824);
                    }
                    b4 = (B4) a4.T;
                    if (b4 == null && E9.x(constraintLayout.i, PSKKeyManager.MAX_KEY_LENGTH_BYTES) && view.getMeasuredWidth() == a4.q() && view.getMeasuredWidth() < b4.q() && view.getMeasuredHeight() == a4.k() && view.getMeasuredHeight() < b4.k() && view.getBaseline() == a4.a0 && !a4.z() && a(a4.G, i, a4.q()) && a(a4.H, makeMeasureSpec2, a4.k())) {
                        v2.e = a4.q();
                        v2.f = a4.k();
                        v2.g = a4.a0;
                        return;
                    }
                    if (i10 != 3) {
                        z = true;
                    } else {
                        z = false;
                    }
                    if (i11 != 3) {
                        z2 = true;
                    } else {
                        z2 = false;
                    }
                    if (i11 == 4 && i11 != 1) {
                        z3 = false;
                    } else {
                        z3 = true;
                    }
                    if (i10 == 4 && i10 != 1) {
                        z4 = false;
                    } else {
                        z4 = true;
                    }
                    if (!z && a4.W > 0.0f) {
                        z5 = true;
                    } else {
                        z5 = false;
                    }
                    if (!z2 && a4.W > 0.0f) {
                        z6 = true;
                    } else {
                        z6 = false;
                    }
                    if (view != null) {
                        return;
                    }
                    C0315q4 c0315q4 = (C0315q4) view.getLayoutParams();
                    int i19 = v2.j;
                    if (i19 != 1 && i19 != 2 && z && a4.r == 0 && z2 && a4.s == 0) {
                        i4 = 0;
                        i6 = -1;
                        baseline = 0;
                        z7 = false;
                        i2 = 0;
                    } else {
                        if ((view instanceof Qh) && (a4 instanceof G7)) {
                            ((Qh) view).j((G7) a4, i, makeMeasureSpec2);
                        } else {
                            view.measure(i, makeMeasureSpec2);
                        }
                        a4.G = i;
                        a4.H = makeMeasureSpec2;
                        a4.g = false;
                        int measuredWidth = view.getMeasuredWidth();
                        int measuredHeight = view.getMeasuredHeight();
                        int baseline2 = view.getBaseline();
                        int i20 = a4.u;
                        if (i20 > 0) {
                            i2 = Math.max(i20, measuredWidth);
                        } else {
                            i2 = measuredWidth;
                        }
                        int i21 = a4.v;
                        if (i21 > 0) {
                            i2 = Math.min(i21, i2);
                        }
                        int i22 = a4.f14x;
                        if (i22 > 0) {
                            i4 = Math.max(i22, measuredHeight);
                            i3 = makeMeasureSpec2;
                        } else {
                            i3 = makeMeasureSpec2;
                            i4 = measuredHeight;
                        }
                        int i23 = a4.y;
                        if (i23 > 0) {
                            i4 = Math.min(i23, i4);
                        }
                        if (!E9.x(constraintLayout.i, 1)) {
                            if (z5 && z3) {
                                i2 = (int) ((i4 * a4.W) + 0.5f);
                            } else if (z6 && z4) {
                                i4 = (int) ((i2 / a4.W) + 0.5f);
                            }
                        }
                        if (measuredWidth == i2 && measuredHeight == i4) {
                            baseline = baseline2;
                            i6 = -1;
                            z7 = false;
                        } else {
                            if (measuredWidth != i2) {
                                i = View.MeasureSpec.makeMeasureSpec(i2, 1073741824);
                            }
                            if (measuredHeight != i4) {
                                i5 = View.MeasureSpec.makeMeasureSpec(i4, 1073741824);
                            } else {
                                i5 = i3;
                            }
                            view.measure(i, i5);
                            a4.G = i;
                            a4.H = i5;
                            z7 = false;
                            a4.g = false;
                            int measuredWidth2 = view.getMeasuredWidth();
                            i4 = view.getMeasuredHeight();
                            i2 = measuredWidth2;
                            baseline = view.getBaseline();
                            i6 = -1;
                        }
                    }
                    if (baseline != i6) {
                        z8 = true;
                    } else {
                        z8 = z7;
                    }
                    if (i2 == v2.c && i4 == v2.d) {
                        z9 = z7;
                    } else {
                        z9 = true;
                    }
                    v2.i = z9;
                    if (c0315q4.c0) {
                        z10 = true;
                    } else {
                        z10 = z8;
                    }
                    if (z10 && baseline != -1 && a4.a0 != baseline) {
                        v2.i = true;
                    }
                    v2.e = i2;
                    v2.f = i4;
                    v2.h = z10;
                    v2.g = baseline;
                    return;
                }
                makeMeasureSpec = ViewGroup.getChildMeasureSpec(this.f, i15, -2);
                if (a4.r == 1) {
                    z13 = true;
                } else {
                    z13 = false;
                }
                int i24 = v2.j;
                if (i24 == 1 || i24 == 2) {
                    if (view.getMeasuredHeight() == a4.k()) {
                        z14 = true;
                    } else {
                        z14 = false;
                    }
                    if (v2.j == 2 || !z13 || ((z13 && z14) || a4.A())) {
                        makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(a4.q(), 1073741824);
                    }
                }
            } else {
                makeMeasureSpec = ViewGroup.getChildMeasureSpec(this.f, i15, -2);
            }
        } else {
            makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(i12, 1073741824);
        }
        i = makeMeasureSpec;
        j = Ue.j(i11);
        if (j == 0) {
        }
        b4 = (B4) a4.T;
        if (b4 == null) {
        }
        if (i10 != 3) {
        }
        if (i11 != 3) {
        }
        if (i11 == 4) {
        }
        z3 = true;
        if (i10 == 4) {
        }
        z4 = true;
        if (!z) {
        }
        z5 = false;
        if (!z2) {
        }
        z6 = false;
        if (view != null) {
        }
    }
}
