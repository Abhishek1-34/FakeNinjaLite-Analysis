package x;

import android.content.Context;
import android.graphics.PointF;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import com.google.android.material.carousel.CarouselLayoutManager;

/* renamed from: x.q3, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0314q3 extends C0151ha {
    public final /* synthetic */ int q;
    public final /* synthetic */ Object r;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ C0314q3(Object obj, Context context, int i) {
        super(context);
        this.q = i;
        this.r = obj;
    }

    @Override // x.C0151ha
    public int b(View view, int i) {
        switch (this.q) {
            case 0:
                ((CarouselLayoutManager) this.r).getClass();
                return 0;
            default:
                return super.b(view, i);
        }
    }

    @Override // x.C0151ha
    public int c(View view, int i) {
        switch (this.q) {
            case 0:
                ((CarouselLayoutManager) this.r).getClass();
                return 0;
            default:
                return super.c(view, i);
        }
    }

    @Override // x.C0151ha
    public float d(DisplayMetrics displayMetrics) {
        switch (this.q) {
            case 1:
                return 100.0f / displayMetrics.densityDpi;
            default:
                return super.d(displayMetrics);
        }
    }

    @Override // x.C0151ha
    public int e(int i) {
        switch (this.q) {
            case 1:
                return Math.min(100, super.e(i));
            default:
                return super.e(i);
        }
    }

    @Override // x.C0151ha
    public PointF f(int i) {
        switch (this.q) {
            case 0:
                ((CarouselLayoutManager) this.r).getClass();
                return null;
            default:
                return super.f(i);
        }
    }

    @Override // x.C0151ha
    public void h(View view, Hd hd) {
        switch (this.q) {
            case 1:
                C0455xc c0455xc = (C0455xc) this.r;
                int[] a = c0455xc.a(c0455xc.a.getLayoutManager(), view);
                int i = a[0];
                int i2 = a[1];
                int ceil = (int) Math.ceil(e(Math.max(Math.abs(i), Math.abs(i2))) / 0.3356d);
                if (ceil > 0) {
                    DecelerateInterpolator decelerateInterpolator = this.j;
                    hd.a = i;
                    hd.b = i2;
                    hd.c = ceil;
                    hd.e = decelerateInterpolator;
                    hd.f = true;
                    return;
                }
                return;
            default:
                super.h(view, hd);
                return;
        }
    }
}
