package x;

/* renamed from: x.f0, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public interface InterfaceC0101f0 {
}
