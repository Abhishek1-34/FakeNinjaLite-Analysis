package x;

import android.view.View;

/* renamed from: x.dg, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0077dg {
    public static void a(View view, CharSequence charSequence) {
        view.setTooltipText(charSequence);
    }
}
