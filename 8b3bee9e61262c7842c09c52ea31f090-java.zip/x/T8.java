package x;

/* loaded from: classes.dex */
public interface T8 {
}
