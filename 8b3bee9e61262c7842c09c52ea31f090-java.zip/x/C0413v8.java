package x;

import android.util.Log;
import java.util.HashMap;
import java.util.Iterator;

/* renamed from: x.v8, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0413v8 extends AbstractC0422vh {
    public final boolean f;
    public final HashMap c = new HashMap();
    public final HashMap d = new HashMap();
    public final HashMap e = new HashMap();
    public boolean g = false;
    public boolean h = false;

    public C0413v8(boolean z) {
        this.f = z;
    }

    @Override // x.AbstractC0422vh
    public final void a() {
        if (Log.isLoggable("FragmentManager", 3)) {
            Log.d("FragmentManager", "onCleared called for " + this);
        }
        this.g = true;
    }

    public final void b(AbstractComponentCallbacksC0089e8 abstractComponentCallbacksC0089e8) {
        if (Log.isLoggable("FragmentManager", 3)) {
            Log.d("FragmentManager", "Clearing non-config state for " + abstractComponentCallbacksC0089e8);
        }
        c(abstractComponentCallbacksC0089e8.e);
    }

    public final void c(String str) {
        HashMap hashMap = this.d;
        C0413v8 c0413v8 = (C0413v8) hashMap.get(str);
        if (c0413v8 != null) {
            c0413v8.a();
            hashMap.remove(str);
        }
        HashMap hashMap2 = this.e;
        C0460xh c0460xh = (C0460xh) hashMap2.get(str);
        if (c0460xh != null) {
            c0460xh.a();
            hashMap2.remove(str);
        }
    }

    public final void d(AbstractComponentCallbacksC0089e8 abstractComponentCallbacksC0089e8) {
        if (this.h) {
            if (Log.isLoggable("FragmentManager", 2)) {
                Log.v("FragmentManager", "Ignoring removeRetainedFragment as the state is already saved");
            }
        } else if (this.c.remove(abstractComponentCallbacksC0089e8.e) != null && Log.isLoggable("FragmentManager", 2)) {
            Log.v("FragmentManager", "Updating retained Fragments: Removed " + abstractComponentCallbacksC0089e8);
        }
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || C0413v8.class != obj.getClass()) {
            return false;
        }
        C0413v8 c0413v8 = (C0413v8) obj;
        if (this.c.equals(c0413v8.c) && this.d.equals(c0413v8.d) && this.e.equals(c0413v8.e)) {
            return true;
        }
        return false;
    }

    public final int hashCode() {
        return this.e.hashCode() + ((this.d.hashCode() + (this.c.hashCode() * 31)) * 31);
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("FragmentManagerViewModel{");
        sb.append(Integer.toHexString(System.identityHashCode(this)));
        sb.append("} Fragments (");
        Iterator it = this.c.values().iterator();
        while (it.hasNext()) {
            sb.append(it.next());
            if (it.hasNext()) {
                sb.append(", ");
            }
        }
        sb.append(") Child Non Config (");
        Iterator it2 = this.d.keySet().iterator();
        while (it2.hasNext()) {
            sb.append((String) it2.next());
            if (it2.hasNext()) {
                sb.append(", ");
            }
        }
        sb.append(") ViewModelStores (");
        Iterator it3 = this.e.keySet().iterator();
        while (it3.hasNext()) {
            sb.append((String) it3.next());
            if (it3.hasNext()) {
                sb.append(", ");
            }
        }
        sb.append(')');
        return sb.toString();
    }
}
