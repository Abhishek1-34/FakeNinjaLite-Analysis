package x;

import android.util.Log;
import android.view.View;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;

/* renamed from: x.af, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0016af {
    public int a;
    public int b;
    public final AbstractComponentCallbacksC0089e8 c;
    public final ArrayList d;
    public final HashSet e;
    public boolean f;
    public boolean g;
    public final androidx.fragment.app.a h;

    public C0016af(int i, int i2, androidx.fragment.app.a aVar, C0276o3 c0276o3) {
        AbstractComponentCallbacksC0089e8 abstractComponentCallbacksC0089e8 = aVar.c;
        this.d = new ArrayList();
        this.e = new HashSet();
        this.f = false;
        this.g = false;
        this.a = i;
        this.b = i2;
        this.c = abstractComponentCallbacksC0089e8;
        c0276o3.a(new B(26, this));
        this.h = aVar;
    }

    public final void a() {
        if (this.f) {
            return;
        }
        this.f = true;
        if (this.e.isEmpty()) {
            b();
            return;
        }
        Iterator it = new ArrayList(this.e).iterator();
        while (it.hasNext()) {
            C0276o3 c0276o3 = (C0276o3) it.next();
            synchronized (c0276o3) {
                try {
                    if (!c0276o3.a) {
                        c0276o3.a = true;
                        c0276o3.c = true;
                        InterfaceC0257n3 interfaceC0257n3 = c0276o3.b;
                        if (interfaceC0257n3 != null) {
                            try {
                                interfaceC0257n3.o();
                            } catch (Throwable th) {
                                synchronized (c0276o3) {
                                    c0276o3.c = false;
                                    c0276o3.notifyAll();
                                    throw th;
                                }
                            }
                        }
                        synchronized (c0276o3) {
                            c0276o3.c = false;
                            c0276o3.notifyAll();
                        }
                    }
                } finally {
                }
            }
        }
    }

    public final void b() {
        if (!this.g) {
            if (Log.isLoggable("FragmentManager", 2)) {
                Log.v("FragmentManager", "SpecialEffectsController: " + this + " has called complete.");
            }
            this.g = true;
            Iterator it = this.d.iterator();
            while (it.hasNext()) {
                ((Runnable) it.next()).run();
            }
        }
        this.h.k();
    }

    public final void c(int i, int i2) {
        int j = Ue.j(i2);
        AbstractComponentCallbacksC0089e8 abstractComponentCallbacksC0089e8 = this.c;
        if (j != 0) {
            if (j != 1) {
                if (j == 2) {
                    if (Log.isLoggable("FragmentManager", 2)) {
                        Log.v("FragmentManager", "SpecialEffectsController: For fragment " + abstractComponentCallbacksC0089e8 + " mFinalState = " + Ue.l(this.a) + " -> REMOVED. mLifecycleImpact  = " + Ue.k(this.b) + " to REMOVING.");
                    }
                    this.a = 1;
                    this.b = 3;
                    return;
                }
                return;
            }
            if (this.a == 1) {
                if (Log.isLoggable("FragmentManager", 2)) {
                    Log.v("FragmentManager", "SpecialEffectsController: For fragment " + abstractComponentCallbacksC0089e8 + " mFinalState = REMOVED -> VISIBLE. mLifecycleImpact = " + Ue.k(this.b) + " to ADDING.");
                }
                this.a = 2;
                this.b = 2;
                return;
            }
            return;
        }
        if (this.a != 1) {
            if (Log.isLoggable("FragmentManager", 2)) {
                Log.v("FragmentManager", "SpecialEffectsController: For fragment " + abstractComponentCallbacksC0089e8 + " mFinalState = " + Ue.l(this.a) + " -> " + Ue.l(i) + ". ");
            }
            this.a = i;
        }
    }

    public final void d() {
        float f;
        int i = this.b;
        androidx.fragment.app.a aVar = this.h;
        if (i == 2) {
            AbstractComponentCallbacksC0089e8 abstractComponentCallbacksC0089e8 = aVar.c;
            View findFocus = abstractComponentCallbacksC0089e8.E.findFocus();
            if (findFocus != null) {
                abstractComponentCallbacksC0089e8.f().k = findFocus;
                if (Log.isLoggable("FragmentManager", 2)) {
                    Log.v("FragmentManager", "requestFocus: Saved focused view " + findFocus + " for Fragment " + abstractComponentCallbacksC0089e8);
                }
            }
            View D = this.c.D();
            if (D.getParent() == null) {
                aVar.b();
                D.setAlpha(0.0f);
            }
            if (D.getAlpha() == 0.0f && D.getVisibility() == 0) {
                D.setVisibility(4);
            }
            C0049c8 c0049c8 = abstractComponentCallbacksC0089e8.H;
            if (c0049c8 == null) {
                f = 1.0f;
            } else {
                f = c0049c8.j;
            }
            D.setAlpha(f);
            return;
        }
        if (i == 3) {
            AbstractComponentCallbacksC0089e8 abstractComponentCallbacksC0089e82 = aVar.c;
            View D2 = abstractComponentCallbacksC0089e82.D();
            if (Log.isLoggable("FragmentManager", 2)) {
                Log.v("FragmentManager", "Clearing focus " + D2.findFocus() + " on view " + D2 + " for Fragment " + abstractComponentCallbacksC0089e82);
            }
            D2.clearFocus();
        }
    }

    public final String toString() {
        return "Operation {" + Integer.toHexString(System.identityHashCode(this)) + "} {mFinalState = " + Ue.l(this.a) + "} {mLifecycleImpact = " + Ue.k(this.b) + "} {mFragment = " + this.c + "}";
    }
}
