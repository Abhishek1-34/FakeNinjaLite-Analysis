package x;

import android.widget.AdapterView;
import android.widget.HorizontalScrollView;

/* renamed from: x.ve, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0419ve extends HorizontalScrollView implements AdapterView.OnItemSelectedListener {
}
