package x;

/* loaded from: classes.dex */
public final class Hg extends C0194jg {
    @Override // x.C0194jg
    public final boolean b(CharSequence charSequence) {
        return r.t(charSequence);
    }
}
