package x;

import android.os.SystemClock;
import java.net.DatagramSocket;
import java.net.InetAddress;

/* renamed from: x.vc, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0417vc {
    public final String a;
    public final String b;
    public final int c;
    public final String d;
    public final int e;
    public final InetAddress f;
    public final DatagramSocket g;
    public volatile long h = SystemClock.elapsedRealtime();
    public volatile boolean i;
    public final /* synthetic */ C0436wc j;

    public C0417vc(C0436wc c0436wc, String str, String str2, int i, String str3, int i2) {
        this.j = c0436wc;
        this.a = str;
        this.b = str2;
        this.c = i;
        this.d = str3;
        this.e = i2;
        this.f = InetAddress.getByName(str3);
        DatagramSocket datagramSocket = new DatagramSocket();
        this.g = datagramSocket;
        if (!c0436wc.a.protect(datagramSocket)) {
            Yb.h("Proteção do socket UDP não confirmada; continuando fora da VPN " + str);
        }
        datagramSocket.setReceiveBufferSize(262144);
        datagramSocket.setSendBufferSize(262144);
        datagramSocket.setSoTimeout(30000);
    }

    public final void a() {
        if (this.i) {
            return;
        }
        this.i = true;
        Yb.d("close", "UDP", this.a);
        this.g.close();
    }
}
