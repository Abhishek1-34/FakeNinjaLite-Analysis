package x;

/* renamed from: x.e2, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public class C0083e2 extends B {
    public final /* synthetic */ C0123g2 c;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0083e2(C0123g2 c0123g2) {
        super(4, c0123g2);
        this.c = c0123g2;
    }

    @Override // x.B, x.InterfaceC0063d2
    public final void c(int i) {
        super/*android.widget.TextView*/.setFirstBaselineToTopHeight(i);
    }

    @Override // x.B, x.InterfaceC0063d2
    public final void w(int i) {
        super/*android.widget.TextView*/.setLastBaselineToBottomHeight(i);
    }
}
