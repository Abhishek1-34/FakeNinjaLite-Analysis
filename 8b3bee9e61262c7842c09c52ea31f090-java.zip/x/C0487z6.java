package x;

import java.nio.ByteBuffer;

/* renamed from: x.z6, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0487z6 {
    public int a = 1;
    public final Ib b;
    public Ib c;
    public Ib d;
    public int e;
    public int f;

    public C0487z6(Ib ib) {
        this.b = ib;
        this.c = ib;
    }

    public final void a() {
        this.a = 1;
        this.c = this.b;
        this.f = 0;
    }

    public final boolean b() {
        Gb c = this.c.b.c();
        int a = c.a(6);
        if ((a != 0 && ((ByteBuffer) c.d).get(a + c.a) != 0) || this.e == 65039) {
            return true;
        }
        return false;
    }
}
