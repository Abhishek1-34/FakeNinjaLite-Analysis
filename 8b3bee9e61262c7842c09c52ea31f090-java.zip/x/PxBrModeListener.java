package x;

import android.content.SharedPreferences;
import android.util.Log;
import android.widget.RadioGroup;
import org.conscrypt.R;

/* loaded from: classes.dex */
public final class PxBrModeListener implements RadioGroup.OnCheckedChangeListener {
    public final SharedPreferences a;

    public PxBrModeListener(SharedPreferences sharedPreferences) {
        this.a = sharedPreferences;
    }

    @Override // android.widget.RadioGroup.OnCheckedChangeListener
    public final void onCheckedChanged(RadioGroup radioGroup, int i) {
        int i2 = i == R.id.brModeDuo ? 2 : i == R.id.brModeSquad ? 3 : 1;
        Z6.f20x = i2;
        this.a.edit().putInt("br_mode", i2).apply();
        Log.i("ProjectX-Rede", "MODO BR selecionado=" + i2);
    }
}
