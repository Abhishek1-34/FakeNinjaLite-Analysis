package x;

import java.util.Locale;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import java.util.concurrent.locks.LockSupport;
import java.util.logging.Level;
import java.util.logging.Logger;

/* renamed from: x.m, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractFutureC0234m implements Future {
    public static final boolean d = Boolean.parseBoolean(System.getProperty("guava.concurrent.generate_cancellation_cause", "false"));
    public static final Logger e = Logger.getLogger(AbstractFutureC0234m.class.getName());
    public static final E9 f;
    public static final Object g;
    public volatile Object a;
    public volatile C0159i b;
    public volatile C0215l c;

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r4v4, types: [x.E9] */
    /* JADX WARN: Type inference failed for: r4v6 */
    /* JADX WARN: Type inference failed for: r4v7 */
    static {
        ?? r4;
        try {
            th = null;
            r4 = new C0177j(AtomicReferenceFieldUpdater.newUpdater(C0215l.class, Thread.class, "a"), AtomicReferenceFieldUpdater.newUpdater(C0215l.class, C0215l.class, "b"), AtomicReferenceFieldUpdater.newUpdater(AbstractFutureC0234m.class, C0215l.class, "c"), AtomicReferenceFieldUpdater.newUpdater(AbstractFutureC0234m.class, C0159i.class, "b"), AtomicReferenceFieldUpdater.newUpdater(AbstractFutureC0234m.class, Object.class, "a"));
        } catch (Throwable th) {
            th = th;
            r4 = new Object();
        }
        f = r4;
        if (th != null) {
            e.log(Level.SEVERE, "SafeAtomicHelper is broken!", th);
        }
        g = new Object();
    }

    public static void b(AbstractFutureC0234m abstractFutureC0234m) {
        C0215l c0215l;
        C0159i c0159i;
        do {
            c0215l = abstractFutureC0234m.c;
        } while (!f.i(abstractFutureC0234m, c0215l, C0215l.c));
        while (c0215l != null) {
            Thread thread = c0215l.a;
            if (thread != null) {
                c0215l.a = null;
                LockSupport.unpark(thread);
            }
            c0215l = c0215l.b;
        }
        do {
            c0159i = abstractFutureC0234m.b;
        } while (!f.g(abstractFutureC0234m, c0159i));
        C0159i c0159i2 = null;
        while (c0159i != null) {
            C0159i c0159i3 = c0159i.a;
            c0159i.a = c0159i2;
            c0159i2 = c0159i;
            c0159i = c0159i3;
        }
        while (c0159i2 != null) {
            c0159i2 = c0159i2.a;
            try {
                throw null;
                break;
            } catch (RuntimeException e2) {
                e.log(Level.SEVERE, "RuntimeException while executing runnable null with executor null", (Throwable) e2);
            }
        }
    }

    public static Object c(Object obj) {
        if (!(obj instanceof C0120g)) {
            if (!(obj instanceof AbstractC0140h)) {
                if (obj == g) {
                    return null;
                }
                return obj;
            }
            ((AbstractC0140h) obj).getClass();
            throw new ExecutionException((Throwable) null);
        }
        CancellationException cancellationException = ((C0120g) obj).a;
        CancellationException cancellationException2 = new CancellationException("Task was cancelled.");
        cancellationException2.initCause(cancellationException);
        throw cancellationException2;
    }

    public static Object d(AbstractFutureC0234m abstractFutureC0234m) {
        Object obj;
        boolean z = false;
        while (true) {
            try {
                obj = abstractFutureC0234m.get();
                break;
            } catch (InterruptedException unused) {
                z = true;
            } catch (Throwable th) {
                if (z) {
                    Thread.currentThread().interrupt();
                }
                throw th;
            }
        }
        if (z) {
            Thread.currentThread().interrupt();
        }
        return obj;
    }

    public final void a(StringBuilder sb) {
        String valueOf;
        try {
            Object d2 = d(this);
            sb.append("SUCCESS, result=[");
            if (d2 == this) {
                valueOf = "this future";
            } else {
                valueOf = String.valueOf(d2);
            }
            sb.append(valueOf);
            sb.append("]");
        } catch (CancellationException unused) {
            sb.append("CANCELLED");
        } catch (RuntimeException e2) {
            sb.append("UNKNOWN, cause=[");
            sb.append(e2.getClass());
            sb.append(" thrown from get()]");
        } catch (ExecutionException e3) {
            sb.append("FAILURE, cause=[");
            sb.append(e3.getCause());
            sb.append("]");
        }
    }

    @Override // java.util.concurrent.Future
    public final boolean cancel(boolean z) {
        C0120g c0120g;
        Object obj = this.a;
        if (obj != null) {
            return false;
        }
        if (d) {
            c0120g = new C0120g(z, new CancellationException("Future.cancel() was called."));
        } else if (z) {
            c0120g = C0120g.b;
        } else {
            c0120g = C0120g.c;
        }
        if (!f.h(this, obj, c0120g)) {
            return false;
        }
        b(this);
        return true;
    }

    public final void e(C0215l c0215l) {
        c0215l.a = null;
        while (true) {
            C0215l c0215l2 = this.c;
            if (c0215l2 == C0215l.c) {
                return;
            }
            C0215l c0215l3 = null;
            while (c0215l2 != null) {
                C0215l c0215l4 = c0215l2.b;
                if (c0215l2.a != null) {
                    c0215l3 = c0215l2;
                } else if (c0215l3 != null) {
                    c0215l3.b = c0215l4;
                    if (c0215l3.a == null) {
                        break;
                    }
                } else if (!f.i(this, c0215l2, c0215l4)) {
                    break;
                }
                c0215l2 = c0215l4;
            }
            return;
        }
    }

    @Override // java.util.concurrent.Future
    public final Object get(long j, TimeUnit timeUnit) {
        long nanos = timeUnit.toNanos(j);
        if (!Thread.interrupted()) {
            Object obj = this.a;
            if (obj != null) {
                return c(obj);
            }
            long nanoTime = nanos > 0 ? System.nanoTime() + nanos : 0L;
            if (nanos >= 1000) {
                C0215l c0215l = this.c;
                C0215l c0215l2 = C0215l.c;
                if (c0215l != c0215l2) {
                    C0215l c0215l3 = new C0215l();
                    do {
                        E9 e9 = f;
                        e9.U(c0215l3, c0215l);
                        if (e9.i(this, c0215l, c0215l3)) {
                            do {
                                LockSupport.parkNanos(this, nanos);
                                if (!Thread.interrupted()) {
                                    Object obj2 = this.a;
                                    if (obj2 != null) {
                                        return c(obj2);
                                    }
                                    nanos = nanoTime - System.nanoTime();
                                } else {
                                    e(c0215l3);
                                    throw new InterruptedException();
                                }
                            } while (nanos >= 1000);
                            e(c0215l3);
                        } else {
                            c0215l = this.c;
                        }
                    } while (c0215l != c0215l2);
                }
                return c(this.a);
            }
            while (nanos > 0) {
                Object obj3 = this.a;
                if (obj3 != null) {
                    return c(obj3);
                }
                if (!Thread.interrupted()) {
                    nanos = nanoTime - System.nanoTime();
                } else {
                    throw new InterruptedException();
                }
            }
            String abstractFutureC0234m = toString();
            String obj4 = timeUnit.toString();
            Locale locale = Locale.ROOT;
            String lowerCase = obj4.toLowerCase(locale);
            String str = "Waited " + j + " " + timeUnit.toString().toLowerCase(locale);
            if (nanos + 1000 < 0) {
                String e2 = Ue.e(str, " (plus ");
                long j2 = -nanos;
                long convert = timeUnit.convert(j2, TimeUnit.NANOSECONDS);
                long nanos2 = j2 - timeUnit.toNanos(convert);
                boolean z = convert == 0 || nanos2 > 1000;
                if (convert > 0) {
                    String str2 = e2 + convert + " " + lowerCase;
                    if (z) {
                        str2 = Ue.e(str2, ",");
                    }
                    e2 = Ue.e(str2, " ");
                }
                if (z) {
                    e2 = e2 + nanos2 + " nanoseconds ";
                }
                str = Ue.e(e2, "delay)");
            }
            if (isDone()) {
                throw new TimeoutException(Ue.e(str, " but future completed as timeout expired"));
            }
            throw new TimeoutException(str + " for " + abstractFutureC0234m);
        }
        throw new InterruptedException();
    }

    @Override // java.util.concurrent.Future
    public final boolean isCancelled() {
        return this.a instanceof C0120g;
    }

    @Override // java.util.concurrent.Future
    public final boolean isDone() {
        if (this.a != null) {
            return true;
        }
        return false;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final String toString() {
        String str;
        StringBuilder sb = new StringBuilder();
        sb.append(super.toString());
        sb.append("[status=");
        if (this.a instanceof C0120g) {
            sb.append("CANCELLED");
        } else if (isDone()) {
            a(sb);
        } else {
            try {
                if (this instanceof ScheduledFuture) {
                    str = "remaining delay=[" + ((ScheduledFuture) this).getDelay(TimeUnit.MILLISECONDS) + " ms]";
                } else {
                    str = null;
                }
            } catch (RuntimeException e2) {
                str = "Exception thrown from implementation: " + e2.getClass();
            }
            if (str != null && !str.isEmpty()) {
                sb.append("PENDING, info=[");
                sb.append(str);
                sb.append("]");
            } else if (isDone()) {
                a(sb);
            } else {
                sb.append("PENDING");
            }
        }
        sb.append("]");
        return sb.toString();
    }

    @Override // java.util.concurrent.Future
    public final Object get() {
        Object obj;
        if (!Thread.interrupted()) {
            Object obj2 = this.a;
            if (obj2 != null) {
                return c(obj2);
            }
            C0215l c0215l = this.c;
            C0215l c0215l2 = C0215l.c;
            if (c0215l != c0215l2) {
                C0215l c0215l3 = new C0215l();
                do {
                    E9 e9 = f;
                    e9.U(c0215l3, c0215l);
                    if (e9.i(this, c0215l, c0215l3)) {
                        do {
                            LockSupport.park(this);
                            if (!Thread.interrupted()) {
                                obj = this.a;
                            } else {
                                e(c0215l3);
                                throw new InterruptedException();
                            }
                        } while (obj == null);
                        return c(obj);
                    }
                    c0215l = this.c;
                } while (c0215l != c0215l2);
            }
            return c(this.a);
        }
        throw new InterruptedException();
    }
}
