package x;

import android.content.Context;
import android.content.ContextWrapper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import androidx.appcompat.view.menu.ExpandedMenuView;

/* renamed from: x.ka, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0207ka implements Cb, AdapterView.OnItemClickListener {
    public Context a;
    public LayoutInflater b;
    public MenuC0246mb c;
    public ExpandedMenuView d;
    public Bb e;
    public C0188ja f;

    public C0207ka(ContextWrapper contextWrapper) {
        this.a = contextWrapper;
        this.b = LayoutInflater.from(contextWrapper);
    }

    @Override // x.Cb
    public final void b(MenuC0246mb menuC0246mb, boolean z) {
        Bb bb = this.e;
        if (bb != null) {
            bb.b(menuC0246mb, z);
        }
    }

    @Override // x.Cb
    public final void c(Bb bb) {
        throw null;
    }

    @Override // x.Cb
    public final void d() {
        C0188ja c0188ja = this.f;
        if (c0188ja != null) {
            c0188ja.notifyDataSetChanged();
        }
    }

    @Override // x.Cb
    public final boolean f(C0303pb c0303pb) {
        return false;
    }

    @Override // x.Cb
    public final boolean g() {
        return false;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v1, types: [x.Bb, android.content.DialogInterface$OnClickListener, java.lang.Object, x.nb, android.content.DialogInterface$OnDismissListener] */
    @Override // x.Cb
    public final boolean h(SubMenuC0363sf subMenuC0363sf) {
        if (!subMenuC0363sf.hasVisibleItems()) {
            return false;
        }
        ?? obj = new Object();
        obj.a = subMenuC0363sf;
        Context context = subMenuC0363sf.a;
        F0 f0 = new F0(context);
        B0 b0 = (B0) f0.b;
        C0207ka c0207ka = new C0207ka(b0.a);
        obj.c = c0207ka;
        c0207ka.e = obj;
        subMenuC0363sf.b(c0207ka, context);
        C0207ka c0207ka2 = obj.c;
        if (c0207ka2.f == null) {
            c0207ka2.f = new C0188ja(c0207ka2);
        }
        b0.g = c0207ka2.f;
        b0.h = obj;
        View view = subMenuC0363sf.o;
        if (view != null) {
            b0.e = view;
        } else {
            b0.c = subMenuC0363sf.n;
            b0.d = subMenuC0363sf.m;
        }
        b0.f = obj;
        G0 a = f0.a();
        obj.b = a;
        a.setOnDismissListener(obj);
        WindowManager.LayoutParams attributes = obj.b.getWindow().getAttributes();
        attributes.type = 1003;
        attributes.flags |= 131072;
        obj.b.show();
        Bb bb = this.e;
        if (bb != null) {
            bb.v(subMenuC0363sf);
            return true;
        }
        return true;
    }

    @Override // x.Cb
    public final void j(Context context, MenuC0246mb menuC0246mb) {
        if (this.a != null) {
            this.a = context;
            if (this.b == null) {
                this.b = LayoutInflater.from(context);
            }
        }
        this.c = menuC0246mb;
        C0188ja c0188ja = this.f;
        if (c0188ja != null) {
            c0188ja.notifyDataSetChanged();
        }
    }

    @Override // x.Cb
    public final boolean k(C0303pb c0303pb) {
        return false;
    }

    @Override // android.widget.AdapterView.OnItemClickListener
    public final void onItemClick(AdapterView adapterView, View view, int i, long j) {
        this.c.q(this.f.getItem(i), this, 0);
    }
}
