package x;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;

/* renamed from: x.ze, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0495ze {
    public AbstractC0124g3 a = new Object();
    public AbstractC0124g3 b = new Object();
    public AbstractC0124g3 c = new Object();
    public AbstractC0124g3 d = new Object();
    public T4 e = new C0080e(0.0f);
    public T4 f = new C0080e(0.0f);
    public T4 g = new C0080e(0.0f);
    public T4 h = new C0080e(0.0f);
    public C0107f6 i = new C0107f6(0);
    public C0107f6 j = new C0107f6(0);
    public C0107f6 k = new C0107f6(0);
    public C0107f6 l = new C0107f6(0);

    public static C0476ye a(Context context, int i, int i2, C0080e c0080e) {
        ContextThemeWrapper contextThemeWrapper = new ContextThemeWrapper(context, i);
        if (i2 != 0) {
            contextThemeWrapper = new ContextThemeWrapper(contextThemeWrapper, i2);
        }
        TypedArray obtainStyledAttributes = contextThemeWrapper.obtainStyledAttributes(AbstractC0191jd.v);
        try {
            int i3 = obtainStyledAttributes.getInt(0, 0);
            int i4 = obtainStyledAttributes.getInt(3, i3);
            int i5 = obtainStyledAttributes.getInt(4, i3);
            int i6 = obtainStyledAttributes.getInt(2, i3);
            int i7 = obtainStyledAttributes.getInt(1, i3);
            T4 c = c(obtainStyledAttributes, 5, c0080e);
            T4 c2 = c(obtainStyledAttributes, 8, c);
            T4 c3 = c(obtainStyledAttributes, 9, c);
            T4 c4 = c(obtainStyledAttributes, 7, c);
            T4 c5 = c(obtainStyledAttributes, 6, c);
            C0476ye c0476ye = new C0476ye();
            AbstractC0124g3 j = AbstractC0112fb.j(i4);
            c0476ye.a = j;
            C0476ye.b(j);
            c0476ye.e = c2;
            AbstractC0124g3 j2 = AbstractC0112fb.j(i5);
            c0476ye.b = j2;
            C0476ye.b(j2);
            c0476ye.f = c3;
            AbstractC0124g3 j3 = AbstractC0112fb.j(i6);
            c0476ye.c = j3;
            C0476ye.b(j3);
            c0476ye.g = c4;
            AbstractC0124g3 j4 = AbstractC0112fb.j(i7);
            c0476ye.d = j4;
            C0476ye.b(j4);
            c0476ye.h = c5;
            return c0476ye;
        } finally {
            obtainStyledAttributes.recycle();
        }
    }

    public static C0476ye b(Context context, AttributeSet attributeSet, int i, int i2) {
        C0080e c0080e = new C0080e(0);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, AbstractC0191jd.p, i, i2);
        int resourceId = obtainStyledAttributes.getResourceId(0, 0);
        int resourceId2 = obtainStyledAttributes.getResourceId(1, 0);
        obtainStyledAttributes.recycle();
        return a(context, resourceId, resourceId2, c0080e);
    }

    public static T4 c(TypedArray typedArray, int i, T4 t4) {
        TypedValue peekValue = typedArray.peekValue(i);
        if (peekValue == null) {
            return t4;
        }
        int i2 = peekValue.type;
        if (i2 == 5) {
            return new C0080e(TypedValue.complexToDimensionPixelSize(peekValue.data, typedArray.getResources().getDisplayMetrics()));
        }
        if (i2 == 6) {
            return new Rd(peekValue.getFraction(1.0f, 1.0f));
        }
        return t4;
    }

    public final boolean d(RectF rectF) {
        boolean z;
        boolean z2;
        boolean z3;
        if (this.l.getClass().equals(C0107f6.class) && this.j.getClass().equals(C0107f6.class) && this.i.getClass().equals(C0107f6.class) && this.k.getClass().equals(C0107f6.class)) {
            z = true;
        } else {
            z = false;
        }
        float a = this.e.a(rectF);
        if (this.f.a(rectF) == a && this.h.a(rectF) == a && this.g.a(rectF) == a) {
            z2 = true;
        } else {
            z2 = false;
        }
        if ((this.b instanceof C0155he) && (this.a instanceof C0155he) && (this.c instanceof C0155he) && (this.d instanceof C0155he)) {
            z3 = true;
        } else {
            z3 = false;
        }
        if (!z || !z2 || !z3) {
            return false;
        }
        return true;
    }

    /* JADX WARN: Type inference failed for: r0v0, types: [x.ye, java.lang.Object] */
    public final C0476ye e() {
        ?? obj = new Object();
        obj.a = this.a;
        obj.b = this.b;
        obj.c = this.c;
        obj.d = this.d;
        obj.e = this.e;
        obj.f = this.f;
        obj.g = this.g;
        obj.h = this.h;
        obj.i = this.i;
        obj.j = this.j;
        obj.k = this.k;
        obj.l = this.l;
        return obj;
    }
}
