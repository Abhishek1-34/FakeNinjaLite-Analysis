package x;

import android.os.Parcel;
import android.os.Parcelable;

/* renamed from: x.ag, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0017ag extends AbstractC0060d {
    public static final Parcelable.Creator<C0017ag> CREATOR = new C0040c(8);
    public int c;
    public boolean d;

    public C0017ag(Parcel parcel, ClassLoader classLoader) {
        super(parcel, classLoader);
        boolean z;
        this.c = parcel.readInt();
        if (parcel.readInt() != 0) {
            z = true;
        } else {
            z = false;
        }
        this.d = z;
    }

    @Override // x.AbstractC0060d, android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i) {
        super.writeToParcel(parcel, i);
        parcel.writeInt(this.c);
        parcel.writeInt(this.d ? 1 : 0);
    }
}
