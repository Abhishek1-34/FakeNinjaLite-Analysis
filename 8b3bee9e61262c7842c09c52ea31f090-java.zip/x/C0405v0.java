package x;

import android.graphics.RectF;
import java.util.Arrays;

/* renamed from: x.v0, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0405v0 implements T4 {
    public final T4 a;
    public final float b;

    public C0405v0(float f, T4 t4) {
        while (t4 instanceof C0405v0) {
            t4 = ((C0405v0) t4).a;
            f += ((C0405v0) t4).b;
        }
        this.a = t4;
        this.b = f;
    }

    @Override // x.T4
    public final float a(RectF rectF) {
        return Math.max(0.0f, this.a.a(rectF) + this.b);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof C0405v0)) {
            return false;
        }
        C0405v0 c0405v0 = (C0405v0) obj;
        if (this.a.equals(c0405v0.a) && this.b == c0405v0.b) {
            return true;
        }
        return false;
    }

    public final int hashCode() {
        return Arrays.hashCode(new Object[]{this.a, Float.valueOf(this.b)});
    }
}
