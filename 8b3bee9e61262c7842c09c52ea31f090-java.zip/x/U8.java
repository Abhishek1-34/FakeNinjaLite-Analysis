package x;

/* loaded from: classes.dex */
public interface U8 {
}
