package x;

import android.os.PowerManager;
import java.util.Locale;

/* renamed from: x.j1, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0179j1 {
    public static boolean a(PowerManager powerManager) {
        return powerManager.isPowerSaveMode();
    }

    public static String b(Locale locale) {
        return locale.toLanguageTag();
    }
}
