package x;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.ListIterator;

/* renamed from: x.gc, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0133gc extends M9 implements G8 {
    public final /* synthetic */ int a;
    public final /* synthetic */ Object b;

    public /* synthetic */ C0133gc(int i, Object obj) {
        this.a = i;
        this.b = obj;
    }

    @Override // x.G8
    public final Object a() {
        Object obj;
        V4 v4;
        switch (this.a) {
            case 0:
                ((androidx.activity.b) this.b).b();
                return C0107f6.d;
            case 1:
                androidx.activity.b bVar = (androidx.activity.b) this.b;
                C0388u2 c0388u2 = bVar.b;
                ListIterator listIterator = c0388u2.listIterator(c0388u2.size());
                while (true) {
                    if (listIterator.hasPrevious()) {
                        obj = listIterator.previous();
                        if (((C0243m8) obj).a) {
                        }
                    } else {
                        obj = null;
                    }
                }
                bVar.c = null;
                return C0107f6.d;
            case 2:
                ((androidx.activity.b) this.b).b();
                return C0107f6.d;
            default:
                InterfaceC0479yh interfaceC0479yh = (InterfaceC0479yh) this.b;
                ArrayList arrayList = new ArrayList();
                Pd.a.getClass();
                Class a = new N3(C0325qe.class).a();
                E9.m(a, "null cannot be cast to non-null type java.lang.Class<T of kotlin.jvm.JvmClassMappingKt.<get-java>>");
                arrayList.add(new C0441wh(a));
                C0441wh[] c0441whArr = (C0441wh[]) arrayList.toArray(new C0441wh[0]);
                C0441wh[] c0441whArr2 = (C0441wh[]) Arrays.copyOf(c0441whArr, c0441whArr.length);
                E9.o(c0441whArr2, "initializers");
                C0460xh c = interfaceC0479yh.c();
                if (interfaceC0479yh instanceof InterfaceC0301p9) {
                    v4 = ((InterfaceC0301p9) interfaceC0479yh).a();
                } else {
                    v4 = U4.b;
                }
                E9.o(c, "store");
                E9.o(v4, "defaultCreationExtras");
                LinkedHashMap linkedHashMap = c.a;
                AbstractC0422vh abstractC0422vh = (AbstractC0422vh) linkedHashMap.get("androidx.lifecycle.internal.SavedStateHandlesVM");
                if (C0325qe.class.isInstance(abstractC0422vh)) {
                    E9.m(abstractC0422vh, "null cannot be cast to non-null type T of androidx.lifecycle.ViewModelProvider.get");
                } else {
                    LinkedHashMap linkedHashMap2 = new LinkedHashMap();
                    linkedHashMap2.putAll(v4.a);
                    linkedHashMap2.put(C0107f6.f, "androidx.lifecycle.internal.SavedStateHandlesVM");
                    try {
                        abstractC0422vh = null;
                        for (C0441wh c0441wh : c0441whArr2) {
                            if (c0441wh.a.equals(C0325qe.class)) {
                                abstractC0422vh = new C0325qe();
                            }
                        }
                        if (abstractC0422vh != null) {
                            AbstractC0422vh abstractC0422vh2 = (AbstractC0422vh) linkedHashMap.put("androidx.lifecycle.internal.SavedStateHandlesVM", abstractC0422vh);
                            if (abstractC0422vh2 != null) {
                                abstractC0422vh2.a();
                            }
                        } else {
                            throw new IllegalArgumentException("No initializer set for given class ".concat(C0325qe.class.getName()));
                        }
                    } catch (AbstractMethodError unused) {
                        throw new UnsupportedOperationException("Factory.create(String) is unsupported.  This Factory requires `CreationExtras` to be passed into `create` method.");
                    }
                }
                return (C0325qe) abstractC0422vh;
        }
    }
}
