package x;

import android.os.Parcel;
import android.os.Parcelable;

/* loaded from: classes.dex */
public final class F3 extends AbstractC0060d {
    public static final Parcelable.Creator<F3> CREATOR = new C0040c(2);
    public boolean c;

    public F3(Parcel parcel, ClassLoader classLoader) {
        super(parcel, classLoader);
        this.c = parcel.readInt() == 1;
    }

    @Override // x.AbstractC0060d, android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i) {
        super.writeToParcel(parcel, i);
        parcel.writeInt(this.c ? 1 : 0);
    }
}
