package x;

import java.util.concurrent.Executor;

/* renamed from: x.e1, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class ExecutorC0082e1 implements Executor {
    @Override // java.util.concurrent.Executor
    public final void execute(Runnable runnable) {
        new Thread(runnable).start();
    }
}
