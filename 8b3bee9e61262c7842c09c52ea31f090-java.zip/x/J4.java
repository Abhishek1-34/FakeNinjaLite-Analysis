package x;

import java.util.concurrent.CopyOnWriteArraySet;

/* loaded from: classes.dex */
public final class J4 {
    public final CopyOnWriteArraySet a = new CopyOnWriteArraySet();
    public volatile androidx.activity.a b;
}
