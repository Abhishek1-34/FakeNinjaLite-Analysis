package x;

/* loaded from: classes.dex */
public final class T7 implements S7 {
    public final U7[] a;

    public T7(U7[] u7Arr) {
        this.a = u7Arr;
    }
}
