package x;

/* renamed from: x.nf, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0269nf extends AbstractC0250mf {
}
