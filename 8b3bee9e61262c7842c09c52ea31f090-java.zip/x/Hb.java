package x;

/* loaded from: classes.dex */
public final class Hb extends Bf {
}
