package x;

import android.graphics.Typeface;

/* renamed from: x.b2, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0023b2 {
    public static Typeface a(Typeface typeface, int i, boolean z) {
        return Typeface.create(typeface, i, z);
    }
}
