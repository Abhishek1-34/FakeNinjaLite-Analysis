package x;

import android.text.TextPaint;
import java.lang.ref.WeakReference;

/* loaded from: classes.dex */
public final class Hf {
    public float c;
    public final WeakReference e;
    public Ef f;
    public final TextPaint a = new TextPaint(1);
    public final H3 b = new H3(1, this);
    public boolean d = true;

    public Hf(L3 l3) {
        this.e = new WeakReference(null);
        this.e = new WeakReference(l3);
    }

    public final float a(String str) {
        float measureText;
        if (!this.d) {
            return this.c;
        }
        TextPaint textPaint = this.a;
        if (str == null) {
            measureText = 0.0f;
        } else {
            measureText = textPaint.measureText((CharSequence) str, 0, str.length());
        }
        this.c = measureText;
        if (str != null) {
            Math.abs(textPaint.getFontMetrics().ascent);
        }
        this.d = false;
        return this.c;
    }
}
