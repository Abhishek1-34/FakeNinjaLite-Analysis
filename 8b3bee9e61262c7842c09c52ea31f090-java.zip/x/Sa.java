package x;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

/* loaded from: classes.dex */
public final class Sa extends LinearLayoutManager {
    public final /* synthetic */ int E;
    public final /* synthetic */ Va F;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public Sa(Va va, int i, int i2) {
        super(i);
        this.F = va;
        this.E = i2;
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager
    public final void A0(Jd jd, int[] iArr) {
        int i = this.E;
        Va va = this.F;
        if (i == 0) {
            iArr[0] = va.a0.getWidth();
            iArr[1] = va.a0.getWidth();
        } else {
            iArr[0] = va.a0.getHeight();
            iArr[1] = va.a0.getHeight();
        }
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, x.AbstractC0475yd
    public final void x0(RecyclerView recyclerView, int i) {
        C0151ha c0151ha = new C0151ha(recyclerView.getContext());
        c0151ha.a = i;
        y0(c0151ha);
    }
}
