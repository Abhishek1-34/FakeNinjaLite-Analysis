package x;

/* renamed from: x.k, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0196k extends E9 {
    @Override // x.E9
    public final void U(C0215l c0215l, C0215l c0215l2) {
        c0215l.b = c0215l2;
    }

    @Override // x.E9
    public final void V(C0215l c0215l, Thread thread) {
        c0215l.a = thread;
    }

    @Override // x.E9
    public final boolean g(AbstractFutureC0234m abstractFutureC0234m, C0159i c0159i) {
        C0159i c0159i2 = C0159i.b;
        synchronized (abstractFutureC0234m) {
            try {
                if (abstractFutureC0234m.b == c0159i) {
                    abstractFutureC0234m.b = c0159i2;
                    return true;
                }
                return false;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    @Override // x.E9
    public final boolean h(AbstractFutureC0234m abstractFutureC0234m, Object obj, Object obj2) {
        synchronized (abstractFutureC0234m) {
            try {
                if (abstractFutureC0234m.a == obj) {
                    abstractFutureC0234m.a = obj2;
                    return true;
                }
                return false;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    @Override // x.E9
    public final boolean i(AbstractFutureC0234m abstractFutureC0234m, C0215l c0215l, C0215l c0215l2) {
        synchronized (abstractFutureC0234m) {
            try {
                if (abstractFutureC0234m.c == c0215l) {
                    abstractFutureC0234m.c = c0215l2;
                    return true;
                }
                return false;
            } catch (Throwable th) {
                throw th;
            }
        }
    }
}
