package x;

/* renamed from: x.sc, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0360sc {
    public int a;
    public int b;
    public long c;
}
