package x;

/* renamed from: x.ua, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0396ua extends AbstractC0415va {
    @Override // x.AbstractC0415va
    public final boolean e() {
        return true;
    }
}
