package x;

/* loaded from: classes.dex */
public abstract class oi {
    public final wi a;
    public C9[] b;

    public oi() {
        this(new wi());
    }

    public final void a() {
        C9[] c9Arr = this.b;
        if (c9Arr != null) {
            C9 c9 = c9Arr[0];
            C9 c92 = c9Arr[1];
            wi wiVar = this.a;
            if (c92 == null) {
                c92 = wiVar.a.f(2);
            }
            if (c9 == null) {
                c9 = wiVar.a.f(1);
            }
            g(C9.a(c9, c92));
            C9 c93 = this.b[AbstractC0112fb.t(16)];
            if (c93 != null) {
                f(c93);
            }
            C9 c94 = this.b[AbstractC0112fb.t(32)];
            if (c94 != null) {
                d(c94);
            }
            C9 c95 = this.b[AbstractC0112fb.t(64)];
            if (c95 != null) {
                h(c95);
            }
        }
    }

    public abstract wi b();

    public void c(int i, C9 c9) {
        if (this.b == null) {
            this.b = new C9[9];
        }
        for (int i2 = 1; i2 <= 256; i2 <<= 1) {
            if ((i & i2) != 0) {
                this.b[AbstractC0112fb.t(i2)] = c9;
            }
        }
    }

    public void d(C9 c9) {
    }

    public abstract void e(C9 c9);

    public void f(C9 c9) {
    }

    public abstract void g(C9 c9);

    public void h(C9 c9) {
    }

    public oi(wi wiVar) {
        this.a = wiVar;
    }
}
