package x;

import android.R;
import android.app.Activity;
import android.app.Dialog;
import android.app.UiModeManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.location.LocationManager;
import android.media.AudioManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.LocaleList;
import android.text.TextUtils;
import android.util.AndroidRuntimeException;
import android.util.AttributeSet;
import android.util.Log;
import android.util.LongSparseArray;
import android.util.TypedValue;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ListAdapter;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;
import androidx.appcompat.view.menu.ExpandedMenuView;
import androidx.appcompat.widget.ActionBarContextView;
import androidx.appcompat.widget.ActionBarOverlayLayout;
import androidx.appcompat.widget.ActionMenuView;
import androidx.appcompat.widget.ContentFrameLayout;
import androidx.appcompat.widget.Toolbar;
import java.lang.ref.WeakReference;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.WeakHashMap;
import org.conscrypt.FileClientSessionCache;
import org.conscrypt.ct.CTConstants;

/* renamed from: x.t1, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class LayoutInflaterFactory2C0368t1 extends AbstractC0102f1 implements InterfaceC0208kb, LayoutInflater.Factory2 {
    public static final Pe h0 = new Pe(0);
    public static final int[] i0 = {R.attr.windowBackground};
    public static final boolean j0 = !"robolectric".equals(Build.FINGERPRINT);
    public ViewGroup A;
    public TextView B;
    public View C;
    public boolean D;
    public boolean E;
    public boolean F;
    public boolean G;
    public boolean H;
    public boolean I;
    public boolean J;
    public boolean K;
    public C0349s1[] L;
    public C0349s1 M;
    public boolean N;
    public boolean O;
    public boolean P;
    public boolean Q;
    public Configuration R;
    public final int S;
    public int T;
    public int U;
    public boolean V;
    public C0274o1 W;
    public C0274o1 X;
    public boolean Y;
    public int Z;
    public boolean b0;
    public Rect c0;
    public Rect d0;
    public C0275o2 e0;
    public OnBackInvokedDispatcher f0;
    public OnBackInvokedCallback g0;
    public final Object j;
    public final Context k;
    public Window l;
    public WindowCallbackC0255n1 m;
    public final Object n;
    public C0059ci o;
    public C0458xf p;
    public CharSequence q;
    public InterfaceC0046c5 r;
    public C0142h1 s;
    public C0142h1 t;
    public AbstractC0121g0 u;
    public ActionBarContextView v;
    public PopupWindow w;

    /* renamed from: x, reason: collision with root package name */
    public RunnableC0122g1 f32x;
    public boolean z;
    public Ah y = null;
    public final RunnableC0122g1 a0 = new RunnableC0122g1(this, 0);

    public LayoutInflaterFactory2C0368t1(Context context, Window window, V0 v0, Object obj) {
        R0 r0 = null;
        this.S = -100;
        this.k = context;
        this.j = obj;
        if (obj instanceof Dialog) {
            while (true) {
                if (context != null) {
                    if (context instanceof R0) {
                        r0 = (R0) context;
                        break;
                    } else if (!(context instanceof ContextWrapper)) {
                        break;
                    } else {
                        context = ((ContextWrapper) context).getBaseContext();
                    }
                } else {
                    break;
                }
            }
            if (r0 != null) {
                this.S = ((LayoutInflaterFactory2C0368t1) r0.k()).S;
            }
        }
        if (this.S == -100) {
            Pe pe = h0;
            Integer num = (Integer) pe.get(this.j.getClass().getName());
            if (num != null) {
                this.S = num.intValue();
                pe.remove(this.j.getClass().getName());
            }
        }
        if (window != null) {
            m(window);
        }
        C0425w1.d();
    }

    public static C0472ya n(Context context) {
        C0472ya c0472ya;
        C0472ya c0472ya2;
        Locale locale;
        if (Build.VERSION.SDK_INT >= 33 || (c0472ya = AbstractC0102f1.c) == null) {
            return null;
        }
        C0472ya b = AbstractC0198k1.b(context.getApplicationContext().getResources().getConfiguration());
        C0491za c0491za = c0472ya.a;
        if (c0491za.a.isEmpty()) {
            c0472ya2 = C0472ya.b;
        } else {
            LinkedHashSet linkedHashSet = new LinkedHashSet();
            for (int i = 0; i < b.a.a.size() + c0491za.a.size(); i++) {
                if (i < c0491za.a.size()) {
                    locale = c0491za.a.get(i);
                } else {
                    locale = b.a.a.get(i - c0491za.a.size());
                }
                if (locale != null) {
                    linkedHashSet.add(locale);
                }
            }
            c0472ya2 = new C0472ya(new C0491za(new LocaleList((Locale[]) linkedHashSet.toArray(new Locale[linkedHashSet.size()]))));
        }
        if (!c0472ya2.a.a.isEmpty()) {
            return c0472ya2;
        }
        return b;
    }

    public static Configuration r(Context context, int i, C0472ya c0472ya, Configuration configuration, boolean z) {
        int i2;
        if (i != 1) {
            if (i != 2) {
                if (z) {
                    i2 = 0;
                } else {
                    i2 = context.getApplicationContext().getResources().getConfiguration().uiMode & 48;
                }
            } else {
                i2 = 32;
            }
        } else {
            i2 = 16;
        }
        Configuration configuration2 = new Configuration();
        configuration2.fontScale = 0.0f;
        if (configuration != null) {
            configuration2.setTo(configuration);
        }
        configuration2.uiMode = i2 | (configuration2.uiMode & (-49));
        if (c0472ya != null) {
            AbstractC0198k1.d(configuration2, c0472ya);
        }
        return configuration2;
    }

    public final void A(int i) {
        this.Z = (1 << i) | this.Z;
        if (!this.Y) {
            View decorView = this.l.getDecorView();
            RunnableC0122g1 runnableC0122g1 = this.a0;
            WeakHashMap weakHashMap = AbstractC0309ph.a;
            decorView.postOnAnimation(runnableC0122g1);
            this.Y = true;
        }
    }

    public final int B(Context context, int i) {
        if (i == -100) {
            return -1;
        }
        if (i != -1) {
            if (i != 0) {
                if (i != 1 && i != 2) {
                    if (i == 3) {
                        if (this.X == null) {
                            this.X = new C0274o1(this, context);
                        }
                        return this.X.f();
                    }
                    throw new IllegalStateException("Unknown value set for night mode. Please use one of the MODE_NIGHT values from AppCompatDelegate.");
                }
            } else {
                if (((UiModeManager) context.getApplicationContext().getSystemService("uimode")).getNightMode() == 0) {
                    return -1;
                }
                return x(context).f();
            }
        }
        return i;
    }

    public final boolean C() {
        InterfaceC0066d5 interfaceC0066d5;
        Xf xf;
        C0303pb c0303pb;
        boolean z = this.N;
        this.N = false;
        C0349s1 y = y(0);
        if (y.m) {
            if (!z) {
                q(y, true);
            }
            return true;
        }
        AbstractC0121g0 abstractC0121g0 = this.u;
        if (abstractC0121g0 != null) {
            abstractC0121g0.a();
            return true;
        }
        z();
        C0059ci c0059ci = this.o;
        if (c0059ci == null || (interfaceC0066d5 = c0059ci.w) == null || (xf = ((C0057cg) interfaceC0066d5).a.L) == null || xf.b == null) {
            return false;
        }
        Xf xf2 = ((C0057cg) interfaceC0066d5).a.L;
        if (xf2 == null) {
            c0303pb = null;
        } else {
            c0303pb = xf2.b;
        }
        if (c0303pb != null) {
            c0303pb.collapseActionView();
        }
        return true;
    }

    /* JADX WARN: Code restructure failed: missing block: B:64:0x0173, code lost:
    
        if (r3.f.getCount() > 0) goto L88;
     */
    /* JADX WARN: Code restructure failed: missing block: B:91:0x0153, code lost:
    
        if (r3 != null) goto L77;
     */
    /* JADX WARN: Removed duplicated region for block: B:36:0x01d1  */
    /* JADX WARN: Removed duplicated region for block: B:38:? A[RETURN, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void D(C0349s1 c0349s1, KeyEvent keyEvent) {
        Context context;
        int i;
        ViewGroup.LayoutParams layoutParams;
        if (!c0349s1.m && !this.Q) {
            int i2 = c0349s1.a;
            Context context2 = this.k;
            if (i2 == 0 && (context2.getResources().getConfiguration().screenLayout & 15) == 4) {
                return;
            }
            Window.Callback callback = this.l.getCallback();
            if (callback != null && !callback.onMenuOpened(i2, c0349s1.h)) {
                q(c0349s1, true);
                return;
            }
            WindowManager windowManager = (WindowManager) context2.getSystemService("window");
            if (windowManager == null || !F(c0349s1, keyEvent)) {
                return;
            }
            C0330r1 c0330r1 = c0349s1.e;
            if (c0330r1 != null && !c0349s1.n) {
                View view = c0349s1.g;
                if (view != null && (layoutParams = view.getLayoutParams()) != null && layoutParams.width == -1) {
                    i = -1;
                    c0349s1.l = false;
                    WindowManager.LayoutParams layoutParams2 = new WindowManager.LayoutParams(i, -2, 0, 0, 1002, 8519680, -3);
                    layoutParams2.gravity = c0349s1.c;
                    layoutParams2.windowAnimations = c0349s1.d;
                    windowManager.addView(c0349s1.e, layoutParams2);
                    c0349s1.m = true;
                    if (i2 != 0) {
                        H();
                        return;
                    }
                    return;
                }
            } else {
                if (c0330r1 == null) {
                    z();
                    C0059ci c0059ci = this.o;
                    if (c0059ci != null) {
                        context = c0059ci.I0();
                    } else {
                        context = null;
                    }
                    if (context != null) {
                        context2 = context;
                    }
                    TypedValue typedValue = new TypedValue();
                    Resources.Theme newTheme = context2.getResources().newTheme();
                    newTheme.setTo(context2.getTheme());
                    newTheme.resolveAttribute(org.conscrypt.R.attr.actionBarPopupTheme, typedValue, true);
                    int i3 = typedValue.resourceId;
                    if (i3 != 0) {
                        newTheme.applyStyle(i3, true);
                    }
                    newTheme.resolveAttribute(org.conscrypt.R.attr.panelMenuListTheme, typedValue, true);
                    int i4 = typedValue.resourceId;
                    if (i4 != 0) {
                        newTheme.applyStyle(i4, true);
                    } else {
                        newTheme.applyStyle(org.conscrypt.R.style.Theme_AppCompat_CompactMenu, true);
                    }
                    L4 l4 = new L4(context2, 0);
                    l4.getTheme().setTo(newTheme);
                    c0349s1.j = l4;
                    TypedArray obtainStyledAttributes = l4.obtainStyledAttributes(AbstractC0210kd.j);
                    c0349s1.b = obtainStyledAttributes.getResourceId(86, 0);
                    c0349s1.d = obtainStyledAttributes.getResourceId(1, 0);
                    obtainStyledAttributes.recycle();
                    c0349s1.e = new C0330r1(this, c0349s1.j);
                    c0349s1.c = 81;
                } else if (c0349s1.n && c0330r1.getChildCount() > 0) {
                    c0349s1.e.removeAllViews();
                }
                View view2 = c0349s1.g;
                if (view2 != null) {
                    c0349s1.f = view2;
                } else {
                    if (c0349s1.h != null) {
                        if (this.t == null) {
                            this.t = new C0142h1(this, 3);
                        }
                        C0142h1 c0142h1 = this.t;
                        if (c0349s1.i == null) {
                            C0207ka c0207ka = new C0207ka(c0349s1.j);
                            c0349s1.i = c0207ka;
                            c0207ka.e = c0142h1;
                            MenuC0246mb menuC0246mb = c0349s1.h;
                            menuC0246mb.b(c0207ka, menuC0246mb.a);
                        }
                        C0207ka c0207ka2 = c0349s1.i;
                        C0330r1 c0330r12 = c0349s1.e;
                        if (c0207ka2.d == null) {
                            c0207ka2.d = (ExpandedMenuView) c0207ka2.b.inflate(org.conscrypt.R.layout.abc_expanded_menu_layout, (ViewGroup) c0330r12, false);
                            if (c0207ka2.f == null) {
                                c0207ka2.f = new C0188ja(c0207ka2);
                            }
                            c0207ka2.d.setAdapter((ListAdapter) c0207ka2.f);
                            c0207ka2.d.setOnItemClickListener(c0207ka2);
                        }
                        ExpandedMenuView expandedMenuView = c0207ka2.d;
                        c0349s1.f = expandedMenuView;
                    }
                    c0349s1.n = true;
                    return;
                }
                if (c0349s1.f != null) {
                    if (c0349s1.g == null) {
                        C0207ka c0207ka3 = c0349s1.i;
                        if (c0207ka3.f == null) {
                            c0207ka3.f = new C0188ja(c0207ka3);
                        }
                    }
                    ViewGroup.LayoutParams layoutParams3 = c0349s1.f.getLayoutParams();
                    if (layoutParams3 == null) {
                        layoutParams3 = new ViewGroup.LayoutParams(-2, -2);
                    }
                    c0349s1.e.setBackgroundResource(c0349s1.b);
                    ViewParent parent = c0349s1.f.getParent();
                    if (parent instanceof ViewGroup) {
                        ((ViewGroup) parent).removeView(c0349s1.f);
                    }
                    c0349s1.e.addView(c0349s1.f, layoutParams3);
                    if (!c0349s1.f.hasFocus()) {
                        c0349s1.f.requestFocus();
                    }
                }
                c0349s1.n = true;
                return;
            }
            i = -2;
            c0349s1.l = false;
            WindowManager.LayoutParams layoutParams22 = new WindowManager.LayoutParams(i, -2, 0, 0, 1002, 8519680, -3);
            layoutParams22.gravity = c0349s1.c;
            layoutParams22.windowAnimations = c0349s1.d;
            windowManager.addView(c0349s1.e, layoutParams22);
            c0349s1.m = true;
            if (i2 != 0) {
            }
        }
    }

    public final boolean E(C0349s1 c0349s1, int i, KeyEvent keyEvent) {
        MenuC0246mb menuC0246mb;
        if (keyEvent.isSystem()) {
            return false;
        }
        if ((!c0349s1.k && !F(c0349s1, keyEvent)) || (menuC0246mb = c0349s1.h) == null) {
            return false;
        }
        return menuC0246mb.performShortcut(i, keyEvent, 1);
    }

    public final boolean F(C0349s1 c0349s1, KeyEvent keyEvent) {
        boolean z;
        InterfaceC0046c5 interfaceC0046c5;
        InterfaceC0046c5 interfaceC0046c52;
        Resources.Theme theme;
        int i;
        boolean z2;
        InterfaceC0046c5 interfaceC0046c53;
        InterfaceC0046c5 interfaceC0046c54;
        if (this.Q) {
            return false;
        }
        if (c0349s1.k) {
            return true;
        }
        C0349s1 c0349s12 = this.M;
        if (c0349s12 != null && c0349s12 != c0349s1) {
            q(c0349s12, false);
        }
        Window.Callback callback = this.l.getCallback();
        int i2 = c0349s1.a;
        if (callback != null) {
            c0349s1.g = callback.onCreatePanelView(i2);
        }
        if (i2 != 0 && i2 != 108) {
            z = false;
        } else {
            z = true;
        }
        if (z && (interfaceC0046c54 = this.r) != null) {
            ActionBarOverlayLayout actionBarOverlayLayout = (ActionBarOverlayLayout) interfaceC0046c54;
            actionBarOverlayLayout.k();
            ((C0057cg) actionBarOverlayLayout.e).l = true;
        }
        if (c0349s1.g == null) {
            MenuC0246mb menuC0246mb = c0349s1.h;
            if (menuC0246mb == null || c0349s1.o) {
                if (menuC0246mb == null) {
                    Context context = this.k;
                    if ((i2 == 0 || i2 == 108) && this.r != null) {
                        TypedValue typedValue = new TypedValue();
                        Resources.Theme theme2 = context.getTheme();
                        theme2.resolveAttribute(org.conscrypt.R.attr.actionBarTheme, typedValue, true);
                        if (typedValue.resourceId != 0) {
                            theme = context.getResources().newTheme();
                            theme.setTo(theme2);
                            theme.applyStyle(typedValue.resourceId, true);
                            theme.resolveAttribute(org.conscrypt.R.attr.actionBarWidgetTheme, typedValue, true);
                        } else {
                            theme2.resolveAttribute(org.conscrypt.R.attr.actionBarWidgetTheme, typedValue, true);
                            theme = null;
                        }
                        if (typedValue.resourceId != 0) {
                            if (theme == null) {
                                theme = context.getResources().newTheme();
                                theme.setTo(theme2);
                            }
                            theme.applyStyle(typedValue.resourceId, true);
                        }
                        if (theme != null) {
                            L4 l4 = new L4(context, 0);
                            l4.getTheme().setTo(theme);
                            context = l4;
                        }
                    }
                    MenuC0246mb menuC0246mb2 = new MenuC0246mb(context);
                    menuC0246mb2.e = this;
                    MenuC0246mb menuC0246mb3 = c0349s1.h;
                    if (menuC0246mb2 != menuC0246mb3) {
                        if (menuC0246mb3 != null) {
                            menuC0246mb3.r(c0349s1.i);
                        }
                        c0349s1.h = menuC0246mb2;
                        C0207ka c0207ka = c0349s1.i;
                        if (c0207ka != null) {
                            menuC0246mb2.b(c0207ka, menuC0246mb2.a);
                        }
                    }
                    if (c0349s1.h == null) {
                        return false;
                    }
                }
                if (z && (interfaceC0046c52 = this.r) != null) {
                    if (this.s == null) {
                        this.s = new C0142h1(this, 2);
                    }
                    ((ActionBarOverlayLayout) interfaceC0046c52).l(c0349s1.h, this.s);
                }
                c0349s1.h.w();
                if (!callback.onCreatePanelMenu(i2, c0349s1.h)) {
                    MenuC0246mb menuC0246mb4 = c0349s1.h;
                    if (menuC0246mb4 != null) {
                        if (menuC0246mb4 != null) {
                            menuC0246mb4.r(c0349s1.i);
                        }
                        c0349s1.h = null;
                    }
                    if (z && (interfaceC0046c5 = this.r) != null) {
                        ((ActionBarOverlayLayout) interfaceC0046c5).l(null, this.s);
                    }
                    return false;
                }
                c0349s1.o = false;
            }
            c0349s1.h.w();
            Bundle bundle = c0349s1.p;
            if (bundle != null) {
                c0349s1.h.s(bundle);
                c0349s1.p = null;
            }
            if (!callback.onPreparePanel(0, c0349s1.g, c0349s1.h)) {
                if (z && (interfaceC0046c53 = this.r) != null) {
                    ((ActionBarOverlayLayout) interfaceC0046c53).l(null, this.s);
                }
                c0349s1.h.v();
                return false;
            }
            if (keyEvent != null) {
                i = keyEvent.getDeviceId();
            } else {
                i = -1;
            }
            if (KeyCharacterMap.load(i).getKeyboardType() != 1) {
                z2 = true;
            } else {
                z2 = false;
            }
            c0349s1.h.setQwertyMode(z2);
            c0349s1.h.v();
        }
        c0349s1.k = true;
        c0349s1.l = false;
        this.M = c0349s1;
        return true;
    }

    public final void G() {
        if (!this.z) {
        } else {
            throw new AndroidRuntimeException("Window feature must be requested before adding content");
        }
    }

    public final void H() {
        OnBackInvokedCallback onBackInvokedCallback;
        if (Build.VERSION.SDK_INT >= 33) {
            boolean z = false;
            if (this.f0 != null && (y(0).m || this.u != null)) {
                z = true;
            }
            if (z && this.g0 == null) {
                this.g0 = AbstractC0236m1.b(this.f0, this);
            } else if (!z && (onBackInvokedCallback = this.g0) != null) {
                AbstractC0236m1.c(this.f0, onBackInvokedCallback);
                this.g0 = null;
            }
        }
    }

    @Override // x.AbstractC0102f1
    public final void a() {
        LayoutInflater from = LayoutInflater.from(this.k);
        if (from.getFactory() == null) {
            from.setFactory2(this);
        } else if (!(from.getFactory2() instanceof LayoutInflaterFactory2C0368t1)) {
            Log.i("AppCompatDelegate", "The Activity's LayoutInflater already has a Factory installed so we can not install AppCompat's");
        }
    }

    @Override // x.AbstractC0102f1
    public final void c() {
        String str;
        this.O = true;
        l(false, true);
        w();
        Object obj = this.j;
        if (obj instanceof Activity) {
            try {
                Activity activity = (Activity) obj;
                try {
                    str = AbstractC0112fb.p(activity, activity.getComponentName());
                } catch (PackageManager.NameNotFoundException e) {
                    throw new IllegalArgumentException(e);
                }
            } catch (IllegalArgumentException unused) {
                str = null;
            }
            if (str != null) {
                C0059ci c0059ci = this.o;
                if (c0059ci == null) {
                    this.b0 = true;
                } else {
                    c0059ci.K0(true);
                }
            }
            synchronized (AbstractC0102f1.h) {
                AbstractC0102f1.e(this);
                AbstractC0102f1.g.add(new WeakReference(this));
            }
        }
        this.R = new Configuration(this.k.getResources().getConfiguration());
        this.P = true;
    }

    /* JADX WARN: Removed duplicated region for block: B:26:0x0060  */
    /* JADX WARN: Removed duplicated region for block: B:29:0x0067  */
    /* JADX WARN: Removed duplicated region for block: B:31:? A[RETURN, SYNTHETIC] */
    @Override // x.AbstractC0102f1
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void d() {
        C0274o1 c0274o1;
        C0274o1 c0274o12;
        if (this.j instanceof Activity) {
            synchronized (AbstractC0102f1.h) {
                AbstractC0102f1.e(this);
            }
        }
        if (this.Y) {
            this.l.getDecorView().removeCallbacks(this.a0);
        }
        this.Q = true;
        if (this.S != -100) {
            Object obj = this.j;
            if ((obj instanceof Activity) && ((Activity) obj).isChangingConfigurations()) {
                h0.put(this.j.getClass().getName(), Integer.valueOf(this.S));
                c0274o1 = this.W;
                if (c0274o1 != null) {
                    c0274o1.c();
                }
                c0274o12 = this.X;
                if (c0274o12 == null) {
                    c0274o12.c();
                    return;
                }
                return;
            }
        }
        h0.remove(this.j.getClass().getName());
        c0274o1 = this.W;
        if (c0274o1 != null) {
        }
        c0274o12 = this.X;
        if (c0274o12 == null) {
        }
    }

    @Override // x.AbstractC0102f1
    public final boolean f(int i) {
        if (i == 8) {
            Log.i("AppCompatDelegate", "You should now use the AppCompatDelegate.FEATURE_SUPPORT_ACTION_BAR id when requesting this feature.");
            i = 108;
        } else if (i == 9) {
            Log.i("AppCompatDelegate", "You should now use the AppCompatDelegate.FEATURE_SUPPORT_ACTION_BAR_OVERLAY id when requesting this feature.");
            i = 109;
        }
        if (this.J && i == 108) {
            return false;
        }
        if (this.F && i == 1) {
            this.F = false;
        }
        if (i != 1) {
            if (i != 2) {
                if (i != 5) {
                    if (i != 10) {
                        if (i != 108) {
                            if (i != 109) {
                                return this.l.requestFeature(i);
                            }
                            G();
                            this.G = true;
                            return true;
                        }
                        G();
                        this.F = true;
                        return true;
                    }
                    G();
                    this.H = true;
                    return true;
                }
                G();
                this.E = true;
                return true;
            }
            G();
            this.D = true;
            return true;
        }
        G();
        this.J = true;
        return true;
    }

    @Override // x.AbstractC0102f1
    public final void g(int i) {
        v();
        ViewGroup viewGroup = (ViewGroup) this.A.findViewById(R.id.content);
        viewGroup.removeAllViews();
        LayoutInflater.from(this.k).inflate(i, viewGroup);
        this.m.a(this.l.getCallback());
    }

    @Override // x.AbstractC0102f1
    public final void h(View view) {
        v();
        ViewGroup viewGroup = (ViewGroup) this.A.findViewById(R.id.content);
        viewGroup.removeAllViews();
        viewGroup.addView(view);
        this.m.a(this.l.getCallback());
    }

    @Override // x.InterfaceC0208kb
    public final boolean i(MenuC0246mb menuC0246mb, MenuItem menuItem) {
        int i;
        C0349s1 c0349s1;
        Window.Callback callback = this.l.getCallback();
        if (callback != null && !this.Q) {
            MenuC0246mb k = menuC0246mb.k();
            C0349s1[] c0349s1Arr = this.L;
            if (c0349s1Arr != null) {
                i = c0349s1Arr.length;
            } else {
                i = 0;
            }
            int i2 = 0;
            while (true) {
                if (i2 < i) {
                    c0349s1 = c0349s1Arr[i2];
                    if (c0349s1 != null && c0349s1.h == k) {
                        break;
                    }
                    i2++;
                } else {
                    c0349s1 = null;
                    break;
                }
            }
            if (c0349s1 != null) {
                return callback.onMenuItemSelected(c0349s1.a, menuItem);
            }
        }
        return false;
    }

    @Override // x.AbstractC0102f1
    public final void j(View view, ViewGroup.LayoutParams layoutParams) {
        v();
        ViewGroup viewGroup = (ViewGroup) this.A.findViewById(R.id.content);
        viewGroup.removeAllViews();
        viewGroup.addView(view, layoutParams);
        this.m.a(this.l.getCallback());
    }

    @Override // x.AbstractC0102f1
    public final void k(CharSequence charSequence) {
        this.q = charSequence;
        InterfaceC0046c5 interfaceC0046c5 = this.r;
        if (interfaceC0046c5 != null) {
            interfaceC0046c5.setWindowTitle(charSequence);
            return;
        }
        C0059ci c0059ci = this.o;
        if (c0059ci != null) {
            C0057cg c0057cg = (C0057cg) c0059ci.w;
            if (!c0057cg.g) {
                c0057cg.h = charSequence;
                if ((c0057cg.b & 8) != 0) {
                    Toolbar toolbar = c0057cg.a;
                    toolbar.setTitle(charSequence);
                    if (c0057cg.g) {
                        AbstractC0309ph.m(toolbar.getRootView(), charSequence);
                        return;
                    }
                    return;
                }
                return;
            }
            return;
        }
        TextView textView = this.B;
        if (textView != null) {
            textView.setText(charSequence);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:145:0x021d  */
    /* JADX WARN: Removed duplicated region for block: B:149:0x0227  */
    /* JADX WARN: Removed duplicated region for block: B:152:0x022e  */
    /* JADX WARN: Removed duplicated region for block: B:154:0x0232  */
    /* JADX WARN: Removed duplicated region for block: B:156:0x0243  */
    /* JADX WARN: Removed duplicated region for block: B:159:0x0255  */
    /* JADX WARN: Removed duplicated region for block: B:164:0x0266  */
    /* JADX WARN: Removed duplicated region for block: B:167:0x024b  */
    /* JADX WARN: Removed duplicated region for block: B:173:0x009d  */
    /* JADX WARN: Removed duplicated region for block: B:174:0x0094  */
    /* JADX WARN: Removed duplicated region for block: B:23:0x007c  */
    /* JADX WARN: Removed duplicated region for block: B:26:0x0092  */
    /* JADX WARN: Removed duplicated region for block: B:28:0x009a  */
    /* JADX WARN: Removed duplicated region for block: B:46:0x00c9  */
    /* JADX WARN: Removed duplicated region for block: B:55:0x00fe A[ADDED_TO_REGION] */
    /* JADX WARN: Removed duplicated region for block: B:79:0x0192  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final boolean l(boolean z, boolean z2) {
        C0472ya c0472ya;
        int i;
        Configuration configuration;
        int i2;
        int i3;
        C0472ya b;
        int i4;
        boolean z3;
        Object obj;
        Object obj2;
        Activity activity;
        int i5;
        int i6 = 0;
        if (this.Q) {
            return false;
        }
        int i7 = this.S;
        if (i7 == -100) {
            i7 = AbstractC0102f1.b;
        }
        int i8 = i7;
        Context context = this.k;
        int B = B(context, i8);
        int i9 = Build.VERSION.SDK_INT;
        LongSparseArray longSparseArray = null;
        if (i9 < 33) {
            c0472ya = n(context);
        } else {
            c0472ya = null;
        }
        if (!z2 && c0472ya != null) {
            c0472ya = AbstractC0198k1.b(context.getResources().getConfiguration());
        }
        Configuration r = r(context, B, c0472ya, null, false);
        boolean z4 = this.V;
        Object obj3 = this.j;
        boolean z5 = true;
        if (!z4 && (obj3 instanceof Activity)) {
            PackageManager packageManager = context.getPackageManager();
            if (packageManager == null) {
                i = 0;
                configuration = this.R;
                if (configuration == null) {
                    configuration = context.getResources().getConfiguration();
                }
                i2 = configuration.uiMode & 48;
                i3 = r.uiMode & 48;
                C0472ya b2 = AbstractC0198k1.b(configuration);
                if (c0472ya != null) {
                    b = null;
                } else {
                    b = AbstractC0198k1.b(r);
                }
                if (i2 == i3) {
                    i4 = 512;
                } else {
                    i4 = 0;
                }
                if (b != null && !b2.equals(b)) {
                    i4 |= 8196;
                }
                if (((~i) & i4) != 0 && z && this.O && ((j0 || this.P) && (obj3 instanceof Activity))) {
                    activity = (Activity) obj3;
                    if (!activity.isChild()) {
                        int i10 = Build.VERSION.SDK_INT;
                        if (i10 >= 31 && (i4 & 8192) != 0) {
                            activity.getWindow().getDecorView().setLayoutDirection(r.getLayoutDirection());
                        }
                        if (i10 >= 28) {
                            activity.recreate();
                        } else {
                            new Handler(activity.getMainLooper()).post(new RunnableC0141h0(i6, activity));
                        }
                        z3 = true;
                        if (z3 && i4 != 0) {
                            if ((i & i4) == i4) {
                                i6 = 1;
                            }
                            Resources resources = context.getResources();
                            Configuration configuration2 = new Configuration(resources.getConfiguration());
                            configuration2.uiMode = (resources.getConfiguration().uiMode & (-49)) | i3;
                            if (b != null) {
                                AbstractC0198k1.d(configuration2, b);
                            }
                            resources.updateConfiguration(configuration2, null);
                            int i11 = Build.VERSION.SDK_INT;
                            if (i11 < 26 && i11 < 28) {
                                if (!AbstractC0171ib.h) {
                                    try {
                                        Field declaredField = Resources.class.getDeclaredField("mResourcesImpl");
                                        AbstractC0171ib.g = declaredField;
                                        declaredField.setAccessible(true);
                                    } catch (NoSuchFieldException e) {
                                        Log.e("ResourcesFlusher", "Could not retrieve Resources#mResourcesImpl field", e);
                                    }
                                    AbstractC0171ib.h = true;
                                }
                                Field field = AbstractC0171ib.g;
                                if (field != null) {
                                    try {
                                        obj = field.get(resources);
                                    } catch (IllegalAccessException e2) {
                                        Log.e("ResourcesFlusher", "Could not retrieve value from Resources#mResourcesImpl", e2);
                                        obj = null;
                                    }
                                    if (obj != null) {
                                        if (!AbstractC0171ib.b) {
                                            try {
                                                Field declaredField2 = obj.getClass().getDeclaredField("mDrawableCache");
                                                AbstractC0171ib.a = declaredField2;
                                                declaredField2.setAccessible(true);
                                            } catch (NoSuchFieldException e3) {
                                                Log.e("ResourcesFlusher", "Could not retrieve ResourcesImpl#mDrawableCache field", e3);
                                            }
                                            AbstractC0171ib.b = true;
                                        }
                                        Field field2 = AbstractC0171ib.a;
                                        if (field2 != null) {
                                            try {
                                                obj2 = field2.get(obj);
                                            } catch (IllegalAccessException e4) {
                                                Log.e("ResourcesFlusher", "Could not retrieve value from ResourcesImpl#mDrawableCache", e4);
                                            }
                                            if (obj2 != null) {
                                                if (!AbstractC0171ib.d) {
                                                    try {
                                                        AbstractC0171ib.c = Class.forName("android.content.res.ThemedResourceCache");
                                                    } catch (ClassNotFoundException e5) {
                                                        Log.e("ResourcesFlusher", "Could not find ThemedResourceCache class", e5);
                                                    }
                                                    AbstractC0171ib.d = true;
                                                }
                                                Class cls = AbstractC0171ib.c;
                                                if (cls != null) {
                                                    if (!AbstractC0171ib.f) {
                                                        try {
                                                            Field declaredField3 = cls.getDeclaredField("mUnthemedEntries");
                                                            AbstractC0171ib.e = declaredField3;
                                                            declaredField3.setAccessible(true);
                                                        } catch (NoSuchFieldException e6) {
                                                            Log.e("ResourcesFlusher", "Could not retrieve ThemedResourceCache#mUnthemedEntries field", e6);
                                                        }
                                                        AbstractC0171ib.f = true;
                                                    }
                                                    Field field3 = AbstractC0171ib.e;
                                                    if (field3 != null) {
                                                        try {
                                                            longSparseArray = (LongSparseArray) field3.get(obj2);
                                                        } catch (IllegalAccessException e7) {
                                                            Log.e("ResourcesFlusher", "Could not retrieve value from ThemedResourceCache#mUnthemedEntries", e7);
                                                        }
                                                        if (longSparseArray != null) {
                                                            longSparseArray.clear();
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        obj2 = null;
                                        if (obj2 != null) {
                                        }
                                    }
                                }
                            }
                            int i12 = this.T;
                            if (i12 != 0) {
                                context.setTheme(i12);
                                context.getTheme().applyStyle(this.T, true);
                            }
                            if (i6 != 0 && (obj3 instanceof Activity)) {
                                Activity activity2 = (Activity) obj3;
                                if (activity2 instanceof Y9) {
                                    if (((Y9) activity2).d().c.compareTo(T9.c) >= 0) {
                                        activity2.onConfigurationChanged(configuration2);
                                    }
                                } else if (this.P && !this.Q) {
                                    activity2.onConfigurationChanged(configuration2);
                                }
                            }
                        } else {
                            z5 = z3;
                        }
                        if (z5 && (obj3 instanceof R0)) {
                            if ((i4 & 512) != 0) {
                            }
                            if ((i4 & 4) != 0) {
                            }
                        }
                        if (b != null) {
                            AbstractC0198k1.c(AbstractC0198k1.b(context.getResources().getConfiguration()));
                        }
                        if (i8 == 0) {
                            x(context).i();
                        } else {
                            C0274o1 c0274o1 = this.W;
                            if (c0274o1 != null) {
                                c0274o1.c();
                            }
                        }
                        if (i8 == 3) {
                            if (this.X == null) {
                                this.X = new C0274o1(this, context);
                            }
                            this.X.i();
                        } else {
                            C0274o1 c0274o12 = this.X;
                            if (c0274o12 != null) {
                                c0274o12.c();
                            }
                        }
                        return z5;
                    }
                }
                z3 = false;
                if (z3) {
                }
                z5 = z3;
                if (z5) {
                    if ((i4 & 512) != 0) {
                    }
                    if ((i4 & 4) != 0) {
                    }
                }
                if (b != null) {
                }
                if (i8 == 0) {
                }
                if (i8 == 3) {
                }
                return z5;
            }
            if (i9 >= 29) {
                i5 = 269221888;
            } else {
                i5 = 786432;
            }
            try {
                ActivityInfo activityInfo = packageManager.getActivityInfo(new ComponentName(context, obj3.getClass()), i5);
                if (activityInfo != null) {
                    this.U = activityInfo.configChanges;
                }
            } catch (PackageManager.NameNotFoundException e8) {
                Log.d("AppCompatDelegate", "Exception while getting ActivityInfo", e8);
                this.U = 0;
            }
        }
        this.V = true;
        i = this.U;
        configuration = this.R;
        if (configuration == null) {
        }
        i2 = configuration.uiMode & 48;
        i3 = r.uiMode & 48;
        C0472ya b22 = AbstractC0198k1.b(configuration);
        if (c0472ya != null) {
        }
        if (i2 == i3) {
        }
        if (b != null) {
            i4 |= 8196;
        }
        if (((~i) & i4) != 0) {
            activity = (Activity) obj3;
            if (!activity.isChild()) {
            }
        }
        z3 = false;
        if (z3) {
        }
        z5 = z3;
        if (z5) {
        }
        if (b != null) {
        }
        if (i8 == 0) {
        }
        if (i8 == 3) {
        }
        return z5;
    }

    public final void m(Window window) {
        Drawable drawable;
        OnBackInvokedDispatcher onBackInvokedDispatcher;
        OnBackInvokedCallback onBackInvokedCallback;
        int resourceId;
        if (this.l == null) {
            Window.Callback callback = window.getCallback();
            if (!(callback instanceof WindowCallbackC0255n1)) {
                WindowCallbackC0255n1 windowCallbackC0255n1 = new WindowCallbackC0255n1(this, callback);
                this.m = windowCallbackC0255n1;
                window.setCallback(windowCallbackC0255n1);
                int[] iArr = i0;
                Context context = this.k;
                TypedArray obtainStyledAttributes = context.obtainStyledAttributes((AttributeSet) null, iArr);
                if (obtainStyledAttributes.hasValue(0) && (resourceId = obtainStyledAttributes.getResourceId(0, 0)) != 0) {
                    C0425w1 a = C0425w1.a();
                    synchronized (a) {
                        drawable = a.a.d(context, resourceId, true);
                    }
                } else {
                    drawable = null;
                }
                if (drawable != null) {
                    window.setBackgroundDrawable(drawable);
                }
                obtainStyledAttributes.recycle();
                this.l = window;
                if (Build.VERSION.SDK_INT >= 33 && (onBackInvokedDispatcher = this.f0) == null) {
                    if (onBackInvokedDispatcher != null && (onBackInvokedCallback = this.g0) != null) {
                        AbstractC0236m1.c(onBackInvokedDispatcher, onBackInvokedCallback);
                        this.g0 = null;
                    }
                    Object obj = this.j;
                    if (obj instanceof Activity) {
                        Activity activity = (Activity) obj;
                        if (activity.getWindow() != null) {
                            this.f0 = AbstractC0236m1.a(activity);
                            H();
                            return;
                        }
                    }
                    this.f0 = null;
                    H();
                    return;
                }
                return;
            }
            throw new IllegalStateException("AppCompat has already installed itself into the Window");
        }
        throw new IllegalStateException("AppCompat has already installed itself into the Window");
    }

    public final void o(int i, C0349s1 c0349s1, MenuC0246mb menuC0246mb) {
        if (menuC0246mb == null) {
            if (c0349s1 == null && i >= 0) {
                C0349s1[] c0349s1Arr = this.L;
                if (i < c0349s1Arr.length) {
                    c0349s1 = c0349s1Arr[i];
                }
            }
            if (c0349s1 != null) {
                menuC0246mb = c0349s1.h;
            }
        }
        if ((c0349s1 == null || c0349s1.m) && !this.Q) {
            WindowCallbackC0255n1 windowCallbackC0255n1 = this.m;
            Window.Callback callback = this.l.getCallback();
            windowCallbackC0255n1.getClass();
            try {
                windowCallbackC0255n1.d = true;
                callback.onPanelClosed(i, menuC0246mb);
            } finally {
                windowCallbackC0255n1.d = false;
            }
        }
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Code restructure failed: missing block: B:117:0x0115, code lost:
    
        if (r2.equals("ImageButton") == false) goto L24;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r8v1 */
    /* JADX WARN: Type inference failed for: r8v2, types: [boolean, int] */
    /* JADX WARN: Type inference failed for: r8v3 */
    @Override // android.view.LayoutInflater.Factory2
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final View onCreateView(View view, String str, Context context, AttributeSet attributeSet) {
        View h1;
        int i;
        String str2 = str;
        char c = 4;
        View view2 = null;
        if (this.e0 == null) {
            int[] iArr = AbstractC0210kd.j;
            Context context2 = this.k;
            TypedArray obtainStyledAttributes = context2.obtainStyledAttributes(iArr);
            String string = obtainStyledAttributes.getString(116);
            obtainStyledAttributes.recycle();
            if (string == null) {
                this.e0 = new C0275o2();
            } else {
                try {
                    this.e0 = (C0275o2) context2.getClassLoader().loadClass(string).getDeclaredConstructor(null).newInstance(null);
                } catch (Throwable th) {
                    Log.i("AppCompatDelegate", "Failed to instantiate custom view inflater " + string + ". Falling back to default.", th);
                    this.e0 = new C0275o2();
                }
            }
        }
        C0275o2 c0275o2 = this.e0;
        int i2 = Ug.a;
        c0275o2.getClass();
        TypedArray obtainStyledAttributes2 = context.obtainStyledAttributes(attributeSet, AbstractC0210kd.y, 0, 0);
        int resourceId = obtainStyledAttributes2.getResourceId(4, 0);
        if (resourceId != 0) {
            Log.i("AppCompatViewInflater", "app:theme is now deprecated. Please move to using android:theme instead.");
        }
        obtainStyledAttributes2.recycle();
        Context l4 = (resourceId == 0 || ((context instanceof L4) && ((L4) context).a == resourceId)) ? context : new L4(context, resourceId);
        str.getClass();
        switch (str.hashCode()) {
            case -1946472170:
                if (str2.equals("RatingBar")) {
                    c = 0;
                    break;
                }
                c = 65535;
                break;
            case -1455429095:
                if (str2.equals("CheckedTextView")) {
                    c = 1;
                    break;
                }
                c = 65535;
                break;
            case -1346021293:
                if (str2.equals("MultiAutoCompleteTextView")) {
                    c = 2;
                    break;
                }
                c = 65535;
                break;
            case -938935918:
                if (str2.equals("TextView")) {
                    c = 3;
                    break;
                }
                c = 65535;
                break;
            case -937446323:
                break;
            case -658531749:
                if (str2.equals("SeekBar")) {
                    c = 5;
                    break;
                }
                c = 65535;
                break;
            case -339785223:
                if (str2.equals("Spinner")) {
                    c = 6;
                    break;
                }
                c = 65535;
                break;
            case 776382189:
                if (str2.equals("RadioButton")) {
                    c = 7;
                    break;
                }
                c = 65535;
                break;
            case 799298502:
                if (str2.equals("ToggleButton")) {
                    c = '\b';
                    break;
                }
                c = 65535;
                break;
            case 1125864064:
                if (str2.equals("ImageView")) {
                    c = '\t';
                    break;
                }
                c = 65535;
                break;
            case 1413872058:
                if (str2.equals("AutoCompleteTextView")) {
                    c = '\n';
                    break;
                }
                c = 65535;
                break;
            case 1601505219:
                if (str2.equals("CheckBox")) {
                    c = 11;
                    break;
                }
                c = 65535;
                break;
            case 1666676343:
                if (str2.equals("EditText")) {
                    c = '\f';
                    break;
                }
                c = 65535;
                break;
            case 2001146706:
                if (str2.equals("Button")) {
                    c = '\r';
                    break;
                }
                c = 65535;
                break;
            default:
                c = 65535;
                break;
        }
        switch (c) {
            case 0:
                h1 = new H1(l4, attributeSet);
                break;
            case 1:
                h1 = new X0(l4, attributeSet);
                break;
            case 2:
                h1 = new D1(l4, attributeSet);
                break;
            case CTConstants.CERTIFICATE_LENGTH_BYTES /* 3 */:
                h1 = c0275o2.e(l4, attributeSet);
                break;
            case 4:
                h1 = new A1(l4, attributeSet, org.conscrypt.R.attr.imageButtonStyle);
                break;
            case 5:
                h1 = new J1(l4, attributeSet);
                break;
            case 6:
                h1 = new V1(l4, attributeSet);
                break;
            case 7:
                h1 = c0275o2.d(l4, attributeSet);
                break;
            case CTConstants.TIMESTAMP_LENGTH /* 8 */:
                h1 = new C0237m2(l4, attributeSet);
                break;
            case '\t':
                h1 = new C1(l4, attributeSet, 0);
                break;
            case '\n':
                h1 = c0275o2.a(l4, attributeSet);
                break;
            case 11:
                h1 = c0275o2.c(l4, attributeSet);
                break;
            case FileClientSessionCache.MAX_SIZE /* 12 */:
                h1 = new C0463y1(l4, attributeSet);
                break;
            case '\r':
                h1 = c0275o2.b(l4, attributeSet);
                break;
            default:
                h1 = null;
                break;
        }
        if (h1 == null && context != l4) {
            Object[] objArr = c0275o2.a;
            if (str2.equals("view")) {
                str2 = attributeSet.getAttributeValue(null, "class");
            }
            try {
                objArr[0] = l4;
                objArr[1] = attributeSet;
                if (-1 == str2.indexOf(46)) {
                    int i3 = 0;
                    while (true) {
                        String[] strArr = C0275o2.g;
                        if (i3 < 3) {
                            View f = c0275o2.f(l4, str2, strArr[i3]);
                            if (f != null) {
                                objArr[0] = null;
                                objArr[1] = null;
                                view2 = f;
                            } else {
                                i3++;
                            }
                        }
                    }
                } else {
                    View f2 = c0275o2.f(l4, str2, null);
                    objArr[0] = null;
                    objArr[1] = null;
                    view2 = f2;
                }
            } catch (Exception unused) {
            } finally {
                objArr[0] = null;
                objArr[1] = null;
            }
            h1 = view2;
        }
        if (h1 != null) {
            Context context3 = h1.getContext();
            if ((context3 instanceof ContextWrapper) && h1.hasOnClickListeners()) {
                TypedArray obtainStyledAttributes3 = context3.obtainStyledAttributes(attributeSet, C0275o2.c);
                String string2 = obtainStyledAttributes3.getString(0);
                if (string2 != null) {
                    h1.setOnClickListener(new ViewOnClickListenerC0256n2(h1, string2));
                }
                obtainStyledAttributes3.recycle();
            }
            if (Build.VERSION.SDK_INT <= 28) {
                TypedArray obtainStyledAttributes4 = l4.obtainStyledAttributes(attributeSet, C0275o2.d);
                if (obtainStyledAttributes4.hasValue(0)) {
                    boolean z = obtainStyledAttributes4.getBoolean(0, false);
                    WeakHashMap weakHashMap = AbstractC0309ph.a;
                    i = 0;
                    new C0078dh(org.conscrypt.R.id.tag_accessibility_heading, Boolean.class, 0, 28, 3).d(h1, Boolean.valueOf(z));
                } else {
                    i = 0;
                }
                obtainStyledAttributes4.recycle();
                TypedArray obtainStyledAttributes5 = l4.obtainStyledAttributes(attributeSet, C0275o2.e);
                if (obtainStyledAttributes5.hasValue(i)) {
                    AbstractC0309ph.m(h1, obtainStyledAttributes5.getString(i));
                }
                obtainStyledAttributes5.recycle();
                TypedArray obtainStyledAttributes6 = l4.obtainStyledAttributes(attributeSet, C0275o2.f);
                if (obtainStyledAttributes6.hasValue(i)) {
                    boolean z2 = obtainStyledAttributes6.getBoolean(i, i);
                    WeakHashMap weakHashMap2 = AbstractC0309ph.a;
                    new C0078dh(org.conscrypt.R.id.tag_screen_reader_focusable, Boolean.class, i, 28, 0).d(h1, Boolean.valueOf(z2));
                }
                obtainStyledAttributes6.recycle();
            }
        }
        return h1;
    }

    public final void p(MenuC0246mb menuC0246mb) {
        C0041c0 c0041c0;
        if (this.K) {
            return;
        }
        this.K = true;
        ActionBarOverlayLayout actionBarOverlayLayout = (ActionBarOverlayLayout) this.r;
        actionBarOverlayLayout.k();
        ActionMenuView actionMenuView = ((C0057cg) actionBarOverlayLayout.e).a.a;
        if (actionMenuView != null && (c0041c0 = actionMenuView.t) != null) {
            c0041c0.e();
            Y y = c0041c0.t;
            if (y != null && y.b()) {
                y.i.dismiss();
            }
        }
        Window.Callback callback = this.l.getCallback();
        if (callback != null && !this.Q) {
            callback.onPanelClosed(108, menuC0246mb);
        }
        this.K = false;
    }

    public final void q(C0349s1 c0349s1, boolean z) {
        C0330r1 c0330r1;
        InterfaceC0046c5 interfaceC0046c5;
        C0041c0 c0041c0;
        if (z && c0349s1.a == 0 && (interfaceC0046c5 = this.r) != null) {
            ActionBarOverlayLayout actionBarOverlayLayout = (ActionBarOverlayLayout) interfaceC0046c5;
            actionBarOverlayLayout.k();
            ActionMenuView actionMenuView = ((C0057cg) actionBarOverlayLayout.e).a.a;
            if (actionMenuView != null && (c0041c0 = actionMenuView.t) != null && c0041c0.i()) {
                p(c0349s1.h);
                return;
            }
        }
        WindowManager windowManager = (WindowManager) this.k.getSystemService("window");
        if (windowManager != null && c0349s1.m && (c0330r1 = c0349s1.e) != null) {
            windowManager.removeView(c0330r1);
            if (z) {
                o(c0349s1.a, c0349s1, null);
            }
        }
        c0349s1.k = false;
        c0349s1.l = false;
        c0349s1.m = false;
        c0349s1.f = null;
        c0349s1.n = true;
        if (this.M == c0349s1) {
            this.M = null;
        }
        if (c0349s1.a == 0) {
            H();
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:61:0x00db, code lost:
    
        if (r7.e() != false) goto L90;
     */
    /* JADX WARN: Code restructure failed: missing block: B:81:0x0101, code lost:
    
        if (r7.l() != false) goto L90;
     */
    /* JADX WARN: Removed duplicated region for block: B:64:0x012c  */
    /* JADX WARN: Removed duplicated region for block: B:70:? A[RETURN, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final boolean s(KeyEvent keyEvent) {
        View decorView;
        boolean z;
        boolean z2;
        ActionMenuView actionMenuView;
        C0041c0 c0041c0;
        Object obj = this.j;
        boolean z3 = true;
        if (((obj instanceof K9) || (obj instanceof G0)) && (decorView = this.l.getDecorView()) != null && E9.v(decorView, keyEvent)) {
            return true;
        }
        if (keyEvent.getKeyCode() == 82) {
            WindowCallbackC0255n1 windowCallbackC0255n1 = this.m;
            Window.Callback callback = this.l.getCallback();
            windowCallbackC0255n1.getClass();
            try {
                windowCallbackC0255n1.c = true;
                if (callback.dispatchKeyEvent(keyEvent)) {
                    return true;
                }
            } finally {
                windowCallbackC0255n1.c = false;
            }
        }
        int keyCode = keyEvent.getKeyCode();
        if (keyEvent.getAction() == 0) {
            if (keyCode != 4) {
                if (keyCode == 82) {
                    if (keyEvent.getRepeatCount() != 0) {
                        return true;
                    }
                    C0349s1 y = y(0);
                    if (y.m) {
                        return true;
                    }
                    F(y, keyEvent);
                    return true;
                }
            } else {
                if ((keyEvent.getFlags() & 128) == 0) {
                    z3 = false;
                }
                this.N = z3;
            }
        } else if (keyCode != 4) {
            if (keyCode == 82) {
                if (this.u != null) {
                    return true;
                }
                C0349s1 y2 = y(0);
                InterfaceC0046c5 interfaceC0046c5 = this.r;
                Context context = this.k;
                if (interfaceC0046c5 != null) {
                    ActionBarOverlayLayout actionBarOverlayLayout = (ActionBarOverlayLayout) interfaceC0046c5;
                    actionBarOverlayLayout.k();
                    Toolbar toolbar = ((C0057cg) actionBarOverlayLayout.e).a;
                    if (toolbar.getVisibility() == 0 && (actionMenuView = toolbar.a) != null && actionMenuView.s && !ViewConfiguration.get(context).hasPermanentMenuKey()) {
                        ActionBarOverlayLayout actionBarOverlayLayout2 = (ActionBarOverlayLayout) this.r;
                        actionBarOverlayLayout2.k();
                        ActionMenuView actionMenuView2 = ((C0057cg) actionBarOverlayLayout2.e).a.a;
                        if (actionMenuView2 != null && (c0041c0 = actionMenuView2.t) != null && c0041c0.i()) {
                            ActionBarOverlayLayout actionBarOverlayLayout3 = (ActionBarOverlayLayout) this.r;
                            actionBarOverlayLayout3.k();
                            ActionMenuView actionMenuView3 = ((C0057cg) actionBarOverlayLayout3.e).a.a;
                            if (actionMenuView3 != null) {
                                C0041c0 c0041c02 = actionMenuView3.t;
                                if (c0041c02 != null) {
                                }
                            }
                            z = false;
                        } else {
                            if (!this.Q && F(y2, keyEvent)) {
                                ActionBarOverlayLayout actionBarOverlayLayout4 = (ActionBarOverlayLayout) this.r;
                                actionBarOverlayLayout4.k();
                                ActionMenuView actionMenuView4 = ((C0057cg) actionBarOverlayLayout4.e).a.a;
                                if (actionMenuView4 != null) {
                                    C0041c0 c0041c03 = actionMenuView4.t;
                                    if (c0041c03 != null) {
                                    }
                                }
                            }
                            z = false;
                        }
                        if (z) {
                            return true;
                        }
                        AudioManager audioManager = (AudioManager) context.getApplicationContext().getSystemService("audio");
                        if (audioManager != null) {
                            audioManager.playSoundEffect(0);
                            return true;
                        }
                        Log.w("AppCompatDelegate", "Couldn't get audio manager");
                        return true;
                    }
                }
                boolean z4 = y2.m;
                if (!z4 && !y2.l) {
                    if (y2.k) {
                        if (y2.o) {
                            y2.k = false;
                            z2 = F(y2, keyEvent);
                        } else {
                            z2 = true;
                        }
                        if (z2) {
                            D(y2, keyEvent);
                            z = true;
                            if (z) {
                            }
                        }
                    }
                    z = false;
                    if (z) {
                    }
                } else {
                    q(y2, true);
                    z = z4;
                    if (z) {
                    }
                }
            }
        } else if (C()) {
            return true;
        }
        return false;
    }

    /* JADX WARN: Code restructure failed: missing block: B:18:0x0048, code lost:
    
        if (r6.i() != false) goto L20;
     */
    @Override // x.InterfaceC0208kb
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void t(MenuC0246mb menuC0246mb) {
        ActionMenuView actionMenuView;
        boolean z;
        C0041c0 c0041c0;
        C0041c0 c0041c02;
        C0041c0 c0041c03;
        InterfaceC0046c5 interfaceC0046c5 = this.r;
        if (interfaceC0046c5 != null) {
            ActionBarOverlayLayout actionBarOverlayLayout = (ActionBarOverlayLayout) interfaceC0046c5;
            actionBarOverlayLayout.k();
            Toolbar toolbar = ((C0057cg) actionBarOverlayLayout.e).a;
            if (toolbar.getVisibility() == 0 && (actionMenuView = toolbar.a) != null && actionMenuView.s) {
                if (ViewConfiguration.get(this.k).hasPermanentMenuKey()) {
                    ActionBarOverlayLayout actionBarOverlayLayout2 = (ActionBarOverlayLayout) this.r;
                    actionBarOverlayLayout2.k();
                    ActionMenuView actionMenuView2 = ((C0057cg) actionBarOverlayLayout2.e).a.a;
                    if (actionMenuView2 != null) {
                        C0041c0 c0041c04 = actionMenuView2.t;
                        if (c0041c04 != null) {
                            if (c0041c04.u == null) {
                            }
                        }
                    }
                }
                Window.Callback callback = this.l.getCallback();
                ActionBarOverlayLayout actionBarOverlayLayout3 = (ActionBarOverlayLayout) this.r;
                actionBarOverlayLayout3.k();
                ActionMenuView actionMenuView3 = ((C0057cg) actionBarOverlayLayout3.e).a.a;
                if (actionMenuView3 != null && (c0041c03 = actionMenuView3.t) != null && c0041c03.i()) {
                    z = true;
                } else {
                    z = false;
                }
                if (z) {
                    ActionBarOverlayLayout actionBarOverlayLayout4 = (ActionBarOverlayLayout) this.r;
                    actionBarOverlayLayout4.k();
                    ActionMenuView actionMenuView4 = ((C0057cg) actionBarOverlayLayout4.e).a.a;
                    if (actionMenuView4 != null && (c0041c02 = actionMenuView4.t) != null) {
                        c0041c02.e();
                    }
                    if (!this.Q) {
                        callback.onPanelClosed(108, y(0).h);
                        return;
                    }
                    return;
                }
                if (callback != null && !this.Q) {
                    if (this.Y && (1 & this.Z) != 0) {
                        View decorView = this.l.getDecorView();
                        RunnableC0122g1 runnableC0122g1 = this.a0;
                        decorView.removeCallbacks(runnableC0122g1);
                        runnableC0122g1.run();
                    }
                    C0349s1 y = y(0);
                    MenuC0246mb menuC0246mb2 = y.h;
                    if (menuC0246mb2 != null && !y.o && callback.onPreparePanel(0, y.g, menuC0246mb2)) {
                        callback.onMenuOpened(108, y.h);
                        ActionBarOverlayLayout actionBarOverlayLayout5 = (ActionBarOverlayLayout) this.r;
                        actionBarOverlayLayout5.k();
                        ActionMenuView actionMenuView5 = ((C0057cg) actionBarOverlayLayout5.e).a.a;
                        if (actionMenuView5 != null && (c0041c0 = actionMenuView5.t) != null) {
                            c0041c0.l();
                            return;
                        }
                        return;
                    }
                    return;
                }
                return;
            }
        }
        C0349s1 y2 = y(0);
        y2.n = true;
        q(y2, false);
        D(y2, null);
    }

    public final void u(int i) {
        C0349s1 y = y(i);
        if (y.h != null) {
            Bundle bundle = new Bundle();
            y.h.t(bundle);
            if (bundle.size() > 0) {
                y.p = bundle;
            }
            y.h.w();
            y.h.clear();
        }
        y.o = true;
        y.n = true;
        if ((i == 108 || i == 0) && this.r != null) {
            C0349s1 y2 = y(0);
            y2.k = false;
            F(y2, null);
        }
    }

    public final void v() {
        ViewGroup viewGroup;
        CharSequence charSequence;
        Context context;
        int i = 1;
        int i2 = 0;
        if (!this.z) {
            int[] iArr = AbstractC0210kd.j;
            Context context2 = this.k;
            TypedArray obtainStyledAttributes = context2.obtainStyledAttributes(iArr);
            if (obtainStyledAttributes.hasValue(117)) {
                if (obtainStyledAttributes.getBoolean(126, false)) {
                    f(1);
                } else if (obtainStyledAttributes.getBoolean(117, false)) {
                    f(108);
                }
                if (obtainStyledAttributes.getBoolean(118, false)) {
                    f(109);
                }
                if (obtainStyledAttributes.getBoolean(119, false)) {
                    f(10);
                }
                this.I = obtainStyledAttributes.getBoolean(0, false);
                obtainStyledAttributes.recycle();
                w();
                this.l.getDecorView();
                LayoutInflater from = LayoutInflater.from(context2);
                if (!this.J) {
                    if (this.I) {
                        viewGroup = (ViewGroup) from.inflate(org.conscrypt.R.layout.abc_dialog_title_material, (ViewGroup) null);
                        this.G = false;
                        this.F = false;
                    } else if (this.F) {
                        TypedValue typedValue = new TypedValue();
                        context2.getTheme().resolveAttribute(org.conscrypt.R.attr.actionBarTheme, typedValue, true);
                        if (typedValue.resourceId != 0) {
                            context = new L4(context2, typedValue.resourceId);
                        } else {
                            context = context2;
                        }
                        viewGroup = (ViewGroup) LayoutInflater.from(context).inflate(org.conscrypt.R.layout.abc_screen_toolbar, (ViewGroup) null);
                        InterfaceC0046c5 interfaceC0046c5 = (InterfaceC0046c5) viewGroup.findViewById(org.conscrypt.R.id.decor_content_parent);
                        this.r = interfaceC0046c5;
                        interfaceC0046c5.setWindowCallback(this.l.getCallback());
                        if (this.G) {
                            ((ActionBarOverlayLayout) this.r).j(109);
                        }
                        if (this.D) {
                            ((ActionBarOverlayLayout) this.r).j(2);
                        }
                        if (this.E) {
                            ((ActionBarOverlayLayout) this.r).j(5);
                        }
                    } else {
                        viewGroup = null;
                    }
                } else {
                    viewGroup = this.H ? (ViewGroup) from.inflate(org.conscrypt.R.layout.abc_screen_simple_overlay_action_mode, (ViewGroup) null) : (ViewGroup) from.inflate(org.conscrypt.R.layout.abc_screen_simple, (ViewGroup) null);
                }
                if (viewGroup != null) {
                    C0142h1 c0142h1 = new C0142h1(this, i2);
                    WeakHashMap weakHashMap = AbstractC0309ph.a;
                    AbstractC0158hh.l(viewGroup, c0142h1);
                    if (this.r == null) {
                        this.B = (TextView) viewGroup.findViewById(org.conscrypt.R.id.title);
                    }
                    boolean z = Ih.a;
                    try {
                        Method method = viewGroup.getClass().getMethod("makeOptionalFitsSystemWindows", null);
                        if (!method.isAccessible()) {
                            method.setAccessible(true);
                        }
                        method.invoke(viewGroup, null);
                    } catch (IllegalAccessException e) {
                        Log.d("ViewUtils", "Could not invoke makeOptionalFitsSystemWindows", e);
                    } catch (NoSuchMethodException unused) {
                        Log.d("ViewUtils", "Could not find method makeOptionalFitsSystemWindows. Oh well...");
                    } catch (InvocationTargetException e2) {
                        Log.d("ViewUtils", "Could not invoke makeOptionalFitsSystemWindows", e2);
                    }
                    ContentFrameLayout contentFrameLayout = (ContentFrameLayout) viewGroup.findViewById(org.conscrypt.R.id.action_bar_activity_content);
                    ViewGroup viewGroup2 = (ViewGroup) this.l.findViewById(R.id.content);
                    if (viewGroup2 != null) {
                        while (viewGroup2.getChildCount() > 0) {
                            View childAt = viewGroup2.getChildAt(0);
                            viewGroup2.removeViewAt(0);
                            contentFrameLayout.addView(childAt);
                        }
                        viewGroup2.setId(-1);
                        contentFrameLayout.setId(R.id.content);
                        if (viewGroup2 instanceof FrameLayout) {
                            ((FrameLayout) viewGroup2).setForeground(null);
                        }
                    }
                    this.l.setContentView(viewGroup);
                    contentFrameLayout.setAttachListener(new C0142h1(this, i));
                    this.A = viewGroup;
                    Object obj = this.j;
                    if (obj instanceof Activity) {
                        charSequence = ((Activity) obj).getTitle();
                    } else {
                        charSequence = this.q;
                    }
                    if (!TextUtils.isEmpty(charSequence)) {
                        InterfaceC0046c5 interfaceC0046c52 = this.r;
                        if (interfaceC0046c52 != null) {
                            interfaceC0046c52.setWindowTitle(charSequence);
                        } else {
                            C0059ci c0059ci = this.o;
                            if (c0059ci != null) {
                                C0057cg c0057cg = (C0057cg) c0059ci.w;
                                if (!c0057cg.g) {
                                    c0057cg.h = charSequence;
                                    if ((c0057cg.b & 8) != 0) {
                                        Toolbar toolbar = c0057cg.a;
                                        toolbar.setTitle(charSequence);
                                        if (c0057cg.g) {
                                            AbstractC0309ph.m(toolbar.getRootView(), charSequence);
                                        }
                                    }
                                }
                            } else {
                                TextView textView = this.B;
                                if (textView != null) {
                                    textView.setText(charSequence);
                                }
                            }
                        }
                    }
                    ContentFrameLayout contentFrameLayout2 = (ContentFrameLayout) this.A.findViewById(R.id.content);
                    View decorView = this.l.getDecorView();
                    contentFrameLayout2.g.set(decorView.getPaddingLeft(), decorView.getPaddingTop(), decorView.getPaddingRight(), decorView.getPaddingBottom());
                    if (contentFrameLayout2.isLaidOut()) {
                        contentFrameLayout2.requestLayout();
                    }
                    TypedArray obtainStyledAttributes2 = context2.obtainStyledAttributes(iArr);
                    obtainStyledAttributes2.getValue(124, contentFrameLayout2.getMinWidthMajor());
                    obtainStyledAttributes2.getValue(125, contentFrameLayout2.getMinWidthMinor());
                    if (obtainStyledAttributes2.hasValue(122)) {
                        obtainStyledAttributes2.getValue(122, contentFrameLayout2.getFixedWidthMajor());
                    }
                    if (obtainStyledAttributes2.hasValue(123)) {
                        obtainStyledAttributes2.getValue(123, contentFrameLayout2.getFixedWidthMinor());
                    }
                    if (obtainStyledAttributes2.hasValue(120)) {
                        obtainStyledAttributes2.getValue(120, contentFrameLayout2.getFixedHeightMajor());
                    }
                    if (obtainStyledAttributes2.hasValue(121)) {
                        obtainStyledAttributes2.getValue(121, contentFrameLayout2.getFixedHeightMinor());
                    }
                    obtainStyledAttributes2.recycle();
                    contentFrameLayout2.requestLayout();
                    this.z = true;
                    C0349s1 y = y(0);
                    if (!this.Q && y.h == null) {
                        A(108);
                        return;
                    }
                    return;
                }
                throw new IllegalArgumentException("AppCompat does not support the current theme features: { windowActionBar: " + this.F + ", windowActionBarOverlay: " + this.G + ", android:windowIsFloating: " + this.I + ", windowActionModeOverlay: " + this.H + ", windowNoTitle: " + this.J + " }");
            }
            obtainStyledAttributes.recycle();
            throw new IllegalStateException("You need to use a Theme.AppCompat theme (or descendant) with this activity.");
        }
    }

    public final void w() {
        if (this.l == null) {
            Object obj = this.j;
            if (obj instanceof Activity) {
                m(((Activity) obj).getWindow());
            }
        }
        if (this.l != null) {
        } else {
            throw new IllegalStateException("We have not been given a Window");
        }
    }

    public final AbstractC0312q1 x(Context context) {
        if (this.W == null) {
            if (C0294p2.g == null) {
                Context applicationContext = context.getApplicationContext();
                C0294p2.g = new C0294p2(applicationContext, (LocationManager) applicationContext.getSystemService("location"));
            }
            this.W = new C0274o1(this, C0294p2.g);
        }
        return this.W;
    }

    /* JADX WARN: Code restructure failed: missing block: B:4:0x0006, code lost:
    
        if (r2 <= r5) goto L6;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r2v3, types: [x.s1, java.lang.Object] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final C0349s1 y(int i) {
        Object[] objArr;
        C0349s1[] c0349s1Arr = this.L;
        if (c0349s1Arr != null) {
            int length = c0349s1Arr.length;
            objArr = c0349s1Arr;
        }
        C0349s1[] c0349s1Arr2 = new C0349s1[i + 1];
        if (c0349s1Arr != null) {
            System.arraycopy(c0349s1Arr, 0, c0349s1Arr2, 0, c0349s1Arr.length);
        }
        this.L = c0349s1Arr2;
        objArr = c0349s1Arr2;
        C0349s1 c0349s1 = objArr[i];
        if (c0349s1 == 0) {
            ?? obj = new Object();
            obj.a = i;
            obj.n = false;
            objArr[i] = obj;
            return obj;
        }
        return c0349s1;
    }

    public final void z() {
        v();
        if (this.F && this.o == null) {
            Object obj = this.j;
            if (obj instanceof Activity) {
                this.o = new C0059ci((Activity) obj, this.G);
            } else if (obj instanceof Dialog) {
                this.o = new C0059ci((Dialog) obj);
            }
            C0059ci c0059ci = this.o;
            if (c0059ci != null) {
                c0059ci.K0(this.b0);
            }
        }
    }

    @Override // android.view.LayoutInflater.Factory
    public final View onCreateView(String str, Context context, AttributeSet attributeSet) {
        return onCreateView(null, str, context, attributeSet);
    }
}
