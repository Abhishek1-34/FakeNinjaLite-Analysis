package x;

/* loaded from: classes.dex */
public abstract class K extends AbstractC0124g3 {
}
