package x;

import org.conscrypt.BuildConfig;

/* loaded from: classes.dex */
public final class F2 {
    public final boolean a;
    public final String b;
    public final String c;
    public final String d;
    public final String e;
    public final boolean f;

    public F2(boolean z, String str, String str2, String str3, String str4, boolean z2) {
        String trim;
        String trim2;
        String trim3;
        this.a = z;
        String str5 = BuildConfig.FLAVOR;
        if (str == null) {
            trim = BuildConfig.FLAVOR;
        } else {
            trim = str.trim();
        }
        this.b = trim;
        if (str2 == null) {
            trim2 = BuildConfig.FLAVOR;
        } else {
            trim2 = str2.trim();
        }
        this.c = trim2;
        if (str3 == null) {
            trim3 = BuildConfig.FLAVOR;
        } else {
            trim3 = str3.trim();
        }
        this.d = trim3;
        this.e = str4 != null ? str4.trim() : str5;
        this.f = z2;
    }
}
