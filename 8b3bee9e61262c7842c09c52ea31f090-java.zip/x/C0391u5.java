package x;

/* renamed from: x.u5, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0391u5 extends AbstractC0312q1 {
}
