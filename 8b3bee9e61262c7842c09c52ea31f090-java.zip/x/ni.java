package x;

/* loaded from: classes.dex */
public final class ni extends mi {
    public ni() {
    }

    @Override // x.oi
    public void c(int i, C9 c9) {
        this.c.setInsets(vi.a(i), c9.d());
    }

    public ni(wi wiVar) {
        super(wiVar);
    }
}
