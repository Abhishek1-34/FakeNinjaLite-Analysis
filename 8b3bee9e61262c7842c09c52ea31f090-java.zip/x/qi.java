package x;

import android.view.WindowInsets;

/* loaded from: classes.dex */
public class qi extends pi {
    public C9 m;

    public qi(wi wiVar, WindowInsets windowInsets) {
        super(wiVar, windowInsets);
        this.m = null;
    }

    @Override // x.ui
    public wi b() {
        return wi.g(null, this.c.consumeStableInsets());
    }

    @Override // x.ui
    public wi c() {
        return wi.g(null, this.c.consumeSystemWindowInsets());
    }

    @Override // x.ui
    public final C9 h() {
        if (this.m == null) {
            WindowInsets windowInsets = this.c;
            this.m = C9.b(windowInsets.getStableInsetLeft(), windowInsets.getStableInsetTop(), windowInsets.getStableInsetRight(), windowInsets.getStableInsetBottom());
        }
        return this.m;
    }

    @Override // x.ui
    public boolean m() {
        return this.c.isConsumed();
    }

    @Override // x.ui
    public void q(C9 c9) {
        this.m = c9;
    }
}
