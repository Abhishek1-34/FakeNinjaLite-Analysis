package x;

import java.util.ArrayList;

/* renamed from: x.r8, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public interface InterfaceC0337r8 {
    boolean a(ArrayList arrayList, ArrayList arrayList2);
}
