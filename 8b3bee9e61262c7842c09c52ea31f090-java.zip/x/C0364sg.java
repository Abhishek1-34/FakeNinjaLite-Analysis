package x;

/* renamed from: x.sg, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0364sg extends AbstractC0289og {
    public final /* synthetic */ int a = 1;
    public AbstractC0270ng b;

    public /* synthetic */ C0364sg() {
    }

    @Override // x.AbstractC0289og, x.InterfaceC0251mg
    public void a(AbstractC0270ng abstractC0270ng) {
        switch (this.a) {
            case 1:
                J2 j2 = (J2) this.b;
                if (!j2.D) {
                    j2.G();
                    j2.D = true;
                    return;
                }
                return;
            default:
                return;
        }
    }

    @Override // x.InterfaceC0251mg
    public final void f(AbstractC0270ng abstractC0270ng) {
        switch (this.a) {
            case 0:
                this.b.z();
                abstractC0270ng.x(this);
                return;
            default:
                J2 j2 = (J2) this.b;
                int i = j2.C - 1;
                j2.C = i;
                if (i == 0) {
                    j2.D = false;
                    j2.m();
                }
                abstractC0270ng.x(this);
                return;
        }
    }

    public C0364sg(AbstractC0270ng abstractC0270ng) {
        this.b = abstractC0270ng;
    }
}
