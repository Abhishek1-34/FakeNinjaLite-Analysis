package x;

/* renamed from: x.n5, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public interface InterfaceC0259n5 extends X9 {
    void a();
}
