package x;

import android.view.WindowInsets;

/* loaded from: classes.dex */
public abstract /* synthetic */ class li {
    public static /* synthetic */ WindowInsets.Builder b() {
        return new WindowInsets.Builder();
    }

    public static /* synthetic */ WindowInsets.Builder c(WindowInsets windowInsets) {
        return new WindowInsets.Builder(windowInsets);
    }
}
