package x;

import android.util.DisplayMetrics;

/* loaded from: classes.dex */
public final class Qe extends C0151ha {
    @Override // x.C0151ha
    public final float d(DisplayMetrics displayMetrics) {
        return 100.0f / displayMetrics.densityDpi;
    }
}
