package x;

/* renamed from: x.l5, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0221l5 {
    public Md a;
    public int b;
    public int c;
    public int d;
    public int e;
}
