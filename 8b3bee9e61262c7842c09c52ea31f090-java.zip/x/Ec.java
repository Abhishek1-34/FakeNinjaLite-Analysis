package x;

/* loaded from: classes.dex */
public final class Ec {
    public final boolean a;

    public Ec(boolean z) {
        this.a = z;
    }
}
