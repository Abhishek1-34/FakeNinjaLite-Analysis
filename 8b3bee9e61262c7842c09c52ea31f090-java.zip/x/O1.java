package x;

import android.content.DialogInterface;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.widget.ListAdapter;
import androidx.appcompat.app.AlertController$RecycleListView;

/* loaded from: classes.dex */
public final class O1 implements U1, DialogInterface.OnClickListener {
    public G0 a;
    public P1 b;
    public CharSequence c;
    public final /* synthetic */ V1 d;

    public O1(V1 v1) {
        this.d = v1;
    }

    @Override // x.U1
    public final boolean a() {
        G0 g0 = this.a;
        if (g0 != null) {
            return g0.isShowing();
        }
        return false;
    }

    @Override // x.U1
    public final CharSequence b() {
        return this.c;
    }

    @Override // x.U1
    public final void c(int i) {
        Log.e("AppCompatSpinner", "Cannot set horizontal offset for MODE_DIALOG, ignoring");
    }

    @Override // x.U1
    public final int d() {
        return 0;
    }

    @Override // x.U1
    public final void dismiss() {
        G0 g0 = this.a;
        if (g0 != null) {
            g0.dismiss();
            this.a = null;
        }
    }

    @Override // x.U1
    public final void f(int i, int i2) {
        if (this.b == null) {
            return;
        }
        V1 v1 = this.d;
        F0 f0 = new F0(v1.getPopupContext());
        CharSequence charSequence = this.c;
        B0 b0 = (B0) f0.b;
        if (charSequence != null) {
            b0.d = charSequence;
        }
        P1 p1 = this.b;
        int selectedItemPosition = v1.getSelectedItemPosition();
        b0.g = p1;
        b0.h = this;
        b0.j = selectedItemPosition;
        b0.i = true;
        G0 a = f0.a();
        this.a = a;
        AlertController$RecycleListView alertController$RecycleListView = a.f.e;
        alertController$RecycleListView.setTextDirection(i);
        alertController$RecycleListView.setTextAlignment(i2);
        this.a.show();
    }

    @Override // x.U1
    public final void h(CharSequence charSequence) {
        this.c = charSequence;
    }

    @Override // x.U1
    public final int j() {
        return 0;
    }

    @Override // x.U1
    public final void k(Drawable drawable) {
        Log.e("AppCompatSpinner", "Cannot set popup background for MODE_DIALOG, ignoring");
    }

    @Override // x.U1
    public final void l(int i) {
        Log.e("AppCompatSpinner", "Cannot set vertical offset for MODE_DIALOG, ignoring");
    }

    @Override // x.U1
    public final Drawable m() {
        return null;
    }

    @Override // x.U1
    public final void o(ListAdapter listAdapter) {
        this.b = (P1) listAdapter;
    }

    @Override // android.content.DialogInterface.OnClickListener
    public final void onClick(DialogInterface dialogInterface, int i) {
        V1 v1 = this.d;
        v1.setSelection(i);
        if (v1.getOnItemClickListener() != null) {
            v1.performItemClick(null, i, this.b.getItemId(i));
        }
        dismiss();
    }

    @Override // x.U1
    public final void p(int i) {
        Log.e("AppCompatSpinner", "Cannot set horizontal (original) offset for MODE_DIALOG, ignoring");
    }
}
