package x;

import android.os.SystemClock;
import java.io.ByteArrayOutputStream;
import java.util.Arrays;
import java.util.concurrent.ConcurrentHashMap;

/* loaded from: classes.dex */
public abstract class Oc {
    public static final ConcurrentHashMap a = new ConcurrentHashMap();
    public static volatile long b;
    public static volatile boolean c;
    public static volatile long d;
    public static volatile long e;

    public static C0353s5 a(String str, byte[] bArr) {
        C0070d9 c2;
        C0110f9 c0110f9 = C0110f9.k;
        Gg gg = (Gg) c0110f9.a.get(str);
        byte[] bArr2 = null;
        if (gg != null && (c2 = gg.c(bArr, bArr.length)) != null) {
            int i = c2.b;
            int i2 = c2.c;
            int i3 = i + i2;
            if (i3 <= bArr.length) {
                byte[] copyOfRange = Arrays.copyOfRange(bArr, i2, i3);
                int i4 = c2.d;
                if ((i4 & 2) == 0 && (copyOfRange == null || copyOfRange.length < 2 || (copyOfRange[0] & 255) != 31 || (copyOfRange[1] & 255) != 139)) {
                    if ((i4 & 1) != 0) {
                        byte[] b2 = c0110f9.b(str);
                        copyOfRange = AbstractC0112fb.k(copyOfRange, b2);
                        if (copyOfRange == null) {
                            return null;
                        }
                        bArr2 = b2;
                    }
                    return new C0353s5(gg, c2, copyOfRange, bArr2);
                }
            }
        }
        return null;
    }

    public static void b(Lc lc, int i, Mc mc) {
        Mc mc2 = lc.d;
        if (mc2 != null && i != 0 && i < 129) {
            long m = m(mc2.a);
            long m2 = m(mc2.b);
            long m3 = m(mc2.c);
            long m4 = m(mc.a);
            long m5 = m(mc.b);
            long m6 = m(mc.c);
            if (Math.abs(m - m4) <= 999 && Math.abs(m2 - m5) <= 999 && Math.abs(m3 - m6) <= 999 && lc.c != i) {
                lc.c = i;
                Yb.h("Congelamento: ID local curto=" + i);
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:35:0x00f1  */
    /* JADX WARN: Removed duplicated region for block: B:42:0x0110 A[Catch: all -> 0x0086, TryCatch #0 {all -> 0x0086, blocks: (B:22:0x0068, B:24:0x0081, B:27:0x009f, B:29:0x00a3, B:31:0x00a7, B:33:0x00af, B:37:0x00fc, B:40:0x010c, B:42:0x0110, B:44:0x0178, B:49:0x0188, B:50:0x01ab, B:53:0x011d, B:55:0x0126, B:56:0x012b, B:58:0x0139, B:59:0x00f2, B:61:0x0089, B:63:0x0091, B:65:0x0099, B:66:0x009d), top: B:21:0x0068 }] */
    /* JADX WARN: Removed duplicated region for block: B:46:0x0182 A[ADDED_TO_REGION] */
    /* JADX WARN: Removed duplicated region for block: B:55:0x0126 A[Catch: all -> 0x0086, TryCatch #0 {all -> 0x0086, blocks: (B:22:0x0068, B:24:0x0081, B:27:0x009f, B:29:0x00a3, B:31:0x00a7, B:33:0x00af, B:37:0x00fc, B:40:0x010c, B:42:0x0110, B:44:0x0178, B:49:0x0188, B:50:0x01ab, B:53:0x011d, B:55:0x0126, B:56:0x012b, B:58:0x0139, B:59:0x00f2, B:61:0x0089, B:63:0x0091, B:65:0x0099, B:66:0x009d), top: B:21:0x0068 }] */
    /* JADX WARN: Removed duplicated region for block: B:58:0x0139 A[Catch: all -> 0x0086, TryCatch #0 {all -> 0x0086, blocks: (B:22:0x0068, B:24:0x0081, B:27:0x009f, B:29:0x00a3, B:31:0x00a7, B:33:0x00af, B:37:0x00fc, B:40:0x010c, B:42:0x0110, B:44:0x0178, B:49:0x0188, B:50:0x01ab, B:53:0x011d, B:55:0x0126, B:56:0x012b, B:58:0x0139, B:59:0x00f2, B:61:0x0089, B:63:0x0091, B:65:0x0099, B:66:0x009d), top: B:21:0x0068 }] */
    /* JADX WARN: Removed duplicated region for block: B:59:0x00f2 A[Catch: all -> 0x0086, TryCatch #0 {all -> 0x0086, blocks: (B:22:0x0068, B:24:0x0081, B:27:0x009f, B:29:0x00a3, B:31:0x00a7, B:33:0x00af, B:37:0x00fc, B:40:0x010c, B:42:0x0110, B:44:0x0178, B:49:0x0188, B:50:0x01ab, B:53:0x011d, B:55:0x0126, B:56:0x012b, B:58:0x0139, B:59:0x00f2, B:61:0x0089, B:63:0x0091, B:65:0x0099, B:66:0x009d), top: B:21:0x0068 }] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static byte[] c(String str, byte[] bArr, boolean z) {
        C0353s5 a2;
        C0108f7 f;
        C0108f7 f2;
        C0108f7 f3;
        Mc mc;
        byte[] bArr2;
        long uptimeMillis;
        int i;
        Mc mc2;
        byte[] byteArray;
        if (!z || bArr.length < 8 || (a2 = a(str, bArr)) == null || ((C0070d9) a2.b).a != 2001) {
            return bArr;
        }
        C0108f7 f4 = f((byte[]) a2.c, 0);
        if (f4 == null) {
            f = null;
        } else {
            f = f((byte[]) a2.c, f4.b);
        }
        if (f == null) {
            f2 = null;
        } else {
            f2 = f((byte[]) a2.c, f.b);
        }
        if (f2 == null) {
            f3 = null;
        } else {
            f3 = f((byte[]) a2.c, f2.b);
        }
        if (f3 == null) {
            return bArr;
        }
        Lc lc = (Lc) a.computeIfAbsent(str, new C0090e9(2));
        synchronized (lc) {
            try {
                long j = f4.a;
                lc.d = new Mc(f.a, f2.a, f3.a);
                if (!c) {
                    if (lc.e != null) {
                    }
                    if (c && (mc2 = lc.e) != null && !mc2.equals(lc.d)) {
                        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream(((byte[]) a2.c).length);
                        byteArrayOutputStream.write((byte[]) a2.c, 0, f4.b);
                        l(byteArrayOutputStream, lc.e.a);
                        l(byteArrayOutputStream, lc.e.b);
                        l(byteArrayOutputStream, lc.e.c);
                        byte[] bArr3 = (byte[]) a2.c;
                        int i2 = f3.b;
                        byteArrayOutputStream.write(bArr3, i2, bArr3.length - i2);
                        byteArray = byteArrayOutputStream.toByteArray();
                        if ((((C0070d9) a2.b).d & 1) == 0) {
                            byteArray = AbstractC0112fb.l(byteArray, (byte[]) a2.d);
                        }
                        if (byteArray != null && (bArr2 = g((Gg) a2.a, bArr, (C0070d9) a2.b, byteArray)) != null) {
                            if (!c || SystemClock.uptimeMillis() - e < 5000) {
                                lc.i++;
                                if (bArr2 != bArr) {
                                    lc.j++;
                                }
                                uptimeMillis = SystemClock.uptimeMillis();
                                if (uptimeMillis - lc.g >= 1000) {
                                    lc.g = uptimeMillis;
                                    Yb.h("Ghost C2S ativo=" + c + " pacotes=" + lc.i + " alterados=" + lc.j + " deltaXYZ(raw)=" + e(lc.e, lc.d) + " " + str);
                                }
                            }
                            i = (int) (f4.a & 255);
                            if (lc.c < 0 && i > 0 && i < 129) {
                                lc.c = i;
                                Yb.h("Congelamento C2S: ID local curto=" + i + " ID do jogador=" + f4.a + " " + str);
                            }
                        }
                    }
                    bArr2 = bArr;
                    if (!c) {
                    }
                    lc.i++;
                    if (bArr2 != bArr) {
                    }
                    uptimeMillis = SystemClock.uptimeMillis();
                    if (uptimeMillis - lc.g >= 1000) {
                    }
                    i = (int) (f4.a & 255);
                    if (lc.c < 0) {
                        lc.c = i;
                        Yb.h("Congelamento C2S: ID local curto=" + i + " ID do jogador=" + f4.a + " " + str);
                    }
                }
                if (lc.f != d) {
                    lc.f = d;
                    if (c) {
                        mc = lc.d;
                    } else {
                        mc = null;
                    }
                    lc.e = mc;
                }
                if (c) {
                    ByteArrayOutputStream byteArrayOutputStream2 = new ByteArrayOutputStream(((byte[]) a2.c).length);
                    byteArrayOutputStream2.write((byte[]) a2.c, 0, f4.b);
                    l(byteArrayOutputStream2, lc.e.a);
                    l(byteArrayOutputStream2, lc.e.b);
                    l(byteArrayOutputStream2, lc.e.c);
                    byte[] bArr32 = (byte[]) a2.c;
                    int i22 = f3.b;
                    byteArrayOutputStream2.write(bArr32, i22, bArr32.length - i22);
                    byteArray = byteArrayOutputStream2.toByteArray();
                    if ((((C0070d9) a2.b).d & 1) == 0) {
                    }
                    if (byteArray != null) {
                        if (!c) {
                        }
                        lc.i++;
                        if (bArr2 != bArr) {
                        }
                        uptimeMillis = SystemClock.uptimeMillis();
                        if (uptimeMillis - lc.g >= 1000) {
                        }
                        i = (int) (f4.a & 255);
                        if (lc.c < 0) {
                        }
                    }
                }
                bArr2 = bArr;
                if (!c) {
                }
                lc.i++;
                if (bArr2 != bArr) {
                }
                uptimeMillis = SystemClock.uptimeMillis();
                if (uptimeMillis - lc.g >= 1000) {
                }
                i = (int) (f4.a & 255);
                if (lc.c < 0) {
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        return bArr2;
    }

    /* JADX WARN: Type inference failed for: r12v1, types: [java.lang.Object, x.g9] */
    public static C0130g9 d(byte[] bArr, int i, int i2) {
        C0108f7[] c0108f7Arr = new C0108f7[6];
        int i3 = i;
        int i4 = 0;
        while (i4 < 6) {
            C0108f7 f = f(bArr, i3);
            c0108f7Arr[i4] = f;
            if (f == null) {
                return null;
            }
            i4++;
            i3 = f.b;
        }
        C0108f7 c0108f7 = c0108f7Arr[2];
        int i5 = c0108f7.b;
        Mc mc = new Mc(c0108f7Arr[0].a, c0108f7Arr[1].a, c0108f7.a);
        ?? obj = new Object();
        obj.a = i;
        obj.b = i5;
        obj.c = i3;
        obj.d = mc;
        return obj;
    }

    public static String e(Mc mc, Mc mc2) {
        if (mc != null && mc2 != null) {
            return (mc2.a - mc.a) + "," + (mc2.b - mc.b) + "," + (mc2.c - mc.c);
        }
        return "sem dado";
    }

    public static C0108f7 f(byte[] bArr, int i) {
        if (i >= 0 && i < bArr.length) {
            long j = 0;
            int i2 = 0;
            while (i < bArr.length && i2 <= 63) {
                int i3 = i + 1;
                j |= (r9 & Byte.MAX_VALUE) << i2;
                if ((bArr[i] & 255) < 128) {
                    return new C0108f7(j, i3);
                }
                i2 += 7;
                i = i3;
            }
        }
        return null;
    }

    public static byte[] g(Gg gg, byte[] bArr, C0070d9 c0070d9, byte[] bArr2) {
        int[] copyOf;
        int i;
        int i2;
        int[] iArr = gg.d;
        if (iArr == null) {
            copyOf = null;
        } else {
            copyOf = Arrays.copyOf(iArr, iArr.length);
        }
        if (copyOf != null) {
            int length = copyOf.length;
            int i3 = c0070d9.c;
            if (i3 == 8) {
                i = 4;
            } else {
                i = 5;
            }
            if (length == i) {
                int length2 = bArr2.length + i3;
                byte[] bArr3 = new byte[length2];
                int i4 = 0;
                System.arraycopy(bArr, 0, bArr3, 0, i3);
                int length3 = copyOf.length;
                int i5 = 2;
                int i6 = 0;
                boolean z = false;
                int i7 = 2;
                while (i6 < length3) {
                    int i8 = copyOf[i6];
                    if (i8 != 0) {
                        if (i8 != 1 && i8 != i5) {
                            if (i8 != 3) {
                                if (i8 != 4) {
                                    return null;
                                }
                                int i9 = i7 + 1;
                                int length4 = bArr2.length & 255;
                                int i10 = c0070d9.e;
                                bArr3[i7] = (byte) (length4 ^ i10);
                                i7 += 2;
                                bArr3[i9] = (byte) (((bArr2.length >>> 8) & 255) ^ i10);
                                z = true;
                            }
                        } else {
                            i7 += 2;
                        }
                        i6++;
                        i5 = 2;
                    }
                    i7++;
                    i6++;
                    i5 = 2;
                }
                if (z && i7 == (i2 = c0070d9.c)) {
                    System.arraycopy(bArr2, 0, bArr3, i2, bArr2.length);
                    byte[] bArr4 = Jb.c;
                    for (int i11 = 2; i11 < length2; i11++) {
                        i4 = bArr4[((i4 << 1) ^ (bArr3[i11] & 255)) & 255] & 255;
                    }
                    bArr3[1] = (byte) i4;
                    return bArr3;
                }
            }
        }
        return null;
    }

    public static Nc h(byte[] bArr, Lc lc, boolean z) {
        C0108f7 f;
        int i;
        C0130g9 d2;
        int i2;
        C0108f7 f2;
        Mc mc;
        boolean z2 = false;
        C0108f7 f3 = f(bArr, 0);
        if (f3 == null) {
            f = null;
        } else {
            f = f(bArr, f3.b);
        }
        if (f == null) {
            return null;
        }
        long m = m(f.a);
        if (m >= 0 && m <= 128) {
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream(bArr.length + 32);
            int i3 = f.b;
            byteArrayOutputStream.write(bArr, 0, i3);
            int i4 = 0;
            int i5 = 0;
            while (true) {
                int i6 = (int) m;
                if (i4 < i6) {
                    if (i3 >= bArr.length || (d2 = d(bArr, i3 + 1, (i = bArr[i3] & 255))) == null || (i2 = d2.c + 5) > bArr.length || (f2 = f(bArr, i2)) == null) {
                        break;
                    }
                    int length = bArr.length;
                    int i7 = f2.b;
                    if (i7 >= length) {
                        break;
                    }
                    d2.c = i7 + 1;
                    Mc mc2 = (Mc) d2.d;
                    b(lc, i, mc2);
                    lc.a.put(Integer.valueOf(i), mc2);
                    if (z && i != lc.c) {
                        mc = (Mc) lc.b.get(Integer.valueOf(i));
                    } else {
                        mc = null;
                    }
                    if (mc != null && !mc.equals(mc2)) {
                        byteArrayOutputStream.write(i);
                        l(byteArrayOutputStream, mc.a);
                        l(byteArrayOutputStream, mc.b);
                        l(byteArrayOutputStream, mc.c);
                        int i8 = d2.c;
                        int i9 = d2.b;
                        byteArrayOutputStream.write(bArr, i9, i8 - i9);
                        i5++;
                    } else {
                        byteArrayOutputStream.write(bArr, i3, d2.c - i3);
                    }
                    i3 = d2.c;
                    i4++;
                } else {
                    C0108f7 f4 = f(bArr, i3);
                    if (f4 != null && f4.b == bArr.length) {
                        byteArrayOutputStream.write(bArr, i3, bArr.length - i3);
                        byte[] byteArray = byteArrayOutputStream.toByteArray();
                        if (i5 > 0) {
                            z2 = true;
                        }
                        return new Nc(i5, i6, z2, byteArray);
                    }
                }
            }
        }
        return null;
    }

    public static Nc i(byte[] bArr, Lc lc, boolean z) {
        int i;
        C0130g9 d2;
        Mc mc = null;
        if (bArr.length < 4 || (bArr[0] & 255) != 0 || (bArr[1] & 255) != 2 || (d2 = d(bArr, 3, (i = bArr[2] & 255))) == null) {
            return null;
        }
        Mc mc2 = (Mc) d2.d;
        b(lc, i, mc2);
        lc.a.put(Integer.valueOf(i), mc2);
        if (z && i != lc.c) {
            mc = (Mc) lc.b.get(Integer.valueOf(i));
        }
        if (mc != null && !mc.equals(mc2)) {
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream(bArr.length + 16);
            byteArrayOutputStream.write(bArr, 0, d2.a);
            l(byteArrayOutputStream, mc.a);
            l(byteArrayOutputStream, mc.b);
            l(byteArrayOutputStream, mc.c);
            int length = bArr.length;
            int i2 = d2.b;
            byteArrayOutputStream.write(bArr, i2, length - i2);
            return new Nc(1, 1, true, byteArrayOutputStream.toByteArray());
        }
        return new Nc(0, 1, false, bArr);
    }

    public static void j(boolean z) {
        if (c == z) {
            return;
        }
        c = z;
        d++;
        e = SystemClock.uptimeMillis();
        Yb.h("Ghost experimental=" + z);
    }

    public static byte[] k(String str, byte[] bArr) {
        C0353s5 a2;
        int i;
        boolean z;
        Nc h;
        Nc nc;
        byte[] g;
        if (bArr == null || bArr.length < 8 || (a2 = a(str, bArr)) == null || ((i = ((C0070d9) a2.b).a) != 2001 && i != 2012)) {
            return bArr;
        }
        Lc lc = (Lc) a.computeIfAbsent(str, new C0090e9(3));
        ConcurrentHashMap concurrentHashMap = E8.a;
        long elapsedRealtime = SystemClock.elapsedRealtime();
        if (!E8.b && (!E8.d || ((!E8.c || !E8.a(elapsedRealtime)) && (!E8.e || !E8.d(elapsedRealtime))))) {
            z = false;
        } else {
            z = true;
        }
        synchronized (lc) {
            try {
                if (z != lc.k) {
                    lc.k = z;
                    lc.b.clear();
                    if (z && !lc.a.isEmpty()) {
                        lc.b.putAll(lc.a);
                        Yb.h("Captura de congelamento S2C: entidades=" + lc.b.size() + " " + str);
                    }
                } else if (z && lc.b.isEmpty() && !lc.a.isEmpty()) {
                    lc.b.putAll(lc.a);
                    Yb.h("Captura tardia de congelamento S2C: entidades=" + lc.b.size() + " " + str);
                }
                byte[] bArr2 = (byte[]) a2.c;
                if (bArr2.length >= 3 && (bArr2[0] & 255) == 0 && (bArr2[1] & 255) == 2) {
                    h = i(bArr2, lc, z);
                } else {
                    h = h(bArr2, lc, z);
                }
                Nc nc2 = h;
                if (nc2 != null) {
                    nc = nc2;
                    E8.b(str, ((C0070d9) a2.b).a, nc2.d, lc.a.size(), lc.b.size(), z);
                } else {
                    nc = nc2;
                }
                long uptimeMillis = SystemClock.uptimeMillis();
                if ((c || uptimeMillis - e < 5000) && uptimeMillis - lc.h >= 1000) {
                    lc.h = uptimeMillis;
                    Yb.h("Ghost S2C cmd=" + ((C0070d9) a2.b).a + " alvoLocal=" + lc.c + " deltaServidorLocal(raw)=" + e((Mc) lc.a.get(Integer.valueOf(lc.c)), lc.d) + " entidades=" + lc.a.size() + " " + str);
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        if (nc == null) {
            if (z) {
                int i2 = ((C0070d9) a2.b).a;
                byte[] bArr3 = (byte[]) a2.c;
                long uptimeMillis2 = SystemClock.uptimeMillis();
                if (uptimeMillis2 - b >= 1000) {
                    b = uptimeMillis2;
                    StringBuilder sb = new StringBuilder("Falha ao analisar congelamento S2C cmd=");
                    sb.append(i2);
                    sb.append(" corpo=");
                    sb.append(bArr3.length);
                    sb.append(" ");
                    sb.append(str);
                    sb.append(" hex=");
                    int min = Math.min(bArr3.length, 96);
                    StringBuilder sb2 = new StringBuilder((2 * min) + 3);
                    for (int i3 = 0; i3 < min; i3++) {
                        int i4 = bArr3[i3] & 255;
                        if (i4 < 16) {
                            sb2.append('0');
                        }
                        sb2.append(Integer.toHexString(i4));
                    }
                    if (bArr3.length > min) {
                        sb2.append("...");
                    }
                    sb.append(sb2.toString());
                    Yb.h(sb.toString());
                }
            }
            return bArr;
        }
        if (!nc.b) {
            return bArr;
        }
        byte[] bArr4 = nc.a;
        if ((((C0070d9) a2.b).d & 1) != 0) {
            bArr4 = AbstractC0112fb.l(bArr4, (byte[]) a2.d);
        }
        if (bArr4 == null || (g = g((Gg) a2.a, bArr, (C0070d9) a2.b, bArr4)) == null) {
            return bArr;
        }
        int i5 = ((C0070d9) a2.b).a;
        int i6 = nc.c;
        if (i6 > 0) {
            long elapsedRealtime2 = SystemClock.elapsedRealtime();
            long j = E8.n + 1;
            E8.n = j;
            if (elapsedRealtime2 - E8.j >= 1000) {
                E8.j = elapsedRealtime2;
                Yb.h("Posição congelada reescrita S2C cmd=" + i5 + " entidades=" + i6 + " total=" + j + " " + str);
            }
        }
        return g;
    }

    public static void l(ByteArrayOutputStream byteArrayOutputStream, long j) {
        while (((-128) & j) != 0) {
            byteArrayOutputStream.write((int) ((127 & j) | 128));
            j >>>= 7;
        }
        byteArrayOutputStream.write((int) j);
    }

    public static long m(long j) {
        return (j >>> 1) ^ (-(1 & j));
    }
}
