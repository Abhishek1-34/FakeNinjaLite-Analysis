package x;

/* loaded from: classes.dex */
public final class Kc extends Jc {
    public final Object c;

    public Kc() {
        super(12);
        this.c = new Object();
    }

    @Override // x.Jc
    public final Object a() {
        Object a;
        synchronized (this.c) {
            a = super.a();
        }
        return a;
    }

    @Override // x.Jc
    public final boolean c(Object obj) {
        boolean c;
        synchronized (this.c) {
            c = super.c(obj);
        }
        return c;
    }
}
