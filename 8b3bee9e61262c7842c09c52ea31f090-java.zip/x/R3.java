package x;

import android.text.Editable;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.widget.EditText;

/* loaded from: classes.dex */
public final /* synthetic */ class R3 implements View.OnClickListener {
    public final /* synthetic */ int a;
    public final /* synthetic */ Object b;

    public /* synthetic */ R3(int i, Object obj) {
        this.a = i;
        this.b = obj;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        switch (this.a) {
            case 0:
                V3 v3 = (V3) this.b;
                EditText editText = v3.i;
                if (editText != null) {
                    Editable text = editText.getText();
                    if (text != null) {
                        text.clear();
                    }
                    v3.q();
                    return;
                }
                return;
            case 1:
                ((C0047c6) this.b).u();
                return;
            case 2:
                ((C0032bb) this.b).I();
                throw null;
            default:
                Bc bc = (Bc) this.b;
                EditText editText2 = bc.f;
                if (editText2 != null) {
                    int selectionEnd = editText2.getSelectionEnd();
                    EditText editText3 = bc.f;
                    if (editText3 != null && (editText3.getTransformationMethod() instanceof PasswordTransformationMethod)) {
                        bc.f.setTransformationMethod(null);
                    } else {
                        bc.f.setTransformationMethod(PasswordTransformationMethod.getInstance());
                    }
                    if (selectionEnd >= 0) {
                        bc.f.setSelection(selectionEnd);
                    }
                    bc.q();
                    return;
                }
                return;
        }
    }
}
