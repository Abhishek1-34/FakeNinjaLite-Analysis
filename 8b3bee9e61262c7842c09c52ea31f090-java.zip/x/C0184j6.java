package x;

/* renamed from: x.j6, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0184j6 {
    public final C0260n6 a;
    public volatile C0294p2 b;
    public volatile C0353s5 c;

    public C0184j6(C0260n6 c0260n6) {
        this.a = c0260n6;
    }
}
