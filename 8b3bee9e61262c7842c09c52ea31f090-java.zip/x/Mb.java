package x;

import androidx.constraintlayout.widget.ConstraintLayout;

/* loaded from: classes.dex */
public abstract class Mb extends ConstraintLayout implements Wb {
    public static final /* synthetic */ int q = 0;
}
