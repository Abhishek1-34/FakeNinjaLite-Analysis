package x;

/* renamed from: x.g6, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract /* synthetic */ class AbstractC0127g6 {
}
