package x;

import java.util.ArrayList;

/* loaded from: classes.dex */
public final class Ze implements Runnable {
    public final /* synthetic */ int a;
    public final /* synthetic */ C0016af b;
    public final /* synthetic */ C0410v5 c;

    public /* synthetic */ Ze(C0410v5 c0410v5, C0016af c0016af, int i) {
        this.a = i;
        this.c = c0410v5;
        this.b = c0016af;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.a) {
            case 0:
                ArrayList arrayList = this.c.b;
                C0016af c0016af = this.b;
                if (arrayList.contains(c0016af)) {
                    Ue.a(c0016af.c.E, c0016af.a);
                    return;
                }
                return;
            default:
                C0410v5 c0410v5 = this.c;
                ArrayList arrayList2 = c0410v5.b;
                C0016af c0016af2 = this.b;
                arrayList2.remove(c0016af2);
                c0410v5.c.remove(c0016af2);
                return;
        }
    }
}
