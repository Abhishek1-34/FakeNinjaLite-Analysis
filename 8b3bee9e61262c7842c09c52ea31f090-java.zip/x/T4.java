package x;

import android.graphics.RectF;

/* loaded from: classes.dex */
public interface T4 {
    float a(RectF rectF);
}
