package x;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.util.Log;

/* renamed from: x.w1, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0425w1 {
    public static final PorterDuff.Mode b = PorterDuff.Mode.SRC_IN;
    public static C0425w1 c;
    public C0015ae a;

    public static synchronized C0425w1 a() {
        C0425w1 c0425w1;
        synchronized (C0425w1.class) {
            try {
                if (c == null) {
                    d();
                }
                c0425w1 = c;
            } catch (Throwable th) {
                throw th;
            }
        }
        return c0425w1;
    }

    public static synchronized PorterDuffColorFilter c(int i, PorterDuff.Mode mode) {
        PorterDuffColorFilter e;
        synchronized (C0425w1.class) {
            e = C0015ae.e(i, mode);
        }
        return e;
    }

    /* JADX WARN: Type inference failed for: r1v2, types: [x.w1, java.lang.Object] */
    public static synchronized void d() {
        synchronized (C0425w1.class) {
            if (c == null) {
                ?? obj = new Object();
                c = obj;
                obj.a = C0015ae.b();
                C0015ae c0015ae = c.a;
                C0406v1 c0406v1 = new C0406v1();
                synchronized (c0015ae) {
                    c0015ae.e = c0406v1;
                }
            }
        }
    }

    public static void e(Drawable drawable, C0014ad c0014ad, int[] iArr) {
        ColorStateList colorStateList;
        PorterDuff.Mode mode;
        PorterDuff.Mode mode2 = C0015ae.f;
        int[] state = drawable.getState();
        if (drawable.mutate() == drawable) {
            if ((drawable instanceof LayerDrawable) && drawable.isStateful()) {
                drawable.setState(new int[0]);
                drawable.setState(state);
            }
            boolean z = c0014ad.b;
            if (!z && !c0014ad.a) {
                drawable.clearColorFilter();
                return;
            }
            PorterDuffColorFilter porterDuffColorFilter = null;
            if (z) {
                colorStateList = (ColorStateList) c0014ad.c;
            } else {
                colorStateList = null;
            }
            if (c0014ad.a) {
                mode = (PorterDuff.Mode) c0014ad.d;
            } else {
                mode = C0015ae.f;
            }
            if (colorStateList != null && mode != null) {
                porterDuffColorFilter = C0015ae.e(colorStateList.getColorForState(iArr, 0), mode);
            }
            drawable.setColorFilter(porterDuffColorFilter);
            return;
        }
        Log.d("ResourceManagerInternal", "Mutated drawable is not the same instance as the input.");
    }

    public final synchronized Drawable b(Context context, int i) {
        return this.a.c(context, i);
    }
}
