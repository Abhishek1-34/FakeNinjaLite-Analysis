package x;

import java.util.ArrayList;

/* loaded from: classes.dex */
public final class P7 implements D4 {
    public final /* synthetic */ int a;
    public final /* synthetic */ Object b;

    public /* synthetic */ P7(int i, Object obj) {
        this.a = i;
        this.b = obj;
    }

    @Override // x.D4
    public final void a(Object obj) {
        switch (this.a) {
            case 0:
                Q7 q7 = (Q7) obj;
                if (q7 == null) {
                    q7 = new Q7(-3);
                }
                ((F1) this.b).H(q7);
                return;
            default:
                Q7 q72 = (Q7) obj;
                synchronized (R7.c) {
                    try {
                        Pe pe = R7.d;
                        ArrayList arrayList = (ArrayList) pe.get((String) this.b);
                        if (arrayList != null) {
                            pe.remove((String) this.b);
                            for (int i = 0; i < arrayList.size(); i++) {
                                ((D4) arrayList.get(i)).a(q72);
                            }
                            return;
                        }
                        return;
                    } finally {
                    }
                }
        }
    }
}
