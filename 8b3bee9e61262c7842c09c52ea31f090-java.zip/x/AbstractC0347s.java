package x;

import android.app.NotificationChannel;

/* renamed from: x.s, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract /* synthetic */ class AbstractC0347s {
    public static /* synthetic */ NotificationChannel b(String str) {
        return new NotificationChannel("projectx_vpn_proxy", str, 2);
    }

    public static /* synthetic */ void e() {
    }
}
