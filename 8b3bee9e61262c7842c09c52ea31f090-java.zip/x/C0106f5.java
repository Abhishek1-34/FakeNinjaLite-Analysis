package x;

import android.text.TextPaint;

/* renamed from: x.f5, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0106f5 {
    public static final ThreadLocal b = new ThreadLocal();
    public final TextPaint a;

    public C0106f5() {
        TextPaint textPaint = new TextPaint();
        this.a = textPaint;
        textPaint.setTextSize(10.0f);
    }
}
