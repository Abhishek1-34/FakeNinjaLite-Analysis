package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.util.SparseIntArray;
import android.view.View;
import android.view.ViewGroup;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import org.conscrypt.FileClientSessionCache;
import org.conscrypt.ct.CTConstants;
import org.xmlpull.v1.XmlPullParserException;
import x.A4;
import x.AbstractC0094ed;
import x.AbstractC0277o4;
import x.AbstractC0296p4;
import x.AbstractC0338r9;
import x.B4;
import x.C0012ab;
import x.C0038bh;
import x.C0170ia;
import x.C0244m9;
import x.C0263n9;
import x.C0282o9;
import x.C0294p2;
import x.C0315q4;
import x.C0333r4;
import x.C0352s4;
import x.C0357s9;
import x.C0465y3;
import x.C0467y5;
import x.C0485z4;
import x.C4;
import x.E9;
import x.F1;
import x.G7;
import x.Le;
import x.P2;
import x.Wh;

/* loaded from: classes.dex */
public class ConstraintLayout extends ViewGroup {
    public static Le p;
    public final SparseArray a;
    public final ArrayList b;
    public final B4 c;
    public int d;
    public int e;
    public int f;
    public int g;
    public boolean h;
    public int i;
    public C0485z4 j;
    public F1 k;
    public int l;
    public HashMap m;
    public final SparseArray n;
    public final C0333r4 o;

    public ConstraintLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.a = new SparseArray();
        this.b = new ArrayList(4);
        this.c = new B4();
        this.d = 0;
        this.e = 0;
        this.f = Integer.MAX_VALUE;
        this.g = Integer.MAX_VALUE;
        this.h = true;
        this.i = 257;
        this.j = null;
        this.k = null;
        this.l = -1;
        this.m = new HashMap();
        this.n = new SparseArray();
        this.o = new C0333r4(this, this);
        i(attributeSet, 0);
    }

    /* JADX WARN: Type inference failed for: r0v0, types: [android.view.ViewGroup$MarginLayoutParams, x.q4] */
    public static C0315q4 g() {
        ?? marginLayoutParams = new ViewGroup.MarginLayoutParams(-2, -2);
        marginLayoutParams.a = -1;
        marginLayoutParams.b = -1;
        marginLayoutParams.c = -1.0f;
        marginLayoutParams.d = true;
        marginLayoutParams.e = -1;
        marginLayoutParams.f = -1;
        marginLayoutParams.g = -1;
        marginLayoutParams.h = -1;
        marginLayoutParams.i = -1;
        marginLayoutParams.j = -1;
        marginLayoutParams.k = -1;
        marginLayoutParams.l = -1;
        marginLayoutParams.m = -1;
        marginLayoutParams.n = -1;
        marginLayoutParams.o = -1;
        marginLayoutParams.p = -1;
        marginLayoutParams.q = 0;
        marginLayoutParams.r = 0.0f;
        marginLayoutParams.s = -1;
        marginLayoutParams.t = -1;
        marginLayoutParams.u = -1;
        marginLayoutParams.v = -1;
        marginLayoutParams.w = Integer.MIN_VALUE;
        marginLayoutParams.f30x = Integer.MIN_VALUE;
        marginLayoutParams.y = Integer.MIN_VALUE;
        marginLayoutParams.z = Integer.MIN_VALUE;
        marginLayoutParams.A = Integer.MIN_VALUE;
        marginLayoutParams.B = Integer.MIN_VALUE;
        marginLayoutParams.C = Integer.MIN_VALUE;
        marginLayoutParams.D = 0;
        marginLayoutParams.E = 0.5f;
        marginLayoutParams.F = 0.5f;
        marginLayoutParams.G = null;
        marginLayoutParams.H = -1.0f;
        marginLayoutParams.I = -1.0f;
        marginLayoutParams.J = 0;
        marginLayoutParams.K = 0;
        marginLayoutParams.L = 0;
        marginLayoutParams.M = 0;
        marginLayoutParams.N = 0;
        marginLayoutParams.O = 0;
        marginLayoutParams.P = 0;
        marginLayoutParams.Q = 0;
        marginLayoutParams.R = 1.0f;
        marginLayoutParams.S = 1.0f;
        marginLayoutParams.T = -1;
        marginLayoutParams.U = -1;
        marginLayoutParams.V = -1;
        marginLayoutParams.W = false;
        marginLayoutParams.X = false;
        marginLayoutParams.Y = null;
        marginLayoutParams.Z = 0;
        marginLayoutParams.a0 = true;
        marginLayoutParams.b0 = true;
        marginLayoutParams.c0 = false;
        marginLayoutParams.d0 = false;
        marginLayoutParams.e0 = false;
        marginLayoutParams.f0 = -1;
        marginLayoutParams.g0 = -1;
        marginLayoutParams.h0 = -1;
        marginLayoutParams.i0 = -1;
        marginLayoutParams.j0 = Integer.MIN_VALUE;
        marginLayoutParams.k0 = Integer.MIN_VALUE;
        marginLayoutParams.l0 = 0.5f;
        marginLayoutParams.p0 = new A4();
        return marginLayoutParams;
    }

    private int getPaddingWidth() {
        int max = Math.max(0, getPaddingRight()) + Math.max(0, getPaddingLeft());
        int max2 = Math.max(0, getPaddingEnd()) + Math.max(0, getPaddingStart());
        if (max2 > 0) {
            return max2;
        }
        return max;
    }

    /* JADX WARN: Type inference failed for: r0v2, types: [x.Le, java.lang.Object] */
    public static Le getSharedValues() {
        if (p == null) {
            ?? obj = new Object();
            new SparseIntArray();
            new HashMap();
            p = obj;
        }
        return p;
    }

    @Override // android.view.ViewGroup
    public final boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof C0315q4;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void dispatchDraw(Canvas canvas) {
        Object tag;
        int size;
        ArrayList arrayList = this.b;
        if (arrayList != null && (size = arrayList.size()) > 0) {
            for (int i = 0; i < size; i++) {
                ((AbstractC0277o4) arrayList.get(i)).getClass();
            }
        }
        super.dispatchDraw(canvas);
        if (isInEditMode()) {
            float width = getWidth();
            float height = getHeight();
            int childCount = getChildCount();
            for (int i2 = 0; i2 < childCount; i2++) {
                View childAt = getChildAt(i2);
                if (childAt.getVisibility() != 8 && (tag = childAt.getTag()) != null && (tag instanceof String)) {
                    String[] split = ((String) tag).split(",");
                    if (split.length == 4) {
                        int parseInt = Integer.parseInt(split[0]);
                        int parseInt2 = Integer.parseInt(split[1]);
                        int parseInt3 = Integer.parseInt(split[2]);
                        int i3 = (int) ((parseInt / 1080.0f) * width);
                        int i4 = (int) ((parseInt2 / 1920.0f) * height);
                        Paint paint = new Paint();
                        paint.setColor(-65536);
                        float f = i3;
                        float f2 = i4;
                        float f3 = i3 + ((int) ((parseInt3 / 1080.0f) * width));
                        canvas.drawLine(f, f2, f3, f2, paint);
                        float parseInt4 = i4 + ((int) ((Integer.parseInt(split[3]) / 1920.0f) * height));
                        canvas.drawLine(f3, f2, f3, parseInt4, paint);
                        canvas.drawLine(f3, parseInt4, f, parseInt4, paint);
                        canvas.drawLine(f, parseInt4, f, f2, paint);
                        paint.setColor(-16711936);
                        canvas.drawLine(f, f2, f3, parseInt4, paint);
                        canvas.drawLine(f, parseInt4, f3, f2, paint);
                    }
                }
            }
        }
    }

    @Override // android.view.View
    public final void forceLayout() {
        this.h = true;
        super.forceLayout();
    }

    @Override // android.view.ViewGroup
    public final /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return g();
    }

    /* JADX WARN: Type inference failed for: r0v0, types: [android.view.ViewGroup$LayoutParams, android.view.ViewGroup$MarginLayoutParams, java.lang.Object, x.q4] */
    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        Context context = getContext();
        ?? marginLayoutParams = new ViewGroup.MarginLayoutParams(context, attributeSet);
        marginLayoutParams.a = -1;
        marginLayoutParams.b = -1;
        marginLayoutParams.c = -1.0f;
        marginLayoutParams.d = true;
        marginLayoutParams.e = -1;
        marginLayoutParams.f = -1;
        marginLayoutParams.g = -1;
        marginLayoutParams.h = -1;
        marginLayoutParams.i = -1;
        marginLayoutParams.j = -1;
        marginLayoutParams.k = -1;
        marginLayoutParams.l = -1;
        marginLayoutParams.m = -1;
        marginLayoutParams.n = -1;
        marginLayoutParams.o = -1;
        marginLayoutParams.p = -1;
        marginLayoutParams.q = 0;
        marginLayoutParams.r = 0.0f;
        marginLayoutParams.s = -1;
        marginLayoutParams.t = -1;
        marginLayoutParams.u = -1;
        marginLayoutParams.v = -1;
        marginLayoutParams.w = Integer.MIN_VALUE;
        marginLayoutParams.f30x = Integer.MIN_VALUE;
        marginLayoutParams.y = Integer.MIN_VALUE;
        marginLayoutParams.z = Integer.MIN_VALUE;
        marginLayoutParams.A = Integer.MIN_VALUE;
        marginLayoutParams.B = Integer.MIN_VALUE;
        marginLayoutParams.C = Integer.MIN_VALUE;
        marginLayoutParams.D = 0;
        marginLayoutParams.E = 0.5f;
        marginLayoutParams.F = 0.5f;
        marginLayoutParams.G = null;
        marginLayoutParams.H = -1.0f;
        marginLayoutParams.I = -1.0f;
        marginLayoutParams.J = 0;
        marginLayoutParams.K = 0;
        marginLayoutParams.L = 0;
        marginLayoutParams.M = 0;
        marginLayoutParams.N = 0;
        marginLayoutParams.O = 0;
        marginLayoutParams.P = 0;
        marginLayoutParams.Q = 0;
        marginLayoutParams.R = 1.0f;
        marginLayoutParams.S = 1.0f;
        marginLayoutParams.T = -1;
        marginLayoutParams.U = -1;
        marginLayoutParams.V = -1;
        marginLayoutParams.W = false;
        marginLayoutParams.X = false;
        marginLayoutParams.Y = null;
        marginLayoutParams.Z = 0;
        marginLayoutParams.a0 = true;
        marginLayoutParams.b0 = true;
        marginLayoutParams.c0 = false;
        marginLayoutParams.d0 = false;
        marginLayoutParams.e0 = false;
        marginLayoutParams.f0 = -1;
        marginLayoutParams.g0 = -1;
        marginLayoutParams.h0 = -1;
        marginLayoutParams.i0 = -1;
        marginLayoutParams.j0 = Integer.MIN_VALUE;
        marginLayoutParams.k0 = Integer.MIN_VALUE;
        marginLayoutParams.l0 = 0.5f;
        marginLayoutParams.p0 = new A4();
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, AbstractC0094ed.b);
        int indexCount = obtainStyledAttributes.getIndexCount();
        for (int i = 0; i < indexCount; i++) {
            int index = obtainStyledAttributes.getIndex(i);
            int i2 = AbstractC0296p4.a.get(index);
            switch (i2) {
                case 1:
                    marginLayoutParams.V = obtainStyledAttributes.getInt(index, marginLayoutParams.V);
                    break;
                case 2:
                    int resourceId = obtainStyledAttributes.getResourceId(index, marginLayoutParams.p);
                    marginLayoutParams.p = resourceId;
                    if (resourceId == -1) {
                        marginLayoutParams.p = obtainStyledAttributes.getInt(index, -1);
                        break;
                    } else {
                        break;
                    }
                case CTConstants.CERTIFICATE_LENGTH_BYTES /* 3 */:
                    marginLayoutParams.q = obtainStyledAttributes.getDimensionPixelSize(index, marginLayoutParams.q);
                    break;
                case 4:
                    float f = obtainStyledAttributes.getFloat(index, marginLayoutParams.r) % 360.0f;
                    marginLayoutParams.r = f;
                    if (f < 0.0f) {
                        marginLayoutParams.r = (360.0f - f) % 360.0f;
                        break;
                    } else {
                        break;
                    }
                case 5:
                    marginLayoutParams.a = obtainStyledAttributes.getDimensionPixelOffset(index, marginLayoutParams.a);
                    break;
                case 6:
                    marginLayoutParams.b = obtainStyledAttributes.getDimensionPixelOffset(index, marginLayoutParams.b);
                    break;
                case 7:
                    marginLayoutParams.c = obtainStyledAttributes.getFloat(index, marginLayoutParams.c);
                    break;
                case CTConstants.TIMESTAMP_LENGTH /* 8 */:
                    int resourceId2 = obtainStyledAttributes.getResourceId(index, marginLayoutParams.e);
                    marginLayoutParams.e = resourceId2;
                    if (resourceId2 == -1) {
                        marginLayoutParams.e = obtainStyledAttributes.getInt(index, -1);
                        break;
                    } else {
                        break;
                    }
                case 9:
                    int resourceId3 = obtainStyledAttributes.getResourceId(index, marginLayoutParams.f);
                    marginLayoutParams.f = resourceId3;
                    if (resourceId3 == -1) {
                        marginLayoutParams.f = obtainStyledAttributes.getInt(index, -1);
                        break;
                    } else {
                        break;
                    }
                case 10:
                    int resourceId4 = obtainStyledAttributes.getResourceId(index, marginLayoutParams.g);
                    marginLayoutParams.g = resourceId4;
                    if (resourceId4 == -1) {
                        marginLayoutParams.g = obtainStyledAttributes.getInt(index, -1);
                        break;
                    } else {
                        break;
                    }
                case 11:
                    int resourceId5 = obtainStyledAttributes.getResourceId(index, marginLayoutParams.h);
                    marginLayoutParams.h = resourceId5;
                    if (resourceId5 == -1) {
                        marginLayoutParams.h = obtainStyledAttributes.getInt(index, -1);
                        break;
                    } else {
                        break;
                    }
                case FileClientSessionCache.MAX_SIZE /* 12 */:
                    int resourceId6 = obtainStyledAttributes.getResourceId(index, marginLayoutParams.i);
                    marginLayoutParams.i = resourceId6;
                    if (resourceId6 == -1) {
                        marginLayoutParams.i = obtainStyledAttributes.getInt(index, -1);
                        break;
                    } else {
                        break;
                    }
                case 13:
                    int resourceId7 = obtainStyledAttributes.getResourceId(index, marginLayoutParams.j);
                    marginLayoutParams.j = resourceId7;
                    if (resourceId7 == -1) {
                        marginLayoutParams.j = obtainStyledAttributes.getInt(index, -1);
                        break;
                    } else {
                        break;
                    }
                case 14:
                    int resourceId8 = obtainStyledAttributes.getResourceId(index, marginLayoutParams.k);
                    marginLayoutParams.k = resourceId8;
                    if (resourceId8 == -1) {
                        marginLayoutParams.k = obtainStyledAttributes.getInt(index, -1);
                        break;
                    } else {
                        break;
                    }
                case 15:
                    int resourceId9 = obtainStyledAttributes.getResourceId(index, marginLayoutParams.l);
                    marginLayoutParams.l = resourceId9;
                    if (resourceId9 == -1) {
                        marginLayoutParams.l = obtainStyledAttributes.getInt(index, -1);
                        break;
                    } else {
                        break;
                    }
                case 16:
                    int resourceId10 = obtainStyledAttributes.getResourceId(index, marginLayoutParams.m);
                    marginLayoutParams.m = resourceId10;
                    if (resourceId10 == -1) {
                        marginLayoutParams.m = obtainStyledAttributes.getInt(index, -1);
                        break;
                    } else {
                        break;
                    }
                case 17:
                    int resourceId11 = obtainStyledAttributes.getResourceId(index, marginLayoutParams.s);
                    marginLayoutParams.s = resourceId11;
                    if (resourceId11 == -1) {
                        marginLayoutParams.s = obtainStyledAttributes.getInt(index, -1);
                        break;
                    } else {
                        break;
                    }
                case 18:
                    int resourceId12 = obtainStyledAttributes.getResourceId(index, marginLayoutParams.t);
                    marginLayoutParams.t = resourceId12;
                    if (resourceId12 == -1) {
                        marginLayoutParams.t = obtainStyledAttributes.getInt(index, -1);
                        break;
                    } else {
                        break;
                    }
                case 19:
                    int resourceId13 = obtainStyledAttributes.getResourceId(index, marginLayoutParams.u);
                    marginLayoutParams.u = resourceId13;
                    if (resourceId13 == -1) {
                        marginLayoutParams.u = obtainStyledAttributes.getInt(index, -1);
                        break;
                    } else {
                        break;
                    }
                case 20:
                    int resourceId14 = obtainStyledAttributes.getResourceId(index, marginLayoutParams.v);
                    marginLayoutParams.v = resourceId14;
                    if (resourceId14 == -1) {
                        marginLayoutParams.v = obtainStyledAttributes.getInt(index, -1);
                        break;
                    } else {
                        break;
                    }
                case 21:
                    marginLayoutParams.w = obtainStyledAttributes.getDimensionPixelSize(index, marginLayoutParams.w);
                    break;
                case 22:
                    marginLayoutParams.f30x = obtainStyledAttributes.getDimensionPixelSize(index, marginLayoutParams.f30x);
                    break;
                case 23:
                    marginLayoutParams.y = obtainStyledAttributes.getDimensionPixelSize(index, marginLayoutParams.y);
                    break;
                case 24:
                    marginLayoutParams.z = obtainStyledAttributes.getDimensionPixelSize(index, marginLayoutParams.z);
                    break;
                case 25:
                    marginLayoutParams.A = obtainStyledAttributes.getDimensionPixelSize(index, marginLayoutParams.A);
                    break;
                case 26:
                    marginLayoutParams.B = obtainStyledAttributes.getDimensionPixelSize(index, marginLayoutParams.B);
                    break;
                case 27:
                    marginLayoutParams.W = obtainStyledAttributes.getBoolean(index, marginLayoutParams.W);
                    break;
                case 28:
                    marginLayoutParams.X = obtainStyledAttributes.getBoolean(index, marginLayoutParams.X);
                    break;
                case 29:
                    marginLayoutParams.E = obtainStyledAttributes.getFloat(index, marginLayoutParams.E);
                    break;
                case 30:
                    marginLayoutParams.F = obtainStyledAttributes.getFloat(index, marginLayoutParams.F);
                    break;
                case 31:
                    int i3 = obtainStyledAttributes.getInt(index, 0);
                    marginLayoutParams.L = i3;
                    if (i3 == 1) {
                        Log.e("ConstraintLayout", "layout_constraintWidth_default=\"wrap\" is deprecated.\nUse layout_width=\"WRAP_CONTENT\" and layout_constrainedWidth=\"true\" instead.");
                        break;
                    } else {
                        break;
                    }
                case 32:
                    int i4 = obtainStyledAttributes.getInt(index, 0);
                    marginLayoutParams.M = i4;
                    if (i4 == 1) {
                        Log.e("ConstraintLayout", "layout_constraintHeight_default=\"wrap\" is deprecated.\nUse layout_height=\"WRAP_CONTENT\" and layout_constrainedHeight=\"true\" instead.");
                        break;
                    } else {
                        break;
                    }
                case 33:
                    try {
                        marginLayoutParams.N = obtainStyledAttributes.getDimensionPixelSize(index, marginLayoutParams.N);
                        break;
                    } catch (Exception unused) {
                        if (obtainStyledAttributes.getInt(index, marginLayoutParams.N) == -2) {
                            marginLayoutParams.N = -2;
                            break;
                        } else {
                            break;
                        }
                    }
                case 34:
                    try {
                        marginLayoutParams.P = obtainStyledAttributes.getDimensionPixelSize(index, marginLayoutParams.P);
                        break;
                    } catch (Exception unused2) {
                        if (obtainStyledAttributes.getInt(index, marginLayoutParams.P) == -2) {
                            marginLayoutParams.P = -2;
                            break;
                        } else {
                            break;
                        }
                    }
                case 35:
                    marginLayoutParams.R = Math.max(0.0f, obtainStyledAttributes.getFloat(index, marginLayoutParams.R));
                    marginLayoutParams.L = 2;
                    break;
                case 36:
                    try {
                        marginLayoutParams.O = obtainStyledAttributes.getDimensionPixelSize(index, marginLayoutParams.O);
                        break;
                    } catch (Exception unused3) {
                        if (obtainStyledAttributes.getInt(index, marginLayoutParams.O) == -2) {
                            marginLayoutParams.O = -2;
                            break;
                        } else {
                            break;
                        }
                    }
                case 37:
                    try {
                        marginLayoutParams.Q = obtainStyledAttributes.getDimensionPixelSize(index, marginLayoutParams.Q);
                        break;
                    } catch (Exception unused4) {
                        if (obtainStyledAttributes.getInt(index, marginLayoutParams.Q) == -2) {
                            marginLayoutParams.Q = -2;
                            break;
                        } else {
                            break;
                        }
                    }
                case 38:
                    marginLayoutParams.S = Math.max(0.0f, obtainStyledAttributes.getFloat(index, marginLayoutParams.S));
                    marginLayoutParams.M = 2;
                    break;
                default:
                    switch (i2) {
                        case 44:
                            C0485z4.h(marginLayoutParams, obtainStyledAttributes.getString(index));
                            break;
                        case 45:
                            marginLayoutParams.H = obtainStyledAttributes.getFloat(index, marginLayoutParams.H);
                            break;
                        case 46:
                            marginLayoutParams.I = obtainStyledAttributes.getFloat(index, marginLayoutParams.I);
                            break;
                        case 47:
                            marginLayoutParams.J = obtainStyledAttributes.getInt(index, 0);
                            break;
                        case 48:
                            marginLayoutParams.K = obtainStyledAttributes.getInt(index, 0);
                            break;
                        case 49:
                            marginLayoutParams.T = obtainStyledAttributes.getDimensionPixelOffset(index, marginLayoutParams.T);
                            break;
                        case 50:
                            marginLayoutParams.U = obtainStyledAttributes.getDimensionPixelOffset(index, marginLayoutParams.U);
                            break;
                        case 51:
                            marginLayoutParams.Y = obtainStyledAttributes.getString(index);
                            break;
                        case 52:
                            int resourceId15 = obtainStyledAttributes.getResourceId(index, marginLayoutParams.n);
                            marginLayoutParams.n = resourceId15;
                            if (resourceId15 == -1) {
                                marginLayoutParams.n = obtainStyledAttributes.getInt(index, -1);
                                break;
                            } else {
                                break;
                            }
                        case 53:
                            int resourceId16 = obtainStyledAttributes.getResourceId(index, marginLayoutParams.o);
                            marginLayoutParams.o = resourceId16;
                            if (resourceId16 == -1) {
                                marginLayoutParams.o = obtainStyledAttributes.getInt(index, -1);
                                break;
                            } else {
                                break;
                            }
                        case 54:
                            marginLayoutParams.D = obtainStyledAttributes.getDimensionPixelSize(index, marginLayoutParams.D);
                            break;
                        case 55:
                            marginLayoutParams.C = obtainStyledAttributes.getDimensionPixelSize(index, marginLayoutParams.C);
                            break;
                        default:
                            switch (i2) {
                                case 64:
                                    C0485z4.g(marginLayoutParams, obtainStyledAttributes, index, 0);
                                    break;
                                case 65:
                                    C0485z4.g(marginLayoutParams, obtainStyledAttributes, index, 1);
                                    break;
                                case 66:
                                    marginLayoutParams.Z = obtainStyledAttributes.getInt(index, marginLayoutParams.Z);
                                    break;
                                case 67:
                                    marginLayoutParams.d = obtainStyledAttributes.getBoolean(index, marginLayoutParams.d);
                                    break;
                            }
                    }
            }
        }
        obtainStyledAttributes.recycle();
        marginLayoutParams.a();
        return marginLayoutParams;
    }

    public int getMaxHeight() {
        return this.g;
    }

    public int getMaxWidth() {
        return this.f;
    }

    public int getMinHeight() {
        return this.e;
    }

    public int getMinWidth() {
        return this.d;
    }

    public int getOptimizationLevel() {
        return this.c.D0;
    }

    public String getSceneString() {
        int id;
        StringBuilder sb = new StringBuilder();
        B4 b4 = this.c;
        if (b4.j == null) {
            int id2 = getId();
            if (id2 != -1) {
                b4.j = getContext().getResources().getResourceEntryName(id2);
            } else {
                b4.j = "parent";
            }
        }
        if (b4.h0 == null) {
            b4.h0 = b4.j;
            Log.v("ConstraintLayout", " setDebugName " + b4.h0);
        }
        Iterator it = b4.q0.iterator();
        while (it.hasNext()) {
            A4 a4 = (A4) it.next();
            View view = a4.f0;
            if (view != null) {
                if (a4.j == null && (id = view.getId()) != -1) {
                    a4.j = getContext().getResources().getResourceEntryName(id);
                }
                if (a4.h0 == null) {
                    a4.h0 = a4.j;
                    Log.v("ConstraintLayout", " setDebugName " + a4.h0);
                }
            }
        }
        b4.n(sb);
        return sb.toString();
    }

    public final A4 h(View view) {
        if (view == this) {
            return this.c;
        }
        if (view != null) {
            if (view.getLayoutParams() instanceof C0315q4) {
                return ((C0315q4) view.getLayoutParams()).p0;
            }
            view.setLayoutParams(generateLayoutParams(view.getLayoutParams()));
            if (view.getLayoutParams() instanceof C0315q4) {
                return ((C0315q4) view.getLayoutParams()).p0;
            }
            return null;
        }
        return null;
    }

    public final void i(AttributeSet attributeSet, int i) {
        B4 b4 = this.c;
        b4.f0 = this;
        C0333r4 c0333r4 = this.o;
        b4.u0 = c0333r4;
        b4.s0.f = c0333r4;
        this.a.put(getId(), this);
        this.j = null;
        if (attributeSet != null) {
            TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, AbstractC0094ed.b, i, 0);
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i2 = 0; i2 < indexCount; i2++) {
                int index = obtainStyledAttributes.getIndex(i2);
                if (index == 16) {
                    this.d = obtainStyledAttributes.getDimensionPixelOffset(index, this.d);
                } else if (index == 17) {
                    this.e = obtainStyledAttributes.getDimensionPixelOffset(index, this.e);
                } else if (index == 14) {
                    this.f = obtainStyledAttributes.getDimensionPixelOffset(index, this.f);
                } else if (index == 15) {
                    this.g = obtainStyledAttributes.getDimensionPixelOffset(index, this.g);
                } else if (index == 113) {
                    this.i = obtainStyledAttributes.getInt(index, this.i);
                } else if (index == 56) {
                    int resourceId = obtainStyledAttributes.getResourceId(index, 0);
                    if (resourceId != 0) {
                        try {
                            j(resourceId);
                        } catch (Resources.NotFoundException unused) {
                            this.k = null;
                        }
                    }
                } else if (index == 34) {
                    int resourceId2 = obtainStyledAttributes.getResourceId(index, 0);
                    try {
                        C0485z4 c0485z4 = new C0485z4();
                        this.j = c0485z4;
                        c0485z4.e(getContext(), resourceId2);
                    } catch (Resources.NotFoundException unused2) {
                        this.j = null;
                    }
                    this.l = resourceId2;
                }
            }
            obtainStyledAttributes.recycle();
        }
        b4.D0 = this.i;
        C0170ia.q = b4.W(512);
    }

    /* JADX WARN: Failed to find 'out' block for switch in B:14:0x003c. Please report as an issue. */
    public final void j(int i) {
        int eventType;
        C0012ab c0012ab;
        Context context = getContext();
        F1 f1 = new F1(6, false);
        f1.b = new SparseArray();
        f1.c = new SparseArray();
        XmlResourceParser xml = context.getResources().getXml(i);
        try {
            eventType = xml.getEventType();
            c0012ab = null;
        } catch (IOException e) {
            Log.e("ConstraintLayoutStates", "Error parsing resource: " + i, e);
        } catch (XmlPullParserException e2) {
            Log.e("ConstraintLayoutStates", "Error parsing resource: " + i, e2);
        }
        while (true) {
            char c = 1;
            if (eventType != 1) {
                if (eventType == 2) {
                    String name = xml.getName();
                    switch (name.hashCode()) {
                        case -1349929691:
                            if (name.equals("ConstraintSet")) {
                                c = 4;
                                break;
                            }
                            c = 65535;
                            break;
                        case 80204913:
                            if (name.equals("State")) {
                                c = 2;
                                break;
                            }
                            c = 65535;
                            break;
                        case 1382829617:
                            if (name.equals("StateSet")) {
                                break;
                            }
                            c = 65535;
                            break;
                        case 1657696882:
                            if (name.equals("layoutDescription")) {
                                c = 0;
                                break;
                            }
                            c = 65535;
                            break;
                        case 1901439077:
                            if (name.equals("Variant")) {
                                c = 3;
                                break;
                            }
                            c = 65535;
                            break;
                        default:
                            c = 65535;
                            break;
                    }
                    if (c != 2) {
                        if (c != 3) {
                            if (c == 4) {
                                f1.I(context, xml);
                            }
                        } else {
                            C0352s4 c0352s4 = new C0352s4(context, xml);
                            if (c0012ab != null) {
                                ((ArrayList) c0012ab.a).add(c0352s4);
                            }
                        }
                    } else {
                        C0012ab c0012ab2 = new C0012ab(context, xml);
                        ((SparseArray) f1.b).put(c0012ab2.b, c0012ab2);
                        c0012ab = c0012ab2;
                    }
                }
                eventType = xml.next();
            } else {
                this.k = f1;
                return;
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:103:0x0348  */
    /* JADX WARN: Removed duplicated region for block: B:184:0x04d1  */
    /* JADX WARN: Removed duplicated region for block: B:186:0x04d5 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:89:0x032b  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void k(B4 b4, int i, int i2, int i3) {
        int i4;
        int max;
        int i5;
        int max2;
        int i6;
        int i7;
        boolean z;
        C0333r4 c0333r4;
        int i8;
        int i9;
        int i10;
        boolean z2;
        ArrayList arrayList;
        int i11;
        C0333r4 c0333r42;
        int i12;
        C0333r4 c0333r43;
        boolean z3;
        C0357s9 c0357s9;
        C0038bh c0038bh;
        int i13;
        int i14;
        int i15;
        int i16;
        int i17;
        int i18;
        boolean z4;
        Iterator it;
        Iterator it2;
        boolean z5;
        B4 b42 = b4;
        int mode = View.MeasureSpec.getMode(i2);
        int size = View.MeasureSpec.getSize(i2);
        int mode2 = View.MeasureSpec.getMode(i3);
        int size2 = View.MeasureSpec.getSize(i3);
        int max3 = Math.max(0, getPaddingTop());
        int max4 = Math.max(0, getPaddingBottom());
        int i19 = max3 + max4;
        int paddingWidth = getPaddingWidth();
        C0333r4 c0333r44 = this.o;
        c0333r44.b = max3;
        c0333r44.c = max4;
        c0333r44.d = paddingWidth;
        c0333r44.e = i19;
        c0333r44.f = i2;
        c0333r44.g = i3;
        int max5 = Math.max(0, getPaddingStart());
        int max6 = Math.max(0, getPaddingEnd());
        int i20 = 1;
        if (max5 <= 0 && max6 <= 0) {
            max5 = Math.max(0, getPaddingLeft());
        } else if ((getContext().getApplicationInfo().flags & 4194304) != 0 && 1 == getLayoutDirection()) {
            max5 = max6;
        }
        int i21 = size - paddingWidth;
        int i22 = size2 - i19;
        int i23 = c0333r44.e;
        int i24 = c0333r44.d;
        int childCount = getChildCount();
        if (mode != Integer.MIN_VALUE) {
            if (mode != 0) {
                if (mode != 1073741824) {
                    i4 = 0;
                } else {
                    i4 = Math.min(this.f - i24, i21);
                    i20 = 1;
                }
            } else if (childCount == 0) {
                max = Math.max(0, this.d);
                i4 = max;
                i20 = 2;
            } else {
                i4 = 0;
                i20 = 2;
            }
        } else if (childCount == 0) {
            max = Math.max(0, this.d);
            i4 = max;
            i20 = 2;
        } else {
            i4 = i21;
            i20 = 2;
        }
        if (mode2 != Integer.MIN_VALUE) {
            if (mode2 != 0) {
                i5 = mode2 != 1073741824 ? 0 : Math.min(this.g - i23, i22);
                i6 = 1;
            } else if (childCount == 0) {
                max2 = Math.max(0, this.e);
                i5 = max2;
                i6 = 2;
            } else {
                i5 = 0;
                i6 = 2;
            }
        } else if (childCount == 0) {
            max2 = Math.max(0, this.e);
            i5 = max2;
            i6 = 2;
        } else {
            i5 = i22;
            i6 = 2;
        }
        int q = b4.q();
        C0467y5 c0467y5 = b42.s0;
        int i25 = i4;
        if (i25 != q || i5 != b4.k()) {
            c0467y5.c = true;
        }
        b42.Y = 0;
        b42.Z = 0;
        int i26 = this.f - i24;
        int[] iArr = b42.C;
        iArr[0] = i26;
        iArr[1] = this.g - i23;
        b42.b0 = 0;
        b42.c0 = 0;
        b42.M(i20);
        b42.O(i25);
        b42.N(i6);
        b42.L(i5);
        int i27 = this.d - i24;
        if (i27 < 0) {
            b42.b0 = 0;
        } else {
            b42.b0 = i27;
        }
        int i28 = this.e - i23;
        if (i28 < 0) {
            b42.c0 = 0;
        } else {
            b42.c0 = i28;
        }
        b42.x0 = max5;
        b42.y0 = max3;
        C0294p2 c0294p2 = b42.r0;
        c0294p2.getClass();
        C0333r4 c0333r45 = b42.u0;
        int size3 = b42.q0.size();
        int q2 = b4.q();
        int k = b4.k();
        boolean x2 = E9.x(i, 128);
        boolean z6 = x2 || E9.x(i, 64);
        if (z6) {
            for (int i29 = 0; i29 < size3; i29++) {
                A4 a4 = (A4) b42.q0.get(i29);
                int[] iArr2 = a4.p0;
                boolean z7 = (iArr2[0] == 3) && (iArr2[1] == 3) && a4.W > 0.0f;
                if ((a4.x() && z7) || ((a4.y() && z7) || (a4 instanceof G7) || a4.x() || a4.y())) {
                    i7 = 1073741824;
                    z6 = false;
                    break;
                }
            }
        }
        i7 = 1073741824;
        boolean z8 = ((mode == i7 && mode2 == i7) || x2) & z6;
        if (z8) {
            int min = Math.min(iArr[0], i21);
            int min2 = Math.min(iArr[1], i22);
            if (mode == 1073741824 && b4.q() != min) {
                b42.O(min);
                b42.s0.b = true;
            }
            if (mode2 == 1073741824 && b4.k() != min2) {
                b42.L(min2);
                b42.s0.b = true;
            }
            if (mode == 1073741824 && mode2 == 1073741824) {
                boolean z9 = c0467y5.b;
                B4 b43 = c0467y5.a;
                if (z9 || c0467y5.c) {
                    Iterator it3 = b43.q0.iterator();
                    while (it3.hasNext()) {
                        A4 a42 = (A4) it3.next();
                        a42.h();
                        a42.a = false;
                        a42.d.n();
                        a42.e.m();
                    }
                    i15 = 0;
                    b43.h();
                    b43.a = false;
                    b43.d.n();
                    b43.e.m();
                    c0467y5.c = false;
                } else {
                    i15 = 0;
                }
                c0467y5.b(c0467y5.d);
                b43.Y = i15;
                b43.Z = i15;
                int j = b43.j(i15);
                int j2 = b43.j(1);
                if (c0467y5.b) {
                    c0467y5.c();
                }
                int r = b43.r();
                int s = b43.s();
                z = z8;
                b43.d.h.d(r);
                b43.e.h.d(s);
                c0467y5.g();
                ArrayList arrayList2 = c0467y5.e;
                c0333r4 = c0333r45;
                if (j == 2 || j2 == 2) {
                    if (x2) {
                        Iterator it4 = arrayList2.iterator();
                        while (true) {
                            if (it4.hasNext()) {
                                if (!((Wh) it4.next()).k()) {
                                    x2 = false;
                                    break;
                                }
                            } else {
                                break;
                            }
                        }
                    }
                    if (x2 && j == 2) {
                        b43.M(1);
                        i8 = q2;
                        b43.O(c0467y5.d(b43, 0));
                        b43.d.e.d(b43.q());
                    } else {
                        i8 = q2;
                    }
                    if (x2 && j2 == 2) {
                        i16 = 1;
                        b43.N(1);
                        b43.L(c0467y5.d(b43, 1));
                        b43.e.e.d(b43.k());
                        int[] iArr3 = b43.p0;
                        i9 = k;
                        i17 = iArr3[0];
                        if (i17 != i16 || i17 == 4) {
                            int q3 = b43.q() + r;
                            b43.d.i.d(q3);
                            b43.d.e.d(q3 - r);
                            c0467y5.g();
                            i18 = iArr3[1];
                            if (i18 != 1 || i18 == 4) {
                                int k2 = b43.k() + s;
                                b43.e.i.d(k2);
                                b43.e.e.d(k2 - s);
                            }
                            c0467y5.g();
                            z4 = true;
                        } else {
                            z4 = false;
                        }
                        it = arrayList2.iterator();
                        while (it.hasNext()) {
                            Wh wh = (Wh) it.next();
                            if (wh.b != b43 || wh.g) {
                                wh.e();
                            }
                        }
                        it2 = arrayList2.iterator();
                        while (it2.hasNext()) {
                            Wh wh2 = (Wh) it2.next();
                            if (z4 || wh2.b != b43) {
                                if (!wh2.h.j || ((!wh2.i.j && !(wh2 instanceof C0282o9)) || (!wh2.e.j && !(wh2 instanceof C0465y3) && !(wh2 instanceof C0282o9)))) {
                                    z5 = false;
                                    break;
                                }
                            }
                        }
                        z5 = true;
                        b43.M(j);
                        b43.N(j2);
                        z2 = z5;
                        i14 = 1073741824;
                        i10 = 2;
                    }
                } else {
                    i8 = q2;
                }
                i16 = 1;
                int[] iArr32 = b43.p0;
                i9 = k;
                i17 = iArr32[0];
                if (i17 != i16) {
                }
                int q32 = b43.q() + r;
                b43.d.i.d(q32);
                b43.d.e.d(q32 - r);
                c0467y5.g();
                i18 = iArr32[1];
                if (i18 != 1) {
                }
                int k22 = b43.k() + s;
                b43.e.i.d(k22);
                b43.e.e.d(k22 - s);
                c0467y5.g();
                z4 = true;
                it = arrayList2.iterator();
                while (it.hasNext()) {
                }
                it2 = arrayList2.iterator();
                while (it2.hasNext()) {
                }
                z5 = true;
                b43.M(j);
                b43.N(j2);
                z2 = z5;
                i14 = 1073741824;
                i10 = 2;
            } else {
                z = z8;
                c0333r4 = c0333r45;
                i8 = q2;
                i9 = k;
                boolean z10 = c0467y5.b;
                B4 b44 = c0467y5.a;
                if (z10) {
                    Iterator it5 = b44.q0.iterator();
                    while (it5.hasNext()) {
                        A4 a43 = (A4) it5.next();
                        a43.h();
                        a43.a = false;
                        C0357s9 c0357s92 = a43.d;
                        c0357s92.e.j = false;
                        c0357s92.g = false;
                        c0357s92.n();
                        C0038bh c0038bh2 = a43.e;
                        c0038bh2.e.j = false;
                        c0038bh2.g = false;
                        c0038bh2.m();
                    }
                    i13 = 0;
                    b44.h();
                    b44.a = false;
                    C0357s9 c0357s93 = b44.d;
                    c0357s93.e.j = false;
                    c0357s93.g = false;
                    c0357s93.n();
                    C0038bh c0038bh3 = b44.e;
                    c0038bh3.e.j = false;
                    c0038bh3.g = false;
                    c0038bh3.m();
                    c0467y5.c();
                } else {
                    i13 = 0;
                }
                c0467y5.b(c0467y5.d);
                b44.Y = i13;
                b44.Z = i13;
                b44.d.h.d(i13);
                b44.e.h.d(i13);
                i14 = 1073741824;
                if (mode == 1073741824) {
                    z2 = b42.T(i13, x2);
                    i10 = 1;
                } else {
                    i10 = 0;
                    z2 = true;
                }
                if (mode2 == 1073741824) {
                    z2 &= b42.T(1, x2);
                    i10++;
                }
            }
            if (z2) {
                b42.P(mode == i14, mode2 == i14);
            }
        } else {
            z = z8;
            c0333r4 = c0333r45;
            i8 = q2;
            i9 = k;
            i10 = 0;
            z2 = false;
        }
        if (z2 && i10 == 2) {
            return;
        }
        int i30 = b42.D0;
        if (size3 > 0) {
            int size4 = b42.q0.size();
            boolean W = b42.W(64);
            C0333r4 c0333r46 = b42.u0;
            for (int i31 = 0; i31 < size4; i31++) {
                A4 a44 = (A4) b42.q0.get(i31);
                if (!(a44 instanceof C0263n9) && !(a44 instanceof P2) && !a44.F && (!W || (c0357s9 = a44.d) == null || (c0038bh = a44.e) == null || !c0357s9.e.j || !c0038bh.e.j)) {
                    int j3 = a44.j(0);
                    int j4 = a44.j(1);
                    boolean z11 = j3 == 3 && a44.r != 1 && j4 == 3 && a44.s != 1;
                    if (!z11 && b42.W(1) && !(a44 instanceof G7)) {
                        if (j3 == 3 && a44.r == 0 && j4 != 3 && !a44.x()) {
                            z11 = true;
                        }
                        if (j4 == 3 && a44.s == 0 && j3 != 3 && !a44.x()) {
                            z11 = true;
                        }
                        if (j3 == 3 || j4 == 3) {
                            if (a44.W > 0.0f) {
                                z11 = true;
                            }
                            if (z11) {
                                c0294p2.x(0, c0333r46, a44);
                            }
                        }
                    }
                    if (z11) {
                    }
                }
            }
            ConstraintLayout constraintLayout = c0333r46.a;
            int childCount2 = constraintLayout.getChildCount();
            for (int i32 = 0; i32 < childCount2; i32++) {
                constraintLayout.getChildAt(i32);
            }
            ArrayList arrayList3 = constraintLayout.b;
            int size5 = arrayList3.size();
            if (size5 > 0) {
                for (int i33 = 0; i33 < size5; i33++) {
                    ((AbstractC0277o4) arrayList3.get(i33)).getClass();
                }
            }
        }
        c0294p2.D(b42);
        ArrayList arrayList4 = (ArrayList) c0294p2.b;
        int size6 = arrayList4.size();
        int i34 = i8;
        int i35 = i9;
        if (size3 > 0) {
            c0294p2.B(b42, 0, i34, i35);
        }
        if (size6 > 0) {
            int[] iArr4 = b42.p0;
            boolean z12 = iArr4[0] == 2;
            boolean z13 = iArr4[1] == 2;
            int q4 = b4.q();
            B4 b45 = (B4) c0294p2.d;
            int max7 = Math.max(q4, b45.b0);
            int max8 = Math.max(b4.k(), b45.c0);
            int i36 = 0;
            boolean z14 = false;
            while (i36 < size6) {
                A4 a45 = (A4) arrayList4.get(i36);
                if (a45 instanceof G7) {
                    int q5 = a45.q();
                    int k3 = a45.k();
                    i12 = i30;
                    c0333r43 = c0333r4;
                    boolean x3 = z14 | c0294p2.x(1, c0333r43, a45);
                    int q6 = a45.q();
                    int k4 = a45.k();
                    if (q6 != q5) {
                        a45.O(q6);
                        if (z12 && a45.r() + a45.U > max7) {
                            max7 = Math.max(max7, a45.i(4).e() + a45.r() + a45.U);
                        }
                        z3 = true;
                    } else {
                        z3 = x3;
                    }
                    if (k4 != k3) {
                        a45.L(k4);
                        if (z13 && a45.s() + a45.V > max8) {
                            max8 = Math.max(max8, a45.i(5).e() + a45.s() + a45.V);
                        }
                        z3 = true;
                    }
                    z14 = ((G7) a45).y0 | z3;
                } else {
                    i12 = i30;
                    c0333r43 = c0333r4;
                }
                i36++;
                c0333r4 = c0333r43;
                i30 = i12;
            }
            int i37 = i30;
            C0333r4 c0333r47 = c0333r4;
            int i38 = 0;
            while (i38 < 2) {
                int i39 = 0;
                while (i39 < size6) {
                    A4 a46 = (A4) arrayList4.get(i39);
                    if (((a46 instanceof AbstractC0338r9) && !(a46 instanceof G7)) || (a46 instanceof C0263n9) || a46.g0 == 8 || ((z && a46.d.e.j && a46.e.e.j) || (a46 instanceof G7))) {
                        c0333r42 = c0333r47;
                        arrayList = arrayList4;
                        i11 = size6;
                    } else {
                        int q7 = a46.q();
                        int k5 = a46.k();
                        arrayList = arrayList4;
                        int i40 = a46.a0;
                        i11 = size6;
                        boolean x4 = c0294p2.x(i38 == 1 ? 2 : 1, c0333r47, a46) | z14;
                        int q8 = a46.q();
                        c0333r42 = c0333r47;
                        int k6 = a46.k();
                        if (q8 != q7) {
                            a46.O(q8);
                            if (z12 && a46.r() + a46.U > max7) {
                                max7 = Math.max(max7, a46.i(4).e() + a46.r() + a46.U);
                            }
                            x4 = true;
                        }
                        if (k6 != k5) {
                            a46.L(k6);
                            if (z13 && a46.s() + a46.V > max8) {
                                max8 = Math.max(max8, a46.i(5).e() + a46.s() + a46.V);
                            }
                            x4 = true;
                        }
                        z14 = (!a46.E || i40 == a46.a0) ? x4 : true;
                    }
                    i39++;
                    arrayList4 = arrayList;
                    size6 = i11;
                    c0333r47 = c0333r42;
                }
                C0333r4 c0333r48 = c0333r47;
                ArrayList arrayList5 = arrayList4;
                int i41 = size6;
                if (!z14) {
                    break;
                }
                i38++;
                c0294p2.B(b4, i38, i34, i35);
                c0333r47 = c0333r48;
                arrayList4 = arrayList5;
                size6 = i41;
                z14 = false;
            }
            b42 = b4;
            i30 = i37;
        }
        b42.D0 = i30;
        C0170ia.q = b42.W(512);
    }

    public final void l(A4 a4, C0315q4 c0315q4, SparseArray sparseArray, int i, int i2) {
        View view = (View) this.a.get(i);
        A4 a42 = (A4) sparseArray.get(i);
        if (a42 != null && view != null && (view.getLayoutParams() instanceof C0315q4)) {
            c0315q4.c0 = true;
            if (i2 == 6) {
                C0315q4 c0315q42 = (C0315q4) view.getLayoutParams();
                c0315q42.c0 = true;
                c0315q42.p0.E = true;
            }
            a4.i(6).b(a42.i(i2), c0315q4.D, c0315q4.C, true);
            a4.E = true;
            a4.i(3).j();
            a4.i(5).j();
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        int childCount = getChildCount();
        boolean isInEditMode = isInEditMode();
        for (int i5 = 0; i5 < childCount; i5++) {
            View childAt = getChildAt(i5);
            C0315q4 c0315q4 = (C0315q4) childAt.getLayoutParams();
            A4 a4 = c0315q4.p0;
            if (childAt.getVisibility() != 8 || c0315q4.d0 || c0315q4.e0 || isInEditMode) {
                int r = a4.r();
                int s = a4.s();
                childAt.layout(r, s, a4.q() + r, a4.k() + s);
            }
        }
        ArrayList arrayList = this.b;
        int size = arrayList.size();
        if (size > 0) {
            for (int i6 = 0; i6 < size; i6++) {
                ((AbstractC0277o4) arrayList.get(i6)).getClass();
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:273:0x02ec  */
    /* JADX WARN: Removed duplicated region for block: B:278:0x0329  */
    /* JADX WARN: Removed duplicated region for block: B:283:0x036d  */
    /* JADX WARN: Removed duplicated region for block: B:288:0x03b1  */
    /* JADX WARN: Removed duplicated region for block: B:292:0x03e1  */
    /* JADX WARN: Removed duplicated region for block: B:295:0x03e9  */
    /* JADX WARN: Removed duplicated region for block: B:296:0x03be  */
    /* JADX WARN: Removed duplicated region for block: B:302:0x038b  */
    /* JADX WARN: Removed duplicated region for block: B:307:0x0346  */
    /* JADX WARN: Removed duplicated region for block: B:312:0x0308  */
    @Override // android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public void onMeasure(int i, int i2) {
        boolean z;
        boolean z2;
        int i3;
        int i4;
        A4 a4;
        int i5;
        A4 a42;
        int i6;
        A4 a43;
        int i7;
        C0315q4 c0315q4;
        float f;
        int i8;
        int i9;
        int i10;
        float parseFloat;
        int i11;
        ArrayList arrayList;
        ArrayList arrayList2;
        String resourceName;
        int id;
        A4 a44;
        String str;
        ConstraintLayout constraintLayout = this;
        boolean z3 = constraintLayout.h;
        constraintLayout.h = z3;
        int i12 = 0;
        if (!z3) {
            int childCount = getChildCount();
            int i13 = 0;
            while (true) {
                if (i13 >= childCount) {
                    break;
                }
                if (constraintLayout.getChildAt(i13).isLayoutRequested()) {
                    constraintLayout.h = true;
                    break;
                }
                i13++;
            }
        }
        if ((getContext().getApplicationInfo().flags & 4194304) != 0 && 1 == getLayoutDirection()) {
            z = true;
        } else {
            z = false;
        }
        B4 b4 = constraintLayout.c;
        b4.v0 = z;
        if (constraintLayout.h) {
            constraintLayout.h = false;
            int childCount2 = getChildCount();
            int i14 = 0;
            while (true) {
                if (i14 < childCount2) {
                    if (constraintLayout.getChildAt(i14).isLayoutRequested()) {
                        z2 = true;
                        break;
                    }
                    i14++;
                } else {
                    z2 = false;
                    break;
                }
            }
            if (z2) {
                boolean isInEditMode = isInEditMode();
                int childCount3 = getChildCount();
                for (int i15 = 0; i15 < childCount3; i15++) {
                    A4 h = constraintLayout.h(constraintLayout.getChildAt(i15));
                    if (h != null) {
                        h.C();
                    }
                }
                Object obj = null;
                if (isInEditMode) {
                    for (int i16 = 0; i16 < childCount3; i16++) {
                        View childAt = constraintLayout.getChildAt(i16);
                        try {
                            resourceName = getResources().getResourceName(childAt.getId());
                            Integer valueOf = Integer.valueOf(childAt.getId());
                            if (resourceName != null) {
                                if (constraintLayout.m == null) {
                                    constraintLayout.m = new HashMap();
                                }
                                int indexOf = resourceName.indexOf("/");
                                if (indexOf != -1) {
                                    str = resourceName.substring(indexOf + 1);
                                } else {
                                    str = resourceName;
                                }
                                constraintLayout.m.put(str, valueOf);
                            }
                            int indexOf2 = resourceName.indexOf(47);
                            if (indexOf2 != -1) {
                                resourceName = resourceName.substring(indexOf2 + 1);
                            }
                            id = childAt.getId();
                        } catch (Resources.NotFoundException unused) {
                        }
                        if (id != 0) {
                            View view = (View) constraintLayout.a.get(id);
                            if (view == null && (view = constraintLayout.findViewById(id)) != null && view != constraintLayout && view.getParent() == constraintLayout) {
                                constraintLayout.onViewAdded(view);
                            }
                            if (view != constraintLayout) {
                                if (view == null) {
                                    a44 = null;
                                } else {
                                    a44 = ((C0315q4) view.getLayoutParams()).p0;
                                }
                                a44.h0 = resourceName;
                            }
                        }
                        a44 = b4;
                        a44.h0 = resourceName;
                    }
                }
                if (constraintLayout.l != -1) {
                    for (int i17 = 0; i17 < childCount3; i17++) {
                        constraintLayout.getChildAt(i17).getId();
                    }
                }
                C0485z4 c0485z4 = constraintLayout.j;
                if (c0485z4 != null) {
                    c0485z4.a(constraintLayout);
                }
                b4.q0.clear();
                ArrayList arrayList3 = constraintLayout.b;
                int size = arrayList3.size();
                if (size > 0) {
                    int i18 = 0;
                    while (i18 < size) {
                        AbstractC0277o4 abstractC0277o4 = (AbstractC0277o4) arrayList3.get(i18);
                        if (abstractC0277o4.isInEditMode()) {
                            abstractC0277o4.setIds(abstractC0277o4.e);
                        }
                        AbstractC0338r9 abstractC0338r9 = abstractC0277o4.d;
                        if (abstractC0338r9 == null) {
                            arrayList = arrayList3;
                        } else {
                            abstractC0338r9.r0 = i12;
                            Arrays.fill(abstractC0338r9.q0, obj);
                            int i19 = i12;
                            while (i19 < abstractC0277o4.b) {
                                int i20 = abstractC0277o4.a[i19];
                                View view2 = (View) constraintLayout.a.get(i20);
                                if (view2 == null) {
                                    Integer valueOf2 = Integer.valueOf(i20);
                                    HashMap hashMap = abstractC0277o4.g;
                                    String str2 = (String) hashMap.get(valueOf2);
                                    int f2 = abstractC0277o4.f(constraintLayout, str2);
                                    if (f2 != 0) {
                                        abstractC0277o4.a[i19] = f2;
                                        hashMap.put(Integer.valueOf(f2), str2);
                                        view2 = (View) constraintLayout.a.get(f2);
                                    }
                                }
                                if (view2 != null) {
                                    AbstractC0338r9 abstractC0338r92 = abstractC0277o4.d;
                                    A4 h2 = constraintLayout.h(view2);
                                    abstractC0338r92.getClass();
                                    if (h2 != abstractC0338r92 && h2 != null) {
                                        int i21 = abstractC0338r92.r0 + 1;
                                        A4[] a4Arr = abstractC0338r92.q0;
                                        arrayList2 = arrayList3;
                                        if (i21 > a4Arr.length) {
                                            abstractC0338r92.q0 = (A4[]) Arrays.copyOf(a4Arr, a4Arr.length * 2);
                                        }
                                        A4[] a4Arr2 = abstractC0338r92.q0;
                                        int i22 = abstractC0338r92.r0;
                                        a4Arr2[i22] = h2;
                                        abstractC0338r92.r0 = i22 + 1;
                                        i19++;
                                        arrayList3 = arrayList2;
                                    }
                                }
                                arrayList2 = arrayList3;
                                i19++;
                                arrayList3 = arrayList2;
                            }
                            arrayList = arrayList3;
                            abstractC0277o4.d.S();
                        }
                        i18++;
                        arrayList3 = arrayList;
                        obj = null;
                        i12 = 0;
                    }
                }
                for (int i23 = 0; i23 < childCount3; i23++) {
                    constraintLayout.getChildAt(i23);
                }
                SparseArray sparseArray = constraintLayout.n;
                sparseArray.clear();
                sparseArray.put(0, b4);
                sparseArray.put(getId(), b4);
                for (int i24 = 0; i24 < childCount3; i24++) {
                    View childAt2 = constraintLayout.getChildAt(i24);
                    sparseArray.put(childAt2.getId(), constraintLayout.h(childAt2));
                }
                int i25 = 0;
                while (i25 < childCount3) {
                    View childAt3 = constraintLayout.getChildAt(i25);
                    A4 h3 = constraintLayout.h(childAt3);
                    if (h3 != null) {
                        C0315q4 c0315q42 = (C0315q4) childAt3.getLayoutParams();
                        b4.q0.add(h3);
                        A4 a45 = h3.T;
                        if (a45 != null) {
                            ((B4) a45).q0.remove(h3);
                            h3.C();
                        }
                        h3.T = b4;
                        c0315q42.a();
                        h3.g0 = childAt3.getVisibility();
                        h3.f0 = childAt3;
                        if (childAt3 instanceof AbstractC0277o4) {
                            ((AbstractC0277o4) childAt3).h(h3, b4.v0);
                        }
                        if (c0315q42.d0) {
                            C0263n9 c0263n9 = (C0263n9) h3;
                            int i26 = c0315q42.m0;
                            int i27 = c0315q42.n0;
                            float f3 = c0315q42.o0;
                            if (f3 != -1.0f) {
                                if (f3 > -1.0f) {
                                    c0263n9.q0 = f3;
                                    c0263n9.r0 = -1;
                                    c0263n9.s0 = -1;
                                }
                            } else if (i26 != -1) {
                                if (i26 > -1) {
                                    c0263n9.q0 = -1.0f;
                                    c0263n9.r0 = i26;
                                    c0263n9.s0 = -1;
                                }
                            } else if (i27 != -1 && i27 > -1) {
                                c0263n9.q0 = -1.0f;
                                c0263n9.r0 = -1;
                                c0263n9.s0 = i27;
                            }
                        } else {
                            int i28 = c0315q42.f0;
                            int i29 = c0315q42.g0;
                            int i30 = c0315q42.h0;
                            int i31 = c0315q42.i0;
                            int i32 = c0315q42.j0;
                            i3 = childCount3;
                            int i33 = c0315q42.k0;
                            float f4 = c0315q42.l0;
                            int i34 = c0315q42.p;
                            if (i34 != -1) {
                                A4 a46 = (A4) sparseArray.get(i34);
                                if (a46 != null) {
                                    float f5 = c0315q42.r;
                                    h3.v(7, 7, c0315q42.q, 0, a46);
                                    h3.D = f5;
                                }
                                c0315q4 = c0315q42;
                            } else {
                                if (i28 != -1) {
                                    A4 a47 = (A4) sparseArray.get(i28);
                                    if (a47 != null) {
                                        h3.v(2, 2, ((ViewGroup.MarginLayoutParams) c0315q42).leftMargin, i32, a47);
                                    }
                                } else {
                                    i4 = -1;
                                    if (i29 != -1) {
                                        A4 a48 = (A4) sparseArray.get(i29);
                                        if (a48 != null) {
                                            h3.v(2, 4, ((ViewGroup.MarginLayoutParams) c0315q42).leftMargin, i32, a48);
                                        }
                                    }
                                    if (i30 == i4) {
                                        A4 a49 = (A4) sparseArray.get(i30);
                                        if (a49 != null) {
                                            h3.v(4, 2, ((ViewGroup.MarginLayoutParams) c0315q42).rightMargin, i33, a49);
                                        }
                                    } else if (i31 != i4 && (a4 = (A4) sparseArray.get(i31)) != null) {
                                        h3.v(4, 4, ((ViewGroup.MarginLayoutParams) c0315q42).rightMargin, i33, a4);
                                    }
                                    i5 = c0315q42.i;
                                    if (i5 == -1) {
                                        A4 a410 = (A4) sparseArray.get(i5);
                                        if (a410 != null) {
                                            h3.v(3, 3, ((ViewGroup.MarginLayoutParams) c0315q42).topMargin, c0315q42.f30x, a410);
                                        }
                                    } else {
                                        int i35 = c0315q42.j;
                                        if (i35 != -1 && (a42 = (A4) sparseArray.get(i35)) != null) {
                                            h3.v(3, 5, ((ViewGroup.MarginLayoutParams) c0315q42).topMargin, c0315q42.f30x, a42);
                                        }
                                    }
                                    i6 = c0315q42.k;
                                    if (i6 == -1) {
                                        A4 a411 = (A4) sparseArray.get(i6);
                                        if (a411 != null) {
                                            h3.v(5, 3, ((ViewGroup.MarginLayoutParams) c0315q42).bottomMargin, c0315q42.z, a411);
                                        }
                                    } else {
                                        int i36 = c0315q42.l;
                                        if (i36 != -1 && (a43 = (A4) sparseArray.get(i36)) != null) {
                                            h3.v(5, 5, ((ViewGroup.MarginLayoutParams) c0315q42).bottomMargin, c0315q42.z, a43);
                                        }
                                    }
                                    i7 = c0315q42.m;
                                    if (i7 == -1) {
                                        c0315q4 = c0315q42;
                                        l(h3, c0315q42, sparseArray, i7, 6);
                                    } else {
                                        c0315q4 = c0315q42;
                                        int i37 = c0315q4.n;
                                        if (i37 != -1) {
                                            l(h3, c0315q4, sparseArray, i37, 3);
                                        } else {
                                            int i38 = c0315q4.o;
                                            if (i38 != -1) {
                                                l(h3, c0315q4, sparseArray, i38, 5);
                                            }
                                        }
                                    }
                                    if (f4 >= 0.0f) {
                                        h3.d0 = f4;
                                    }
                                    f = c0315q4.F;
                                    if (f >= 0.0f) {
                                        h3.e0 = f;
                                    }
                                }
                                i4 = -1;
                                if (i30 == i4) {
                                }
                                i5 = c0315q42.i;
                                if (i5 == -1) {
                                }
                                i6 = c0315q42.k;
                                if (i6 == -1) {
                                }
                                i7 = c0315q42.m;
                                if (i7 == -1) {
                                }
                                if (f4 >= 0.0f) {
                                }
                                f = c0315q4.F;
                                if (f >= 0.0f) {
                                }
                            }
                            if (isInEditMode && ((i11 = c0315q4.T) != -1 || c0315q4.U != -1)) {
                                int i39 = c0315q4.U;
                                h3.Y = i11;
                                h3.Z = i39;
                            }
                            if (!c0315q4.a0) {
                                if (((ViewGroup.MarginLayoutParams) c0315q4).width == -1) {
                                    if (c0315q4.W) {
                                        h3.M(3);
                                    } else {
                                        h3.M(4);
                                    }
                                    h3.i(2).g = ((ViewGroup.MarginLayoutParams) c0315q4).leftMargin;
                                    h3.i(4).g = ((ViewGroup.MarginLayoutParams) c0315q4).rightMargin;
                                } else {
                                    h3.M(3);
                                    h3.O(0);
                                }
                            } else {
                                h3.M(1);
                                h3.O(((ViewGroup.MarginLayoutParams) c0315q4).width);
                                if (((ViewGroup.MarginLayoutParams) c0315q4).width == -2) {
                                    h3.M(2);
                                }
                            }
                            if (!c0315q4.b0) {
                                i8 = -1;
                                if (((ViewGroup.MarginLayoutParams) c0315q4).height == -1) {
                                    if (c0315q4.X) {
                                        h3.N(3);
                                    } else {
                                        h3.N(4);
                                    }
                                    h3.i(3).g = ((ViewGroup.MarginLayoutParams) c0315q4).topMargin;
                                    h3.i(5).g = ((ViewGroup.MarginLayoutParams) c0315q4).bottomMargin;
                                } else {
                                    h3.N(3);
                                    h3.L(0);
                                }
                            } else {
                                i8 = -1;
                                h3.N(1);
                                h3.L(((ViewGroup.MarginLayoutParams) c0315q4).height);
                                if (((ViewGroup.MarginLayoutParams) c0315q4).height == -2) {
                                    h3.N(2);
                                }
                            }
                            String str3 = c0315q4.G;
                            if (str3 != null && str3.length() != 0) {
                                int length = str3.length();
                                int indexOf3 = str3.indexOf(44);
                                if (indexOf3 > 0 && indexOf3 < length - 1) {
                                    String substring = str3.substring(0, indexOf3);
                                    if (substring.equalsIgnoreCase("W")) {
                                        i9 = 0;
                                    } else if (substring.equalsIgnoreCase("H")) {
                                        i9 = 1;
                                    } else {
                                        i9 = i8;
                                    }
                                    i10 = indexOf3 + 1;
                                } else {
                                    i9 = i8;
                                    i10 = 0;
                                }
                                int indexOf4 = str3.indexOf(58);
                                if (indexOf4 >= 0 && indexOf4 < length - 1) {
                                    String substring2 = str3.substring(i10, indexOf4);
                                    String substring3 = str3.substring(indexOf4 + 1);
                                    if (substring2.length() > 0 && substring3.length() > 0) {
                                        try {
                                            float parseFloat2 = Float.parseFloat(substring2);
                                            float parseFloat3 = Float.parseFloat(substring3);
                                            if (parseFloat2 > 0.0f && parseFloat3 > 0.0f) {
                                                if (i9 == 1) {
                                                    parseFloat = Math.abs(parseFloat3 / parseFloat2);
                                                } else {
                                                    parseFloat = Math.abs(parseFloat2 / parseFloat3);
                                                }
                                            }
                                        } catch (NumberFormatException unused2) {
                                        }
                                    }
                                    parseFloat = 0.0f;
                                } else {
                                    String substring4 = str3.substring(i10);
                                    if (substring4.length() > 0) {
                                        parseFloat = Float.parseFloat(substring4);
                                    }
                                    parseFloat = 0.0f;
                                }
                                if (parseFloat > 0.0f) {
                                    h3.W = parseFloat;
                                    h3.X = i9;
                                }
                            } else {
                                h3.W = 0.0f;
                            }
                            float f6 = c0315q4.H;
                            float[] fArr = h3.k0;
                            fArr[0] = f6;
                            fArr[1] = c0315q4.I;
                            h3.i0 = c0315q4.J;
                            h3.j0 = c0315q4.K;
                            int i40 = c0315q4.Z;
                            if (i40 >= 0 && i40 <= 3) {
                                h3.q = i40;
                            }
                            int i41 = c0315q4.L;
                            int i42 = c0315q4.N;
                            int i43 = c0315q4.P;
                            float f7 = c0315q4.R;
                            h3.r = i41;
                            h3.u = i42;
                            if (i43 == Integer.MAX_VALUE) {
                                i43 = 0;
                            }
                            h3.v = i43;
                            h3.w = f7;
                            if (f7 > 0.0f && f7 < 1.0f && i41 == 0) {
                                h3.r = 2;
                            }
                            int i44 = c0315q4.M;
                            int i45 = c0315q4.O;
                            int i46 = c0315q4.Q;
                            float f8 = c0315q4.S;
                            h3.s = i44;
                            h3.f14x = i45;
                            if (i46 == Integer.MAX_VALUE) {
                                i46 = 0;
                            }
                            h3.y = i46;
                            h3.z = f8;
                            if (f8 > 0.0f && f8 < 1.0f && i44 == 0) {
                                h3.s = 2;
                            }
                            i25++;
                            constraintLayout = this;
                            childCount3 = i3;
                        }
                    }
                    i3 = childCount3;
                    i25++;
                    constraintLayout = this;
                    childCount3 = i3;
                }
            }
            if (z2) {
                b4.r0.D(b4);
            }
        }
        b4.w0.getClass();
        k(b4, this.i, i, i2);
        int q = b4.q();
        int k = b4.k();
        boolean z4 = b4.E0;
        boolean z5 = b4.F0;
        C0333r4 c0333r4 = this.o;
        int i47 = c0333r4.e;
        int resolveSizeAndState = View.resolveSizeAndState(q + c0333r4.d, i, 0);
        int resolveSizeAndState2 = View.resolveSizeAndState(k + i47, i2, 0) & 16777215;
        int min = Math.min(this.f, resolveSizeAndState & 16777215);
        int min2 = Math.min(this.g, resolveSizeAndState2);
        if (z4) {
            min |= 16777216;
        }
        if (z5) {
            min2 |= 16777216;
        }
        setMeasuredDimension(min, min2);
    }

    @Override // android.view.ViewGroup
    public final void onViewAdded(View view) {
        super.onViewAdded(view);
        A4 h = h(view);
        if ((view instanceof C0244m9) && !(h instanceof C0263n9)) {
            C0315q4 c0315q4 = (C0315q4) view.getLayoutParams();
            C0263n9 c0263n9 = new C0263n9();
            c0315q4.p0 = c0263n9;
            c0315q4.d0 = true;
            c0263n9.S(c0315q4.V);
        }
        if (view instanceof AbstractC0277o4) {
            AbstractC0277o4 abstractC0277o4 = (AbstractC0277o4) view;
            abstractC0277o4.i();
            ((C0315q4) view.getLayoutParams()).e0 = true;
            ArrayList arrayList = this.b;
            if (!arrayList.contains(abstractC0277o4)) {
                arrayList.add(abstractC0277o4);
            }
        }
        this.a.put(view.getId(), view);
        this.h = true;
    }

    @Override // android.view.ViewGroup
    public void onViewRemoved(View view) {
        super.onViewRemoved(view);
        this.a.remove(view.getId());
        A4 h = h(view);
        this.c.q0.remove(h);
        h.C();
        this.b.remove(view);
        this.h = true;
    }

    @Override // android.view.View, android.view.ViewParent
    public final void requestLayout() {
        this.h = true;
        super.requestLayout();
    }

    public void setConstraintSet(C0485z4 c0485z4) {
        this.j = c0485z4;
    }

    @Override // android.view.View
    public void setId(int i) {
        int id = getId();
        SparseArray sparseArray = this.a;
        sparseArray.remove(id);
        super.setId(i);
        sparseArray.put(getId(), this);
    }

    public void setMaxHeight(int i) {
        if (i == this.g) {
            return;
        }
        this.g = i;
        requestLayout();
    }

    public void setMaxWidth(int i) {
        if (i == this.f) {
            return;
        }
        this.f = i;
        requestLayout();
    }

    public void setMinHeight(int i) {
        if (i == this.e) {
            return;
        }
        this.e = i;
        requestLayout();
    }

    public void setMinWidth(int i) {
        if (i == this.d) {
            return;
        }
        this.d = i;
        requestLayout();
    }

    public void setOnConstraintsChanged(C4 c4) {
        F1 f1 = this.k;
        if (f1 != null) {
            f1.getClass();
        }
    }

    public void setOptimizationLevel(int i) {
        this.i = i;
        B4 b4 = this.c;
        b4.D0 = i;
        C0170ia.q = b4.W(512);
    }

    @Override // android.view.ViewGroup
    public final boolean shouldDelayChildPressedState() {
        return false;
    }

    public ConstraintLayout(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.a = new SparseArray();
        this.b = new ArrayList(4);
        this.c = new B4();
        this.d = 0;
        this.e = 0;
        this.f = Integer.MAX_VALUE;
        this.g = Integer.MAX_VALUE;
        this.h = true;
        this.i = 257;
        this.j = null;
        this.k = null;
        this.l = -1;
        this.m = new HashMap();
        this.n = new SparseArray();
        this.o = new C0333r4(this, this);
        i(attributeSet, i);
    }

    /* JADX WARN: Type inference failed for: r0v0, types: [android.view.ViewGroup$LayoutParams, android.view.ViewGroup$MarginLayoutParams, x.q4] */
    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        ?? marginLayoutParams = new ViewGroup.MarginLayoutParams(layoutParams);
        marginLayoutParams.a = -1;
        marginLayoutParams.b = -1;
        marginLayoutParams.c = -1.0f;
        marginLayoutParams.d = true;
        marginLayoutParams.e = -1;
        marginLayoutParams.f = -1;
        marginLayoutParams.g = -1;
        marginLayoutParams.h = -1;
        marginLayoutParams.i = -1;
        marginLayoutParams.j = -1;
        marginLayoutParams.k = -1;
        marginLayoutParams.l = -1;
        marginLayoutParams.m = -1;
        marginLayoutParams.n = -1;
        marginLayoutParams.o = -1;
        marginLayoutParams.p = -1;
        marginLayoutParams.q = 0;
        marginLayoutParams.r = 0.0f;
        marginLayoutParams.s = -1;
        marginLayoutParams.t = -1;
        marginLayoutParams.u = -1;
        marginLayoutParams.v = -1;
        marginLayoutParams.w = Integer.MIN_VALUE;
        marginLayoutParams.f30x = Integer.MIN_VALUE;
        marginLayoutParams.y = Integer.MIN_VALUE;
        marginLayoutParams.z = Integer.MIN_VALUE;
        marginLayoutParams.A = Integer.MIN_VALUE;
        marginLayoutParams.B = Integer.MIN_VALUE;
        marginLayoutParams.C = Integer.MIN_VALUE;
        marginLayoutParams.D = 0;
        marginLayoutParams.E = 0.5f;
        marginLayoutParams.F = 0.5f;
        marginLayoutParams.G = null;
        marginLayoutParams.H = -1.0f;
        marginLayoutParams.I = -1.0f;
        marginLayoutParams.J = 0;
        marginLayoutParams.K = 0;
        marginLayoutParams.L = 0;
        marginLayoutParams.M = 0;
        marginLayoutParams.N = 0;
        marginLayoutParams.O = 0;
        marginLayoutParams.P = 0;
        marginLayoutParams.Q = 0;
        marginLayoutParams.R = 1.0f;
        marginLayoutParams.S = 1.0f;
        marginLayoutParams.T = -1;
        marginLayoutParams.U = -1;
        marginLayoutParams.V = -1;
        marginLayoutParams.W = false;
        marginLayoutParams.X = false;
        marginLayoutParams.Y = null;
        marginLayoutParams.Z = 0;
        marginLayoutParams.a0 = true;
        marginLayoutParams.b0 = true;
        marginLayoutParams.c0 = false;
        marginLayoutParams.d0 = false;
        marginLayoutParams.e0 = false;
        marginLayoutParams.f0 = -1;
        marginLayoutParams.g0 = -1;
        marginLayoutParams.h0 = -1;
        marginLayoutParams.i0 = -1;
        marginLayoutParams.j0 = Integer.MIN_VALUE;
        marginLayoutParams.k0 = Integer.MIN_VALUE;
        marginLayoutParams.l0 = 0.5f;
        marginLayoutParams.p0 = new A4();
        if (layoutParams instanceof ViewGroup.MarginLayoutParams) {
            ViewGroup.MarginLayoutParams marginLayoutParams2 = (ViewGroup.MarginLayoutParams) layoutParams;
            ((ViewGroup.MarginLayoutParams) marginLayoutParams).leftMargin = marginLayoutParams2.leftMargin;
            ((ViewGroup.MarginLayoutParams) marginLayoutParams).rightMargin = marginLayoutParams2.rightMargin;
            ((ViewGroup.MarginLayoutParams) marginLayoutParams).topMargin = marginLayoutParams2.topMargin;
            ((ViewGroup.MarginLayoutParams) marginLayoutParams).bottomMargin = marginLayoutParams2.bottomMargin;
            marginLayoutParams.setMarginStart(marginLayoutParams2.getMarginStart());
            marginLayoutParams.setMarginEnd(marginLayoutParams2.getMarginEnd());
        }
        if (layoutParams instanceof C0315q4) {
            C0315q4 c0315q4 = (C0315q4) layoutParams;
            marginLayoutParams.a = c0315q4.a;
            marginLayoutParams.b = c0315q4.b;
            marginLayoutParams.c = c0315q4.c;
            marginLayoutParams.d = c0315q4.d;
            marginLayoutParams.e = c0315q4.e;
            marginLayoutParams.f = c0315q4.f;
            marginLayoutParams.g = c0315q4.g;
            marginLayoutParams.h = c0315q4.h;
            marginLayoutParams.i = c0315q4.i;
            marginLayoutParams.j = c0315q4.j;
            marginLayoutParams.k = c0315q4.k;
            marginLayoutParams.l = c0315q4.l;
            marginLayoutParams.m = c0315q4.m;
            marginLayoutParams.n = c0315q4.n;
            marginLayoutParams.o = c0315q4.o;
            marginLayoutParams.p = c0315q4.p;
            marginLayoutParams.q = c0315q4.q;
            marginLayoutParams.r = c0315q4.r;
            marginLayoutParams.s = c0315q4.s;
            marginLayoutParams.t = c0315q4.t;
            marginLayoutParams.u = c0315q4.u;
            marginLayoutParams.v = c0315q4.v;
            marginLayoutParams.w = c0315q4.w;
            marginLayoutParams.f30x = c0315q4.f30x;
            marginLayoutParams.y = c0315q4.y;
            marginLayoutParams.z = c0315q4.z;
            marginLayoutParams.A = c0315q4.A;
            marginLayoutParams.B = c0315q4.B;
            marginLayoutParams.C = c0315q4.C;
            marginLayoutParams.D = c0315q4.D;
            marginLayoutParams.E = c0315q4.E;
            marginLayoutParams.F = c0315q4.F;
            marginLayoutParams.G = c0315q4.G;
            marginLayoutParams.H = c0315q4.H;
            marginLayoutParams.I = c0315q4.I;
            marginLayoutParams.J = c0315q4.J;
            marginLayoutParams.K = c0315q4.K;
            marginLayoutParams.W = c0315q4.W;
            marginLayoutParams.X = c0315q4.X;
            marginLayoutParams.L = c0315q4.L;
            marginLayoutParams.M = c0315q4.M;
            marginLayoutParams.N = c0315q4.N;
            marginLayoutParams.P = c0315q4.P;
            marginLayoutParams.O = c0315q4.O;
            marginLayoutParams.Q = c0315q4.Q;
            marginLayoutParams.R = c0315q4.R;
            marginLayoutParams.S = c0315q4.S;
            marginLayoutParams.T = c0315q4.T;
            marginLayoutParams.U = c0315q4.U;
            marginLayoutParams.V = c0315q4.V;
            marginLayoutParams.a0 = c0315q4.a0;
            marginLayoutParams.b0 = c0315q4.b0;
            marginLayoutParams.c0 = c0315q4.c0;
            marginLayoutParams.d0 = c0315q4.d0;
            marginLayoutParams.f0 = c0315q4.f0;
            marginLayoutParams.g0 = c0315q4.g0;
            marginLayoutParams.h0 = c0315q4.h0;
            marginLayoutParams.i0 = c0315q4.i0;
            marginLayoutParams.j0 = c0315q4.j0;
            marginLayoutParams.k0 = c0315q4.k0;
            marginLayoutParams.l0 = c0315q4.l0;
            marginLayoutParams.Y = c0315q4.Y;
            marginLayoutParams.Z = c0315q4.Z;
            marginLayoutParams.p0 = c0315q4.p0;
        }
        return marginLayoutParams;
    }
}
