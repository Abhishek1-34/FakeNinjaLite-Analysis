package androidx.constraintlayout.helper.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import x.A4;
import x.AbstractC0094ed;
import x.AbstractC0338r9;
import x.B4;
import x.C0239m4;
import x.C0263n9;
import x.C0333r4;
import x.F7;
import x.G7;
import x.Qh;
import x.V2;

/* loaded from: classes.dex */
public class Flow extends Qh {
    public final G7 j;

    /* JADX WARN: Type inference failed for: r1v0, types: [x.V2, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r8v1, types: [x.G7, x.r9] */
    public Flow(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.a = new int[32];
        this.g = new HashMap();
        this.c = context;
        super.g(attributeSet);
        ?? abstractC0338r9 = new AbstractC0338r9();
        abstractC0338r9.s0 = 0;
        abstractC0338r9.t0 = 0;
        abstractC0338r9.u0 = 0;
        abstractC0338r9.v0 = 0;
        abstractC0338r9.w0 = 0;
        abstractC0338r9.x0 = 0;
        abstractC0338r9.y0 = false;
        abstractC0338r9.z0 = 0;
        abstractC0338r9.A0 = 0;
        abstractC0338r9.B0 = new Object();
        abstractC0338r9.C0 = null;
        abstractC0338r9.D0 = -1;
        abstractC0338r9.E0 = -1;
        abstractC0338r9.F0 = -1;
        abstractC0338r9.G0 = -1;
        abstractC0338r9.H0 = -1;
        abstractC0338r9.I0 = -1;
        abstractC0338r9.J0 = 0.5f;
        abstractC0338r9.K0 = 0.5f;
        abstractC0338r9.L0 = 0.5f;
        abstractC0338r9.M0 = 0.5f;
        abstractC0338r9.N0 = 0.5f;
        abstractC0338r9.O0 = 0.5f;
        abstractC0338r9.P0 = 0;
        abstractC0338r9.Q0 = 0;
        abstractC0338r9.R0 = 2;
        abstractC0338r9.S0 = 2;
        abstractC0338r9.T0 = 0;
        abstractC0338r9.U0 = -1;
        abstractC0338r9.V0 = 0;
        abstractC0338r9.W0 = new ArrayList();
        abstractC0338r9.X0 = null;
        abstractC0338r9.Y0 = null;
        abstractC0338r9.Z0 = null;
        abstractC0338r9.b1 = 0;
        this.j = abstractC0338r9;
        if (attributeSet != null) {
            TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, AbstractC0094ed.b);
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i = 0; i < indexCount; i++) {
                int index = obtainStyledAttributes.getIndex(i);
                if (index == 0) {
                    this.j.V0 = obtainStyledAttributes.getInt(index, 0);
                } else if (index == 1) {
                    G7 g7 = this.j;
                    int dimensionPixelSize = obtainStyledAttributes.getDimensionPixelSize(index, 0);
                    g7.s0 = dimensionPixelSize;
                    g7.t0 = dimensionPixelSize;
                    g7.u0 = dimensionPixelSize;
                    g7.v0 = dimensionPixelSize;
                } else if (index == 18) {
                    G7 g72 = this.j;
                    int dimensionPixelSize2 = obtainStyledAttributes.getDimensionPixelSize(index, 0);
                    g72.u0 = dimensionPixelSize2;
                    g72.w0 = dimensionPixelSize2;
                    g72.x0 = dimensionPixelSize2;
                } else if (index == 19) {
                    this.j.v0 = obtainStyledAttributes.getDimensionPixelSize(index, 0);
                } else if (index == 2) {
                    this.j.w0 = obtainStyledAttributes.getDimensionPixelSize(index, 0);
                } else if (index == 3) {
                    this.j.s0 = obtainStyledAttributes.getDimensionPixelSize(index, 0);
                } else if (index == 4) {
                    this.j.x0 = obtainStyledAttributes.getDimensionPixelSize(index, 0);
                } else if (index == 5) {
                    this.j.t0 = obtainStyledAttributes.getDimensionPixelSize(index, 0);
                } else if (index == 54) {
                    this.j.T0 = obtainStyledAttributes.getInt(index, 0);
                } else if (index == 44) {
                    this.j.D0 = obtainStyledAttributes.getInt(index, 0);
                } else if (index == 53) {
                    this.j.E0 = obtainStyledAttributes.getInt(index, 0);
                } else if (index == 38) {
                    this.j.F0 = obtainStyledAttributes.getInt(index, 0);
                } else if (index == 46) {
                    this.j.H0 = obtainStyledAttributes.getInt(index, 0);
                } else if (index == 40) {
                    this.j.G0 = obtainStyledAttributes.getInt(index, 0);
                } else if (index == 48) {
                    this.j.I0 = obtainStyledAttributes.getInt(index, 0);
                } else if (index == 42) {
                    this.j.J0 = obtainStyledAttributes.getFloat(index, 0.5f);
                } else if (index == 37) {
                    this.j.L0 = obtainStyledAttributes.getFloat(index, 0.5f);
                } else if (index == 45) {
                    this.j.N0 = obtainStyledAttributes.getFloat(index, 0.5f);
                } else if (index == 39) {
                    this.j.M0 = obtainStyledAttributes.getFloat(index, 0.5f);
                } else if (index == 47) {
                    this.j.O0 = obtainStyledAttributes.getFloat(index, 0.5f);
                } else if (index == 51) {
                    this.j.K0 = obtainStyledAttributes.getFloat(index, 0.5f);
                } else if (index == 41) {
                    this.j.R0 = obtainStyledAttributes.getInt(index, 2);
                } else if (index == 50) {
                    this.j.S0 = obtainStyledAttributes.getInt(index, 2);
                } else if (index == 43) {
                    this.j.P0 = obtainStyledAttributes.getDimensionPixelSize(index, 0);
                } else if (index == 52) {
                    this.j.Q0 = obtainStyledAttributes.getDimensionPixelSize(index, 0);
                } else if (index == 49) {
                    this.j.U0 = obtainStyledAttributes.getInt(index, -1);
                }
            }
            obtainStyledAttributes.recycle();
        }
        this.d = this.j;
        i();
    }

    @Override // x.AbstractC0277o4
    public final void h(A4 a4, boolean z) {
        G7 g7 = this.j;
        int i = g7.u0;
        if (i > 0 || g7.v0 > 0) {
            if (z) {
                g7.w0 = g7.v0;
                g7.x0 = i;
            } else {
                g7.w0 = i;
                g7.x0 = g7.v0;
            }
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:83:0x07a8  */
    /* JADX WARN: Removed duplicated region for block: B:85:0x07c1  */
    /* JADX WARN: Removed duplicated region for block: B:88:0x07e0  */
    /* JADX WARN: Removed duplicated region for block: B:90:0x07e2  */
    /* JADX WARN: Removed duplicated region for block: B:91:0x07c4  */
    /* JADX WARN: Removed duplicated region for block: B:96:0x07ad  */
    /* JADX WARN: Type inference failed for: r2v6 */
    /* JADX WARN: Type inference failed for: r2v8 */
    /* JADX WARN: Type inference failed for: r2v9 */
    @Override // x.Qh
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void j(G7 g7, int i, int i2) {
        int i3;
        int i4;
        int i5;
        int i6;
        int i7;
        int i8;
        int i9;
        int i10;
        int i11;
        int[] iArr;
        F7 f7;
        char c;
        ?? r2;
        int i12;
        int i13;
        int i14;
        int i15;
        boolean z;
        int[] iArr2;
        int i16;
        int i17;
        boolean z2;
        A4[] a4Arr;
        int i18;
        boolean z3;
        int i19;
        ArrayList arrayList;
        boolean z4;
        int[] iArr3;
        A4 a4;
        int i20;
        int i21;
        int i22;
        int i23;
        boolean z5;
        Object obj;
        A4 a42;
        int i24;
        boolean z6;
        int i25;
        boolean z7;
        int i26;
        ArrayList arrayList2;
        int i27;
        boolean z8;
        int i28;
        int i29;
        A4 a43;
        int i30;
        int i31;
        C0333r4 c0333r4;
        int mode = View.MeasureSpec.getMode(i);
        int size = View.MeasureSpec.getSize(i);
        int mode2 = View.MeasureSpec.getMode(i2);
        int size2 = View.MeasureSpec.getSize(i2);
        if (g7 != null) {
            if (g7.r0 > 0) {
                A4 a44 = g7.T;
                if (a44 != null) {
                    c0333r4 = ((B4) a44).u0;
                } else {
                    c0333r4 = null;
                }
                if (c0333r4 == null) {
                    g7.z0 = 0;
                    g7.A0 = 0;
                    g7.y0 = false;
                    setMeasuredDimension(g7.z0, g7.A0);
                    return;
                }
                for (int i32 = 0; i32 < g7.r0; i32++) {
                    A4 a45 = g7.q0[i32];
                    if (a45 != null && !(a45 instanceof C0263n9)) {
                        int j = a45.j(0);
                        int j2 = a45.j(1);
                        if (j != 3 || a45.r == 1 || j2 != 3 || a45.s == 1) {
                            if (j == 3) {
                                j = 2;
                            }
                            if (j2 == 3) {
                                j2 = 2;
                            }
                            V2 v2 = g7.B0;
                            v2.a = j;
                            v2.b = j2;
                            v2.c = a45.q();
                            v2.d = a45.k();
                            c0333r4.b(a45, v2);
                            a45.O(v2.e);
                            a45.L(v2.f);
                            a45.I(v2.g);
                        }
                    }
                }
            }
            int i33 = g7.w0;
            int i34 = g7.x0;
            int i35 = g7.s0;
            int i36 = g7.t0;
            int[] iArr4 = new int[2];
            int i37 = (size - i33) - i34;
            int i38 = g7.V0;
            if (i38 == 1) {
                i37 = (size2 - i35) - i36;
            }
            if (i38 == 0) {
                if (g7.D0 == -1) {
                    g7.D0 = 0;
                }
                if (g7.E0 == -1) {
                    g7.E0 = 0;
                }
            } else {
                if (g7.D0 == -1) {
                    g7.D0 = 0;
                }
                if (g7.E0 == -1) {
                    g7.E0 = 0;
                }
            }
            A4[] a4Arr2 = g7.q0;
            int i39 = 0;
            int i40 = 0;
            while (true) {
                i3 = g7.r0;
                if (i39 >= i3) {
                    break;
                }
                if (g7.q0[i39].g0 == 8) {
                    i40++;
                }
                i39++;
            }
            if (i40 > 0) {
                a4Arr2 = new A4[i3 - i40];
                int i41 = 0;
                i3 = 0;
                while (i41 < g7.r0) {
                    A4 a46 = g7.q0[i41];
                    int i42 = i37;
                    int[] iArr5 = iArr4;
                    if (a46.g0 != 8) {
                        a4Arr2[i3] = a46;
                        i3++;
                    }
                    i41++;
                    i37 = i42;
                    iArr4 = iArr5;
                }
            }
            int i43 = i37;
            int[] iArr6 = iArr4;
            int i44 = i3;
            A4[] a4Arr3 = a4Arr2;
            g7.a1 = a4Arr3;
            g7.b1 = i44;
            int i45 = g7.T0;
            ArrayList arrayList3 = g7.W0;
            if (i45 != 0) {
                C0239m4 c0239m4 = g7.J;
                C0239m4 c0239m42 = g7.I;
                C0239m4 c0239m43 = g7.K;
                C0239m4 c0239m44 = g7.L;
                int[] iArr7 = g7.p0;
                if (i45 != 1) {
                    if (i45 != 2) {
                        if (i45 == 3) {
                            int i46 = g7.V0;
                            if (i44 != 0) {
                                arrayList3.clear();
                                i11 = size2;
                                int i47 = i43;
                                iArr = iArr6;
                                i4 = i36;
                                i5 = i35;
                                i6 = i34;
                                i7 = i33;
                                i10 = mode2;
                                ArrayList arrayList4 = arrayList3;
                                F7 f72 = new F7(g7, i46, g7.I, g7.J, g7.K, g7.L, i47);
                                arrayList4.add(f72);
                                if (i46 == 0) {
                                    int i48 = 0;
                                    i24 = 0;
                                    int i49 = 0;
                                    int i50 = 0;
                                    while (i50 < i44) {
                                        i48++;
                                        A4 a47 = a4Arr3[i50];
                                        int i51 = i47;
                                        int U = g7.U(a47, i51);
                                        if (a47.p0[0] == 3) {
                                            i24++;
                                        }
                                        int i52 = i24;
                                        if ((i49 == i51 || g7.P0 + i49 + U > i51) && f72.b != null) {
                                            z8 = true;
                                        } else {
                                            z8 = false;
                                        }
                                        if (!z8 && i50 > 0 && (i31 = g7.U0) > 0 && i48 > i31) {
                                            z8 = true;
                                        }
                                        if (z8) {
                                            i47 = i51;
                                            i29 = size;
                                            a43 = a47;
                                            i28 = mode;
                                            i30 = i50;
                                            f72 = new F7(g7, i46, g7.I, g7.J, g7.K, g7.L, i47);
                                            f72.n = i30;
                                            arrayList4.add(f72);
                                            i49 = U;
                                            i48 = 1;
                                        } else {
                                            i47 = i51;
                                            i28 = mode;
                                            i29 = size;
                                            a43 = a47;
                                            i30 = i50;
                                            if (i30 > 0) {
                                                i49 = g7.P0 + U + i49;
                                            } else {
                                                i49 = U;
                                            }
                                        }
                                        f72.a(a43);
                                        i50 = i30 + 1;
                                        i24 = i52;
                                        size = i29;
                                        mode = i28;
                                    }
                                    i8 = mode;
                                    i9 = size;
                                } else {
                                    i8 = mode;
                                    i9 = size;
                                    int i53 = 0;
                                    i24 = 0;
                                    int i54 = 0;
                                    int i55 = 0;
                                    while (i55 < i44) {
                                        i53++;
                                        A4 a48 = a4Arr3[i55];
                                        int i56 = i47;
                                        int T = g7.T(a48, i56);
                                        if (a48.p0[1] == 3) {
                                            i24++;
                                        }
                                        int i57 = i24;
                                        if ((i54 == i56 || g7.Q0 + i54 + T > i56) && f72.b != null) {
                                            z6 = true;
                                        } else {
                                            z6 = false;
                                        }
                                        if (!z6 && i55 > 0 && (i25 = g7.U0) > 0 && i53 > i25) {
                                            z6 = true;
                                        }
                                        if (z6) {
                                            i47 = i56;
                                            f72 = new F7(g7, i46, g7.I, g7.J, g7.K, g7.L, i56);
                                            f72.n = i55;
                                            arrayList4.add(f72);
                                            i54 = T;
                                            i53 = 1;
                                        } else {
                                            i47 = i56;
                                            if (i55 > 0) {
                                                i54 = g7.Q0 + T + i54;
                                            } else {
                                                i54 = T;
                                            }
                                        }
                                        f72.a(a48);
                                        i55++;
                                        i24 = i57;
                                    }
                                }
                                int size3 = arrayList4.size();
                                int i58 = g7.w0;
                                int i59 = g7.s0;
                                int i60 = g7.x0;
                                int i61 = g7.t0;
                                if (iArr7[0] != 2 && iArr7[1] != 2) {
                                    z7 = false;
                                } else {
                                    z7 = true;
                                }
                                if (i24 > 0 && z7) {
                                    int i62 = 0;
                                    while (i62 < size3) {
                                        F7 f73 = (F7) arrayList4.get(i62);
                                        if (i46 == 0) {
                                            i27 = i47;
                                            f73.e(i27 - f73.d());
                                        } else {
                                            i27 = i47;
                                            f73.e(i27 - f73.c());
                                        }
                                        i62++;
                                        i47 = i27;
                                    }
                                }
                                int i63 = i47;
                                C0239m4 c0239m45 = c0239m4;
                                C0239m4 c0239m46 = c0239m42;
                                C0239m4 c0239m47 = c0239m43;
                                C0239m4 c0239m48 = c0239m44;
                                int i64 = 0;
                                int i65 = 0;
                                int i66 = 0;
                                while (i64 < size3) {
                                    F7 f74 = (F7) arrayList4.get(i64);
                                    if (i46 == 0) {
                                        if (i64 < size3 - 1) {
                                            c0239m48 = ((F7) arrayList4.get(i64 + 1)).b.J;
                                            arrayList2 = arrayList4;
                                            i61 = 0;
                                        } else {
                                            i61 = g7.t0;
                                            arrayList2 = arrayList4;
                                            c0239m48 = c0239m44;
                                        }
                                        C0239m4 c0239m49 = f74.b.L;
                                        f74.f(i46, c0239m46, c0239m45, c0239m47, c0239m48, i58, i59, i60, i61, i63);
                                        int max = Math.max(i65, f74.d());
                                        int c2 = f74.c() + i66;
                                        if (i64 > 0) {
                                            c2 += g7.Q0;
                                        }
                                        i26 = size3;
                                        i65 = max;
                                        i66 = c2;
                                        c0239m45 = c0239m49;
                                        arrayList4 = arrayList2;
                                        i59 = 0;
                                    } else {
                                        ArrayList arrayList5 = arrayList4;
                                        if (i64 < size3 - 1) {
                                            arrayList4 = arrayList5;
                                            i26 = size3;
                                            c0239m47 = ((F7) arrayList4.get(i64 + 1)).b.I;
                                            i60 = 0;
                                        } else {
                                            arrayList4 = arrayList5;
                                            i60 = g7.x0;
                                            i26 = size3;
                                            c0239m47 = c0239m43;
                                        }
                                        C0239m4 c0239m410 = f74.b.K;
                                        f74.f(i46, c0239m46, c0239m45, c0239m47, c0239m48, i58, i59, i60, i61, i63);
                                        int d = f74.d() + i65;
                                        int max2 = Math.max(i66, f74.c());
                                        if (i64 > 0) {
                                            d += g7.P0;
                                        }
                                        i65 = d;
                                        c0239m46 = c0239m410;
                                        i66 = max2;
                                        i58 = 0;
                                    }
                                    i64++;
                                    size3 = i26;
                                }
                                iArr[0] = i65;
                                iArr[1] = i66;
                            }
                        }
                        i4 = i36;
                        i5 = i35;
                        i6 = i34;
                        i7 = i33;
                        i8 = mode;
                        i9 = size;
                        i10 = mode2;
                        i11 = size2;
                        iArr = iArr6;
                    } else {
                        i4 = i36;
                        i5 = i35;
                        i6 = i34;
                        i7 = i33;
                        i8 = mode;
                        i9 = size;
                        i10 = mode2;
                        i11 = size2;
                        iArr = iArr6;
                        int i67 = g7.V0;
                        if (i67 == 0) {
                            int i68 = g7.U0;
                            if (i68 <= 0) {
                                int i69 = 0;
                                i23 = 0;
                                for (int i70 = 0; i70 < i44; i70++) {
                                    if (i70 > 0) {
                                        i69 += g7.P0;
                                    }
                                    A4 a49 = a4Arr3[i70];
                                    if (a49 != null) {
                                        int U2 = g7.U(a49, i43) + i69;
                                        if (U2 > i43) {
                                            break;
                                        }
                                        i23++;
                                        i69 = U2;
                                    }
                                }
                            } else {
                                i23 = i68;
                            }
                            i22 = 0;
                        } else {
                            i22 = g7.U0;
                            if (i22 <= 0) {
                                int i71 = 0;
                                int i72 = 0;
                                for (int i73 = 0; i73 < i44; i73++) {
                                    if (i73 > 0) {
                                        i71 += g7.Q0;
                                    }
                                    A4 a410 = a4Arr3[i73];
                                    if (a410 != null) {
                                        int T2 = g7.T(a410, i43) + i71;
                                        if (T2 > i43) {
                                            break;
                                        }
                                        i72++;
                                        i71 = T2;
                                    }
                                }
                                i22 = i72;
                            }
                            i23 = 0;
                        }
                        if (g7.Z0 == null) {
                            g7.Z0 = new int[2];
                        }
                        if ((i22 == 0 && i67 == 1) || (i23 == 0 && i67 == 0)) {
                            z5 = true;
                        } else {
                            z5 = false;
                        }
                        while (!z5) {
                            if (i67 == 0) {
                                i22 = (int) Math.ceil(i44 / i23);
                            } else {
                                i23 = (int) Math.ceil(i44 / i22);
                            }
                            A4[] a4Arr4 = g7.Y0;
                            if (a4Arr4 == null || a4Arr4.length < i23) {
                                obj = null;
                                g7.Y0 = new A4[i23];
                            } else {
                                obj = null;
                                Arrays.fill(a4Arr4, (Object) null);
                            }
                            A4[] a4Arr5 = g7.X0;
                            if (a4Arr5 != null && a4Arr5.length >= i22) {
                                Arrays.fill(a4Arr5, obj);
                            } else {
                                g7.X0 = new A4[i22];
                            }
                            for (int i74 = 0; i74 < i23; i74++) {
                                for (int i75 = 0; i75 < i22; i75++) {
                                    int i76 = (i75 * i23) + i74;
                                    if (i67 == 1) {
                                        i76 = (i74 * i22) + i75;
                                    }
                                    if (i76 < a4Arr3.length && (a42 = a4Arr3[i76]) != null) {
                                        int U3 = g7.U(a42, i43);
                                        A4 a411 = g7.Y0[i74];
                                        if (a411 == null || a411.q() < U3) {
                                            g7.Y0[i74] = a42;
                                        }
                                        int T3 = g7.T(a42, i43);
                                        A4 a412 = g7.X0[i75];
                                        if (a412 == null || a412.k() < T3) {
                                            g7.X0[i75] = a42;
                                        }
                                    }
                                }
                            }
                            int i77 = 0;
                            for (int i78 = 0; i78 < i23; i78++) {
                                A4 a413 = g7.Y0[i78];
                                if (a413 != null) {
                                    if (i78 > 0) {
                                        i77 += g7.P0;
                                    }
                                    i77 = g7.U(a413, i43) + i77;
                                }
                            }
                            int i79 = 0;
                            for (int i80 = 0; i80 < i22; i80++) {
                                A4 a414 = g7.X0[i80];
                                if (a414 != null) {
                                    if (i80 > 0) {
                                        i79 += g7.Q0;
                                    }
                                    i79 = g7.T(a414, i43) + i79;
                                }
                            }
                            iArr[0] = i77;
                            iArr[1] = i79;
                            if (i67 == 0) {
                                if (i77 > i43 && i23 > 1) {
                                    i23--;
                                }
                                z5 = true;
                            } else {
                                if (i79 > i43 && i22 > 1) {
                                    i22--;
                                }
                                z5 = true;
                            }
                        }
                        int[] iArr8 = g7.Z0;
                        iArr8[0] = i23;
                        iArr8[1] = i22;
                    }
                } else {
                    i4 = i36;
                    i5 = i35;
                    i6 = i34;
                    i7 = i33;
                    i8 = mode;
                    i9 = size;
                    i10 = mode2;
                    i11 = size2;
                    iArr = iArr6;
                    ArrayList arrayList6 = arrayList3;
                    int i81 = g7.V0;
                    if (i44 != 0) {
                        arrayList6.clear();
                        F7 f75 = new F7(g7, i81, g7.I, g7.J, g7.K, g7.L, i43);
                        arrayList6.add(f75);
                        if (i81 == 0) {
                            F7 f76 = f75;
                            i17 = 0;
                            int i82 = 0;
                            int i83 = 0;
                            while (i83 < i44) {
                                A4 a415 = a4Arr3[i83];
                                int U4 = g7.U(a415, i43);
                                if (a415.p0[0] == 3) {
                                    i17++;
                                }
                                int i84 = i17;
                                if ((i82 == i43 || g7.P0 + i82 + U4 > i43) && f76.b != null) {
                                    z4 = true;
                                } else {
                                    z4 = false;
                                }
                                if (!z4 && i83 > 0 && (i21 = g7.U0) > 0 && i83 % i21 == 0) {
                                    z4 = true;
                                }
                                if (z4) {
                                    iArr3 = iArr7;
                                    a4 = a415;
                                    i20 = i81;
                                    F7 f77 = new F7(g7, i81, g7.I, g7.J, g7.K, g7.L, i43);
                                    f77.n = i83;
                                    arrayList6.add(f77);
                                    f76 = f77;
                                } else {
                                    iArr3 = iArr7;
                                    a4 = a415;
                                    i20 = i81;
                                    if (i83 > 0) {
                                        i82 = g7.P0 + U4 + i82;
                                        f76.a(a4);
                                        i83++;
                                        i17 = i84;
                                        iArr7 = iArr3;
                                        i81 = i20;
                                    }
                                }
                                i82 = U4;
                                f76.a(a4);
                                i83++;
                                i17 = i84;
                                iArr7 = iArr3;
                                i81 = i20;
                            }
                            iArr2 = iArr7;
                            i16 = i81;
                        } else {
                            iArr2 = iArr7;
                            i16 = i81;
                            F7 f78 = f75;
                            int i85 = 0;
                            i17 = 0;
                            int i86 = 0;
                            while (i85 < i44) {
                                A4 a416 = a4Arr3[i85];
                                int T4 = g7.T(a416, i43);
                                if (a416.p0[1] == 3) {
                                    i17++;
                                }
                                int i87 = i17;
                                if ((i86 == i43 || g7.Q0 + i86 + T4 > i43) && f78.b != null) {
                                    z2 = true;
                                } else {
                                    z2 = false;
                                }
                                if (!z2 && i85 > 0 && (i18 = g7.U0) > 0 && i85 % i18 == 0) {
                                    z2 = true;
                                }
                                if (z2) {
                                    a4Arr = a4Arr3;
                                    F7 f79 = new F7(g7, i16, g7.I, g7.J, g7.K, g7.L, i43);
                                    f79.n = i85;
                                    arrayList6.add(f79);
                                    i86 = T4;
                                    f78 = f79;
                                } else {
                                    a4Arr = a4Arr3;
                                    if (i85 > 0) {
                                        i86 = g7.Q0 + T4 + i86;
                                    } else {
                                        i86 = T4;
                                    }
                                }
                                f78.a(a416);
                                i85++;
                                i17 = i87;
                                a4Arr3 = a4Arr;
                            }
                        }
                        int size4 = arrayList6.size();
                        int i88 = g7.w0;
                        int i89 = g7.s0;
                        int i90 = g7.x0;
                        int i91 = g7.t0;
                        if (iArr2[0] != 2 && iArr2[1] != 2) {
                            z3 = false;
                        } else {
                            z3 = true;
                        }
                        if (i17 > 0 && z3) {
                            for (int i92 = 0; i92 < size4; i92++) {
                                F7 f710 = (F7) arrayList6.get(i92);
                                if (i16 == 0) {
                                    f710.e(i43 - f710.d());
                                } else {
                                    f710.e(i43 - f710.c());
                                }
                            }
                        }
                        int i93 = i89;
                        C0239m4 c0239m411 = c0239m42;
                        C0239m4 c0239m412 = c0239m43;
                        C0239m4 c0239m413 = c0239m44;
                        int i94 = 0;
                        int i95 = 0;
                        int i96 = 0;
                        int i97 = i88;
                        C0239m4 c0239m414 = c0239m4;
                        while (i94 < size4) {
                            F7 f711 = (F7) arrayList6.get(i94);
                            if (i16 == 0) {
                                if (i94 < size4 - 1) {
                                    c0239m413 = ((F7) arrayList6.get(i94 + 1)).b.J;
                                    arrayList = arrayList6;
                                    i91 = 0;
                                } else {
                                    i91 = g7.t0;
                                    arrayList = arrayList6;
                                    c0239m413 = c0239m44;
                                }
                                C0239m4 c0239m415 = f711.b.L;
                                f711.f(i16, c0239m411, c0239m414, c0239m412, c0239m413, i97, i93, i90, i91, i43);
                                int max3 = Math.max(i95, f711.d());
                                int c3 = f711.c() + i96;
                                if (i94 > 0) {
                                    c3 += g7.Q0;
                                }
                                i19 = size4;
                                i95 = max3;
                                i96 = c3;
                                c0239m414 = c0239m415;
                                arrayList6 = arrayList;
                                i93 = 0;
                            } else {
                                ArrayList arrayList7 = arrayList6;
                                if (i94 < size4 - 1) {
                                    arrayList6 = arrayList7;
                                    i19 = size4;
                                    c0239m412 = ((F7) arrayList6.get(i94 + 1)).b.I;
                                    i90 = 0;
                                } else {
                                    arrayList6 = arrayList7;
                                    i90 = g7.x0;
                                    i19 = size4;
                                    c0239m412 = c0239m43;
                                }
                                C0239m4 c0239m416 = f711.b.K;
                                f711.f(i16, c0239m411, c0239m414, c0239m412, c0239m413, i97, i93, i90, i91, i43);
                                int d2 = f711.d() + i95;
                                int max4 = Math.max(i96, f711.c());
                                if (i94 > 0) {
                                    d2 += g7.P0;
                                }
                                i95 = d2;
                                i96 = max4;
                                i97 = 0;
                                c0239m411 = c0239m416;
                            }
                            i94++;
                            size4 = i19;
                        }
                        iArr[0] = i95;
                        iArr[1] = i96;
                    }
                }
            } else {
                i4 = i36;
                i5 = i35;
                i6 = i34;
                i7 = i33;
                i8 = mode;
                i9 = size;
                i10 = mode2;
                i11 = size2;
                iArr = iArr6;
                int i98 = g7.V0;
                if (i44 != 0) {
                    if (arrayList3.size() == 0) {
                        f7 = new F7(g7, i98, g7.I, g7.J, g7.K, g7.L, i43);
                        arrayList3.add(f7);
                    } else {
                        f7 = (F7) arrayList3.get(0);
                        f7.c = 0;
                        f7.b = null;
                        f7.l = 0;
                        f7.m = 0;
                        f7.n = 0;
                        f7.o = 0;
                        f7.p = 0;
                        f7.f(i98, g7.I, g7.J, g7.K, g7.L, g7.w0, g7.s0, g7.x0, g7.t0, i43);
                    }
                    for (int i99 = 0; i99 < i44; i99++) {
                        f7.a(a4Arr3[i99]);
                    }
                    c = 0;
                    iArr[0] = f7.d();
                    r2 = 1;
                    iArr[1] = f7.c();
                    int i100 = iArr[c] + i7 + i6;
                    int i101 = iArr[r2] + i5 + i4;
                    i12 = i8;
                    if (i12 != 1073741824) {
                        i13 = i10;
                        i14 = i9;
                    } else {
                        if (i12 == Integer.MIN_VALUE) {
                            i14 = Math.min(i100, i9);
                        } else if (i12 == 0) {
                            i14 = i100;
                        } else {
                            i13 = i10;
                            i14 = 0;
                        }
                        i13 = i10;
                    }
                    if (i13 != 1073741824) {
                        i15 = i11;
                    } else if (i13 == Integer.MIN_VALUE) {
                        i15 = Math.min(i101, i11);
                    } else if (i13 == 0) {
                        i15 = i101;
                    } else {
                        i15 = 0;
                    }
                    g7.z0 = i14;
                    g7.A0 = i15;
                    g7.O(i14);
                    g7.L(i15);
                    if (g7.r0 <= 0) {
                        z = r2;
                    } else {
                        z = false;
                    }
                    g7.y0 = z;
                    setMeasuredDimension(g7.z0, g7.A0);
                    return;
                }
            }
            c = 0;
            r2 = 1;
            int i1002 = iArr[c] + i7 + i6;
            int i1012 = iArr[r2] + i5 + i4;
            i12 = i8;
            if (i12 != 1073741824) {
            }
            if (i13 != 1073741824) {
            }
            g7.z0 = i14;
            g7.A0 = i15;
            g7.O(i14);
            g7.L(i15);
            if (g7.r0 <= 0) {
            }
            g7.y0 = z;
            setMeasuredDimension(g7.z0, g7.A0);
            return;
        }
        setMeasuredDimension(0, 0);
    }

    @Override // x.AbstractC0277o4, android.view.View
    public final void onMeasure(int i, int i2) {
        j(this.j, i, i2);
    }

    public void setFirstHorizontalBias(float f) {
        this.j.L0 = f;
        requestLayout();
    }

    public void setFirstHorizontalStyle(int i) {
        this.j.F0 = i;
        requestLayout();
    }

    public void setFirstVerticalBias(float f) {
        this.j.M0 = f;
        requestLayout();
    }

    public void setFirstVerticalStyle(int i) {
        this.j.G0 = i;
        requestLayout();
    }

    public void setHorizontalAlign(int i) {
        this.j.R0 = i;
        requestLayout();
    }

    public void setHorizontalBias(float f) {
        this.j.J0 = f;
        requestLayout();
    }

    public void setHorizontalGap(int i) {
        this.j.P0 = i;
        requestLayout();
    }

    public void setHorizontalStyle(int i) {
        this.j.D0 = i;
        requestLayout();
    }

    public void setLastHorizontalBias(float f) {
        this.j.N0 = f;
        requestLayout();
    }

    public void setLastHorizontalStyle(int i) {
        this.j.H0 = i;
        requestLayout();
    }

    public void setLastVerticalBias(float f) {
        this.j.O0 = f;
        requestLayout();
    }

    public void setLastVerticalStyle(int i) {
        this.j.I0 = i;
        requestLayout();
    }

    public void setMaxElementsWrap(int i) {
        this.j.U0 = i;
        requestLayout();
    }

    public void setOrientation(int i) {
        this.j.V0 = i;
        requestLayout();
    }

    public void setPadding(int i) {
        G7 g7 = this.j;
        g7.s0 = i;
        g7.t0 = i;
        g7.u0 = i;
        g7.v0 = i;
        requestLayout();
    }

    public void setPaddingBottom(int i) {
        this.j.t0 = i;
        requestLayout();
    }

    public void setPaddingLeft(int i) {
        this.j.w0 = i;
        requestLayout();
    }

    public void setPaddingRight(int i) {
        this.j.x0 = i;
        requestLayout();
    }

    public void setPaddingTop(int i) {
        this.j.s0 = i;
        requestLayout();
    }

    public void setVerticalAlign(int i) {
        this.j.S0 = i;
        requestLayout();
    }

    public void setVerticalBias(float f) {
        this.j.K0 = f;
        requestLayout();
    }

    public void setVerticalGap(int i) {
        this.j.Q0 = i;
        requestLayout();
    }

    public void setVerticalStyle(int i) {
        this.j.E0 = i;
        requestLayout();
    }

    public void setWrapMode(int i) {
        this.j.T0 = i;
        requestLayout();
    }
}
