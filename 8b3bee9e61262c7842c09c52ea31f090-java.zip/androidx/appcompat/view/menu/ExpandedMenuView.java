package androidx.appcompat.view.menu;

import android.R;
import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import x.C0294p2;
import x.C0303pb;
import x.Eb;
import x.InterfaceC0227lb;
import x.MenuC0246mb;

/* loaded from: classes.dex */
public final class ExpandedMenuView extends ListView implements InterfaceC0227lb, Eb, AdapterView.OnItemClickListener {
    public static final int[] b = {R.attr.background, R.attr.divider};
    public MenuC0246mb a;

    public ExpandedMenuView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        setOnItemClickListener(this);
        C0294p2 y = C0294p2.y(context, attributeSet, b, R.attr.listViewStyle);
        TypedArray typedArray = (TypedArray) y.b;
        if (typedArray.hasValue(0)) {
            setBackgroundDrawable(y.o(0));
        }
        if (typedArray.hasValue(1)) {
            setDivider(y.o(1));
        }
        y.A();
    }

    @Override // x.Eb
    public final void a(MenuC0246mb menuC0246mb) {
        this.a = menuC0246mb;
    }

    @Override // x.InterfaceC0227lb
    public final boolean b(C0303pb c0303pb) {
        return this.a.q(c0303pb, null, 0);
    }

    public int getWindowAnimations() {
        return 0;
    }

    @Override // android.widget.ListView, android.widget.AbsListView, android.widget.AdapterView, android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        setChildrenDrawingCacheEnabled(false);
    }

    @Override // android.widget.AdapterView.OnItemClickListener
    public final void onItemClick(AdapterView adapterView, View view, int i, long j) {
        b((C0303pb) getAdapter().getItem(i));
    }
}
