package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.WeakHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import org.conscrypt.R;
import x.A1;
import x.AbstractC0060d;
import x.AbstractC0124g3;
import x.AbstractC0171ib;
import x.AbstractC0210kd;
import x.AbstractC0309ph;
import x.C0017ag;
import x.C0041c0;
import x.C0057cg;
import x.C0123g2;
import x.C0174ie;
import x.C0262n8;
import x.C0294p2;
import x.C0303pb;
import x.C0458xf;
import x.C1;
import x.I2;
import x.Ih;
import x.InterfaceC0066d5;
import x.MenuC0246mb;
import x.O;
import x.Qa;
import x.Uf;
import x.Vf;
import x.Wf;
import x.Xf;
import x.Yf;
import x.Zf;

/* loaded from: classes.dex */
public class Toolbar extends ViewGroup {
    public ColorStateList A;
    public boolean B;
    public boolean C;
    public final ArrayList D;
    public final ArrayList E;
    public final int[] F;
    public final C0294p2 G;
    public ArrayList H;
    public final Vf I;
    public C0057cg J;
    public C0041c0 K;
    public Xf L;
    public boolean M;
    public OnBackInvokedCallback N;
    public OnBackInvokedDispatcher O;
    public boolean P;
    public final I2 Q;
    public ActionMenuView a;
    public C0123g2 b;
    public C0123g2 c;
    public A1 d;
    public C1 e;
    public final Drawable f;
    public final CharSequence g;
    public A1 h;
    public View i;
    public Context j;
    public int k;
    public int l;
    public int m;
    public final int n;
    public final int o;
    public int p;
    public int q;
    public int r;
    public int s;
    public C0174ie t;
    public int u;
    public int v;
    public final int w;

    /* renamed from: x, reason: collision with root package name */
    public CharSequence f3x;
    public CharSequence y;
    public ColorStateList z;

    public Toolbar(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    private ArrayList<MenuItem> getCurrentMenuItems() {
        ArrayList<MenuItem> arrayList = new ArrayList<>();
        Menu menu = getMenu();
        for (int i = 0; i < menu.size(); i++) {
            arrayList.add(menu.getItem(i));
        }
        return arrayList;
    }

    private MenuInflater getMenuInflater() {
        return new C0458xf(getContext());
    }

    /* JADX WARN: Type inference failed for: r0v0, types: [x.Yf, android.view.ViewGroup$MarginLayoutParams] */
    public static Yf h() {
        ?? marginLayoutParams = new ViewGroup.MarginLayoutParams(-2, -2);
        marginLayoutParams.b = 0;
        marginLayoutParams.a = 8388627;
        return marginLayoutParams;
    }

    public static Yf i(ViewGroup.LayoutParams layoutParams) {
        boolean z = layoutParams instanceof Yf;
        if (z) {
            Yf yf = (Yf) layoutParams;
            Yf yf2 = new Yf(yf);
            yf2.b = 0;
            yf2.b = yf.b;
            return yf2;
        }
        if (z) {
            Yf yf3 = new Yf((Yf) layoutParams);
            yf3.b = 0;
            return yf3;
        }
        if (layoutParams instanceof ViewGroup.MarginLayoutParams) {
            ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) layoutParams;
            Yf yf4 = new Yf(marginLayoutParams);
            yf4.b = 0;
            ((ViewGroup.MarginLayoutParams) yf4).leftMargin = marginLayoutParams.leftMargin;
            ((ViewGroup.MarginLayoutParams) yf4).topMargin = marginLayoutParams.topMargin;
            ((ViewGroup.MarginLayoutParams) yf4).rightMargin = marginLayoutParams.rightMargin;
            ((ViewGroup.MarginLayoutParams) yf4).bottomMargin = marginLayoutParams.bottomMargin;
            return yf4;
        }
        Yf yf5 = new Yf(layoutParams);
        yf5.b = 0;
        return yf5;
    }

    public static int k(View view) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        return marginLayoutParams.getMarginEnd() + marginLayoutParams.getMarginStart();
    }

    public static int l(View view) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        return marginLayoutParams.topMargin + marginLayoutParams.bottomMargin;
    }

    public final void a(ArrayList arrayList, int i) {
        boolean z;
        if (getLayoutDirection() == 1) {
            z = true;
        } else {
            z = false;
        }
        int childCount = getChildCount();
        int absoluteGravity = Gravity.getAbsoluteGravity(i, getLayoutDirection());
        arrayList.clear();
        if (z) {
            for (int i2 = childCount - 1; i2 >= 0; i2--) {
                View childAt = getChildAt(i2);
                Yf yf = (Yf) childAt.getLayoutParams();
                if (yf.b == 0 && t(childAt)) {
                    int i3 = yf.a;
                    int layoutDirection = getLayoutDirection();
                    int absoluteGravity2 = Gravity.getAbsoluteGravity(i3, layoutDirection) & 7;
                    if (absoluteGravity2 != 1 && absoluteGravity2 != 3 && absoluteGravity2 != 5) {
                        absoluteGravity2 = layoutDirection == 1 ? 5 : 3;
                    }
                    if (absoluteGravity2 == absoluteGravity) {
                        arrayList.add(childAt);
                    }
                }
            }
            return;
        }
        for (int i4 = 0; i4 < childCount; i4++) {
            View childAt2 = getChildAt(i4);
            Yf yf2 = (Yf) childAt2.getLayoutParams();
            if (yf2.b == 0 && t(childAt2)) {
                int i5 = yf2.a;
                int layoutDirection2 = getLayoutDirection();
                int absoluteGravity3 = Gravity.getAbsoluteGravity(i5, layoutDirection2) & 7;
                if (absoluteGravity3 != 1 && absoluteGravity3 != 3 && absoluteGravity3 != 5) {
                    absoluteGravity3 = layoutDirection2 == 1 ? 5 : 3;
                }
                if (absoluteGravity3 == absoluteGravity) {
                    arrayList.add(childAt2);
                }
            }
        }
    }

    public final void b(View view, boolean z) {
        Yf yf;
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        if (layoutParams == null) {
            yf = h();
        } else if (!checkLayoutParams(layoutParams)) {
            yf = i(layoutParams);
        } else {
            yf = (Yf) layoutParams;
        }
        yf.b = 1;
        if (z && this.i != null) {
            view.setLayoutParams(yf);
            this.E.add(view);
        } else {
            addView(view, yf);
        }
    }

    public final void c() {
        if (this.h == null) {
            A1 a1 = new A1(getContext(), null, R.attr.toolbarNavigationButtonStyle);
            this.h = a1;
            a1.setImageDrawable(this.f);
            this.h.setContentDescription(this.g);
            Yf h = h();
            h.a = (this.n & 112) | 8388611;
            h.b = 2;
            this.h.setLayoutParams(h);
            this.h.setOnClickListener(new O(3, this));
        }
    }

    @Override // android.view.ViewGroup
    public final boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        if (super.checkLayoutParams(layoutParams) && (layoutParams instanceof Yf)) {
            return true;
        }
        return false;
    }

    /* JADX WARN: Type inference failed for: r0v1, types: [x.ie, java.lang.Object] */
    public final void d() {
        if (this.t == null) {
            ?? obj = new Object();
            obj.a = 0;
            obj.b = 0;
            obj.c = Integer.MIN_VALUE;
            obj.d = Integer.MIN_VALUE;
            obj.e = 0;
            obj.f = 0;
            obj.g = false;
            obj.h = false;
            this.t = obj;
        }
    }

    public final void e() {
        f();
        ActionMenuView actionMenuView = this.a;
        if (actionMenuView.p == null) {
            MenuC0246mb menuC0246mb = (MenuC0246mb) actionMenuView.getMenu();
            if (this.L == null) {
                this.L = new Xf(this);
            }
            this.a.setExpandedActionViewsExclusive(true);
            menuC0246mb.b(this.L, this.j);
            u();
        }
    }

    public final void f() {
        if (this.a == null) {
            ActionMenuView actionMenuView = new ActionMenuView(getContext(), null);
            this.a = actionMenuView;
            actionMenuView.setPopupTheme(this.k);
            this.a.setOnMenuItemClickListener(this.I);
            ActionMenuView actionMenuView2 = this.a;
            Vf vf = new Vf(this);
            actionMenuView2.getClass();
            actionMenuView2.u = vf;
            Yf h = h();
            h.a = (this.n & 112) | 8388613;
            this.a.setLayoutParams(h);
            b(this.a, false);
        }
    }

    public final void g() {
        if (this.d == null) {
            this.d = new A1(getContext(), null, R.attr.toolbarNavigationButtonStyle);
            Yf h = h();
            h.a = (this.n & 112) | 8388611;
            this.d.setLayoutParams(h);
        }
    }

    @Override // android.view.ViewGroup
    public final /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return h();
    }

    @Override // android.view.ViewGroup
    public final /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return i(layoutParams);
    }

    public CharSequence getCollapseContentDescription() {
        A1 a1 = this.h;
        if (a1 != null) {
            return a1.getContentDescription();
        }
        return null;
    }

    public Drawable getCollapseIcon() {
        A1 a1 = this.h;
        if (a1 != null) {
            return a1.getDrawable();
        }
        return null;
    }

    public int getContentInsetEnd() {
        C0174ie c0174ie = this.t;
        if (c0174ie != null) {
            if (c0174ie.g) {
                return c0174ie.a;
            }
            return c0174ie.b;
        }
        return 0;
    }

    public int getContentInsetEndWithActions() {
        int i = this.v;
        if (i == Integer.MIN_VALUE) {
            return getContentInsetEnd();
        }
        return i;
    }

    public int getContentInsetLeft() {
        C0174ie c0174ie = this.t;
        if (c0174ie != null) {
            return c0174ie.a;
        }
        return 0;
    }

    public int getContentInsetRight() {
        C0174ie c0174ie = this.t;
        if (c0174ie != null) {
            return c0174ie.b;
        }
        return 0;
    }

    public int getContentInsetStart() {
        C0174ie c0174ie = this.t;
        if (c0174ie != null) {
            if (c0174ie.g) {
                return c0174ie.b;
            }
            return c0174ie.a;
        }
        return 0;
    }

    public int getContentInsetStartWithNavigation() {
        int i = this.u;
        if (i == Integer.MIN_VALUE) {
            return getContentInsetStart();
        }
        return i;
    }

    public int getCurrentContentInsetEnd() {
        MenuC0246mb menuC0246mb;
        ActionMenuView actionMenuView = this.a;
        if (actionMenuView != null && (menuC0246mb = actionMenuView.p) != null && menuC0246mb.hasVisibleItems()) {
            return Math.max(getContentInsetEnd(), Math.max(this.v, 0));
        }
        return getContentInsetEnd();
    }

    public int getCurrentContentInsetLeft() {
        if (getLayoutDirection() == 1) {
            return getCurrentContentInsetEnd();
        }
        return getCurrentContentInsetStart();
    }

    public int getCurrentContentInsetRight() {
        if (getLayoutDirection() == 1) {
            return getCurrentContentInsetStart();
        }
        return getCurrentContentInsetEnd();
    }

    public int getCurrentContentInsetStart() {
        if (getNavigationIcon() != null) {
            return Math.max(getContentInsetStart(), Math.max(this.u, 0));
        }
        return getContentInsetStart();
    }

    public Drawable getLogo() {
        C1 c1 = this.e;
        if (c1 != null) {
            return c1.getDrawable();
        }
        return null;
    }

    public CharSequence getLogoDescription() {
        C1 c1 = this.e;
        if (c1 != null) {
            return c1.getContentDescription();
        }
        return null;
    }

    public Menu getMenu() {
        e();
        return this.a.getMenu();
    }

    public View getNavButtonView() {
        return this.d;
    }

    public CharSequence getNavigationContentDescription() {
        A1 a1 = this.d;
        if (a1 != null) {
            return a1.getContentDescription();
        }
        return null;
    }

    public Drawable getNavigationIcon() {
        A1 a1 = this.d;
        if (a1 != null) {
            return a1.getDrawable();
        }
        return null;
    }

    public C0041c0 getOuterActionMenuPresenter() {
        return this.K;
    }

    public Drawable getOverflowIcon() {
        e();
        return this.a.getOverflowIcon();
    }

    public Context getPopupContext() {
        return this.j;
    }

    public int getPopupTheme() {
        return this.k;
    }

    public CharSequence getSubtitle() {
        return this.y;
    }

    public final TextView getSubtitleTextView() {
        return this.c;
    }

    public CharSequence getTitle() {
        return this.f3x;
    }

    public int getTitleMarginBottom() {
        return this.s;
    }

    public int getTitleMarginEnd() {
        return this.q;
    }

    public int getTitleMarginStart() {
        return this.p;
    }

    public int getTitleMarginTop() {
        return this.r;
    }

    public final TextView getTitleTextView() {
        return this.b;
    }

    /* JADX WARN: Type inference failed for: r0v2, types: [java.lang.Object, x.cg] */
    public InterfaceC0066d5 getWrapper() {
        boolean z;
        Drawable drawable;
        if (this.J == null) {
            ?? obj = new Object();
            obj.n = 0;
            obj.a = this;
            obj.h = getTitle();
            obj.i = getSubtitle();
            if (obj.h != null) {
                z = true;
            } else {
                z = false;
            }
            obj.g = z;
            obj.f = getNavigationIcon();
            String str = null;
            C0294p2 y = C0294p2.y(getContext(), null, AbstractC0210kd.a, R.attr.actionBarStyle);
            obj.o = y.o(15);
            TypedArray typedArray = (TypedArray) y.b;
            CharSequence text = typedArray.getText(27);
            if (!TextUtils.isEmpty(text)) {
                obj.g = true;
                obj.h = text;
                if ((obj.b & 8) != 0) {
                    Toolbar toolbar = obj.a;
                    toolbar.setTitle(text);
                    if (obj.g) {
                        AbstractC0309ph.m(toolbar.getRootView(), text);
                    }
                }
            }
            CharSequence text2 = typedArray.getText(25);
            if (!TextUtils.isEmpty(text2)) {
                obj.i = text2;
                if ((obj.b & 8) != 0) {
                    setSubtitle(text2);
                }
            }
            Drawable o = y.o(20);
            if (o != null) {
                obj.e = o;
                obj.c();
            }
            Drawable o2 = y.o(17);
            if (o2 != null) {
                obj.d = o2;
                obj.c();
            }
            if (obj.f == null && (drawable = obj.o) != null) {
                obj.f = drawable;
                int i = obj.b & 4;
                Toolbar toolbar2 = obj.a;
                if (i != 0) {
                    toolbar2.setNavigationIcon(drawable);
                } else {
                    toolbar2.setNavigationIcon((Drawable) null);
                }
            }
            obj.a(typedArray.getInt(10, 0));
            int resourceId = typedArray.getResourceId(9, 0);
            if (resourceId != 0) {
                View inflate = LayoutInflater.from(getContext()).inflate(resourceId, (ViewGroup) this, false);
                View view = obj.c;
                if (view != null && (obj.b & 16) != 0) {
                    removeView(view);
                }
                obj.c = inflate;
                if (inflate != null && (obj.b & 16) != 0) {
                    addView(inflate);
                }
                obj.a(obj.b | 16);
            }
            int layoutDimension = typedArray.getLayoutDimension(13, 0);
            if (layoutDimension > 0) {
                ViewGroup.LayoutParams layoutParams = getLayoutParams();
                layoutParams.height = layoutDimension;
                setLayoutParams(layoutParams);
            }
            int dimensionPixelOffset = typedArray.getDimensionPixelOffset(7, -1);
            int dimensionPixelOffset2 = typedArray.getDimensionPixelOffset(3, -1);
            if (dimensionPixelOffset >= 0 || dimensionPixelOffset2 >= 0) {
                int max = Math.max(dimensionPixelOffset, 0);
                int max2 = Math.max(dimensionPixelOffset2, 0);
                d();
                this.t.a(max, max2);
            }
            int resourceId2 = typedArray.getResourceId(28, 0);
            if (resourceId2 != 0) {
                Context context = getContext();
                this.l = resourceId2;
                C0123g2 c0123g2 = this.b;
                if (c0123g2 != null) {
                    c0123g2.setTextAppearance(context, resourceId2);
                }
            }
            int resourceId3 = typedArray.getResourceId(26, 0);
            if (resourceId3 != 0) {
                Context context2 = getContext();
                this.m = resourceId3;
                C0123g2 c0123g22 = this.c;
                if (c0123g22 != null) {
                    c0123g22.setTextAppearance(context2, resourceId3);
                }
            }
            int resourceId4 = typedArray.getResourceId(22, 0);
            if (resourceId4 != 0) {
                setPopupTheme(resourceId4);
            }
            y.A();
            if (R.string.abc_action_bar_up_description != obj.n) {
                obj.n = R.string.abc_action_bar_up_description;
                if (TextUtils.isEmpty(getNavigationContentDescription())) {
                    int i2 = obj.n;
                    if (i2 != 0) {
                        str = getContext().getString(i2);
                    }
                    obj.j = str;
                    obj.b();
                }
            }
            obj.j = getNavigationContentDescription();
            setNavigationOnClickListener(new Qa(obj));
            this.J = obj;
        }
        return this.J;
    }

    public final int j(View view, int i) {
        int i2;
        Yf yf = (Yf) view.getLayoutParams();
        int measuredHeight = view.getMeasuredHeight();
        if (i > 0) {
            i2 = (measuredHeight - i) / 2;
        } else {
            i2 = 0;
        }
        int i3 = yf.a & 112;
        if (i3 != 16 && i3 != 48 && i3 != 80) {
            i3 = this.w & 112;
        }
        if (i3 != 48) {
            if (i3 != 80) {
                int paddingTop = getPaddingTop();
                int paddingBottom = getPaddingBottom();
                int height = getHeight();
                int i4 = (((height - paddingTop) - paddingBottom) - measuredHeight) / 2;
                int i5 = ((ViewGroup.MarginLayoutParams) yf).topMargin;
                if (i4 < i5) {
                    i4 = i5;
                } else {
                    int i6 = (((height - paddingBottom) - measuredHeight) - i4) - paddingTop;
                    int i7 = ((ViewGroup.MarginLayoutParams) yf).bottomMargin;
                    if (i6 < i7) {
                        i4 = Math.max(0, i4 - (i7 - i6));
                    }
                }
                return paddingTop + i4;
            }
            return (((getHeight() - getPaddingBottom()) - measuredHeight) - ((ViewGroup.MarginLayoutParams) yf).bottomMargin) - i2;
        }
        return getPaddingTop() - i2;
    }

    public void m(int i) {
        getMenuInflater().inflate(i, getMenu());
    }

    public final void n() {
        Iterator it = this.H.iterator();
        while (it.hasNext()) {
            getMenu().removeItem(((MenuItem) it.next()).getItemId());
        }
        getMenu();
        ArrayList<MenuItem> currentMenuItems = getCurrentMenuItems();
        getMenuInflater();
        Iterator it2 = ((CopyOnWriteArrayList) this.G.d).iterator();
        while (it2.hasNext()) {
            ((C0262n8) it2.next()).a.j();
        }
        ArrayList<MenuItem> currentMenuItems2 = getCurrentMenuItems();
        currentMenuItems2.removeAll(currentMenuItems);
        this.H = currentMenuItems2;
    }

    public final boolean o(View view) {
        if (view.getParent() != this && !this.E.contains(view)) {
            return false;
        }
        return true;
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        u();
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        removeCallbacks(this.Q);
        u();
    }

    @Override // android.view.View
    public final boolean onHoverEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 9) {
            this.C = false;
        }
        if (!this.C) {
            boolean onHoverEvent = super.onHoverEvent(motionEvent);
            if (actionMasked == 9 && !onHoverEvent) {
                this.C = true;
            }
        }
        if (actionMasked == 10 || actionMasked == 3) {
            this.C = false;
        }
        return true;
    }

    /* JADX WARN: Removed duplicated region for block: B:112:0x01a2  */
    /* JADX WARN: Removed duplicated region for block: B:117:0x0137  */
    /* JADX WARN: Removed duplicated region for block: B:118:0x0130  */
    /* JADX WARN: Removed duplicated region for block: B:119:0x011e  */
    /* JADX WARN: Removed duplicated region for block: B:120:0x0101  */
    /* JADX WARN: Removed duplicated region for block: B:13:0x0062  */
    /* JADX WARN: Removed duplicated region for block: B:18:0x0079  */
    /* JADX WARN: Removed duplicated region for block: B:23:0x00b6  */
    /* JADX WARN: Removed duplicated region for block: B:28:0x00cd  */
    /* JADX WARN: Removed duplicated region for block: B:33:0x00ea  */
    /* JADX WARN: Removed duplicated region for block: B:35:0x0106  */
    /* JADX WARN: Removed duplicated region for block: B:41:0x0298 A[LOOP:0: B:40:0x0296->B:41:0x0298, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:45:0x02b5 A[LOOP:1: B:44:0x02b3->B:45:0x02b5, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:49:0x02d3 A[LOOP:2: B:48:0x02d1->B:49:0x02d3, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:53:0x0314  */
    /* JADX WARN: Removed duplicated region for block: B:58:0x0321 A[LOOP:3: B:57:0x031f->B:58:0x0321, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:64:0x012d  */
    /* JADX WARN: Removed duplicated region for block: B:66:0x0134  */
    /* JADX WARN: Removed duplicated region for block: B:74:0x016a  */
    /* JADX WARN: Removed duplicated region for block: B:81:0x01b1  */
    /* JADX WARN: Removed duplicated region for block: B:95:0x0221  */
    @Override // android.view.ViewGroup, android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        boolean z2;
        int i5;
        int i6;
        int i7;
        boolean t;
        boolean t2;
        int i8;
        int i9;
        int i10;
        C0123g2 c0123g2;
        C0123g2 c0123g22;
        int i11;
        boolean z3;
        int i12;
        int i13;
        int i14;
        int paddingTop;
        int i15;
        int i16;
        int i17;
        int i18;
        int i19;
        int i20;
        int size;
        int i21;
        int i22;
        int size2;
        int i23;
        int size3;
        int i24;
        int i25;
        int i26;
        int size4;
        if (getLayoutDirection() == 1) {
            z2 = true;
        } else {
            z2 = false;
        }
        int width = getWidth();
        int height = getHeight();
        int paddingLeft = getPaddingLeft();
        int paddingRight = getPaddingRight();
        int paddingTop2 = getPaddingTop();
        int paddingBottom = getPaddingBottom();
        int i27 = width - paddingRight;
        int[] iArr = this.F;
        iArr[1] = 0;
        iArr[0] = 0;
        WeakHashMap weakHashMap = AbstractC0309ph.a;
        int minimumHeight = getMinimumHeight();
        if (minimumHeight >= 0) {
            i5 = Math.min(minimumHeight, i4 - i2);
        } else {
            i5 = 0;
        }
        if (t(this.d)) {
            if (z2) {
                i7 = q(this.d, i27, i5, iArr);
                i6 = paddingLeft;
                if (t(this.h)) {
                    if (z2) {
                        i7 = q(this.h, i7, i5, iArr);
                    } else {
                        i6 = p(this.h, i6, i5, iArr);
                    }
                }
                if (t(this.a)) {
                    if (z2) {
                        i6 = p(this.a, i6, i5, iArr);
                    } else {
                        i7 = q(this.a, i7, i5, iArr);
                    }
                }
                int currentContentInsetLeft = getCurrentContentInsetLeft();
                int currentContentInsetRight = getCurrentContentInsetRight();
                iArr[0] = Math.max(0, currentContentInsetLeft - i6);
                iArr[1] = Math.max(0, currentContentInsetRight - (i27 - i7));
                int max = Math.max(i6, currentContentInsetLeft);
                int min = Math.min(i7, i27 - currentContentInsetRight);
                if (t(this.i)) {
                    if (z2) {
                        min = q(this.i, min, i5, iArr);
                    } else {
                        max = p(this.i, max, i5, iArr);
                    }
                }
                if (t(this.e)) {
                    if (z2) {
                        min = q(this.e, min, i5, iArr);
                    } else {
                        max = p(this.e, max, i5, iArr);
                    }
                }
                t = t(this.b);
                t2 = t(this.c);
                if (!t) {
                    Yf yf = (Yf) this.b.getLayoutParams();
                    i8 = paddingRight;
                    i9 = ((ViewGroup.MarginLayoutParams) yf).bottomMargin + this.b.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) yf).topMargin;
                } else {
                    i8 = paddingRight;
                    i9 = 0;
                }
                if (!t2) {
                    Yf yf2 = (Yf) this.c.getLayoutParams();
                    i10 = width;
                    i9 += this.c.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) yf2).topMargin + ((ViewGroup.MarginLayoutParams) yf2).bottomMargin;
                } else {
                    i10 = width;
                }
                if (t && !t2) {
                    i11 = paddingLeft;
                    i13 = i5;
                } else {
                    if (!t) {
                        c0123g2 = this.b;
                    } else {
                        c0123g2 = this.c;
                    }
                    if (!t2) {
                        c0123g22 = this.c;
                    } else {
                        c0123g22 = this.b;
                    }
                    Yf yf3 = (Yf) c0123g2.getLayoutParams();
                    Yf yf4 = (Yf) c0123g22.getLayoutParams();
                    if ((!t && this.b.getMeasuredWidth() > 0) || (t2 && this.c.getMeasuredWidth() > 0)) {
                        i11 = paddingLeft;
                        z3 = true;
                    } else {
                        i11 = paddingLeft;
                        z3 = false;
                    }
                    i12 = this.w & 112;
                    i13 = i5;
                    if (i12 == 48) {
                        if (i12 != 80) {
                            int i28 = (((height - paddingTop2) - paddingBottom) - i9) / 2;
                            i14 = max;
                            int i29 = ((ViewGroup.MarginLayoutParams) yf3).topMargin + this.r;
                            if (i28 < i29) {
                                i28 = i29;
                            } else {
                                int i30 = (((height - paddingBottom) - i9) - i28) - paddingTop2;
                                int i31 = ((ViewGroup.MarginLayoutParams) yf3).bottomMargin;
                                int i32 = this.s;
                                if (i30 < i31 + i32) {
                                    i28 = Math.max(0, i28 - ((((ViewGroup.MarginLayoutParams) yf4).bottomMargin + i32) - i30));
                                }
                            }
                            paddingTop = paddingTop2 + i28;
                        } else {
                            i14 = max;
                            paddingTop = (((height - paddingBottom) - ((ViewGroup.MarginLayoutParams) yf4).bottomMargin) - this.s) - i9;
                        }
                    } else {
                        i14 = max;
                        paddingTop = getPaddingTop() + ((ViewGroup.MarginLayoutParams) yf3).topMargin + this.r;
                    }
                    if (!z2) {
                        if (z3) {
                            i18 = this.p;
                        } else {
                            i18 = 0;
                        }
                        int i33 = i18 - iArr[1];
                        min -= Math.max(0, i33);
                        iArr[1] = Math.max(0, -i33);
                        if (t) {
                            Yf yf5 = (Yf) this.b.getLayoutParams();
                            int measuredWidth = min - this.b.getMeasuredWidth();
                            int measuredHeight = this.b.getMeasuredHeight() + paddingTop;
                            this.b.layout(measuredWidth, paddingTop, min, measuredHeight);
                            i19 = measuredWidth - this.q;
                            paddingTop = measuredHeight + ((ViewGroup.MarginLayoutParams) yf5).bottomMargin;
                        } else {
                            i19 = min;
                        }
                        if (t2) {
                            int i34 = paddingTop + ((ViewGroup.MarginLayoutParams) ((Yf) this.c.getLayoutParams())).topMargin;
                            this.c.layout(min - this.c.getMeasuredWidth(), i34, min, this.c.getMeasuredHeight() + i34);
                            i20 = min - this.q;
                        } else {
                            i20 = min;
                        }
                        if (z3) {
                            min = Math.min(i19, i20);
                        }
                        max = i14;
                    } else {
                        if (z3) {
                            i15 = this.p;
                        } else {
                            i15 = 0;
                        }
                        int i35 = i15 - iArr[0];
                        max = Math.max(0, i35) + i14;
                        iArr[0] = Math.max(0, -i35);
                        if (t) {
                            Yf yf6 = (Yf) this.b.getLayoutParams();
                            int measuredWidth2 = this.b.getMeasuredWidth() + max;
                            int measuredHeight2 = this.b.getMeasuredHeight() + paddingTop;
                            this.b.layout(max, paddingTop, measuredWidth2, measuredHeight2);
                            i16 = measuredWidth2 + this.q;
                            paddingTop = measuredHeight2 + ((ViewGroup.MarginLayoutParams) yf6).bottomMargin;
                        } else {
                            i16 = max;
                        }
                        if (t2) {
                            int i36 = paddingTop + ((ViewGroup.MarginLayoutParams) ((Yf) this.c.getLayoutParams())).topMargin;
                            int measuredWidth3 = this.c.getMeasuredWidth() + max;
                            this.c.layout(max, i36, measuredWidth3, this.c.getMeasuredHeight() + i36);
                            i17 = measuredWidth3 + this.q;
                        } else {
                            i17 = max;
                        }
                        if (z3) {
                            max = Math.max(i16, i17);
                        }
                    }
                }
                ArrayList arrayList = this.D;
                a(arrayList, 3);
                size = arrayList.size();
                i21 = max;
                for (i22 = 0; i22 < size; i22++) {
                    i21 = p((View) arrayList.get(i22), i21, i13, iArr);
                }
                int i37 = i13;
                a(arrayList, 5);
                size2 = arrayList.size();
                for (i23 = 0; i23 < size2; i23++) {
                    min = q((View) arrayList.get(i23), min, i37, iArr);
                }
                a(arrayList, 1);
                int i38 = iArr[0];
                int i39 = iArr[1];
                size3 = arrayList.size();
                int i40 = i39;
                int i41 = i38;
                i24 = 0;
                int i42 = 0;
                while (i24 < size3) {
                    View view = (View) arrayList.get(i24);
                    Yf yf7 = (Yf) view.getLayoutParams();
                    int i43 = ((ViewGroup.MarginLayoutParams) yf7).leftMargin - i41;
                    int i44 = ((ViewGroup.MarginLayoutParams) yf7).rightMargin - i40;
                    int max2 = Math.max(0, i43);
                    int max3 = Math.max(0, i44);
                    int max4 = Math.max(0, -i43);
                    int max5 = Math.max(0, -i44);
                    i42 += view.getMeasuredWidth() + max2 + max3;
                    i24++;
                    i40 = max5;
                    i41 = max4;
                }
                i26 = ((((i10 - i11) - i8) / 2) + i11) - (i42 / 2);
                int i45 = i42 + i26;
                if (i26 >= i21) {
                    if (i45 > min) {
                        i21 = i26 - (i45 - min);
                    } else {
                        i21 = i26;
                    }
                }
                size4 = arrayList.size();
                for (i25 = 0; i25 < size4; i25++) {
                    i21 = p((View) arrayList.get(i25), i21, i37, iArr);
                }
                arrayList.clear();
            }
            i6 = p(this.d, paddingLeft, i5, iArr);
        } else {
            i6 = paddingLeft;
        }
        i7 = i27;
        if (t(this.h)) {
        }
        if (t(this.a)) {
        }
        int currentContentInsetLeft2 = getCurrentContentInsetLeft();
        int currentContentInsetRight2 = getCurrentContentInsetRight();
        iArr[0] = Math.max(0, currentContentInsetLeft2 - i6);
        iArr[1] = Math.max(0, currentContentInsetRight2 - (i27 - i7));
        int max6 = Math.max(i6, currentContentInsetLeft2);
        int min2 = Math.min(i7, i27 - currentContentInsetRight2);
        if (t(this.i)) {
        }
        if (t(this.e)) {
        }
        t = t(this.b);
        t2 = t(this.c);
        if (!t) {
        }
        if (!t2) {
        }
        if (t) {
        }
        if (!t) {
        }
        if (!t2) {
        }
        Yf yf32 = (Yf) c0123g2.getLayoutParams();
        Yf yf42 = (Yf) c0123g22.getLayoutParams();
        if (!t) {
        }
        i11 = paddingLeft;
        z3 = false;
        i12 = this.w & 112;
        i13 = i5;
        if (i12 == 48) {
        }
        if (!z2) {
        }
        ArrayList arrayList2 = this.D;
        a(arrayList2, 3);
        size = arrayList2.size();
        i21 = max6;
        while (i22 < size) {
        }
        int i372 = i13;
        a(arrayList2, 5);
        size2 = arrayList2.size();
        while (i23 < size2) {
        }
        a(arrayList2, 1);
        int i382 = iArr[0];
        int i392 = iArr[1];
        size3 = arrayList2.size();
        int i402 = i392;
        int i412 = i382;
        i24 = 0;
        int i422 = 0;
        while (i24 < size3) {
        }
        i26 = ((((i10 - i11) - i8) / 2) + i11) - (i422 / 2);
        int i452 = i422 + i26;
        if (i26 >= i21) {
        }
        size4 = arrayList2.size();
        while (i25 < size4) {
        }
        arrayList2.clear();
    }

    @Override // android.view.View
    public final void onMeasure(int i, int i2) {
        char c;
        char c2;
        int i3;
        int i4;
        int i5;
        int i6;
        int i7;
        int i8;
        int i9;
        boolean z = Ih.a;
        int i10 = 0;
        if (getLayoutDirection() == 1) {
            c2 = 1;
            c = 0;
        } else {
            c = 1;
            c2 = 0;
        }
        if (t(this.d)) {
            s(this.d, i, 0, i2, this.o);
            i3 = k(this.d) + this.d.getMeasuredWidth();
            i4 = Math.max(0, l(this.d) + this.d.getMeasuredHeight());
            i5 = View.combineMeasuredStates(0, this.d.getMeasuredState());
        } else {
            i3 = 0;
            i4 = 0;
            i5 = 0;
        }
        if (t(this.h)) {
            s(this.h, i, 0, i2, this.o);
            i3 = k(this.h) + this.h.getMeasuredWidth();
            i4 = Math.max(i4, l(this.h) + this.h.getMeasuredHeight());
            i5 = View.combineMeasuredStates(i5, this.h.getMeasuredState());
        }
        int currentContentInsetStart = getCurrentContentInsetStart();
        int max = Math.max(currentContentInsetStart, i3);
        int max2 = Math.max(0, currentContentInsetStart - i3);
        int[] iArr = this.F;
        iArr[c2] = max2;
        if (t(this.a)) {
            s(this.a, i, max, i2, this.o);
            i6 = k(this.a) + this.a.getMeasuredWidth();
            i4 = Math.max(i4, l(this.a) + this.a.getMeasuredHeight());
            i5 = View.combineMeasuredStates(i5, this.a.getMeasuredState());
        } else {
            i6 = 0;
        }
        int currentContentInsetEnd = getCurrentContentInsetEnd();
        int max3 = max + Math.max(currentContentInsetEnd, i6);
        iArr[c] = Math.max(0, currentContentInsetEnd - i6);
        if (t(this.i)) {
            max3 += r(this.i, i, max3, i2, 0, iArr);
            i4 = Math.max(i4, l(this.i) + this.i.getMeasuredHeight());
            i5 = View.combineMeasuredStates(i5, this.i.getMeasuredState());
        }
        if (t(this.e)) {
            max3 += r(this.e, i, max3, i2, 0, iArr);
            i4 = Math.max(i4, l(this.e) + this.e.getMeasuredHeight());
            i5 = View.combineMeasuredStates(i5, this.e.getMeasuredState());
        }
        int childCount = getChildCount();
        for (int i11 = 0; i11 < childCount; i11++) {
            View childAt = getChildAt(i11);
            if (((Yf) childAt.getLayoutParams()).b == 0 && t(childAt)) {
                max3 += r(childAt, i, max3, i2, 0, iArr);
                i4 = Math.max(i4, l(childAt) + childAt.getMeasuredHeight());
                i5 = View.combineMeasuredStates(i5, childAt.getMeasuredState());
            }
        }
        int i12 = this.r + this.s;
        int i13 = this.p + this.q;
        if (t(this.b)) {
            r(this.b, i, max3 + i13, i2, i12, iArr);
            int k = k(this.b) + this.b.getMeasuredWidth();
            i7 = l(this.b) + this.b.getMeasuredHeight();
            i8 = View.combineMeasuredStates(i5, this.b.getMeasuredState());
            i9 = k;
        } else {
            i7 = 0;
            i8 = i5;
            i9 = 0;
        }
        if (t(this.c)) {
            i9 = Math.max(i9, r(this.c, i, max3 + i13, i2, i7 + i12, iArr));
            i7 = l(this.c) + this.c.getMeasuredHeight() + i7;
            i8 = View.combineMeasuredStates(i8, this.c.getMeasuredState());
        }
        int max4 = Math.max(i4, i7);
        int paddingRight = getPaddingRight() + getPaddingLeft();
        int paddingBottom = getPaddingBottom() + getPaddingTop() + max4;
        int resolveSizeAndState = View.resolveSizeAndState(Math.max(paddingRight + max3 + i9, getSuggestedMinimumWidth()), i, (-16777216) & i8);
        int resolveSizeAndState2 = View.resolveSizeAndState(Math.max(paddingBottom, getSuggestedMinimumHeight()), i2, i8 << 16);
        if (this.M) {
            int childCount2 = getChildCount();
            for (int i14 = 0; i14 < childCount2; i14++) {
                View childAt2 = getChildAt(i14);
                if (!t(childAt2) || childAt2.getMeasuredWidth() <= 0 || childAt2.getMeasuredHeight() <= 0) {
                }
            }
            setMeasuredDimension(resolveSizeAndState, i10);
        }
        i10 = resolveSizeAndState2;
        setMeasuredDimension(resolveSizeAndState, i10);
    }

    @Override // android.view.View
    public final void onRestoreInstanceState(Parcelable parcelable) {
        MenuC0246mb menuC0246mb;
        MenuItem findItem;
        if (!(parcelable instanceof C0017ag)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        C0017ag c0017ag = (C0017ag) parcelable;
        super.onRestoreInstanceState(c0017ag.a);
        ActionMenuView actionMenuView = this.a;
        if (actionMenuView != null) {
            menuC0246mb = actionMenuView.p;
        } else {
            menuC0246mb = null;
        }
        int i = c0017ag.c;
        if (i != 0 && this.L != null && menuC0246mb != null && (findItem = menuC0246mb.findItem(i)) != null) {
            findItem.expandActionView();
        }
        if (c0017ag.d) {
            I2 i2 = this.Q;
            removeCallbacks(i2);
            post(i2);
        }
    }

    @Override // android.view.View
    public final void onRtlPropertiesChanged(int i) {
        super.onRtlPropertiesChanged(i);
        d();
        C0174ie c0174ie = this.t;
        boolean z = true;
        if (i != 1) {
            z = false;
        }
        if (z != c0174ie.g) {
            c0174ie.g = z;
            if (c0174ie.h) {
                if (z) {
                    int i2 = c0174ie.d;
                    if (i2 == Integer.MIN_VALUE) {
                        i2 = c0174ie.e;
                    }
                    c0174ie.a = i2;
                    int i3 = c0174ie.c;
                    if (i3 == Integer.MIN_VALUE) {
                        i3 = c0174ie.f;
                    }
                    c0174ie.b = i3;
                    return;
                }
                int i4 = c0174ie.c;
                if (i4 == Integer.MIN_VALUE) {
                    i4 = c0174ie.e;
                }
                c0174ie.a = i4;
                int i5 = c0174ie.d;
                if (i5 == Integer.MIN_VALUE) {
                    i5 = c0174ie.f;
                }
                c0174ie.b = i5;
                return;
            }
            c0174ie.a = c0174ie.e;
            c0174ie.b = c0174ie.f;
        }
    }

    /* JADX WARN: Type inference failed for: r0v0, types: [android.os.Parcelable, x.ag, x.d] */
    @Override // android.view.View
    public final Parcelable onSaveInstanceState() {
        boolean z;
        C0041c0 c0041c0;
        C0303pb c0303pb;
        ?? abstractC0060d = new AbstractC0060d(super.onSaveInstanceState());
        Xf xf = this.L;
        if (xf != null && (c0303pb = xf.b) != null) {
            abstractC0060d.c = c0303pb.a;
        }
        ActionMenuView actionMenuView = this.a;
        if (actionMenuView != null && (c0041c0 = actionMenuView.t) != null && c0041c0.i()) {
            z = true;
        } else {
            z = false;
        }
        abstractC0060d.d = z;
        return abstractC0060d;
    }

    @Override // android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            this.B = false;
        }
        if (!this.B) {
            boolean onTouchEvent = super.onTouchEvent(motionEvent);
            if (actionMasked == 0 && !onTouchEvent) {
                this.B = true;
            }
        }
        if (actionMasked == 1 || actionMasked == 3) {
            this.B = false;
        }
        return true;
    }

    public final int p(View view, int i, int i2, int[] iArr) {
        Yf yf = (Yf) view.getLayoutParams();
        int i3 = ((ViewGroup.MarginLayoutParams) yf).leftMargin - iArr[0];
        int max = Math.max(0, i3) + i;
        iArr[0] = Math.max(0, -i3);
        int j = j(view, i2);
        int measuredWidth = view.getMeasuredWidth();
        view.layout(max, j, max + measuredWidth, view.getMeasuredHeight() + j);
        return measuredWidth + ((ViewGroup.MarginLayoutParams) yf).rightMargin + max;
    }

    public final int q(View view, int i, int i2, int[] iArr) {
        Yf yf = (Yf) view.getLayoutParams();
        int i3 = ((ViewGroup.MarginLayoutParams) yf).rightMargin - iArr[1];
        int max = i - Math.max(0, i3);
        iArr[1] = Math.max(0, -i3);
        int j = j(view, i2);
        int measuredWidth = view.getMeasuredWidth();
        view.layout(max - measuredWidth, j, max, view.getMeasuredHeight() + j);
        return max - (measuredWidth + ((ViewGroup.MarginLayoutParams) yf).leftMargin);
    }

    public final int r(View view, int i, int i2, int i3, int i4, int[] iArr) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        int i5 = marginLayoutParams.leftMargin - iArr[0];
        int i6 = marginLayoutParams.rightMargin - iArr[1];
        int max = Math.max(0, i6) + Math.max(0, i5);
        iArr[0] = Math.max(0, -i5);
        iArr[1] = Math.max(0, -i6);
        view.measure(ViewGroup.getChildMeasureSpec(i, getPaddingRight() + getPaddingLeft() + max + i2, marginLayoutParams.width), ViewGroup.getChildMeasureSpec(i3, getPaddingBottom() + getPaddingTop() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin + i4, marginLayoutParams.height));
        return view.getMeasuredWidth() + max;
    }

    public final void s(View view, int i, int i2, int i3, int i4) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        int childMeasureSpec = ViewGroup.getChildMeasureSpec(i, getPaddingRight() + getPaddingLeft() + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + i2, marginLayoutParams.width);
        int childMeasureSpec2 = ViewGroup.getChildMeasureSpec(i3, getPaddingBottom() + getPaddingTop() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin, marginLayoutParams.height);
        int mode = View.MeasureSpec.getMode(childMeasureSpec2);
        if (mode != 1073741824 && i4 >= 0) {
            if (mode != 0) {
                i4 = Math.min(View.MeasureSpec.getSize(childMeasureSpec2), i4);
            }
            childMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(i4, 1073741824);
        }
        view.measure(childMeasureSpec, childMeasureSpec2);
    }

    public void setBackInvokedCallbackEnabled(boolean z) {
        if (this.P != z) {
            this.P = z;
            u();
        }
    }

    public void setCollapseContentDescription(int i) {
        setCollapseContentDescription(i != 0 ? getContext().getText(i) : null);
    }

    public void setCollapseIcon(int i) {
        setCollapseIcon(AbstractC0124g3.r(getContext(), i));
    }

    public void setCollapsible(boolean z) {
        this.M = z;
        requestLayout();
    }

    public void setContentInsetEndWithActions(int i) {
        if (i < 0) {
            i = Integer.MIN_VALUE;
        }
        if (i != this.v) {
            this.v = i;
            if (getNavigationIcon() != null) {
                requestLayout();
            }
        }
    }

    public void setContentInsetStartWithNavigation(int i) {
        if (i < 0) {
            i = Integer.MIN_VALUE;
        }
        if (i != this.u) {
            this.u = i;
            if (getNavigationIcon() != null) {
                requestLayout();
            }
        }
    }

    public void setLogo(int i) {
        setLogo(AbstractC0124g3.r(getContext(), i));
    }

    public void setLogoDescription(int i) {
        setLogoDescription(getContext().getText(i));
    }

    public void setNavigationContentDescription(int i) {
        setNavigationContentDescription(i != 0 ? getContext().getText(i) : null);
    }

    public void setNavigationIcon(int i) {
        setNavigationIcon(AbstractC0124g3.r(getContext(), i));
    }

    public void setNavigationOnClickListener(View.OnClickListener onClickListener) {
        g();
        this.d.setOnClickListener(onClickListener);
    }

    public void setOnMenuItemClickListener(Zf zf) {
    }

    public void setOverflowIcon(Drawable drawable) {
        e();
        this.a.setOverflowIcon(drawable);
    }

    public void setPopupTheme(int i) {
        if (this.k != i) {
            this.k = i;
            if (i == 0) {
                this.j = getContext();
            } else {
                this.j = new ContextThemeWrapper(getContext(), i);
            }
        }
    }

    public void setSubtitle(int i) {
        setSubtitle(getContext().getText(i));
    }

    public void setSubtitleTextColor(int i) {
        setSubtitleTextColor(ColorStateList.valueOf(i));
    }

    public void setTitle(int i) {
        setTitle(getContext().getText(i));
    }

    public void setTitleMarginBottom(int i) {
        this.s = i;
        requestLayout();
    }

    public void setTitleMarginEnd(int i) {
        this.q = i;
        requestLayout();
    }

    public void setTitleMarginStart(int i) {
        this.p = i;
        requestLayout();
    }

    public void setTitleMarginTop(int i) {
        this.r = i;
        requestLayout();
    }

    public void setTitleTextColor(int i) {
        setTitleTextColor(ColorStateList.valueOf(i));
    }

    public final boolean t(View view) {
        if (view != null && view.getParent() == this && view.getVisibility() != 8) {
            return true;
        }
        return false;
    }

    public final void u() {
        boolean z;
        OnBackInvokedDispatcher onBackInvokedDispatcher;
        if (Build.VERSION.SDK_INT >= 33) {
            OnBackInvokedDispatcher a = Wf.a(this);
            Xf xf = this.L;
            if (xf != null && xf.b != null && a != null && isAttachedToWindow() && this.P) {
                z = true;
            } else {
                z = false;
            }
            if (z && this.O == null) {
                if (this.N == null) {
                    this.N = Wf.b(new Uf(this, 0));
                }
                Wf.c(a, this.N);
                this.O = a;
                return;
            }
            if (!z && (onBackInvokedDispatcher = this.O) != null) {
                Wf.d(onBackInvokedDispatcher, this.N);
                this.O = null;
            }
        }
    }

    public Toolbar(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, R.attr.toolbarStyle);
        this.w = 8388627;
        this.D = new ArrayList();
        this.E = new ArrayList();
        this.F = new int[2];
        this.G = new C0294p2(new Uf(this, 1));
        this.H = new ArrayList();
        this.I = new Vf(this);
        this.Q = new I2(12, this);
        Context context2 = getContext();
        int[] iArr = AbstractC0210kd.f25x;
        C0294p2 y = C0294p2.y(context2, attributeSet, iArr, R.attr.toolbarStyle);
        AbstractC0309ph.k(this, context, iArr, attributeSet, (TypedArray) y.b, R.attr.toolbarStyle);
        TypedArray typedArray = (TypedArray) y.b;
        this.l = typedArray.getResourceId(28, 0);
        this.m = typedArray.getResourceId(19, 0);
        this.w = typedArray.getInteger(0, 8388627);
        this.n = typedArray.getInteger(2, 48);
        int dimensionPixelOffset = typedArray.getDimensionPixelOffset(22, 0);
        dimensionPixelOffset = typedArray.hasValue(27) ? typedArray.getDimensionPixelOffset(27, dimensionPixelOffset) : dimensionPixelOffset;
        this.s = dimensionPixelOffset;
        this.r = dimensionPixelOffset;
        this.q = dimensionPixelOffset;
        this.p = dimensionPixelOffset;
        int dimensionPixelOffset2 = typedArray.getDimensionPixelOffset(25, -1);
        if (dimensionPixelOffset2 >= 0) {
            this.p = dimensionPixelOffset2;
        }
        int dimensionPixelOffset3 = typedArray.getDimensionPixelOffset(24, -1);
        if (dimensionPixelOffset3 >= 0) {
            this.q = dimensionPixelOffset3;
        }
        int dimensionPixelOffset4 = typedArray.getDimensionPixelOffset(26, -1);
        if (dimensionPixelOffset4 >= 0) {
            this.r = dimensionPixelOffset4;
        }
        int dimensionPixelOffset5 = typedArray.getDimensionPixelOffset(23, -1);
        if (dimensionPixelOffset5 >= 0) {
            this.s = dimensionPixelOffset5;
        }
        this.o = typedArray.getDimensionPixelSize(13, -1);
        int dimensionPixelOffset6 = typedArray.getDimensionPixelOffset(9, Integer.MIN_VALUE);
        int dimensionPixelOffset7 = typedArray.getDimensionPixelOffset(5, Integer.MIN_VALUE);
        int dimensionPixelSize = typedArray.getDimensionPixelSize(7, 0);
        int dimensionPixelSize2 = typedArray.getDimensionPixelSize(8, 0);
        d();
        C0174ie c0174ie = this.t;
        c0174ie.h = false;
        if (dimensionPixelSize != Integer.MIN_VALUE) {
            c0174ie.e = dimensionPixelSize;
            c0174ie.a = dimensionPixelSize;
        }
        if (dimensionPixelSize2 != Integer.MIN_VALUE) {
            c0174ie.f = dimensionPixelSize2;
            c0174ie.b = dimensionPixelSize2;
        }
        if (dimensionPixelOffset6 != Integer.MIN_VALUE || dimensionPixelOffset7 != Integer.MIN_VALUE) {
            c0174ie.a(dimensionPixelOffset6, dimensionPixelOffset7);
        }
        this.u = typedArray.getDimensionPixelOffset(10, Integer.MIN_VALUE);
        this.v = typedArray.getDimensionPixelOffset(6, Integer.MIN_VALUE);
        this.f = y.o(4);
        this.g = typedArray.getText(3);
        CharSequence text = typedArray.getText(21);
        if (!TextUtils.isEmpty(text)) {
            setTitle(text);
        }
        CharSequence text2 = typedArray.getText(18);
        if (!TextUtils.isEmpty(text2)) {
            setSubtitle(text2);
        }
        this.j = getContext();
        setPopupTheme(typedArray.getResourceId(17, 0));
        Drawable o = y.o(16);
        if (o != null) {
            setNavigationIcon(o);
        }
        CharSequence text3 = typedArray.getText(15);
        if (!TextUtils.isEmpty(text3)) {
            setNavigationContentDescription(text3);
        }
        Drawable o2 = y.o(11);
        if (o2 != null) {
            setLogo(o2);
        }
        CharSequence text4 = typedArray.getText(12);
        if (!TextUtils.isEmpty(text4)) {
            setLogoDescription(text4);
        }
        if (typedArray.hasValue(29)) {
            setTitleTextColor(y.n(29));
        }
        if (typedArray.hasValue(20)) {
            setSubtitleTextColor(y.n(20));
        }
        if (typedArray.hasValue(14)) {
            m(typedArray.getResourceId(14, 0));
        }
        y.A();
    }

    /* JADX WARN: Type inference failed for: r0v0, types: [x.Yf, android.view.ViewGroup$LayoutParams, android.view.ViewGroup$MarginLayoutParams] */
    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        Context context = getContext();
        ?? marginLayoutParams = new ViewGroup.MarginLayoutParams(context, attributeSet);
        marginLayoutParams.a = 0;
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, AbstractC0210kd.b);
        marginLayoutParams.a = obtainStyledAttributes.getInt(0, 0);
        obtainStyledAttributes.recycle();
        marginLayoutParams.b = 0;
        return marginLayoutParams;
    }

    public void setCollapseContentDescription(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            c();
        }
        A1 a1 = this.h;
        if (a1 != null) {
            a1.setContentDescription(charSequence);
        }
    }

    public void setCollapseIcon(Drawable drawable) {
        if (drawable != null) {
            c();
            this.h.setImageDrawable(drawable);
        } else {
            A1 a1 = this.h;
            if (a1 != null) {
                a1.setImageDrawable(this.f);
            }
        }
    }

    public void setLogo(Drawable drawable) {
        if (drawable != null) {
            if (this.e == null) {
                this.e = new C1(getContext(), null, 0);
            }
            if (!o(this.e)) {
                b(this.e, true);
            }
        } else {
            C1 c1 = this.e;
            if (c1 != null && o(c1)) {
                removeView(this.e);
                this.E.remove(this.e);
            }
        }
        C1 c12 = this.e;
        if (c12 != null) {
            c12.setImageDrawable(drawable);
        }
    }

    public void setLogoDescription(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence) && this.e == null) {
            this.e = new C1(getContext(), null, 0);
        }
        C1 c1 = this.e;
        if (c1 != null) {
            c1.setContentDescription(charSequence);
        }
    }

    public void setNavigationContentDescription(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            g();
        }
        A1 a1 = this.d;
        if (a1 != null) {
            a1.setContentDescription(charSequence);
            AbstractC0171ib.U(this.d, charSequence);
        }
    }

    public void setNavigationIcon(Drawable drawable) {
        if (drawable != null) {
            g();
            if (!o(this.d)) {
                b(this.d, true);
            }
        } else {
            A1 a1 = this.d;
            if (a1 != null && o(a1)) {
                removeView(this.d);
                this.E.remove(this.d);
            }
        }
        A1 a12 = this.d;
        if (a12 != null) {
            a12.setImageDrawable(drawable);
        }
    }

    public void setSubtitle(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            if (this.c == null) {
                Context context = getContext();
                C0123g2 c0123g2 = new C0123g2(context, null);
                this.c = c0123g2;
                c0123g2.setSingleLine();
                this.c.setEllipsize(TextUtils.TruncateAt.END);
                int i = this.m;
                if (i != 0) {
                    this.c.setTextAppearance(context, i);
                }
                ColorStateList colorStateList = this.A;
                if (colorStateList != null) {
                    this.c.setTextColor(colorStateList);
                }
            }
            if (!o(this.c)) {
                b(this.c, true);
            }
        } else {
            C0123g2 c0123g22 = this.c;
            if (c0123g22 != null && o(c0123g22)) {
                removeView(this.c);
                this.E.remove(this.c);
            }
        }
        C0123g2 c0123g23 = this.c;
        if (c0123g23 != null) {
            c0123g23.setText(charSequence);
        }
        this.y = charSequence;
    }

    public void setSubtitleTextColor(ColorStateList colorStateList) {
        this.A = colorStateList;
        C0123g2 c0123g2 = this.c;
        if (c0123g2 != null) {
            c0123g2.setTextColor(colorStateList);
        }
    }

    public void setTitle(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            if (this.b == null) {
                Context context = getContext();
                C0123g2 c0123g2 = new C0123g2(context, null);
                this.b = c0123g2;
                c0123g2.setSingleLine();
                this.b.setEllipsize(TextUtils.TruncateAt.END);
                int i = this.l;
                if (i != 0) {
                    this.b.setTextAppearance(context, i);
                }
                ColorStateList colorStateList = this.z;
                if (colorStateList != null) {
                    this.b.setTextColor(colorStateList);
                }
            }
            if (!o(this.b)) {
                b(this.b, true);
            }
        } else {
            C0123g2 c0123g22 = this.b;
            if (c0123g22 != null && o(c0123g22)) {
                removeView(this.b);
                this.E.remove(this.b);
            }
        }
        C0123g2 c0123g23 = this.b;
        if (c0123g23 != null) {
            c0123g23.setText(charSequence);
        }
        this.f3x = charSequence;
    }

    public void setTitleTextColor(ColorStateList colorStateList) {
        this.z = colorStateList;
        C0123g2 c0123g2 = this.b;
        if (c0123g2 != null) {
            c0123g2.setTextColor(colorStateList);
        }
    }
}
