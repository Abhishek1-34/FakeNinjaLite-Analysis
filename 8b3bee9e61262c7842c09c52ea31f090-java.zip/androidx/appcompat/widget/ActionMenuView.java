package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.widget.LinearLayout;
import androidx.appcompat.view.menu.ActionMenuItemView;
import x.AbstractC0051ca;
import x.B;
import x.C0021b0;
import x.C0031ba;
import x.C0041c0;
import x.C0081e0;
import x.C0107f6;
import x.C0303pb;
import x.Eb;
import x.Ih;
import x.InterfaceC0061d0;
import x.InterfaceC0101f0;
import x.InterfaceC0227lb;
import x.MenuC0246mb;
import x.Vf;
import x.Y;

/* loaded from: classes.dex */
public class ActionMenuView extends AbstractC0051ca implements InterfaceC0227lb, Eb {
    public MenuC0246mb p;
    public Context q;
    public int r;
    public boolean s;
    public C0041c0 t;
    public Vf u;
    public boolean v;
    public int w;

    /* renamed from: x, reason: collision with root package name */
    public final int f1x;
    public final int y;
    public InterfaceC0101f0 z;

    public ActionMenuView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        setBaselineAligned(false);
        float f = context.getResources().getDisplayMetrics().density;
        this.f1x = (int) (56.0f * f);
        this.y = (int) (f * 4.0f);
        this.q = context;
        this.r = 0;
    }

    /* JADX WARN: Type inference failed for: r0v0, types: [x.e0, android.widget.LinearLayout$LayoutParams] */
    public static C0081e0 j() {
        ?? layoutParams = new LinearLayout.LayoutParams(-2, -2);
        layoutParams.a = false;
        ((LinearLayout.LayoutParams) layoutParams).gravity = 16;
        return layoutParams;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v3, types: [x.e0, android.widget.LinearLayout$LayoutParams] */
    public static C0081e0 k(ViewGroup.LayoutParams layoutParams) {
        C0081e0 c0081e0;
        if (layoutParams != null) {
            if (layoutParams instanceof C0081e0) {
                C0081e0 c0081e02 = (C0081e0) layoutParams;
                ?? layoutParams2 = new LinearLayout.LayoutParams((ViewGroup.LayoutParams) c0081e02);
                layoutParams2.a = c0081e02.a;
                c0081e0 = layoutParams2;
            } else {
                c0081e0 = new LinearLayout.LayoutParams(layoutParams);
            }
            if (((LinearLayout.LayoutParams) c0081e0).gravity <= 0) {
                ((LinearLayout.LayoutParams) c0081e0).gravity = 16;
            }
            return c0081e0;
        }
        return j();
    }

    @Override // x.Eb
    public final void a(MenuC0246mb menuC0246mb) {
        this.p = menuC0246mb;
    }

    @Override // x.InterfaceC0227lb
    public final boolean b(C0303pb c0303pb) {
        return this.p.q(c0303pb, null, 0);
    }

    @Override // x.AbstractC0051ca, android.view.ViewGroup
    public final boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof C0081e0;
    }

    @Override // android.view.View
    public final boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        return false;
    }

    @Override // x.AbstractC0051ca
    /* renamed from: f */
    public final /* bridge */ /* synthetic */ C0031ba generateDefaultLayoutParams() {
        return j();
    }

    /* JADX WARN: Type inference failed for: r0v0, types: [x.ba, android.widget.LinearLayout$LayoutParams] */
    @Override // x.AbstractC0051ca
    /* renamed from: g */
    public final C0031ba generateLayoutParams(AttributeSet attributeSet) {
        return new LinearLayout.LayoutParams(getContext(), attributeSet);
    }

    @Override // x.AbstractC0051ca, android.view.ViewGroup
    public final /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return j();
    }

    @Override // x.AbstractC0051ca, android.view.ViewGroup
    public final /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return k(layoutParams);
    }

    public Menu getMenu() {
        if (this.p == null) {
            Context context = getContext();
            MenuC0246mb menuC0246mb = new MenuC0246mb(context);
            this.p = menuC0246mb;
            menuC0246mb.e = new B(3, this);
            C0041c0 c0041c0 = new C0041c0(context);
            this.t = c0041c0;
            c0041c0.l = true;
            c0041c0.m = true;
            c0041c0.e = new C0107f6(6);
            this.p.b(c0041c0, this.q);
            C0041c0 c0041c02 = this.t;
            c0041c02.h = this;
            this.p = c0041c02.c;
        }
        return this.p;
    }

    public Drawable getOverflowIcon() {
        getMenu();
        C0041c0 c0041c0 = this.t;
        C0021b0 c0021b0 = c0041c0.i;
        if (c0021b0 != null) {
            return c0021b0.getDrawable();
        }
        if (c0041c0.k) {
            return c0041c0.j;
        }
        return null;
    }

    public int getPopupTheme() {
        return this.r;
    }

    public int getWindowAnimations() {
        return 0;
    }

    @Override // x.AbstractC0051ca
    /* renamed from: h */
    public final /* bridge */ /* synthetic */ C0031ba generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return k(layoutParams);
    }

    public final boolean l(int i) {
        boolean z = false;
        if (i == 0) {
            return false;
        }
        KeyEvent.Callback childAt = getChildAt(i - 1);
        KeyEvent.Callback childAt2 = getChildAt(i);
        if (i < getChildCount() && (childAt instanceof InterfaceC0061d0)) {
            z = ((InterfaceC0061d0) childAt).b();
        }
        if (i > 0 && (childAt2 instanceof InterfaceC0061d0)) {
            return z | ((InterfaceC0061d0) childAt2).a();
        }
        return z;
    }

    @Override // android.view.View
    public final void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        C0041c0 c0041c0 = this.t;
        if (c0041c0 != null) {
            c0041c0.d();
            if (this.t.i()) {
                this.t.e();
                this.t.l();
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        C0041c0 c0041c0 = this.t;
        if (c0041c0 != null) {
            c0041c0.e();
            Y y = c0041c0.t;
            if (y != null && y.b()) {
                y.i.dismiss();
            }
        }
    }

    @Override // x.AbstractC0051ca, android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z, int i, int i2, int i3, int i4) {
        boolean z2;
        int i5;
        int width;
        int i6;
        if (!this.v) {
            super.onLayout(z, i, i2, i3, i4);
            return;
        }
        int childCount = getChildCount();
        int i7 = (i4 - i2) / 2;
        int dividerWidth = getDividerWidth();
        int i8 = i3 - i;
        int paddingRight = (i8 - getPaddingRight()) - getPaddingLeft();
        boolean z3 = Ih.a;
        if (getLayoutDirection() == 1) {
            z2 = true;
        } else {
            z2 = false;
        }
        int i9 = 0;
        int i10 = 0;
        for (int i11 = 0; i11 < childCount; i11++) {
            View childAt = getChildAt(i11);
            if (childAt.getVisibility() != 8) {
                C0081e0 c0081e0 = (C0081e0) childAt.getLayoutParams();
                if (c0081e0.a) {
                    int measuredWidth = childAt.getMeasuredWidth();
                    if (l(i11)) {
                        measuredWidth += dividerWidth;
                    }
                    int measuredHeight = childAt.getMeasuredHeight();
                    if (z2) {
                        i6 = getPaddingLeft() + ((LinearLayout.LayoutParams) c0081e0).leftMargin;
                        width = i6 + measuredWidth;
                    } else {
                        width = (getWidth() - getPaddingRight()) - ((LinearLayout.LayoutParams) c0081e0).rightMargin;
                        i6 = width - measuredWidth;
                    }
                    int i12 = i7 - (measuredHeight / 2);
                    childAt.layout(i6, i12, width, measuredHeight + i12);
                    paddingRight -= measuredWidth;
                    i9 = 1;
                } else {
                    paddingRight -= (childAt.getMeasuredWidth() + ((LinearLayout.LayoutParams) c0081e0).leftMargin) + ((LinearLayout.LayoutParams) c0081e0).rightMargin;
                    l(i11);
                    i10++;
                }
            }
        }
        if (childCount == 1 && i9 == 0) {
            View childAt2 = getChildAt(0);
            int measuredWidth2 = childAt2.getMeasuredWidth();
            int measuredHeight2 = childAt2.getMeasuredHeight();
            int i13 = (i8 / 2) - (measuredWidth2 / 2);
            int i14 = i7 - (measuredHeight2 / 2);
            childAt2.layout(i13, i14, measuredWidth2 + i13, measuredHeight2 + i14);
            return;
        }
        int i15 = i10 - (i9 ^ 1);
        if (i15 > 0) {
            i5 = paddingRight / i15;
        } else {
            i5 = 0;
        }
        int max = Math.max(0, i5);
        if (z2) {
            int width2 = getWidth() - getPaddingRight();
            for (int i16 = 0; i16 < childCount; i16++) {
                View childAt3 = getChildAt(i16);
                C0081e0 c0081e02 = (C0081e0) childAt3.getLayoutParams();
                if (childAt3.getVisibility() != 8 && !c0081e02.a) {
                    int i17 = width2 - ((LinearLayout.LayoutParams) c0081e02).rightMargin;
                    int measuredWidth3 = childAt3.getMeasuredWidth();
                    int measuredHeight3 = childAt3.getMeasuredHeight();
                    int i18 = i7 - (measuredHeight3 / 2);
                    childAt3.layout(i17 - measuredWidth3, i18, i17, measuredHeight3 + i18);
                    width2 = i17 - ((measuredWidth3 + ((LinearLayout.LayoutParams) c0081e02).leftMargin) + max);
                }
            }
            return;
        }
        int paddingLeft = getPaddingLeft();
        for (int i19 = 0; i19 < childCount; i19++) {
            View childAt4 = getChildAt(i19);
            C0081e0 c0081e03 = (C0081e0) childAt4.getLayoutParams();
            if (childAt4.getVisibility() != 8 && !c0081e03.a) {
                int i20 = paddingLeft + ((LinearLayout.LayoutParams) c0081e03).leftMargin;
                int measuredWidth4 = childAt4.getMeasuredWidth();
                int measuredHeight4 = childAt4.getMeasuredHeight();
                int i21 = i7 - (measuredHeight4 / 2);
                childAt4.layout(i20, i21, i20 + measuredWidth4, measuredHeight4 + i21);
                paddingLeft = measuredWidth4 + ((LinearLayout.LayoutParams) c0081e03).rightMargin + max + i20;
            }
        }
    }

    /* JADX WARN: Type inference failed for: r4v28 */
    /* JADX WARN: Type inference failed for: r4v29, types: [boolean, int] */
    /* JADX WARN: Type inference failed for: r4v31 */
    /* JADX WARN: Type inference failed for: r4v36 */
    @Override // x.AbstractC0051ca, android.view.View
    public final void onMeasure(int i, int i2) {
        boolean z;
        int i3;
        boolean z2;
        boolean z3;
        boolean z4;
        int i4;
        boolean z5;
        int i5;
        int i6;
        int i7;
        int i8;
        ?? r4;
        boolean z6;
        int i9;
        int i10;
        int i11;
        ActionMenuItemView actionMenuItemView;
        boolean z7;
        int i12;
        boolean z8;
        MenuC0246mb menuC0246mb;
        boolean z9 = this.v;
        if (View.MeasureSpec.getMode(i) == 1073741824) {
            z = true;
        } else {
            z = false;
        }
        this.v = z;
        if (z9 != z) {
            this.w = 0;
        }
        int size = View.MeasureSpec.getSize(i);
        if (this.v && (menuC0246mb = this.p) != null && size != this.w) {
            this.w = size;
            menuC0246mb.p(true);
        }
        int childCount = getChildCount();
        if (this.v && childCount > 0) {
            int mode = View.MeasureSpec.getMode(i2);
            int size2 = View.MeasureSpec.getSize(i);
            int size3 = View.MeasureSpec.getSize(i2);
            int paddingRight = getPaddingRight() + getPaddingLeft();
            int paddingBottom = getPaddingBottom() + getPaddingTop();
            int childMeasureSpec = ViewGroup.getChildMeasureSpec(i2, paddingBottom, -2);
            int i13 = size2 - paddingRight;
            int i14 = this.f1x;
            int i15 = i13 / i14;
            int i16 = i13 % i14;
            if (i15 == 0) {
                setMeasuredDimension(i13, 0);
                return;
            }
            int i17 = (i16 / i15) + i14;
            int childCount2 = getChildCount();
            int i18 = 0;
            int i19 = 0;
            int i20 = 0;
            int i21 = 0;
            boolean z10 = false;
            int i22 = 0;
            long j = 0;
            while (true) {
                i3 = this.y;
                if (i21 >= childCount2) {
                    break;
                }
                View childAt = getChildAt(i21);
                int i23 = size3;
                int i24 = i13;
                if (childAt.getVisibility() == 8) {
                    i10 = mode;
                    i11 = paddingBottom;
                } else {
                    boolean z11 = childAt instanceof ActionMenuItemView;
                    int i25 = i19 + 1;
                    if (z11) {
                        childAt.setPadding(i3, 0, i3, 0);
                    }
                    C0081e0 c0081e0 = (C0081e0) childAt.getLayoutParams();
                    c0081e0.f = false;
                    c0081e0.c = 0;
                    c0081e0.b = 0;
                    c0081e0.d = false;
                    ((LinearLayout.LayoutParams) c0081e0).leftMargin = 0;
                    ((LinearLayout.LayoutParams) c0081e0).rightMargin = 0;
                    if (z11 && !TextUtils.isEmpty(((ActionMenuItemView) childAt).getText())) {
                        z6 = true;
                    } else {
                        z6 = false;
                    }
                    c0081e0.e = z6;
                    if (c0081e0.a) {
                        i9 = 1;
                    } else {
                        i9 = i15;
                    }
                    C0081e0 c0081e02 = (C0081e0) childAt.getLayoutParams();
                    i10 = mode;
                    i11 = paddingBottom;
                    int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(View.MeasureSpec.getSize(childMeasureSpec) - paddingBottom, View.MeasureSpec.getMode(childMeasureSpec));
                    if (z11) {
                        actionMenuItemView = (ActionMenuItemView) childAt;
                    } else {
                        actionMenuItemView = null;
                    }
                    if (actionMenuItemView != null && !TextUtils.isEmpty(actionMenuItemView.getText())) {
                        z7 = true;
                    } else {
                        z7 = false;
                    }
                    if (i9 > 0 && (!z7 || i9 >= 2)) {
                        childAt.measure(View.MeasureSpec.makeMeasureSpec(i9 * i17, Integer.MIN_VALUE), makeMeasureSpec);
                        int measuredWidth = childAt.getMeasuredWidth();
                        i12 = measuredWidth / i17;
                        if (measuredWidth % i17 != 0) {
                            i12++;
                        }
                        if (z7 && i12 < 2) {
                            i12 = 2;
                        }
                    } else {
                        i12 = 0;
                    }
                    if (!c0081e02.a && z7) {
                        z8 = true;
                    } else {
                        z8 = false;
                    }
                    c0081e02.d = z8;
                    c0081e02.b = i12;
                    childAt.measure(View.MeasureSpec.makeMeasureSpec(i12 * i17, 1073741824), makeMeasureSpec);
                    i20 = Math.max(i20, i12);
                    if (c0081e0.d) {
                        i22++;
                    }
                    if (c0081e0.a) {
                        z10 = true;
                    }
                    i15 -= i12;
                    i18 = Math.max(i18, childAt.getMeasuredHeight());
                    if (i12 == 1) {
                        j |= 1 << i21;
                    }
                    i19 = i25;
                }
                i21++;
                size3 = i23;
                i13 = i24;
                paddingBottom = i11;
                mode = i10;
            }
            int i26 = mode;
            int i27 = i13;
            int i28 = size3;
            if (z10 && i19 == 2) {
                z2 = true;
            } else {
                z2 = false;
            }
            boolean z12 = false;
            while (i22 > 0 && i15 > 0) {
                int i29 = Integer.MAX_VALUE;
                int i30 = 0;
                int i31 = 0;
                long j2 = 0;
                while (i31 < childCount2) {
                    C0081e0 c0081e03 = (C0081e0) getChildAt(i31).getLayoutParams();
                    boolean z13 = z12;
                    if (c0081e03.d) {
                        int i32 = c0081e03.b;
                        if (i32 < i29) {
                            j2 = 1 << i31;
                            i29 = i32;
                            i30 = 1;
                        } else if (i32 == i29) {
                            j2 |= 1 << i31;
                            i30++;
                        }
                    }
                    i31++;
                    z12 = z13;
                }
                z3 = z12;
                j |= j2;
                if (i30 > i15) {
                    break;
                }
                int i33 = i29 + 1;
                int i34 = 0;
                while (i34 < childCount2) {
                    View childAt2 = getChildAt(i34);
                    C0081e0 c0081e04 = (C0081e0) childAt2.getLayoutParams();
                    int i35 = i18;
                    int i36 = childMeasureSpec;
                    int i37 = childCount2;
                    long j3 = 1 << i34;
                    if ((j2 & j3) == 0) {
                        if (c0081e04.b == i33) {
                            j |= j3;
                        }
                    } else {
                        if (z2 && c0081e04.e) {
                            r4 = 1;
                            r4 = 1;
                            if (i15 == 1) {
                                childAt2.setPadding(i3 + i17, 0, i3, 0);
                            }
                        } else {
                            r4 = 1;
                        }
                        c0081e04.b += r4;
                        c0081e04.f = r4;
                        i15--;
                    }
                    i34++;
                    childMeasureSpec = i36;
                    i18 = i35;
                    childCount2 = i37;
                }
                z12 = true;
            }
            z3 = z12;
            int i38 = i18;
            int i39 = childMeasureSpec;
            int i40 = childCount2;
            if (!z10 && i19 == 1) {
                z4 = true;
            } else {
                z4 = false;
            }
            if (i15 <= 0 || j == 0 || (i15 >= i19 - 1 && !z4 && i20 <= 1)) {
                i4 = i40;
                z5 = z3;
            } else {
                float bitCount = Long.bitCount(j);
                if (!z4) {
                    if ((j & 1) != 0 && !((C0081e0) getChildAt(0).getLayoutParams()).e) {
                        bitCount -= 0.5f;
                    }
                    int i41 = i40 - 1;
                    if ((j & (1 << i41)) != 0 && !((C0081e0) getChildAt(i41).getLayoutParams()).e) {
                        bitCount -= 0.5f;
                    }
                }
                if (bitCount > 0.0f) {
                    i8 = (int) ((i15 * i17) / bitCount);
                } else {
                    i8 = 0;
                }
                boolean z14 = z3;
                i4 = i40;
                for (int i42 = 0; i42 < i4; i42++) {
                    if ((j & (1 << i42)) != 0) {
                        View childAt3 = getChildAt(i42);
                        C0081e0 c0081e05 = (C0081e0) childAt3.getLayoutParams();
                        if (childAt3 instanceof ActionMenuItemView) {
                            c0081e05.c = i8;
                            c0081e05.f = true;
                            if (i42 == 0 && !c0081e05.e) {
                                ((LinearLayout.LayoutParams) c0081e05).leftMargin = (-i8) / 2;
                            }
                            z14 = true;
                        } else {
                            if (c0081e05.a) {
                                c0081e05.c = i8;
                                c0081e05.f = true;
                                ((LinearLayout.LayoutParams) c0081e05).rightMargin = (-i8) / 2;
                                z14 = true;
                            } else {
                                if (i42 != 0) {
                                    ((LinearLayout.LayoutParams) c0081e05).leftMargin = i8 / 2;
                                }
                                if (i42 != i4 - 1) {
                                    ((LinearLayout.LayoutParams) c0081e05).rightMargin = i8 / 2;
                                }
                            }
                        }
                    }
                }
                z5 = z14;
            }
            if (z5) {
                int i43 = 0;
                while (i43 < i4) {
                    View childAt4 = getChildAt(i43);
                    C0081e0 c0081e06 = (C0081e0) childAt4.getLayoutParams();
                    if (!c0081e06.f) {
                        i7 = i39;
                    } else {
                        i7 = i39;
                        childAt4.measure(View.MeasureSpec.makeMeasureSpec((c0081e06.b * i17) + c0081e06.c, 1073741824), i7);
                    }
                    i43++;
                    i39 = i7;
                }
            }
            if (i26 != 1073741824) {
                i6 = i27;
                i5 = i38;
            } else {
                i5 = i28;
                i6 = i27;
            }
            setMeasuredDimension(i6, i5);
            return;
        }
        for (int i44 = 0; i44 < childCount; i44++) {
            C0081e0 c0081e07 = (C0081e0) getChildAt(i44).getLayoutParams();
            ((LinearLayout.LayoutParams) c0081e07).rightMargin = 0;
            ((LinearLayout.LayoutParams) c0081e07).leftMargin = 0;
        }
        super.onMeasure(i, i2);
    }

    public void setExpandedActionViewsExclusive(boolean z) {
        this.t.q = z;
    }

    public void setOnMenuItemClickListener(InterfaceC0101f0 interfaceC0101f0) {
        this.z = interfaceC0101f0;
    }

    public void setOverflowIcon(Drawable drawable) {
        getMenu();
        C0041c0 c0041c0 = this.t;
        C0021b0 c0021b0 = c0041c0.i;
        if (c0021b0 != null) {
            c0021b0.setImageDrawable(drawable);
        } else {
            c0041c0.k = true;
            c0041c0.j = drawable;
        }
    }

    public void setOverflowReserved(boolean z) {
        this.s = z;
    }

    public void setPopupTheme(int i) {
        if (this.r != i) {
            this.r = i;
            if (i == 0) {
                this.q = getContext();
            } else {
                this.q = new ContextThemeWrapper(getContext(), i);
            }
        }
    }

    public void setPresenter(C0041c0 c0041c0) {
        this.t = c0041c0;
        c0041c0.h = this;
        this.p = c0041c0.c;
    }

    @Override // x.AbstractC0051ca, android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new LinearLayout.LayoutParams(getContext(), attributeSet);
    }
}
