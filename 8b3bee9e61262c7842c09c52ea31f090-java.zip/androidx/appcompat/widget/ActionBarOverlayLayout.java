package androidx.appcompat.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewPropertyAnimator;
import android.view.Window;
import android.view.WindowInsets;
import android.widget.OverScroller;
import java.util.WeakHashMap;
import org.conscrypt.PSKKeyManager;
import org.conscrypt.R;
import x.AbstractC0118fh;
import x.AbstractC0124g3;
import x.AbstractC0158hh;
import x.AbstractC0309ph;
import x.Bb;
import x.Bh;
import x.C0041c0;
import x.C0057cg;
import x.C0059ci;
import x.C9;
import x.InterfaceC0046c5;
import x.InterfaceC0066d5;
import x.MenuC0246mb;
import x.P;
import x.Q;
import x.S;
import x.T;
import x.U;
import x.Vb;
import x.Wb;
import x.Xb;
import x.Xf;
import x.ki;
import x.mi;
import x.ni;
import x.oi;
import x.ui;
import x.wi;

@SuppressLint({"UnknownNullness"})
/* loaded from: classes.dex */
public class ActionBarOverlayLayout extends ViewGroup implements InterfaceC0046c5, Vb, Wb {
    public static final int[] C = {R.attr.actionBarSize, android.R.attr.windowContentOverlay};
    public static final wi D;
    public static final Rect E;
    public final Xb A;
    public final U B;
    public int a;
    public int b;
    public ContentFrameLayout c;
    public ActionBarContainer d;
    public InterfaceC0066d5 e;
    public Drawable f;
    public boolean g;
    public boolean h;
    public boolean i;
    public boolean j;
    public int k;
    public int l;
    public final Rect m;
    public final Rect n;
    public final Rect o;
    public final Rect p;
    public wi q;
    public wi r;
    public wi s;
    public wi t;
    public S u;
    public OverScroller v;
    public ViewPropertyAnimator w;

    /* renamed from: x, reason: collision with root package name */
    public final P f0x;
    public final Q y;
    public final Q z;

    static {
        oi kiVar;
        int i = Build.VERSION.SDK_INT;
        if (i >= 30) {
            kiVar = new ni();
        } else if (i >= 29) {
            kiVar = new mi();
        } else {
            kiVar = new ki();
        }
        kiVar.g(C9.b(0, 1, 0, 1));
        D = kiVar.b();
        E = new Rect();
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r3v14, types: [x.Xb, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r3v15, types: [android.view.View, x.U] */
    public ActionBarOverlayLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.b = 0;
        this.m = new Rect();
        this.n = new Rect();
        this.o = new Rect();
        this.p = new Rect();
        new Rect();
        new Rect();
        new Rect();
        new Rect();
        wi wiVar = wi.b;
        this.q = wiVar;
        this.r = wiVar;
        this.s = wiVar;
        this.t = wiVar;
        this.f0x = new P(0, this);
        this.y = new Q(this, 0);
        this.z = new Q(this, 1);
        i(context);
        this.A = new Object();
        ?? view = new View(context);
        view.setWillNotDraw(true);
        this.B = view;
        addView(view);
    }

    public static boolean g(View view, Rect rect, boolean z) {
        boolean z2;
        T t = (T) view.getLayoutParams();
        int i = ((ViewGroup.MarginLayoutParams) t).leftMargin;
        int i2 = rect.left;
        if (i != i2) {
            ((ViewGroup.MarginLayoutParams) t).leftMargin = i2;
            z2 = true;
        } else {
            z2 = false;
        }
        int i3 = ((ViewGroup.MarginLayoutParams) t).topMargin;
        int i4 = rect.top;
        if (i3 != i4) {
            ((ViewGroup.MarginLayoutParams) t).topMargin = i4;
            z2 = true;
        }
        int i5 = ((ViewGroup.MarginLayoutParams) t).rightMargin;
        int i6 = rect.right;
        if (i5 != i6) {
            ((ViewGroup.MarginLayoutParams) t).rightMargin = i6;
            z2 = true;
        }
        if (z) {
            int i7 = ((ViewGroup.MarginLayoutParams) t).bottomMargin;
            int i8 = rect.bottom;
            if (i7 != i8) {
                ((ViewGroup.MarginLayoutParams) t).bottomMargin = i8;
                return true;
            }
        }
        return z2;
    }

    @Override // x.Vb
    public final void a(View view, View view2, int i, int i2) {
        if (i2 == 0) {
            onNestedScrollAccepted(view, view2, i);
        }
    }

    @Override // x.Wb
    public final void b(View view, int i, int i2, int i3, int i4, int i5, int[] iArr) {
        c(view, i, i2, i3, i4, i5);
    }

    @Override // x.Vb
    public final void c(View view, int i, int i2, int i3, int i4, int i5) {
        if (i5 == 0) {
            onNestedScroll(view, i, i2, i3, i4);
        }
    }

    @Override // android.view.ViewGroup
    public final boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof T;
    }

    @Override // x.Vb
    public final void d(View view, int i) {
        if (i == 0) {
            onStopNestedScroll(view);
        }
    }

    @Override // android.view.View
    public final void draw(Canvas canvas) {
        int i;
        super.draw(canvas);
        if (this.f != null) {
            if (this.d.getVisibility() == 0) {
                i = (int) (this.d.getTranslationY() + this.d.getBottom() + 0.5f);
            } else {
                i = 0;
            }
            this.f.setBounds(0, i, getWidth(), this.f.getIntrinsicHeight() + i);
            this.f.draw(canvas);
        }
    }

    @Override // x.Vb
    public final void e(View view, int i, int i2, int[] iArr, int i3) {
    }

    @Override // x.Vb
    public final boolean f(View view, View view2, int i, int i2) {
        if (i2 == 0 && onStartNestedScroll(view, view2, i)) {
            return true;
        }
        return false;
    }

    @Override // android.view.View
    public final boolean fitSystemWindows(Rect rect) {
        return super.fitSystemWindows(rect);
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new ViewGroup.MarginLayoutParams(-1, -1);
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new ViewGroup.MarginLayoutParams(getContext(), attributeSet);
    }

    public int getActionBarHideOffset() {
        ActionBarContainer actionBarContainer = this.d;
        if (actionBarContainer != null) {
            return -((int) actionBarContainer.getTranslationY());
        }
        return 0;
    }

    @Override // android.view.ViewGroup
    public int getNestedScrollAxes() {
        Xb xb = this.A;
        return xb.b | xb.a;
    }

    public CharSequence getTitle() {
        k();
        return ((C0057cg) this.e).a.getTitle();
    }

    public final void h() {
        removeCallbacks(this.y);
        removeCallbacks(this.z);
        ViewPropertyAnimator viewPropertyAnimator = this.w;
        if (viewPropertyAnimator != null) {
            viewPropertyAnimator.cancel();
        }
    }

    public final void i(Context context) {
        TypedArray obtainStyledAttributes = getContext().getTheme().obtainStyledAttributes(C);
        boolean z = false;
        this.a = obtainStyledAttributes.getDimensionPixelSize(0, 0);
        Drawable drawable = obtainStyledAttributes.getDrawable(1);
        this.f = drawable;
        if (drawable == null) {
            z = true;
        }
        setWillNotDraw(z);
        obtainStyledAttributes.recycle();
        this.v = new OverScroller(context);
    }

    public final void j(int i) {
        k();
        if (i != 2) {
            if (i != 5) {
                if (i == 109) {
                    setOverlayMode(true);
                    return;
                }
                return;
            } else {
                ((C0057cg) this.e).getClass();
                Log.i("ToolbarWidgetWrapper", "Progress display unsupported");
                return;
            }
        }
        ((C0057cg) this.e).getClass();
        Log.i("ToolbarWidgetWrapper", "Progress display unsupported");
    }

    public final void k() {
        InterfaceC0066d5 wrapper;
        if (this.c == null) {
            this.c = (ContentFrameLayout) findViewById(R.id.action_bar_activity_content);
            this.d = (ActionBarContainer) findViewById(R.id.action_bar_container);
            KeyEvent.Callback findViewById = findViewById(R.id.action_bar);
            if (findViewById instanceof InterfaceC0066d5) {
                wrapper = (InterfaceC0066d5) findViewById;
            } else if (findViewById instanceof Toolbar) {
                wrapper = ((Toolbar) findViewById).getWrapper();
            } else {
                throw new IllegalStateException("Can't make a decor toolbar out of ".concat(findViewById.getClass().getSimpleName()));
            }
            this.e = wrapper;
        }
    }

    public final void l(MenuC0246mb menuC0246mb, Bb bb) {
        k();
        C0057cg c0057cg = (C0057cg) this.e;
        C0041c0 c0041c0 = c0057cg.m;
        Toolbar toolbar = c0057cg.a;
        if (c0041c0 == null) {
            c0057cg.m = new C0041c0(toolbar.getContext());
        }
        C0041c0 c0041c02 = c0057cg.m;
        c0041c02.e = bb;
        if (menuC0246mb != null || toolbar.a != null) {
            toolbar.f();
            MenuC0246mb menuC0246mb2 = toolbar.a.p;
            if (menuC0246mb2 != menuC0246mb) {
                if (menuC0246mb2 != null) {
                    menuC0246mb2.r(toolbar.K);
                    menuC0246mb2.r(toolbar.L);
                }
                if (toolbar.L == null) {
                    toolbar.L = new Xf(toolbar);
                }
                c0041c02.q = true;
                if (menuC0246mb != null) {
                    menuC0246mb.b(c0041c02, toolbar.j);
                    menuC0246mb.b(toolbar.L, toolbar.j);
                } else {
                    c0041c02.j(toolbar.j, null);
                    toolbar.L.j(toolbar.j, null);
                    c0041c02.d();
                    toolbar.L.d();
                }
                toolbar.a.setPopupTheme(toolbar.k);
                toolbar.a.setPresenter(c0041c02);
                toolbar.K = c0041c02;
                toolbar.u();
            }
        }
    }

    @Override // android.view.View
    public final WindowInsets onApplyWindowInsets(WindowInsets windowInsets) {
        k();
        wi g = wi.g(this, windowInsets);
        boolean g2 = g(this.d, new Rect(g.b(), g.d(), g.c(), g.a()), false);
        WeakHashMap weakHashMap = AbstractC0309ph.a;
        Rect rect = this.m;
        AbstractC0158hh.b(this, g, rect);
        int i = rect.left;
        int i2 = rect.top;
        int i3 = rect.right;
        int i4 = rect.bottom;
        ui uiVar = g.a;
        wi l = uiVar.l(i, i2, i3, i4);
        this.q = l;
        boolean z = true;
        if (!this.r.equals(l)) {
            this.r = this.q;
            g2 = true;
        }
        Rect rect2 = this.n;
        if (!rect2.equals(rect)) {
            rect2.set(rect);
        } else {
            z = g2;
        }
        if (z) {
            requestLayout();
        }
        return uiVar.a().a.c().a.b().f();
    }

    @Override // android.view.View
    public final void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        i(getContext());
        WeakHashMap weakHashMap = AbstractC0309ph.a;
        AbstractC0118fh.c(this);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        h();
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z, int i, int i2, int i3, int i4) {
        int childCount = getChildCount();
        int paddingLeft = getPaddingLeft();
        int paddingTop = getPaddingTop();
        for (int i5 = 0; i5 < childCount; i5++) {
            View childAt = getChildAt(i5);
            if (childAt.getVisibility() != 8) {
                T t = (T) childAt.getLayoutParams();
                int measuredWidth = childAt.getMeasuredWidth();
                int measuredHeight = childAt.getMeasuredHeight();
                int i6 = ((ViewGroup.MarginLayoutParams) t).leftMargin + paddingLeft;
                int i7 = ((ViewGroup.MarginLayoutParams) t).topMargin + paddingTop;
                childAt.layout(i6, i7, measuredWidth + i6, measuredHeight + i7);
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:18:0x00fc  */
    @Override // android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void onMeasure(int i, int i2) {
        boolean z;
        int measuredHeight;
        oi kiVar;
        k();
        measureChildWithMargins(this.d, i, 0, i2, 0);
        T t = (T) this.d.getLayoutParams();
        int max = Math.max(0, this.d.getMeasuredWidth() + ((ViewGroup.MarginLayoutParams) t).leftMargin + ((ViewGroup.MarginLayoutParams) t).rightMargin);
        int max2 = Math.max(0, this.d.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) t).topMargin + ((ViewGroup.MarginLayoutParams) t).bottomMargin);
        int combineMeasuredStates = View.combineMeasuredStates(0, this.d.getMeasuredState());
        WeakHashMap weakHashMap = AbstractC0309ph.a;
        if ((getWindowSystemUiVisibility() & PSKKeyManager.MAX_KEY_LENGTH_BYTES) != 0) {
            z = true;
        } else {
            z = false;
        }
        if (z) {
            measuredHeight = this.a;
            if (this.h && this.d.getTabContainer() != null) {
                measuredHeight += this.a;
            }
        } else {
            measuredHeight = this.d.getVisibility() != 8 ? this.d.getMeasuredHeight() : 0;
        }
        Rect rect = this.m;
        Rect rect2 = this.o;
        rect2.set(rect);
        this.s = this.q;
        if (!this.g && !z) {
            U u = this.B;
            wi wiVar = D;
            Rect rect3 = this.p;
            AbstractC0158hh.b(u, wiVar, rect3);
            if (!rect3.equals(E)) {
                rect2.top += measuredHeight;
                rect2.bottom = rect2.bottom;
                this.s = this.s.a.l(0, measuredHeight, 0, 0);
                g(this.c, rect2, true);
                if (!this.t.equals(this.s)) {
                    wi wiVar2 = this.s;
                    this.t = wiVar2;
                    ContentFrameLayout contentFrameLayout = this.c;
                    WindowInsets f = wiVar2.f();
                    if (f != null) {
                        WindowInsets a = AbstractC0118fh.a(contentFrameLayout, f);
                        if (!a.equals(f)) {
                            wi.g(contentFrameLayout, a);
                        }
                    }
                }
                measureChildWithMargins(this.c, i, 0, i2, 0);
                T t2 = (T) this.c.getLayoutParams();
                int max3 = Math.max(max, this.c.getMeasuredWidth() + ((ViewGroup.MarginLayoutParams) t2).leftMargin + ((ViewGroup.MarginLayoutParams) t2).rightMargin);
                int max4 = Math.max(max2, this.c.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) t2).topMargin + ((ViewGroup.MarginLayoutParams) t2).bottomMargin);
                int combineMeasuredStates2 = View.combineMeasuredStates(combineMeasuredStates, this.c.getMeasuredState());
                setMeasuredDimension(View.resolveSizeAndState(Math.max(getPaddingRight() + getPaddingLeft() + max3, getSuggestedMinimumWidth()), i, combineMeasuredStates2), View.resolveSizeAndState(Math.max(getPaddingBottom() + getPaddingTop() + max4, getSuggestedMinimumHeight()), i2, combineMeasuredStates2 << 16));
            }
        }
        C9 b = C9.b(this.s.b(), this.s.d() + measuredHeight, this.s.c(), this.s.a());
        wi wiVar3 = this.s;
        int i3 = Build.VERSION.SDK_INT;
        if (i3 >= 30) {
            kiVar = new ni(wiVar3);
        } else if (i3 >= 29) {
            kiVar = new mi(wiVar3);
        } else {
            kiVar = new ki(wiVar3);
        }
        kiVar.g(b);
        this.s = kiVar.b();
        g(this.c, rect2, true);
        if (!this.t.equals(this.s)) {
        }
        measureChildWithMargins(this.c, i, 0, i2, 0);
        T t22 = (T) this.c.getLayoutParams();
        int max32 = Math.max(max, this.c.getMeasuredWidth() + ((ViewGroup.MarginLayoutParams) t22).leftMargin + ((ViewGroup.MarginLayoutParams) t22).rightMargin);
        int max42 = Math.max(max2, this.c.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) t22).topMargin + ((ViewGroup.MarginLayoutParams) t22).bottomMargin);
        int combineMeasuredStates22 = View.combineMeasuredStates(combineMeasuredStates, this.c.getMeasuredState());
        setMeasuredDimension(View.resolveSizeAndState(Math.max(getPaddingRight() + getPaddingLeft() + max32, getSuggestedMinimumWidth()), i, combineMeasuredStates22), View.resolveSizeAndState(Math.max(getPaddingBottom() + getPaddingTop() + max42, getSuggestedMinimumHeight()), i2, combineMeasuredStates22 << 16));
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onNestedFling(View view, float f, float f2, boolean z) {
        if (this.i && z) {
            this.v.fling(0, 0, 0, (int) f2, 0, 0, Integer.MIN_VALUE, Integer.MAX_VALUE);
            if (this.v.getFinalY() > this.d.getHeight()) {
                h();
                this.z.run();
            } else {
                h();
                this.y.run();
            }
            this.j = true;
            return true;
        }
        return false;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onNestedPreFling(View view, float f, float f2) {
        return false;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedPreScroll(View view, int i, int i2, int[] iArr) {
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedScroll(View view, int i, int i2, int i3, int i4) {
        int i5 = this.k + i2;
        this.k = i5;
        setActionBarHideOffset(i5);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedScrollAccepted(View view, View view2, int i) {
        C0059ci c0059ci;
        Bh bh;
        this.A.a = i;
        this.k = getActionBarHideOffset();
        h();
        S s = this.u;
        if (s != null && (bh = (c0059ci = (C0059ci) s).K) != null) {
            bh.a();
            c0059ci.K = null;
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onStartNestedScroll(View view, View view2, int i) {
        if ((i & 2) != 0 && this.d.getVisibility() == 0) {
            return this.i;
        }
        return false;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onStopNestedScroll(View view) {
        if (this.i && !this.j) {
            if (this.k <= this.d.getHeight()) {
                h();
                postDelayed(this.y, 600L);
            } else {
                h();
                postDelayed(this.z, 600L);
            }
        }
    }

    @Override // android.view.View
    public final void onWindowSystemUiVisibilityChanged(int i) {
        boolean z;
        boolean z2;
        super.onWindowSystemUiVisibilityChanged(i);
        k();
        int i2 = this.l ^ i;
        this.l = i;
        if ((i & 4) == 0) {
            z = true;
        } else {
            z = false;
        }
        if ((i & PSKKeyManager.MAX_KEY_LENGTH_BYTES) != 0) {
            z2 = true;
        } else {
            z2 = false;
        }
        S s = this.u;
        if (s != null) {
            C0059ci c0059ci = (C0059ci) s;
            c0059ci.G = !z2;
            if (!z && z2) {
                if (!c0059ci.H) {
                    c0059ci.H = true;
                    c0059ci.M0(true);
                }
            } else if (c0059ci.H) {
                c0059ci.H = false;
                c0059ci.M0(true);
            }
        }
        if ((i2 & PSKKeyManager.MAX_KEY_LENGTH_BYTES) != 0 && this.u != null) {
            WeakHashMap weakHashMap = AbstractC0309ph.a;
            AbstractC0118fh.c(this);
        }
    }

    @Override // android.view.View
    public final void onWindowVisibilityChanged(int i) {
        super.onWindowVisibilityChanged(i);
        this.b = i;
        S s = this.u;
        if (s != null) {
            ((C0059ci) s).F = i;
        }
    }

    public void setActionBarHideOffset(int i) {
        h();
        this.d.setTranslationY(-Math.max(0, Math.min(i, this.d.getHeight())));
    }

    public void setActionBarVisibilityCallback(S s) {
        this.u = s;
        if (getWindowToken() != null) {
            ((C0059ci) this.u).F = this.b;
            int i = this.l;
            if (i != 0) {
                onWindowSystemUiVisibilityChanged(i);
                WeakHashMap weakHashMap = AbstractC0309ph.a;
                AbstractC0118fh.c(this);
            }
        }
    }

    public void setHasNonEmbeddedTabs(boolean z) {
        this.h = z;
    }

    public void setHideOnContentScrollEnabled(boolean z) {
        if (z != this.i) {
            this.i = z;
            if (!z) {
                h();
                setActionBarHideOffset(0);
            }
        }
    }

    public void setIcon(int i) {
        k();
        C0057cg c0057cg = (C0057cg) this.e;
        c0057cg.d = i != 0 ? AbstractC0124g3.r(c0057cg.a.getContext(), i) : null;
        c0057cg.c();
    }

    public void setLogo(int i) {
        Drawable drawable;
        k();
        C0057cg c0057cg = (C0057cg) this.e;
        if (i != 0) {
            drawable = AbstractC0124g3.r(c0057cg.a.getContext(), i);
        } else {
            drawable = null;
        }
        c0057cg.e = drawable;
        c0057cg.c();
    }

    public void setOverlayMode(boolean z) {
        this.g = z;
    }

    public void setShowingForActionMode(boolean z) {
    }

    public void setUiOptions(int i) {
    }

    @Override // x.InterfaceC0046c5
    public void setWindowCallback(Window.Callback callback) {
        k();
        ((C0057cg) this.e).k = callback;
    }

    @Override // x.InterfaceC0046c5
    public void setWindowTitle(CharSequence charSequence) {
        k();
        C0057cg c0057cg = (C0057cg) this.e;
        if (!c0057cg.g) {
            c0057cg.h = charSequence;
            if ((c0057cg.b & 8) != 0) {
                Toolbar toolbar = c0057cg.a;
                toolbar.setTitle(charSequence);
                if (c0057cg.g) {
                    AbstractC0309ph.m(toolbar.getRootView(), charSequence);
                }
            }
        }
    }

    @Override // android.view.ViewGroup
    public final boolean shouldDelayChildPressedState() {
        return false;
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return new ViewGroup.MarginLayoutParams(layoutParams);
    }

    public void setIcon(Drawable drawable) {
        k();
        C0057cg c0057cg = (C0057cg) this.e;
        c0057cg.d = drawable;
        c0057cg.c();
    }
}
