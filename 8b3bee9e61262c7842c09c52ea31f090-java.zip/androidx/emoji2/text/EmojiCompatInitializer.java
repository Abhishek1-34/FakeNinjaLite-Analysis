package androidx.emoji2.text;

import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import androidx.lifecycle.ProcessLifecycleInitializer;
import androidx.lifecycle.a;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import x.AbstractC0203k6;
import x.AbstractC0220l4;
import x.C0260n6;
import x.C0294p2;
import x.C0317q6;
import x.InterfaceC0259n5;
import x.InterfaceC0433w9;
import x.Y9;

/* loaded from: classes.dex */
public class EmojiCompatInitializer implements InterfaceC0433w9 {
    @Override // x.InterfaceC0433w9
    public final List a() {
        return Collections.singletonList(ProcessLifecycleInitializer.class);
    }

    /* JADX WARN: Type inference failed for: r0v0, types: [x.k6, x.N7] */
    @Override // x.InterfaceC0433w9
    public final Object b(Context context) {
        Object obj;
        ?? abstractC0203k6 = new AbstractC0203k6(new C0317q6(context, 0));
        abstractC0203k6.a = 1;
        if (C0260n6.k == null) {
            synchronized (C0260n6.j) {
                try {
                    if (C0260n6.k == null) {
                        C0260n6.k = new C0260n6(abstractC0203k6);
                    }
                } finally {
                }
            }
        }
        C0294p2 r = C0294p2.r(context);
        r.getClass();
        synchronized (C0294p2.f) {
            try {
                obj = ((HashMap) r.b).get(ProcessLifecycleInitializer.class);
                if (obj == null) {
                    obj = r.k(ProcessLifecycleInitializer.class, new HashSet());
                }
            } finally {
            }
        }
        final a d = ((Y9) obj).d();
        d.a(new InterfaceC0259n5() { // from class: androidx.emoji2.text.EmojiCompatInitializer.1
            /* JADX WARN: Multi-variable type inference failed */
            /* JADX WARN: Type inference failed for: r1v2, types: [java.lang.Object, java.lang.Runnable] */
            @Override // x.InterfaceC0259n5
            public final void a() {
                Handler handler;
                EmojiCompatInitializer.this.getClass();
                if (Build.VERSION.SDK_INT >= 28) {
                    handler = AbstractC0220l4.a(Looper.getMainLooper());
                } else {
                    handler = new Handler(Looper.getMainLooper());
                }
                handler.postDelayed(new Object(), 500L);
                d.f(this);
            }
        });
        return Boolean.TRUE;
    }
}
