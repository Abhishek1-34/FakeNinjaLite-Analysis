package androidx.fragment.app;

import x.S9;
import x.W9;
import x.Y9;

/* loaded from: classes.dex */
class FragmentManager$6 implements W9 {
    @Override // x.W9
    public final void b(Y9 y9, S9 s9) {
        if (s9 != S9.ON_START) {
            if (s9 != S9.ON_DESTROY) {
                return;
            } else {
                throw null;
            }
        }
        throw null;
    }
}
