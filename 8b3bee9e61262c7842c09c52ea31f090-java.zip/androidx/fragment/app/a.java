package androidx.fragment.app;

import android.content.res.Resources;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.AndroidRuntimeException;
import android.util.Log;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import androidx.lifecycle.b;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.WeakHashMap;
import org.conscrypt.R;
import org.conscrypt.ct.CTConstants;
import x.A8;
import x.AbstractC0118fh;
import x.AbstractC0309ph;
import x.AbstractComponentCallbacksC0089e8;
import x.B8;
import x.C0009a8;
import x.C0016af;
import x.C0049c8;
import x.C0129g8;
import x.C0281o8;
import x.C0353s5;
import x.C0375t8;
import x.C0410v5;
import x.C0413v8;
import x.C0434wa;
import x.C0451x8;
import x.C0470y8;
import x.D8;
import x.F1;
import x.InterfaceC0432w8;
import x.R0;
import x.S9;
import x.T9;
import x.Ue;
import x.ViewOnAttachStateChangeListenerC0370t3;
import x.W9;
import x.Y9;
import x.Ye;

/* loaded from: classes.dex */
public final class a {
    public final F1 a;
    public final C0353s5 b;
    public final AbstractComponentCallbacksC0089e8 c;
    public boolean d = false;
    public int e = -1;

    public a(F1 f1, C0353s5 c0353s5, AbstractComponentCallbacksC0089e8 abstractComponentCallbacksC0089e8) {
        this.a = f1;
        this.b = c0353s5;
        this.c = abstractComponentCallbacksC0089e8;
    }

    public final void a() {
        boolean isLoggable = Log.isLoggable("FragmentManager", 3);
        AbstractComponentCallbacksC0089e8 abstractComponentCallbacksC0089e8 = this.c;
        if (isLoggable) {
            Log.d("FragmentManager", "moveto ACTIVITY_CREATED: " + abstractComponentCallbacksC0089e8);
        }
        Bundle bundle = abstractComponentCallbacksC0089e8.b;
        abstractComponentCallbacksC0089e8.t.J();
        abstractComponentCallbacksC0089e8.a = 3;
        abstractComponentCallbacksC0089e8.C = false;
        abstractComponentCallbacksC0089e8.p();
        if (abstractComponentCallbacksC0089e8.C) {
            if (Log.isLoggable("FragmentManager", 3)) {
                Log.d("FragmentManager", "moveto RESTORE_VIEW_STATE: " + abstractComponentCallbacksC0089e8);
            }
            View view = abstractComponentCallbacksC0089e8.E;
            if (view != null) {
                Bundle bundle2 = abstractComponentCallbacksC0089e8.b;
                SparseArray<Parcelable> sparseArray = abstractComponentCallbacksC0089e8.c;
                if (sparseArray != null) {
                    view.restoreHierarchyState(sparseArray);
                    abstractComponentCallbacksC0089e8.c = null;
                }
                if (abstractComponentCallbacksC0089e8.E != null) {
                    abstractComponentCallbacksC0089e8.N.d.b(abstractComponentCallbacksC0089e8.d);
                    abstractComponentCallbacksC0089e8.d = null;
                }
                abstractComponentCallbacksC0089e8.C = false;
                abstractComponentCallbacksC0089e8.A(bundle2);
                if (abstractComponentCallbacksC0089e8.C) {
                    if (abstractComponentCallbacksC0089e8.E != null) {
                        abstractComponentCallbacksC0089e8.N.e(S9.ON_CREATE);
                    }
                } else {
                    throw new AndroidRuntimeException("Fragment " + abstractComponentCallbacksC0089e8 + " did not call through to super.onViewStateRestored()");
                }
            }
            abstractComponentCallbacksC0089e8.b = null;
            C0375t8 c0375t8 = abstractComponentCallbacksC0089e8.t;
            c0375t8.E = false;
            c0375t8.F = false;
            c0375t8.L.h = false;
            c0375t8.t(4);
            this.a.b(false);
            return;
        }
        throw new AndroidRuntimeException("Fragment " + abstractComponentCallbacksC0089e8 + " did not call through to super.onActivityCreated()");
    }

    public final void b() {
        View view;
        View view2;
        C0353s5 c0353s5 = this.b;
        c0353s5.getClass();
        AbstractComponentCallbacksC0089e8 abstractComponentCallbacksC0089e8 = this.c;
        ViewGroup viewGroup = abstractComponentCallbacksC0089e8.D;
        int i = -1;
        if (viewGroup != null) {
            ArrayList arrayList = (ArrayList) c0353s5.a;
            int indexOf = arrayList.indexOf(abstractComponentCallbacksC0089e8);
            int i2 = indexOf - 1;
            while (true) {
                if (i2 < 0) {
                    while (true) {
                        indexOf++;
                        if (indexOf >= arrayList.size()) {
                            break;
                        }
                        AbstractComponentCallbacksC0089e8 abstractComponentCallbacksC0089e82 = (AbstractComponentCallbacksC0089e8) arrayList.get(indexOf);
                        if (abstractComponentCallbacksC0089e82.D == viewGroup && (view = abstractComponentCallbacksC0089e82.E) != null) {
                            i = viewGroup.indexOfChild(view);
                            break;
                        }
                    }
                } else {
                    AbstractComponentCallbacksC0089e8 abstractComponentCallbacksC0089e83 = (AbstractComponentCallbacksC0089e8) arrayList.get(i2);
                    if (abstractComponentCallbacksC0089e83.D == viewGroup && (view2 = abstractComponentCallbacksC0089e83.E) != null) {
                        i = viewGroup.indexOfChild(view2) + 1;
                        break;
                    }
                    i2--;
                }
            }
        }
        abstractComponentCallbacksC0089e8.D.addView(abstractComponentCallbacksC0089e8.E, i);
    }

    public final void c() {
        boolean isLoggable = Log.isLoggable("FragmentManager", 3);
        AbstractComponentCallbacksC0089e8 abstractComponentCallbacksC0089e8 = this.c;
        if (isLoggable) {
            Log.d("FragmentManager", "moveto ATTACHED: " + abstractComponentCallbacksC0089e8);
        }
        AbstractComponentCallbacksC0089e8 abstractComponentCallbacksC0089e82 = abstractComponentCallbacksC0089e8.g;
        a aVar = null;
        C0353s5 c0353s5 = this.b;
        if (abstractComponentCallbacksC0089e82 != null) {
            a aVar2 = (a) ((HashMap) c0353s5.b).get(abstractComponentCallbacksC0089e82.e);
            if (aVar2 != null) {
                abstractComponentCallbacksC0089e8.h = abstractComponentCallbacksC0089e8.g.e;
                abstractComponentCallbacksC0089e8.g = null;
                aVar = aVar2;
            } else {
                throw new IllegalStateException("Fragment " + abstractComponentCallbacksC0089e8 + " declared target fragment " + abstractComponentCallbacksC0089e8.g + " that does not belong to this FragmentManager!");
            }
        } else {
            String str = abstractComponentCallbacksC0089e8.h;
            if (str != null && (aVar = (a) ((HashMap) c0353s5.b).get(str)) == null) {
                throw new IllegalStateException("Fragment " + abstractComponentCallbacksC0089e8 + " declared target fragment " + abstractComponentCallbacksC0089e8.h + " that does not belong to this FragmentManager!");
            }
        }
        if (aVar != null) {
            aVar.k();
        }
        C0375t8 c0375t8 = abstractComponentCallbacksC0089e8.r;
        abstractComponentCallbacksC0089e8.s = c0375t8.t;
        abstractComponentCallbacksC0089e8.u = c0375t8.v;
        F1 f1 = this.a;
        f1.i(false);
        ArrayList arrayList = abstractComponentCallbacksC0089e8.Q;
        Iterator it = arrayList.iterator();
        while (it.hasNext()) {
            ((C0009a8) it.next()).a();
        }
        arrayList.clear();
        abstractComponentCallbacksC0089e8.t.b(abstractComponentCallbacksC0089e8.s, abstractComponentCallbacksC0089e8.e(), abstractComponentCallbacksC0089e8);
        abstractComponentCallbacksC0089e8.a = 0;
        abstractComponentCallbacksC0089e8.C = false;
        abstractComponentCallbacksC0089e8.r(abstractComponentCallbacksC0089e8.s.a0);
        if (abstractComponentCallbacksC0089e8.C) {
            Iterator it2 = abstractComponentCallbacksC0089e8.r.m.iterator();
            while (it2.hasNext()) {
                ((InterfaceC0432w8) it2.next()).a();
            }
            C0375t8 c0375t82 = abstractComponentCallbacksC0089e8.t;
            c0375t82.E = false;
            c0375t82.F = false;
            c0375t82.L.h = false;
            c0375t82.t(0);
            f1.c(false);
            return;
        }
        throw new AndroidRuntimeException("Fragment " + abstractComponentCallbacksC0089e8 + " did not call through to super.onAttach()");
    }

    public final int d() {
        C0016af c0016af;
        AbstractComponentCallbacksC0089e8 abstractComponentCallbacksC0089e8 = this.c;
        if (abstractComponentCallbacksC0089e8.r == null) {
            return abstractComponentCallbacksC0089e8.a;
        }
        int i = this.e;
        int ordinal = abstractComponentCallbacksC0089e8.L.ordinal();
        int i2 = 0;
        if (ordinal != 1) {
            if (ordinal != 2) {
                if (ordinal != 3) {
                    if (ordinal != 4) {
                        i = Math.min(i, -1);
                    }
                } else {
                    i = Math.min(i, 5);
                }
            } else {
                i = Math.min(i, 1);
            }
        } else {
            i = Math.min(i, 0);
        }
        if (abstractComponentCallbacksC0089e8.m) {
            if (abstractComponentCallbacksC0089e8.n) {
                i = Math.max(this.e, 2);
                View view = abstractComponentCallbacksC0089e8.E;
                if (view != null && view.getParent() == null) {
                    i = Math.min(i, 2);
                }
            } else {
                i = this.e < 4 ? Math.min(i, abstractComponentCallbacksC0089e8.a) : Math.min(i, 1);
            }
        }
        if (!abstractComponentCallbacksC0089e8.k) {
            i = Math.min(i, 1);
        }
        ViewGroup viewGroup = abstractComponentCallbacksC0089e8.D;
        if (viewGroup != null) {
            C0410v5 f = C0410v5.f(viewGroup, abstractComponentCallbacksC0089e8.j().C());
            f.getClass();
            C0016af d = f.d(abstractComponentCallbacksC0089e8);
            if (d != null) {
                i2 = d.b;
            }
            Iterator it = f.c.iterator();
            while (true) {
                if (it.hasNext()) {
                    c0016af = (C0016af) it.next();
                    if (c0016af.c.equals(abstractComponentCallbacksC0089e8) && !c0016af.f) {
                        break;
                    }
                } else {
                    c0016af = null;
                    break;
                }
            }
            if (c0016af != null && (i2 == 0 || i2 == 1)) {
                i2 = c0016af.b;
            }
        }
        if (i2 == 2) {
            i = Math.min(i, 6);
        } else if (i2 == 3) {
            i = Math.max(i, 3);
        } else if (abstractComponentCallbacksC0089e8.l) {
            if (abstractComponentCallbacksC0089e8.o()) {
                i = Math.min(i, 1);
            } else {
                i = Math.min(i, -1);
            }
        }
        if (abstractComponentCallbacksC0089e8.F && abstractComponentCallbacksC0089e8.a < 5) {
            i = Math.min(i, 4);
        }
        if (Log.isLoggable("FragmentManager", 2)) {
            Log.v("FragmentManager", "computeExpectedState() of " + i + " for " + abstractComponentCallbacksC0089e8);
        }
        return i;
    }

    public final void e() {
        boolean isLoggable = Log.isLoggable("FragmentManager", 3);
        final AbstractComponentCallbacksC0089e8 abstractComponentCallbacksC0089e8 = this.c;
        if (isLoggable) {
            Log.d("FragmentManager", "moveto CREATED: " + abstractComponentCallbacksC0089e8);
        }
        if (!abstractComponentCallbacksC0089e8.J) {
            F1 f1 = this.a;
            f1.j(false);
            Bundle bundle = abstractComponentCallbacksC0089e8.b;
            abstractComponentCallbacksC0089e8.t.J();
            abstractComponentCallbacksC0089e8.a = 1;
            abstractComponentCallbacksC0089e8.C = false;
            abstractComponentCallbacksC0089e8.M.a(new W9() { // from class: androidx.fragment.app.Fragment$6
                @Override // x.W9
                public final void b(Y9 y9, S9 s9) {
                    View view;
                    if (s9 == S9.ON_STOP && (view = AbstractComponentCallbacksC0089e8.this.E) != null) {
                        view.cancelPendingInputEvents();
                    }
                }
            });
            abstractComponentCallbacksC0089e8.P.b(bundle);
            abstractComponentCallbacksC0089e8.s(bundle);
            abstractComponentCallbacksC0089e8.J = true;
            if (abstractComponentCallbacksC0089e8.C) {
                abstractComponentCallbacksC0089e8.M.d(S9.ON_CREATE);
                f1.d(false);
                return;
            } else {
                throw new AndroidRuntimeException("Fragment " + abstractComponentCallbacksC0089e8 + " did not call through to super.onCreate()");
            }
        }
        abstractComponentCallbacksC0089e8.E(abstractComponentCallbacksC0089e8.b);
        abstractComponentCallbacksC0089e8.a = 1;
    }

    public final void f() {
        String str;
        int i = 2;
        AbstractComponentCallbacksC0089e8 abstractComponentCallbacksC0089e8 = this.c;
        if (abstractComponentCallbacksC0089e8.m) {
            return;
        }
        if (Log.isLoggable("FragmentManager", 3)) {
            Log.d("FragmentManager", "moveto CREATE_VIEW: " + abstractComponentCallbacksC0089e8);
        }
        LayoutInflater w = abstractComponentCallbacksC0089e8.w(abstractComponentCallbacksC0089e8.b);
        ViewGroup viewGroup = abstractComponentCallbacksC0089e8.D;
        if (viewGroup == null) {
            int i2 = abstractComponentCallbacksC0089e8.w;
            if (i2 != 0) {
                if (i2 != -1) {
                    viewGroup = (ViewGroup) abstractComponentCallbacksC0089e8.r.u.D(i2);
                    if (viewGroup == null) {
                        if (!abstractComponentCallbacksC0089e8.o) {
                            try {
                                str = abstractComponentCallbacksC0089e8.C().getResources().getResourceName(abstractComponentCallbacksC0089e8.w);
                            } catch (Resources.NotFoundException unused) {
                                str = "unknown";
                            }
                            throw new IllegalArgumentException("No view found for id 0x" + Integer.toHexString(abstractComponentCallbacksC0089e8.w) + " (" + str + ") for fragment " + abstractComponentCallbacksC0089e8);
                        }
                    } else if (!(viewGroup instanceof FragmentContainerView)) {
                        A8 a8 = B8.a;
                        B8.b(new C0451x8(abstractComponentCallbacksC0089e8, "Attempting to add fragment " + abstractComponentCallbacksC0089e8 + " to container " + viewGroup + " which is not a FragmentContainerView"));
                        B8.a(abstractComponentCallbacksC0089e8).getClass();
                    }
                } else {
                    throw new IllegalArgumentException("Cannot create fragment " + abstractComponentCallbacksC0089e8 + " for a container view with no id");
                }
            } else {
                viewGroup = null;
            }
        }
        abstractComponentCallbacksC0089e8.D = viewGroup;
        abstractComponentCallbacksC0089e8.B(w, viewGroup, abstractComponentCallbacksC0089e8.b);
        View view = abstractComponentCallbacksC0089e8.E;
        if (view != null) {
            view.setSaveFromParentEnabled(false);
            abstractComponentCallbacksC0089e8.E.setTag(R.id.fragment_container_view_tag, abstractComponentCallbacksC0089e8);
            if (viewGroup != null) {
                b();
            }
            if (abstractComponentCallbacksC0089e8.y) {
                abstractComponentCallbacksC0089e8.E.setVisibility(8);
            }
            View view2 = abstractComponentCallbacksC0089e8.E;
            WeakHashMap weakHashMap = AbstractC0309ph.a;
            if (view2.isAttachedToWindow()) {
                AbstractC0118fh.c(abstractComponentCallbacksC0089e8.E);
            } else {
                View view3 = abstractComponentCallbacksC0089e8.E;
                view3.addOnAttachStateChangeListener(new ViewOnAttachStateChangeListenerC0370t3(i, view3));
            }
            abstractComponentCallbacksC0089e8.t.t(2);
            this.a.q(false);
            int visibility = abstractComponentCallbacksC0089e8.E.getVisibility();
            abstractComponentCallbacksC0089e8.f().j = abstractComponentCallbacksC0089e8.E.getAlpha();
            if (abstractComponentCallbacksC0089e8.D != null && visibility == 0) {
                View findFocus = abstractComponentCallbacksC0089e8.E.findFocus();
                if (findFocus != null) {
                    abstractComponentCallbacksC0089e8.f().k = findFocus;
                    if (Log.isLoggable("FragmentManager", 2)) {
                        Log.v("FragmentManager", "requestFocus: Saved focused view " + findFocus + " for Fragment " + abstractComponentCallbacksC0089e8);
                    }
                }
                abstractComponentCallbacksC0089e8.E.setAlpha(0.0f);
            }
        }
        abstractComponentCallbacksC0089e8.a = 2;
    }

    public final void g() {
        boolean z;
        boolean z2;
        boolean z3;
        AbstractComponentCallbacksC0089e8 c;
        boolean isLoggable = Log.isLoggable("FragmentManager", 3);
        AbstractComponentCallbacksC0089e8 abstractComponentCallbacksC0089e8 = this.c;
        if (isLoggable) {
            Log.d("FragmentManager", "movefrom CREATED: " + abstractComponentCallbacksC0089e8);
        }
        if (abstractComponentCallbacksC0089e8.l && !abstractComponentCallbacksC0089e8.o()) {
            z = true;
        } else {
            z = false;
        }
        C0353s5 c0353s5 = this.b;
        if (z) {
        }
        if (!z) {
            C0413v8 c0413v8 = (C0413v8) c0353s5.d;
            if (!c0413v8.c.containsKey(abstractComponentCallbacksC0089e8.e) || !c0413v8.f) {
                z3 = true;
            } else {
                z3 = c0413v8.g;
            }
            if (!z3) {
                String str = abstractComponentCallbacksC0089e8.h;
                if (str != null && (c = c0353s5.c(str)) != null && c.A) {
                    abstractComponentCallbacksC0089e8.g = c;
                }
                abstractComponentCallbacksC0089e8.a = 0;
                return;
            }
        }
        C0129g8 c0129g8 = abstractComponentCallbacksC0089e8.s;
        if (c0129g8 != null) {
            z2 = ((C0413v8) c0353s5.d).g;
        } else {
            R0 r0 = c0129g8.a0;
            if (r0 != null) {
                z2 = !r0.isChangingConfigurations();
            } else {
                z2 = true;
            }
        }
        if (z || z2) {
            ((C0413v8) c0353s5.d).b(abstractComponentCallbacksC0089e8);
        }
        abstractComponentCallbacksC0089e8.t.k();
        abstractComponentCallbacksC0089e8.M.d(S9.ON_DESTROY);
        abstractComponentCallbacksC0089e8.a = 0;
        abstractComponentCallbacksC0089e8.J = false;
        abstractComponentCallbacksC0089e8.C = true;
        this.a.e(false);
        Iterator it = c0353s5.f().iterator();
        while (it.hasNext()) {
            a aVar = (a) it.next();
            if (aVar != null) {
                String str2 = abstractComponentCallbacksC0089e8.e;
                AbstractComponentCallbacksC0089e8 abstractComponentCallbacksC0089e82 = aVar.c;
                if (str2.equals(abstractComponentCallbacksC0089e82.h)) {
                    abstractComponentCallbacksC0089e82.g = abstractComponentCallbacksC0089e8;
                    abstractComponentCallbacksC0089e82.h = null;
                }
            }
        }
        String str3 = abstractComponentCallbacksC0089e8.h;
        if (str3 != null) {
            abstractComponentCallbacksC0089e8.g = c0353s5.c(str3);
        }
        c0353s5.j(this);
    }

    public final void h() {
        View view;
        boolean isLoggable = Log.isLoggable("FragmentManager", 3);
        AbstractComponentCallbacksC0089e8 abstractComponentCallbacksC0089e8 = this.c;
        if (isLoggable) {
            Log.d("FragmentManager", "movefrom CREATE_VIEW: " + abstractComponentCallbacksC0089e8);
        }
        ViewGroup viewGroup = abstractComponentCallbacksC0089e8.D;
        if (viewGroup != null && (view = abstractComponentCallbacksC0089e8.E) != null) {
            viewGroup.removeView(view);
        }
        abstractComponentCallbacksC0089e8.t.t(1);
        if (abstractComponentCallbacksC0089e8.E != null) {
            D8 d8 = abstractComponentCallbacksC0089e8.N;
            d8.f();
            if (d8.c.c.compareTo(T9.c) >= 0) {
                abstractComponentCallbacksC0089e8.N.e(S9.ON_DESTROY);
            }
        }
        abstractComponentCallbacksC0089e8.a = 1;
        abstractComponentCallbacksC0089e8.C = false;
        abstractComponentCallbacksC0089e8.u();
        if (abstractComponentCallbacksC0089e8.C) {
            Ye ye = ((C0434wa) F1.w(abstractComponentCallbacksC0089e8).c).c;
            if (ye.c <= 0) {
                abstractComponentCallbacksC0089e8.p = false;
                this.a.r(false);
                abstractComponentCallbacksC0089e8.D = null;
                abstractComponentCallbacksC0089e8.E = null;
                abstractComponentCallbacksC0089e8.N = null;
                b bVar = abstractComponentCallbacksC0089e8.O;
                bVar.getClass();
                b.a("setValue");
                bVar.g++;
                bVar.e = null;
                bVar.c(null);
                abstractComponentCallbacksC0089e8.n = false;
                return;
            }
            ye.b[0].getClass();
            throw new ClassCastException();
        }
        throw new AndroidRuntimeException("Fragment " + abstractComponentCallbacksC0089e8 + " did not call through to super.onDestroyView()");
    }

    public final void i() {
        boolean isLoggable = Log.isLoggable("FragmentManager", 3);
        AbstractComponentCallbacksC0089e8 abstractComponentCallbacksC0089e8 = this.c;
        if (isLoggable) {
            Log.d("FragmentManager", "movefrom ATTACHED: " + abstractComponentCallbacksC0089e8);
        }
        abstractComponentCallbacksC0089e8.a = -1;
        abstractComponentCallbacksC0089e8.C = false;
        abstractComponentCallbacksC0089e8.v();
        if (abstractComponentCallbacksC0089e8.C) {
            C0375t8 c0375t8 = abstractComponentCallbacksC0089e8.t;
            if (!c0375t8.G) {
                c0375t8.k();
                abstractComponentCallbacksC0089e8.t = new C0375t8();
            }
            this.a.g(false);
            abstractComponentCallbacksC0089e8.a = -1;
            abstractComponentCallbacksC0089e8.s = null;
            abstractComponentCallbacksC0089e8.u = null;
            abstractComponentCallbacksC0089e8.r = null;
            if (!abstractComponentCallbacksC0089e8.l || abstractComponentCallbacksC0089e8.o()) {
                C0413v8 c0413v8 = (C0413v8) this.b.d;
                boolean z = true;
                if (c0413v8.c.containsKey(abstractComponentCallbacksC0089e8.e) && c0413v8.f) {
                    z = c0413v8.g;
                }
                if (!z) {
                    return;
                }
            }
            if (Log.isLoggable("FragmentManager", 3)) {
                Log.d("FragmentManager", "initState called for fragment: " + abstractComponentCallbacksC0089e8);
            }
            abstractComponentCallbacksC0089e8.l();
            return;
        }
        throw new AndroidRuntimeException("Fragment " + abstractComponentCallbacksC0089e8 + " did not call through to super.onDetach()");
    }

    public final void j() {
        AbstractComponentCallbacksC0089e8 abstractComponentCallbacksC0089e8 = this.c;
        if (abstractComponentCallbacksC0089e8.m && abstractComponentCallbacksC0089e8.n && !abstractComponentCallbacksC0089e8.p) {
            if (Log.isLoggable("FragmentManager", 3)) {
                Log.d("FragmentManager", "moveto CREATE_VIEW: " + abstractComponentCallbacksC0089e8);
            }
            abstractComponentCallbacksC0089e8.B(abstractComponentCallbacksC0089e8.w(abstractComponentCallbacksC0089e8.b), null, abstractComponentCallbacksC0089e8.b);
            View view = abstractComponentCallbacksC0089e8.E;
            if (view != null) {
                view.setSaveFromParentEnabled(false);
                abstractComponentCallbacksC0089e8.E.setTag(R.id.fragment_container_view_tag, abstractComponentCallbacksC0089e8);
                if (abstractComponentCallbacksC0089e8.y) {
                    abstractComponentCallbacksC0089e8.E.setVisibility(8);
                }
                abstractComponentCallbacksC0089e8.t.t(2);
                this.a.q(false);
                abstractComponentCallbacksC0089e8.a = 2;
            }
        }
    }

    public final void k() {
        ViewGroup viewGroup;
        ViewGroup viewGroup2;
        ViewGroup viewGroup3;
        C0353s5 c0353s5 = this.b;
        boolean z = this.d;
        AbstractComponentCallbacksC0089e8 abstractComponentCallbacksC0089e8 = this.c;
        if (z) {
            if (Log.isLoggable("FragmentManager", 2)) {
                Log.v("FragmentManager", "Ignoring re-entrant call to moveToExpectedState() for " + abstractComponentCallbacksC0089e8);
                return;
            }
            return;
        }
        try {
            this.d = true;
            boolean z2 = false;
            while (true) {
                int d = d();
                int i = abstractComponentCallbacksC0089e8.a;
                if (d != i) {
                    if (d > i) {
                        switch (i + 1) {
                            case 0:
                                c();
                                break;
                            case 1:
                                e();
                                break;
                            case 2:
                                j();
                                f();
                                break;
                            case CTConstants.CERTIFICATE_LENGTH_BYTES /* 3 */:
                                a();
                                break;
                            case 4:
                                if (abstractComponentCallbacksC0089e8.E != null && (viewGroup3 = abstractComponentCallbacksC0089e8.D) != null) {
                                    C0410v5 f = C0410v5.f(viewGroup3, abstractComponentCallbacksC0089e8.j().C());
                                    int b = Ue.b(abstractComponentCallbacksC0089e8.E.getVisibility());
                                    f.getClass();
                                    if (Log.isLoggable("FragmentManager", 2)) {
                                        Log.v("FragmentManager", "SpecialEffectsController: Enqueuing add operation for fragment " + abstractComponentCallbacksC0089e8);
                                    }
                                    f.a(b, 2, this);
                                }
                                abstractComponentCallbacksC0089e8.a = 4;
                                break;
                            case 5:
                                p();
                                break;
                            case 6:
                                abstractComponentCallbacksC0089e8.a = 6;
                                break;
                            case 7:
                                n();
                                break;
                        }
                    } else {
                        switch (i - 1) {
                            case -1:
                                i();
                                break;
                            case 0:
                                g();
                                break;
                            case 1:
                                h();
                                abstractComponentCallbacksC0089e8.a = 1;
                                break;
                            case 2:
                                abstractComponentCallbacksC0089e8.n = false;
                                abstractComponentCallbacksC0089e8.a = 2;
                                break;
                            case CTConstants.CERTIFICATE_LENGTH_BYTES /* 3 */:
                                if (Log.isLoggable("FragmentManager", 3)) {
                                    Log.d("FragmentManager", "movefrom ACTIVITY_CREATED: " + abstractComponentCallbacksC0089e8);
                                }
                                if (abstractComponentCallbacksC0089e8.E != null && abstractComponentCallbacksC0089e8.c == null) {
                                    o();
                                }
                                if (abstractComponentCallbacksC0089e8.E != null && (viewGroup2 = abstractComponentCallbacksC0089e8.D) != null) {
                                    C0410v5 f2 = C0410v5.f(viewGroup2, abstractComponentCallbacksC0089e8.j().C());
                                    f2.getClass();
                                    if (Log.isLoggable("FragmentManager", 2)) {
                                        Log.v("FragmentManager", "SpecialEffectsController: Enqueuing remove operation for fragment " + abstractComponentCallbacksC0089e8);
                                    }
                                    f2.a(1, 3, this);
                                }
                                abstractComponentCallbacksC0089e8.a = 3;
                                break;
                            case 4:
                                q();
                                break;
                            case 5:
                                abstractComponentCallbacksC0089e8.a = 5;
                                break;
                            case 6:
                                l();
                                break;
                        }
                    }
                    z2 = true;
                } else {
                    if (!z2 && i == -1 && abstractComponentCallbacksC0089e8.l && !abstractComponentCallbacksC0089e8.o()) {
                        if (Log.isLoggable("FragmentManager", 3)) {
                            Log.d("FragmentManager", "Cleaning up state of never attached fragment: " + abstractComponentCallbacksC0089e8);
                        }
                        ((C0413v8) c0353s5.d).b(abstractComponentCallbacksC0089e8);
                        c0353s5.j(this);
                        if (Log.isLoggable("FragmentManager", 3)) {
                            Log.d("FragmentManager", "initState called for fragment: " + abstractComponentCallbacksC0089e8);
                        }
                        abstractComponentCallbacksC0089e8.l();
                    }
                    if (abstractComponentCallbacksC0089e8.I) {
                        if (abstractComponentCallbacksC0089e8.E != null && (viewGroup = abstractComponentCallbacksC0089e8.D) != null) {
                            C0410v5 f3 = C0410v5.f(viewGroup, abstractComponentCallbacksC0089e8.j().C());
                            if (abstractComponentCallbacksC0089e8.y) {
                                f3.getClass();
                                if (Log.isLoggable("FragmentManager", 2)) {
                                    Log.v("FragmentManager", "SpecialEffectsController: Enqueuing hide operation for fragment " + abstractComponentCallbacksC0089e8);
                                }
                                f3.a(3, 1, this);
                            } else {
                                f3.getClass();
                                if (Log.isLoggable("FragmentManager", 2)) {
                                    Log.v("FragmentManager", "SpecialEffectsController: Enqueuing show operation for fragment " + abstractComponentCallbacksC0089e8);
                                }
                                f3.a(2, 1, this);
                            }
                        }
                        C0375t8 c0375t8 = abstractComponentCallbacksC0089e8.r;
                        if (c0375t8 != null && abstractComponentCallbacksC0089e8.k && C0375t8.E(abstractComponentCallbacksC0089e8)) {
                            c0375t8.D = true;
                        }
                        abstractComponentCallbacksC0089e8.I = false;
                        abstractComponentCallbacksC0089e8.t.n();
                    }
                    this.d = false;
                    return;
                }
            }
        } catch (Throwable th) {
            this.d = false;
            throw th;
        }
    }

    public final void l() {
        boolean isLoggable = Log.isLoggable("FragmentManager", 3);
        AbstractComponentCallbacksC0089e8 abstractComponentCallbacksC0089e8 = this.c;
        if (isLoggable) {
            Log.d("FragmentManager", "movefrom RESUMED: " + abstractComponentCallbacksC0089e8);
        }
        abstractComponentCallbacksC0089e8.t.t(5);
        if (abstractComponentCallbacksC0089e8.E != null) {
            abstractComponentCallbacksC0089e8.N.e(S9.ON_PAUSE);
        }
        abstractComponentCallbacksC0089e8.M.d(S9.ON_PAUSE);
        abstractComponentCallbacksC0089e8.a = 6;
        abstractComponentCallbacksC0089e8.C = true;
        this.a.h(false);
    }

    public final void m(ClassLoader classLoader) {
        AbstractComponentCallbacksC0089e8 abstractComponentCallbacksC0089e8 = this.c;
        Bundle bundle = abstractComponentCallbacksC0089e8.b;
        if (bundle == null) {
            return;
        }
        bundle.setClassLoader(classLoader);
        abstractComponentCallbacksC0089e8.c = abstractComponentCallbacksC0089e8.b.getSparseParcelableArray("android:view_state");
        abstractComponentCallbacksC0089e8.d = abstractComponentCallbacksC0089e8.b.getBundle("android:view_registry_state");
        String string = abstractComponentCallbacksC0089e8.b.getString("android:target_state");
        abstractComponentCallbacksC0089e8.h = string;
        if (string != null) {
            abstractComponentCallbacksC0089e8.i = abstractComponentCallbacksC0089e8.b.getInt("android:target_req_state", 0);
        }
        boolean z = abstractComponentCallbacksC0089e8.b.getBoolean("android:user_visible_hint", true);
        abstractComponentCallbacksC0089e8.G = z;
        if (!z) {
            abstractComponentCallbacksC0089e8.F = true;
        }
    }

    public final void n() {
        View view;
        String str;
        boolean isLoggable = Log.isLoggable("FragmentManager", 3);
        AbstractComponentCallbacksC0089e8 abstractComponentCallbacksC0089e8 = this.c;
        if (isLoggable) {
            Log.d("FragmentManager", "moveto RESUMED: " + abstractComponentCallbacksC0089e8);
        }
        C0049c8 c0049c8 = abstractComponentCallbacksC0089e8.H;
        if (c0049c8 == null) {
            view = null;
        } else {
            view = c0049c8.k;
        }
        if (view != null) {
            if (view != abstractComponentCallbacksC0089e8.E) {
                for (ViewParent parent = view.getParent(); parent != null; parent = parent.getParent()) {
                    if (parent != abstractComponentCallbacksC0089e8.E) {
                    }
                }
            }
            boolean requestFocus = view.requestFocus();
            if (Log.isLoggable("FragmentManager", 2)) {
                StringBuilder sb = new StringBuilder("requestFocus: Restoring focused view ");
                sb.append(view);
                sb.append(" ");
                if (requestFocus) {
                    str = "succeeded";
                } else {
                    str = "failed";
                }
                sb.append(str);
                sb.append(" on Fragment ");
                sb.append(abstractComponentCallbacksC0089e8);
                sb.append(" resulting in focused view ");
                sb.append(abstractComponentCallbacksC0089e8.E.findFocus());
                Log.v("FragmentManager", sb.toString());
            }
        }
        abstractComponentCallbacksC0089e8.f().k = null;
        abstractComponentCallbacksC0089e8.t.J();
        abstractComponentCallbacksC0089e8.t.x(true);
        abstractComponentCallbacksC0089e8.a = 7;
        abstractComponentCallbacksC0089e8.C = true;
        androidx.lifecycle.a aVar = abstractComponentCallbacksC0089e8.M;
        S9 s9 = S9.ON_RESUME;
        aVar.d(s9);
        if (abstractComponentCallbacksC0089e8.E != null) {
            abstractComponentCallbacksC0089e8.N.c.d(s9);
        }
        C0375t8 c0375t8 = abstractComponentCallbacksC0089e8.t;
        c0375t8.E = false;
        c0375t8.F = false;
        c0375t8.L.h = false;
        c0375t8.t(7);
        this.a.k(false);
        abstractComponentCallbacksC0089e8.b = null;
        abstractComponentCallbacksC0089e8.c = null;
        abstractComponentCallbacksC0089e8.d = null;
    }

    public final void o() {
        AbstractComponentCallbacksC0089e8 abstractComponentCallbacksC0089e8 = this.c;
        if (abstractComponentCallbacksC0089e8.E == null) {
            return;
        }
        if (Log.isLoggable("FragmentManager", 2)) {
            Log.v("FragmentManager", "Saving view state for fragment " + abstractComponentCallbacksC0089e8 + " with view " + abstractComponentCallbacksC0089e8.E);
        }
        SparseArray<Parcelable> sparseArray = new SparseArray<>();
        abstractComponentCallbacksC0089e8.E.saveHierarchyState(sparseArray);
        if (sparseArray.size() > 0) {
            abstractComponentCallbacksC0089e8.c = sparseArray;
        }
        Bundle bundle = new Bundle();
        abstractComponentCallbacksC0089e8.N.d.c(bundle);
        if (!bundle.isEmpty()) {
            abstractComponentCallbacksC0089e8.d = bundle;
        }
    }

    public final void p() {
        boolean isLoggable = Log.isLoggable("FragmentManager", 3);
        AbstractComponentCallbacksC0089e8 abstractComponentCallbacksC0089e8 = this.c;
        if (isLoggable) {
            Log.d("FragmentManager", "moveto STARTED: " + abstractComponentCallbacksC0089e8);
        }
        abstractComponentCallbacksC0089e8.t.J();
        abstractComponentCallbacksC0089e8.t.x(true);
        abstractComponentCallbacksC0089e8.a = 5;
        abstractComponentCallbacksC0089e8.C = false;
        abstractComponentCallbacksC0089e8.y();
        if (abstractComponentCallbacksC0089e8.C) {
            androidx.lifecycle.a aVar = abstractComponentCallbacksC0089e8.M;
            S9 s9 = S9.ON_START;
            aVar.d(s9);
            if (abstractComponentCallbacksC0089e8.E != null) {
                abstractComponentCallbacksC0089e8.N.c.d(s9);
            }
            C0375t8 c0375t8 = abstractComponentCallbacksC0089e8.t;
            c0375t8.E = false;
            c0375t8.F = false;
            c0375t8.L.h = false;
            c0375t8.t(5);
            this.a.n(false);
            return;
        }
        throw new AndroidRuntimeException("Fragment " + abstractComponentCallbacksC0089e8 + " did not call through to super.onStart()");
    }

    public final void q() {
        boolean isLoggable = Log.isLoggable("FragmentManager", 3);
        AbstractComponentCallbacksC0089e8 abstractComponentCallbacksC0089e8 = this.c;
        if (isLoggable) {
            Log.d("FragmentManager", "movefrom STARTED: " + abstractComponentCallbacksC0089e8);
        }
        C0375t8 c0375t8 = abstractComponentCallbacksC0089e8.t;
        c0375t8.F = true;
        c0375t8.L.h = true;
        c0375t8.t(4);
        if (abstractComponentCallbacksC0089e8.E != null) {
            abstractComponentCallbacksC0089e8.N.e(S9.ON_STOP);
        }
        abstractComponentCallbacksC0089e8.M.d(S9.ON_STOP);
        abstractComponentCallbacksC0089e8.a = 4;
        abstractComponentCallbacksC0089e8.C = false;
        abstractComponentCallbacksC0089e8.z();
        if (abstractComponentCallbacksC0089e8.C) {
            this.a.p(false);
            return;
        }
        throw new AndroidRuntimeException("Fragment " + abstractComponentCallbacksC0089e8 + " did not call through to super.onStop()");
    }

    public a(F1 f1, C0353s5 c0353s5, ClassLoader classLoader, C0281o8 c0281o8, C0470y8 c0470y8) {
        this.a = f1;
        this.b = c0353s5;
        AbstractComponentCallbacksC0089e8 a = c0281o8.a(c0470y8.a);
        Bundle bundle = c0470y8.j;
        if (bundle != null) {
            bundle.setClassLoader(classLoader);
        }
        a.G(bundle);
        a.e = c0470y8.b;
        a.m = c0470y8.c;
        a.o = true;
        a.v = c0470y8.d;
        a.w = c0470y8.e;
        a.f22x = c0470y8.f;
        a.A = c0470y8.g;
        a.l = c0470y8.h;
        a.z = c0470y8.i;
        a.y = c0470y8.k;
        a.L = T9.values()[c0470y8.l];
        Bundle bundle2 = c0470y8.m;
        if (bundle2 != null) {
            a.b = bundle2;
        } else {
            a.b = new Bundle();
        }
        this.c = a;
        if (Log.isLoggable("FragmentManager", 2)) {
            Log.v("FragmentManager", "Instantiated fragment " + a);
        }
    }

    public a(F1 f1, C0353s5 c0353s5, AbstractComponentCallbacksC0089e8 abstractComponentCallbacksC0089e8, C0470y8 c0470y8) {
        this.a = f1;
        this.b = c0353s5;
        this.c = abstractComponentCallbacksC0089e8;
        abstractComponentCallbacksC0089e8.c = null;
        abstractComponentCallbacksC0089e8.d = null;
        abstractComponentCallbacksC0089e8.q = 0;
        abstractComponentCallbacksC0089e8.n = false;
        abstractComponentCallbacksC0089e8.k = false;
        AbstractComponentCallbacksC0089e8 abstractComponentCallbacksC0089e82 = abstractComponentCallbacksC0089e8.g;
        abstractComponentCallbacksC0089e8.h = abstractComponentCallbacksC0089e82 != null ? abstractComponentCallbacksC0089e82.e : null;
        abstractComponentCallbacksC0089e8.g = null;
        Bundle bundle = c0470y8.m;
        if (bundle != null) {
            abstractComponentCallbacksC0089e8.b = bundle;
        } else {
            abstractComponentCallbacksC0089e8.b = new Bundle();
        }
    }
}
