package androidx.fragment.app;

import android.animation.LayoutTransition;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.widget.FrameLayout;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.WeakHashMap;
import org.conscrypt.BuildConfig;
import org.conscrypt.R;
import x.AbstractC0118fh;
import x.AbstractC0154hd;
import x.AbstractC0309ph;
import x.AbstractComponentCallbacksC0089e8;
import x.B8;
import x.C0129g8;
import x.C0281o8;
import x.C0375t8;
import x.C8;
import x.E9;
import x.L2;
import x.R0;
import x.wi;

/* loaded from: classes.dex */
public final class FragmentContainerView extends FrameLayout {
    public final ArrayList a;
    public final ArrayList b;
    public View.OnApplyWindowInsetsListener c;
    public boolean d;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public FragmentContainerView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 0);
        String str;
        E9.o(context, "context");
        this.a = new ArrayList();
        this.b = new ArrayList();
        this.d = true;
        if (attributeSet != null) {
            String classAttribute = attributeSet.getClassAttribute();
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, AbstractC0154hd.b, 0, 0);
            if (classAttribute == null) {
                classAttribute = obtainStyledAttributes.getString(0);
                str = "android:name";
            } else {
                str = "class";
            }
            obtainStyledAttributes.recycle();
            if (classAttribute == null || isInEditMode()) {
                return;
            }
            throw new UnsupportedOperationException("FragmentContainerView must be within a FragmentActivity to use " + str + "=\"" + classAttribute + '\"');
        }
    }

    public final void a(View view) {
        if (this.b.contains(view)) {
            this.a.add(view);
        }
    }

    @Override // android.view.ViewGroup
    public final void addView(View view, int i, ViewGroup.LayoutParams layoutParams) {
        AbstractComponentCallbacksC0089e8 abstractComponentCallbacksC0089e8;
        E9.o(view, "child");
        Object tag = view.getTag(R.id.fragment_container_view_tag);
        if (tag instanceof AbstractComponentCallbacksC0089e8) {
            abstractComponentCallbacksC0089e8 = (AbstractComponentCallbacksC0089e8) tag;
        } else {
            abstractComponentCallbacksC0089e8 = null;
        }
        if (abstractComponentCallbacksC0089e8 != null) {
            super.addView(view, i, layoutParams);
            return;
        }
        throw new IllegalStateException(("Views added to a FragmentContainerView must be associated with a Fragment. View " + view + " is not associated with a Fragment.").toString());
    }

    @Override // android.view.ViewGroup, android.view.View
    public final WindowInsets dispatchApplyWindowInsets(WindowInsets windowInsets) {
        wi wiVar;
        E9.o(windowInsets, "insets");
        wi g = wi.g(null, windowInsets);
        View.OnApplyWindowInsetsListener onApplyWindowInsetsListener = this.c;
        if (onApplyWindowInsetsListener != null) {
            WindowInsets onApplyWindowInsets = onApplyWindowInsetsListener.onApplyWindowInsets(this, windowInsets);
            E9.n(onApplyWindowInsets, "onApplyWindowInsetsListe…lyWindowInsets(v, insets)");
            wiVar = wi.g(null, onApplyWindowInsets);
        } else {
            WeakHashMap weakHashMap = AbstractC0309ph.a;
            WindowInsets f = g.f();
            if (f != null) {
                WindowInsets b = AbstractC0118fh.b(this, f);
                if (!b.equals(f)) {
                    g = wi.g(this, b);
                }
            }
            wiVar = g;
        }
        if (!wiVar.a.m()) {
            int childCount = getChildCount();
            for (int i = 0; i < childCount; i++) {
                View childAt = getChildAt(i);
                WeakHashMap weakHashMap2 = AbstractC0309ph.a;
                WindowInsets f2 = wiVar.f();
                if (f2 != null) {
                    WindowInsets a = AbstractC0118fh.a(childAt, f2);
                    if (!a.equals(f2)) {
                        wi.g(childAt, a);
                    }
                }
            }
        }
        return windowInsets;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void dispatchDraw(Canvas canvas) {
        E9.o(canvas, "canvas");
        if (this.d) {
            Iterator it = this.a.iterator();
            while (it.hasNext()) {
                super.drawChild(canvas, (View) it.next(), getDrawingTime());
            }
        }
        super.dispatchDraw(canvas);
    }

    @Override // android.view.ViewGroup
    public final boolean drawChild(Canvas canvas, View view, long j) {
        E9.o(canvas, "canvas");
        E9.o(view, "child");
        if (this.d) {
            ArrayList arrayList = this.a;
            if (!arrayList.isEmpty() && arrayList.contains(view)) {
                return false;
            }
        }
        return super.drawChild(canvas, view, j);
    }

    @Override // android.view.ViewGroup
    public final void endViewTransition(View view) {
        E9.o(view, "view");
        this.b.remove(view);
        if (this.a.remove(view)) {
            this.d = true;
        }
        super.endViewTransition(view);
    }

    public final <F extends AbstractComponentCallbacksC0089e8> F getFragment() {
        R0 r0;
        AbstractComponentCallbacksC0089e8 abstractComponentCallbacksC0089e8;
        C0375t8 c0375t8;
        View view = this;
        while (true) {
            r0 = null;
            if (view != null) {
                Object tag = view.getTag(R.id.fragment_container_view_tag);
                if (tag instanceof AbstractComponentCallbacksC0089e8) {
                    abstractComponentCallbacksC0089e8 = (AbstractComponentCallbacksC0089e8) tag;
                } else {
                    abstractComponentCallbacksC0089e8 = null;
                }
                if (abstractComponentCallbacksC0089e8 != null) {
                    break;
                }
                Object parent = view.getParent();
                if (parent instanceof View) {
                    view = (View) parent;
                } else {
                    view = null;
                }
            } else {
                abstractComponentCallbacksC0089e8 = null;
                break;
            }
        }
        if (abstractComponentCallbacksC0089e8 != null) {
            if (abstractComponentCallbacksC0089e8.m()) {
                c0375t8 = abstractComponentCallbacksC0089e8.g();
            } else {
                throw new IllegalStateException("The Fragment " + abstractComponentCallbacksC0089e8 + " that owns View " + this + " has already been destroyed. Nested fragments should always use the child FragmentManager.");
            }
        } else {
            Context context = getContext();
            while (true) {
                if (!(context instanceof ContextWrapper)) {
                    break;
                }
                if (context instanceof R0) {
                    r0 = (R0) context;
                    break;
                }
                context = ((ContextWrapper) context).getBaseContext();
            }
            if (r0 != null) {
                c0375t8 = ((C0129g8) r0.s.b).c0;
            } else {
                throw new IllegalStateException("View " + this + " is not within a subclass of FragmentActivity.");
            }
        }
        return (F) c0375t8.z(getId());
    }

    @Override // android.view.View
    public final WindowInsets onApplyWindowInsets(WindowInsets windowInsets) {
        E9.o(windowInsets, "insets");
        return windowInsets;
    }

    @Override // android.view.ViewGroup
    public final void removeAllViewsInLayout() {
        int childCount = getChildCount();
        while (true) {
            childCount--;
            if (-1 < childCount) {
                View childAt = getChildAt(childCount);
                E9.n(childAt, "view");
                a(childAt);
            } else {
                super.removeAllViewsInLayout();
                return;
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewManager
    public final void removeView(View view) {
        E9.o(view, "view");
        a(view);
        super.removeView(view);
    }

    @Override // android.view.ViewGroup
    public final void removeViewAt(int i) {
        View childAt = getChildAt(i);
        E9.n(childAt, "view");
        a(childAt);
        super.removeViewAt(i);
    }

    @Override // android.view.ViewGroup
    public final void removeViewInLayout(View view) {
        E9.o(view, "view");
        a(view);
        super.removeViewInLayout(view);
    }

    @Override // android.view.ViewGroup
    public final void removeViews(int i, int i2) {
        int i3 = i + i2;
        for (int i4 = i; i4 < i3; i4++) {
            View childAt = getChildAt(i4);
            E9.n(childAt, "view");
            a(childAt);
        }
        super.removeViews(i, i2);
    }

    @Override // android.view.ViewGroup
    public final void removeViewsInLayout(int i, int i2) {
        int i3 = i + i2;
        for (int i4 = i; i4 < i3; i4++) {
            View childAt = getChildAt(i4);
            E9.n(childAt, "view");
            a(childAt);
        }
        super.removeViewsInLayout(i, i2);
    }

    public final void setDrawDisappearingViewsLast(boolean z) {
        this.d = z;
    }

    @Override // android.view.ViewGroup
    public void setLayoutTransition(LayoutTransition layoutTransition) {
        throw new UnsupportedOperationException("FragmentContainerView does not support Layout Transitions or animateLayoutChanges=\"true\".");
    }

    @Override // android.view.View
    public void setOnApplyWindowInsetsListener(View.OnApplyWindowInsetsListener onApplyWindowInsetsListener) {
        E9.o(onApplyWindowInsetsListener, "listener");
        this.c = onApplyWindowInsetsListener;
    }

    @Override // android.view.ViewGroup
    public final void startViewTransition(View view) {
        E9.o(view, "view");
        if (view.getParent() == this) {
            this.b.add(view);
        }
        super.startViewTransition(view);
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public FragmentContainerView(Context context, AttributeSet attributeSet, C0375t8 c0375t8) {
        super(context, attributeSet);
        View view;
        E9.o(context, "context");
        E9.o(attributeSet, "attrs");
        E9.o(c0375t8, "fm");
        this.a = new ArrayList();
        this.b = new ArrayList();
        this.d = true;
        String classAttribute = attributeSet.getClassAttribute();
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, AbstractC0154hd.b, 0, 0);
        classAttribute = classAttribute == null ? obtainStyledAttributes.getString(0) : classAttribute;
        String string = obtainStyledAttributes.getString(1);
        obtainStyledAttributes.recycle();
        int id = getId();
        AbstractComponentCallbacksC0089e8 z = c0375t8.z(id);
        if (classAttribute != null && z == null) {
            if (id == -1) {
                throw new IllegalStateException("FragmentContainerView must have an android:id to add Fragment " + classAttribute + (string != null ? " with tag ".concat(string) : BuildConfig.FLAVOR));
            }
            C0281o8 B = c0375t8.B();
            context.getClassLoader();
            AbstractComponentCallbacksC0089e8 a = B.a(classAttribute);
            E9.n(a, "fm.fragmentFactory.insta…ontext.classLoader, name)");
            a.C = true;
            C0129g8 c0129g8 = a.s;
            if ((c0129g8 == null ? null : c0129g8.Z) != null) {
                a.C = true;
            }
            L2 l2 = new L2(c0375t8);
            l2.o = true;
            a.D = this;
            int id2 = getId();
            String str = a.K;
            if (str != null) {
                B8.c(a, str);
            }
            Class<?> cls = a.getClass();
            int modifiers = cls.getModifiers();
            if (!cls.isAnonymousClass() && Modifier.isPublic(modifiers) && (!cls.isMemberClass() || Modifier.isStatic(modifiers))) {
                if (string != null) {
                    String str2 = a.f22x;
                    if (str2 != null && !string.equals(str2)) {
                        throw new IllegalStateException("Can't change tag of fragment " + a + ": was " + a.f22x + " now " + string);
                    }
                    a.f22x = string;
                }
                if (id2 != 0) {
                    if (id2 == -1) {
                        throw new IllegalArgumentException("Can't add fragment " + a + " with tag " + string + " to container view with no id");
                    }
                    int i = a.v;
                    if (i != 0 && i != id2) {
                        throw new IllegalStateException("Can't change container ID of fragment " + a + ": was " + a.v + " now " + id2);
                    }
                    a.v = id2;
                    a.w = id2;
                }
                l2.b(new C8(1, a));
                C0375t8 c0375t82 = l2.p;
                a.r = c0375t82;
                if (!l2.g) {
                    if (c0375t82.t != null && !c0375t82.G) {
                        c0375t82.w(true);
                        l2.a(c0375t82.I, c0375t82.J);
                        c0375t82.b = true;
                        try {
                            c0375t82.O(c0375t82.I, c0375t82.J);
                            c0375t82.d();
                            c0375t82.Z();
                            if (c0375t82.H) {
                                c0375t82.H = false;
                                c0375t82.X();
                            }
                            ((HashMap) c0375t82.c.b).values().removeAll(Collections.singleton(null));
                        } catch (Throwable th) {
                            c0375t82.d();
                            throw th;
                        }
                    }
                } else {
                    throw new IllegalStateException("This transaction is already being added to the back stack");
                }
            } else {
                throw new IllegalStateException("Fragment " + cls.getCanonicalName() + " must be a public static class to be  properly recreated from instance state.");
            }
        }
        Iterator it = c0375t8.c.f().iterator();
        while (it.hasNext()) {
            a aVar = (a) it.next();
            AbstractComponentCallbacksC0089e8 abstractComponentCallbacksC0089e8 = aVar.c;
            if (abstractComponentCallbacksC0089e8.w == getId() && (view = abstractComponentCallbacksC0089e8.E) != null && view.getParent() == null) {
                abstractComponentCallbacksC0089e8.D = this;
                aVar.b();
            }
        }
    }
}
