package androidx.versionedparcelable;

import android.annotation.SuppressLint;
import android.os.Parcel;
import android.os.Parcelable;
import x.C0197k0;
import x.InterfaceC0018ah;
import x.Zg;

@SuppressLint({"BanParcelableUsage"})
/* loaded from: classes.dex */
public class ParcelImpl implements Parcelable {
    public static final Parcelable.Creator<ParcelImpl> CREATOR = new C0197k0(14);
    public final InterfaceC0018ah a;

    public ParcelImpl(Parcel parcel) {
        this.a = new Zg(parcel).g();
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i) {
        new Zg(parcel).i(this.a);
    }
}
