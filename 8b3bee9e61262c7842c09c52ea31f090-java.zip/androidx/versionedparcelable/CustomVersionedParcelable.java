package androidx.versionedparcelable;

import x.InterfaceC0018ah;

/* loaded from: classes.dex */
public abstract class CustomVersionedParcelable implements InterfaceC0018ah {
}
