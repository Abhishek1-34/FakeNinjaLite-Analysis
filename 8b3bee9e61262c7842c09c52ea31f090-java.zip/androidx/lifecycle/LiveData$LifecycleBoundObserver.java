package androidx.lifecycle;

import x.AbstractC0415va;
import x.S9;
import x.W9;
import x.Y9;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: classes.dex */
public class LiveData$LifecycleBoundObserver extends AbstractC0415va implements W9 {
    @Override // x.W9
    public final void b(Y9 y9, S9 s9) {
        throw null;
    }

    @Override // x.AbstractC0415va
    public final void d() {
        throw null;
    }

    @Override // x.AbstractC0415va
    public final boolean e() {
        throw null;
    }
}
