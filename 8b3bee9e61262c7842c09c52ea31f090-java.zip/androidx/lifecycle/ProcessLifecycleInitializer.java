package androidx.lifecycle;

import android.app.Application;
import android.content.Context;
import android.os.Handler;
import java.util.HashSet;
import java.util.List;
import x.C0294p2;
import x.E9;
import x.H6;
import x.InterfaceC0433w9;
import x.S9;
import x.Tc;
import x.U9;
import x.Uc;
import x.V9;

/* loaded from: classes.dex */
public final class ProcessLifecycleInitializer implements InterfaceC0433w9 {
    @Override // x.InterfaceC0433w9
    public final List a() {
        return H6.a;
    }

    @Override // x.InterfaceC0433w9
    public final Object b(Context context) {
        E9.o(context, "context");
        C0294p2 r = C0294p2.r(context);
        E9.n(r, "getInstance(context)");
        if (((HashSet) r.c).contains(ProcessLifecycleInitializer.class)) {
            if (!V9.a.getAndSet(true)) {
                Context applicationContext = context.getApplicationContext();
                E9.m(applicationContext, "null cannot be cast to non-null type android.app.Application");
                ((Application) applicationContext).registerActivityLifecycleCallbacks(new U9());
            }
            Uc uc = Uc.i;
            uc.getClass();
            uc.e = new Handler();
            uc.f.d(S9.ON_CREATE);
            Context applicationContext2 = context.getApplicationContext();
            E9.m(applicationContext2, "null cannot be cast to non-null type android.app.Application");
            ((Application) applicationContext2).registerActivityLifecycleCallbacks(new Tc(uc));
            return uc;
        }
        throw new IllegalStateException("ProcessLifecycleInitializer cannot be initialized lazily.\n               Please ensure that you have:\n               <meta-data\n                   android:name='androidx.lifecycle.ProcessLifecycleInitializer'\n                   android:value='androidx.startup' />\n               under InitializationProvider in your AndroidManifest.xml");
    }
}
