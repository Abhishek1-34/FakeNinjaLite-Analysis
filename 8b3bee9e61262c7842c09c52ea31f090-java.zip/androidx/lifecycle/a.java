package androidx.lifecycle;

import android.os.Looper;
import java.lang.ref.WeakReference;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;
import x.AbstractC0011aa;
import x.C0211ke;
import x.C0230le;
import x.C0242m7;
import x.C0249me;
import x.C0369t2;
import x.E9;
import x.InterfaceC0187j9;
import x.InterfaceC0259n5;
import x.Q9;
import x.S9;
import x.T9;
import x.W9;
import x.X9;
import x.Y9;
import x.Z9;

/* loaded from: classes.dex */
public final class a {
    public final boolean a;
    public C0242m7 b;
    public T9 c;
    public final WeakReference d;
    public int e;
    public boolean f;
    public boolean g;
    public final ArrayList h;

    public a(Y9 y9) {
        new AtomicReference();
        this.a = true;
        this.b = new C0242m7();
        this.c = T9.b;
        this.h = new ArrayList();
        this.d = new WeakReference(y9);
    }

    /* JADX WARN: Type inference failed for: r3v2, types: [x.Z9, java.lang.Object] */
    public final void a(X9 x9) {
        W9 reflectiveGenericLifecycleObserver;
        Y9 y9;
        ArrayList arrayList = this.h;
        Object obj = null;
        c("addObserver");
        T9 t9 = this.c;
        T9 t92 = T9.a;
        if (t9 != t92) {
            t92 = T9.b;
        }
        ?? obj2 = new Object();
        HashMap hashMap = AbstractC0011aa.a;
        boolean z = x9 instanceof W9;
        boolean z2 = x9 instanceof InterfaceC0259n5;
        boolean z3 = false;
        if (z && z2) {
            reflectiveGenericLifecycleObserver = new DefaultLifecycleObserverAdapter((InterfaceC0259n5) x9, (W9) x9);
        } else if (z2) {
            reflectiveGenericLifecycleObserver = new DefaultLifecycleObserverAdapter((InterfaceC0259n5) x9, null);
        } else if (z) {
            reflectiveGenericLifecycleObserver = (W9) x9;
        } else {
            Class<?> cls = x9.getClass();
            if (AbstractC0011aa.c(cls) == 2) {
                Object obj3 = AbstractC0011aa.b.get(cls);
                E9.l(obj3);
                List list = (List) obj3;
                if (list.size() != 1) {
                    int size = list.size();
                    InterfaceC0187j9[] interfaceC0187j9Arr = new InterfaceC0187j9[size];
                    if (size <= 0) {
                        reflectiveGenericLifecycleObserver = new CompositeGeneratedAdaptersObserver(interfaceC0187j9Arr);
                    } else {
                        AbstractC0011aa.a((Constructor) list.get(0), x9);
                        throw null;
                    }
                } else {
                    AbstractC0011aa.a((Constructor) list.get(0), x9);
                    throw null;
                }
            } else {
                reflectiveGenericLifecycleObserver = new ReflectiveGenericLifecycleObserver(x9);
            }
        }
        obj2.b = reflectiveGenericLifecycleObserver;
        obj2.a = t92;
        C0242m7 c0242m7 = this.b;
        C0230le a = c0242m7.a(x9);
        if (a != null) {
            obj = a.b;
        } else {
            HashMap hashMap2 = c0242m7.e;
            C0230le c0230le = new C0230le(x9, obj2);
            c0242m7.d++;
            C0230le c0230le2 = c0242m7.b;
            if (c0230le2 == null) {
                c0242m7.a = c0230le;
                c0242m7.b = c0230le;
            } else {
                c0230le2.c = c0230le;
                c0230le.d = c0230le2;
                c0242m7.b = c0230le;
            }
            hashMap2.put(x9, c0230le);
        }
        if (((Z9) obj) != null || (y9 = (Y9) this.d.get()) == null) {
            return;
        }
        if (this.e != 0 || this.f) {
            z3 = true;
        }
        T9 b = b(x9);
        this.e++;
        while (obj2.a.compareTo(b) < 0 && this.b.e.containsKey(x9)) {
            arrayList.add(obj2.a);
            Q9 q9 = S9.Companion;
            T9 t93 = obj2.a;
            q9.getClass();
            S9 a2 = Q9.a(t93);
            if (a2 != null) {
                obj2.a(y9, a2);
                arrayList.remove(arrayList.size() - 1);
                b = b(x9);
            } else {
                throw new IllegalStateException("no event up from " + obj2.a);
            }
        }
        if (!z3) {
            h();
        }
        this.e--;
    }

    public final T9 b(X9 x9) {
        C0230le c0230le;
        T9 t9;
        HashMap hashMap = this.b.e;
        T9 t92 = null;
        if (hashMap.containsKey(x9)) {
            c0230le = ((C0230le) hashMap.get(x9)).d;
        } else {
            c0230le = null;
        }
        if (c0230le != null) {
            t9 = ((Z9) c0230le.b).a;
        } else {
            t9 = null;
        }
        ArrayList arrayList = this.h;
        if (!arrayList.isEmpty()) {
            t92 = (T9) arrayList.get(arrayList.size() - 1);
        }
        T9 t93 = this.c;
        E9.o(t93, "state1");
        if (t9 == null || t9.compareTo(t93) >= 0) {
            t9 = t93;
        }
        if (t92 == null || t92.compareTo(t9) >= 0) {
            return t9;
        }
        return t92;
    }

    public final void c(String str) {
        if (this.a) {
            ((C0369t2) C0369t2.a0().l).getClass();
            if (Looper.getMainLooper().getThread() != Thread.currentThread()) {
                throw new IllegalStateException(("Method " + str + " must be called on the main thread").toString());
            }
        }
    }

    public final void d(S9 s9) {
        E9.o(s9, "event");
        c("handleLifecycleEvent");
        e(s9.a());
    }

    public final void e(T9 t9) {
        T9 t92 = this.c;
        if (t92 == t9) {
            return;
        }
        T9 t93 = T9.b;
        T9 t94 = T9.a;
        if (t92 == t93 && t9 == t94) {
            throw new IllegalStateException(("no event down from " + this.c + " in component " + this.d.get()).toString());
        }
        this.c = t9;
        if (!this.f && this.e == 0) {
            this.f = true;
            h();
            this.f = false;
            if (this.c == t94) {
                this.b = new C0242m7();
                return;
            }
            return;
        }
        this.g = true;
    }

    public final void f(X9 x9) {
        E9.o(x9, "observer");
        c("removeObserver");
        this.b.b(x9);
    }

    public final void g() {
        T9 t9 = T9.c;
        c("setCurrentState");
        e(t9);
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x0030, code lost:
    
        r7.g = false;
     */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x0032, code lost:
    
        return;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void h() {
        S9 s9;
        Y9 y9 = (Y9) this.d.get();
        if (y9 == null) {
            throw new IllegalStateException("LifecycleOwner of this LifecycleRegistry is already garbage collected. It is too late to change lifecycle state.");
        }
        while (true) {
            C0242m7 c0242m7 = this.b;
            if (c0242m7.d != 0) {
                C0230le c0230le = c0242m7.a;
                E9.l(c0230le);
                T9 t9 = ((Z9) c0230le.b).a;
                C0230le c0230le2 = this.b.b;
                E9.l(c0230le2);
                T9 t92 = ((Z9) c0230le2.b).a;
                if (t9 == t92 && this.c == t92) {
                    break;
                }
                this.g = false;
                T9 t93 = this.c;
                C0230le c0230le3 = this.b.a;
                E9.l(c0230le3);
                if (t93.compareTo(((Z9) c0230le3.b).a) < 0) {
                    C0242m7 c0242m72 = this.b;
                    C0211ke c0211ke = new C0211ke(c0242m72.b, c0242m72.a, 1);
                    c0242m72.c.put(c0211ke, Boolean.FALSE);
                    while (c0211ke.hasNext() && !this.g) {
                        Map.Entry entry = (Map.Entry) c0211ke.next();
                        E9.n(entry, "next()");
                        X9 x9 = (X9) entry.getKey();
                        Z9 z9 = (Z9) entry.getValue();
                        while (z9.a.compareTo(this.c) > 0 && !this.g && this.b.e.containsKey(x9)) {
                            Q9 q9 = S9.Companion;
                            T9 t94 = z9.a;
                            q9.getClass();
                            E9.o(t94, "state");
                            int ordinal = t94.ordinal();
                            if (ordinal != 2) {
                                if (ordinal != 3) {
                                    if (ordinal != 4) {
                                        s9 = null;
                                    } else {
                                        s9 = S9.ON_PAUSE;
                                    }
                                } else {
                                    s9 = S9.ON_STOP;
                                }
                            } else {
                                s9 = S9.ON_DESTROY;
                            }
                            if (s9 != null) {
                                this.h.add(s9.a());
                                z9.a(y9, s9);
                                this.h.remove(r4.size() - 1);
                            } else {
                                throw new IllegalStateException("no event down from " + z9.a);
                            }
                        }
                    }
                }
                C0230le c0230le4 = this.b.b;
                if (!this.g && c0230le4 != null && this.c.compareTo(((Z9) c0230le4.b).a) > 0) {
                    C0242m7 c0242m73 = this.b;
                    c0242m73.getClass();
                    C0249me c0249me = new C0249me(c0242m73);
                    c0242m73.c.put(c0249me, Boolean.FALSE);
                    while (c0249me.hasNext() && !this.g) {
                        Map.Entry entry2 = (Map.Entry) c0249me.next();
                        X9 x92 = (X9) entry2.getKey();
                        Z9 z92 = (Z9) entry2.getValue();
                        while (z92.a.compareTo(this.c) < 0 && !this.g && this.b.e.containsKey(x92)) {
                            this.h.add(z92.a);
                            Q9 q92 = S9.Companion;
                            T9 t95 = z92.a;
                            q92.getClass();
                            S9 a = Q9.a(t95);
                            if (a != null) {
                                z92.a(y9, a);
                                this.h.remove(r4.size() - 1);
                            } else {
                                throw new IllegalStateException("no event up from " + z92.a);
                            }
                        }
                    }
                }
            } else {
                break;
            }
        }
    }
}
