package androidx.lifecycle;

import java.util.HashMap;
import java.util.List;
import x.O3;
import x.Q3;
import x.S9;
import x.W9;
import x.X9;
import x.Y9;

/* JADX INFO: Access modifiers changed from: package-private */
@Deprecated
/* loaded from: classes.dex */
public class ReflectiveGenericLifecycleObserver implements W9 {
    public final X9 a;
    public final O3 b;

    public ReflectiveGenericLifecycleObserver(X9 x9) {
        this.a = x9;
        Q3 q3 = Q3.c;
        Class<?> cls = x9.getClass();
        O3 o3 = (O3) q3.a.get(cls);
        this.b = o3 == null ? q3.a(cls, null) : o3;
    }

    @Override // x.W9
    public final void b(Y9 y9, S9 s9) {
        HashMap hashMap = this.b.a;
        List list = (List) hashMap.get(s9);
        X9 x9 = this.a;
        O3.a(list, y9, s9, x9);
        O3.a((List) hashMap.get(S9.ON_ANY), y9, s9, x9);
    }
}
