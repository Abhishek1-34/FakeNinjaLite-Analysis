package androidx.lifecycle;

import android.os.Bundle;
import x.C0306pe;
import x.S9;
import x.W9;
import x.Y9;

/* loaded from: classes.dex */
public final class SavedStateHandleAttacher implements W9 {
    public final C0306pe a;

    public SavedStateHandleAttacher(C0306pe c0306pe) {
        this.a = c0306pe;
    }

    @Override // x.W9
    public final void b(Y9 y9, S9 s9) {
        if (s9 == S9.ON_CREATE) {
            y9.d().f(this);
            C0306pe c0306pe = this.a;
            if (!c0306pe.b) {
                Bundle c = c0306pe.a.c("androidx.lifecycle.internal.SavedStateHandlesProvider");
                Bundle bundle = new Bundle();
                Bundle bundle2 = c0306pe.c;
                if (bundle2 != null) {
                    bundle.putAll(bundle2);
                }
                if (c != null) {
                    bundle.putAll(c);
                }
                c0306pe.c = bundle;
                c0306pe.b = true;
                return;
            }
            return;
        }
        throw new IllegalStateException(("Next event must be ON_CREATE, it was " + s9).toString());
    }
}
