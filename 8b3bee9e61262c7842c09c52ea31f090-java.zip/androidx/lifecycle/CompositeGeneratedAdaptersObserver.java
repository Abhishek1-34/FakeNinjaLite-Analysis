package androidx.lifecycle;

import java.util.HashMap;
import x.InterfaceC0187j9;
import x.S9;
import x.W9;
import x.Y9;

/* loaded from: classes.dex */
public final class CompositeGeneratedAdaptersObserver implements W9 {
    public final InterfaceC0187j9[] a;

    public CompositeGeneratedAdaptersObserver(InterfaceC0187j9[] interfaceC0187j9Arr) {
        this.a = interfaceC0187j9Arr;
    }

    @Override // x.W9
    public final void b(Y9 y9, S9 s9) {
        new HashMap();
        InterfaceC0187j9[] interfaceC0187j9Arr = this.a;
        if (interfaceC0187j9Arr.length <= 0) {
            if (interfaceC0187j9Arr.length <= 0) {
                return;
            }
            InterfaceC0187j9 interfaceC0187j9 = interfaceC0187j9Arr[0];
            throw null;
        }
        InterfaceC0187j9 interfaceC0187j92 = interfaceC0187j9Arr[0];
        throw null;
    }
}
