package androidx.lifecycle;

import x.AbstractC0278o5;
import x.InterfaceC0259n5;
import x.S9;
import x.W9;
import x.Y9;

/* loaded from: classes.dex */
public final class DefaultLifecycleObserverAdapter implements W9 {
    public final InterfaceC0259n5 a;
    public final W9 b;

    public DefaultLifecycleObserverAdapter(InterfaceC0259n5 interfaceC0259n5, W9 w9) {
        this.a = interfaceC0259n5;
        this.b = w9;
    }

    @Override // x.W9
    public final void b(Y9 y9, S9 s9) {
        int i = AbstractC0278o5.a[s9.ordinal()];
        InterfaceC0259n5 interfaceC0259n5 = this.a;
        if (i != 3) {
            if (i == 7) {
                throw new IllegalArgumentException("ON_ANY must not been send by anybody");
            }
        } else {
            interfaceC0259n5.a();
        }
        W9 w9 = this.b;
        if (w9 != null) {
            w9.b(y9, s9);
        }
    }
}
