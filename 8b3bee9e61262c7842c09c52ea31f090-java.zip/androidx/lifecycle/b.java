package androidx.lifecycle;

import android.os.Looper;
import android.util.Log;
import android.view.View;
import java.util.Map;
import x.AbstractC0415va;
import x.B;
import x.C0230le;
import x.C0249me;
import x.C0287oe;
import x.C0369t2;
import x.H5;
import x.Y9;

/* loaded from: classes.dex */
public class b {
    public static final Object j = new Object();
    public final Object a;
    public final C0287oe b = new C0287oe();
    public int c = 0;
    public boolean d;
    public volatile Object e;
    public volatile Object f;
    public int g;
    public boolean h;
    public boolean i;

    public b() {
        Object obj = j;
        this.f = obj;
        this.e = obj;
        this.g = -1;
    }

    public static void a(String str) {
        ((C0369t2) C0369t2.a0().l).getClass();
        if (Looper.getMainLooper().getThread() == Thread.currentThread()) {
            return;
        }
        throw new IllegalStateException("Cannot invoke " + str + " on a background thread");
    }

    public final void b(AbstractC0415va abstractC0415va) {
        if (!abstractC0415va.b) {
            return;
        }
        if (!abstractC0415va.e()) {
            abstractC0415va.c(false);
            return;
        }
        int i = abstractC0415va.c;
        int i2 = this.g;
        if (i >= i2) {
            return;
        }
        abstractC0415va.c = i2;
        B b = abstractC0415va.a;
        Object obj = this.e;
        b.getClass();
        if (((Y9) obj) != null) {
            H5 h5 = (H5) b.b;
            if (h5.Y) {
                View D = h5.D();
                if (D.getParent() == null) {
                    if (h5.c0 != null) {
                        if (Log.isLoggable("FragmentManager", 3)) {
                            Log.d("FragmentManager", "DialogFragment " + b + " setting the content view on " + h5.c0);
                        }
                        h5.c0.setContentView(D);
                        return;
                    }
                    return;
                }
                throw new IllegalStateException("DialogFragment can not be attached to a container view");
            }
        }
    }

    public final void c(AbstractC0415va abstractC0415va) {
        if (this.h) {
            this.i = true;
            return;
        }
        this.h = true;
        do {
            this.i = false;
            if (abstractC0415va != null) {
                b(abstractC0415va);
                abstractC0415va = null;
            } else {
                C0287oe c0287oe = this.b;
                c0287oe.getClass();
                C0249me c0249me = new C0249me(c0287oe);
                c0287oe.c.put(c0249me, Boolean.FALSE);
                while (c0249me.hasNext()) {
                    b((AbstractC0415va) ((Map.Entry) c0249me.next()).getValue());
                    if (this.i) {
                        break;
                    }
                }
            }
        } while (this.i);
        this.h = false;
    }

    public final void d(B b) {
        Object obj;
        a("observeForever");
        AbstractC0415va abstractC0415va = new AbstractC0415va(this, b);
        C0287oe c0287oe = this.b;
        C0230le a = c0287oe.a(b);
        if (a != null) {
            obj = a.b;
        } else {
            C0230le c0230le = new C0230le(b, abstractC0415va);
            c0287oe.d++;
            C0230le c0230le2 = c0287oe.b;
            if (c0230le2 == null) {
                c0287oe.a = c0230le;
                c0287oe.b = c0230le;
            } else {
                c0230le2.c = c0230le;
                c0230le.d = c0230le2;
                c0287oe.b = c0230le;
            }
            obj = null;
        }
        AbstractC0415va abstractC0415va2 = (AbstractC0415va) obj;
        if (!(abstractC0415va2 instanceof LiveData$LifecycleBoundObserver)) {
            if (abstractC0415va2 != null) {
                return;
            }
            abstractC0415va.c(true);
            return;
        }
        throw new IllegalArgumentException("Cannot add the same observer with different lifecycles");
    }
}
