package androidx.activity;

import android.os.Build;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;
import java.util.Iterator;
import java.util.ListIterator;
import x.C0113fc;
import x.C0133gc;
import x.C0153hc;
import x.C0190jc;
import x.C0228lc;
import x.C0243m8;
import x.C0375t8;
import x.C0388u2;
import x.E9;
import x.T9;
import x.Y9;

/* loaded from: classes.dex */
public final class b {
    public final Runnable a;
    public final C0388u2 b = new C0388u2();
    public C0243m8 c;
    public final OnBackInvokedCallback d;
    public OnBackInvokedDispatcher e;
    public boolean f;
    public boolean g;

    public b(Runnable runnable) {
        OnBackInvokedCallback a;
        this.a = runnable;
        int i = Build.VERSION.SDK_INT;
        if (i >= 33) {
            if (i >= 34) {
                a = C0190jc.a.a(new C0113fc(this, 0), new C0113fc(this, 1), new C0133gc(0, this), new C0133gc(1, this));
            } else {
                a = C0153hc.a.a(new C0133gc(2, this));
            }
            this.d = a;
        }
    }

    public final void a(Y9 y9, C0243m8 c0243m8) {
        E9.o(c0243m8, "onBackPressedCallback");
        androidx.lifecycle.a d = y9.d();
        if (d.c == T9.a) {
            return;
        }
        c0243m8.b.add(new OnBackPressedDispatcher$LifecycleOnBackPressedCancellable(this, d, c0243m8));
        d();
        c0243m8.c = new C0228lc(0, this);
    }

    public final void b() {
        Object obj;
        C0388u2 c0388u2 = this.b;
        c0388u2.getClass();
        ListIterator listIterator = c0388u2.listIterator(c0388u2.c);
        while (true) {
            if (listIterator.hasPrevious()) {
                obj = listIterator.previous();
                if (((C0243m8) obj).a) {
                    break;
                }
            } else {
                obj = null;
                break;
            }
        }
        C0243m8 c0243m8 = (C0243m8) obj;
        this.c = null;
        if (c0243m8 != null) {
            C0375t8 c0375t8 = c0243m8.d;
            c0375t8.x(true);
            if (c0375t8.h.a) {
                c0375t8.K();
                return;
            } else {
                c0375t8.g.b();
                return;
            }
        }
        this.a.run();
    }

    public final void c(boolean z) {
        OnBackInvokedDispatcher onBackInvokedDispatcher = this.e;
        OnBackInvokedCallback onBackInvokedCallback = this.d;
        if (onBackInvokedDispatcher != null && onBackInvokedCallback != null) {
            C0153hc c0153hc = C0153hc.a;
            if (z && !this.f) {
                c0153hc.b(onBackInvokedDispatcher, 0, onBackInvokedCallback);
                this.f = true;
            } else if (!z && this.f) {
                c0153hc.c(onBackInvokedDispatcher, onBackInvokedCallback);
                this.f = false;
            }
        }
    }

    public final void d() {
        boolean z = this.g;
        boolean z2 = false;
        C0388u2 c0388u2 = this.b;
        if (c0388u2 == null || !c0388u2.isEmpty()) {
            Iterator<E> it = c0388u2.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                } else if (((C0243m8) it.next()).a) {
                    z2 = true;
                    break;
                }
            }
        }
        this.g = z2;
        if (z2 != z && Build.VERSION.SDK_INT >= 33) {
            c(z2);
        }
    }
}
