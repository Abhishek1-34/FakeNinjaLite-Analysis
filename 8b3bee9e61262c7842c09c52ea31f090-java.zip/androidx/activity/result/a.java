package androidx.activity.result;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import x.AbstractC0124g3;
import x.AbstractC0267nd;
import x.C0216l0;
import x.C0273o0;
import x.C0292p0;
import x.C0311q0;
import x.C0329r0;
import x.C0348s0;
import x.InterfaceC0235m0;
import x.S9;
import x.T9;
import x.W9;
import x.Y9;

/* loaded from: classes.dex */
public abstract class a {
    public final HashMap a = new HashMap();
    public final HashMap b = new HashMap();
    public final HashMap c = new HashMap();
    public ArrayList d = new ArrayList();
    public final transient HashMap e = new HashMap();
    public final HashMap f = new HashMap();
    public final Bundle g = new Bundle();

    public final boolean a(int i, int i2, Intent intent) {
        String str = (String) this.a.get(Integer.valueOf(i));
        if (str == null) {
            return false;
        }
        C0329r0 c0329r0 = (C0329r0) this.e.get(str);
        if (c0329r0 != null) {
            InterfaceC0235m0 interfaceC0235m0 = c0329r0.a;
            if (this.d.contains(str)) {
                interfaceC0235m0.a(c0329r0.b.J(i2, intent));
                this.d.remove(str);
                return true;
            }
        }
        this.f.remove(str);
        this.g.putParcelable(str, new C0216l0(i2, intent));
        return true;
    }

    public abstract void b(int i, AbstractC0124g3 abstractC0124g3, Intent intent);

    public final C0292p0 c(final String str, androidx.activity.a aVar, final C0273o0 c0273o0, final InterfaceC0235m0 interfaceC0235m0) {
        androidx.lifecycle.a aVar2 = aVar.d;
        if (aVar2.c.compareTo(T9.d) < 0) {
            e(str);
            HashMap hashMap = this.c;
            C0348s0 c0348s0 = (C0348s0) hashMap.get(str);
            if (c0348s0 == null) {
                c0348s0 = new C0348s0(aVar2);
            }
            W9 w9 = new W9() { // from class: androidx.activity.result.ActivityResultRegistry$1
                @Override // x.W9
                public final void b(Y9 y9, S9 s9) {
                    boolean equals = S9.ON_START.equals(s9);
                    String str2 = str;
                    a aVar3 = a.this;
                    if (equals) {
                        HashMap hashMap2 = aVar3.e;
                        InterfaceC0235m0 interfaceC0235m02 = interfaceC0235m0;
                        hashMap2.put(str2, new C0329r0(interfaceC0235m02, c0273o0));
                        HashMap hashMap3 = aVar3.f;
                        if (hashMap3.containsKey(str2)) {
                            Object obj = hashMap3.get(str2);
                            hashMap3.remove(str2);
                            interfaceC0235m02.a(obj);
                        }
                        Bundle bundle = aVar3.g;
                        C0216l0 c0216l0 = (C0216l0) bundle.getParcelable(str2);
                        if (c0216l0 != null) {
                            bundle.remove(str2);
                            interfaceC0235m02.a(new C0216l0(c0216l0.a, c0216l0.b));
                            return;
                        }
                        return;
                    }
                    if (S9.ON_STOP.equals(s9)) {
                        aVar3.e.remove(str2);
                    } else if (S9.ON_DESTROY.equals(s9)) {
                        aVar3.f(str2);
                    }
                }
            };
            c0348s0.a.a(w9);
            c0348s0.b.add(w9);
            hashMap.put(str, c0348s0);
            return new C0292p0(this, str, c0273o0);
        }
        throw new IllegalStateException("LifecycleOwner " + aVar + " is attempting to register while current state is " + aVar2.c + ". LifecycleOwners must call register before they are STARTED.");
    }

    public final C0311q0 d(String str, AbstractC0124g3 abstractC0124g3, InterfaceC0235m0 interfaceC0235m0) {
        e(str);
        this.e.put(str, new C0329r0(interfaceC0235m0, abstractC0124g3));
        HashMap hashMap = this.f;
        if (hashMap.containsKey(str)) {
            Object obj = hashMap.get(str);
            hashMap.remove(str);
            interfaceC0235m0.a(obj);
        }
        Bundle bundle = this.g;
        C0216l0 c0216l0 = (C0216l0) bundle.getParcelable(str);
        if (c0216l0 != null) {
            bundle.remove(str);
            interfaceC0235m0.a(abstractC0124g3.J(c0216l0.a, c0216l0.b));
        }
        return new C0311q0(this, str, abstractC0124g3);
    }

    public final void e(String str) {
        HashMap hashMap = this.b;
        if (((Integer) hashMap.get(str)) != null) {
            return;
        }
        AbstractC0267nd.a.getClass();
        int a = AbstractC0267nd.b.a();
        while (true) {
            int i = a + 65536;
            HashMap hashMap2 = this.a;
            if (hashMap2.containsKey(Integer.valueOf(i))) {
                AbstractC0267nd.a.getClass();
                a = AbstractC0267nd.b.a();
            } else {
                hashMap2.put(Integer.valueOf(i), str);
                hashMap.put(str, Integer.valueOf(i));
                return;
            }
        }
    }

    public final void f(String str) {
        Integer num;
        if (!this.d.contains(str) && (num = (Integer) this.b.remove(str)) != null) {
            this.a.remove(num);
        }
        this.e.remove(str);
        HashMap hashMap = this.f;
        if (hashMap.containsKey(str)) {
            Log.w("ActivityResultRegistry", "Dropping pending result for request " + str + ": " + hashMap.get(str));
            hashMap.remove(str);
        }
        Bundle bundle = this.g;
        if (bundle.containsKey(str)) {
            Log.w("ActivityResultRegistry", "Dropping pending result for request " + str + ": " + bundle.getParcelable(str));
            bundle.remove(str);
        }
        HashMap hashMap2 = this.c;
        C0348s0 c0348s0 = (C0348s0) hashMap2.get(str);
        if (c0348s0 != null) {
            ArrayList arrayList = c0348s0.b;
            Iterator it = arrayList.iterator();
            while (it.hasNext()) {
                c0348s0.a.f((W9) it.next());
            }
            arrayList.clear();
            hashMap2.remove(str);
        }
    }
}
