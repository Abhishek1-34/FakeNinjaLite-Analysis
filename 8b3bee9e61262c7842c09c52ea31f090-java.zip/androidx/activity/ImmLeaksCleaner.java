package androidx.activity;

import android.view.inputmethod.InputMethodManager;
import x.S9;
import x.W9;
import x.Y9;

/* loaded from: classes.dex */
final class ImmLeaksCleaner implements W9 {
    public static int a;

    @Override // x.W9
    public final void b(Y9 y9, S9 s9) {
        if (s9 != S9.ON_DESTROY) {
            return;
        }
        if (a == 0) {
            try {
                a = 2;
                InputMethodManager.class.getDeclaredField("mServedView").setAccessible(true);
                InputMethodManager.class.getDeclaredField("mNextServedView").setAccessible(true);
                InputMethodManager.class.getDeclaredField("mH").setAccessible(true);
                a = 1;
            } catch (NoSuchFieldException unused) {
            }
        }
        if (a != 1) {
        } else {
            throw null;
        }
    }
}
