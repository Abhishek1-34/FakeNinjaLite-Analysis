package androidx.activity;

import android.annotation.SuppressLint;
import android.app.Application;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.os.Trace;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.window.OnBackInvokedDispatcher;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicInteger;
import org.conscrypt.R;
import x.AbstractActivityC0164i4;
import x.AbstractC0105f4;
import x.AbstractC0112fb;
import x.AbstractC0124g3;
import x.C0045c4;
import x.C0065d4;
import x.C0085e4;
import x.C0107f6;
import x.C0125g4;
import x.C0262n8;
import x.C0294p2;
import x.C0460xh;
import x.D4;
import x.E9;
import x.Ec;
import x.ExecutorC0145h4;
import x.G2;
import x.G8;
import x.I2;
import x.InterfaceC0247mc;
import x.InterfaceC0301p9;
import x.InterfaceC0400ue;
import x.InterfaceC0479yh;
import x.J4;
import x.Pb;
import x.Qb;
import x.R0;
import x.RunnableC0141h0;
import x.S9;
import x.Sd;
import x.Ud;
import x.W9;
import x.Y0;
import x.Y9;

/* loaded from: classes.dex */
public abstract class a extends AbstractActivityC0164i4 implements InterfaceC0479yh, InterfaceC0301p9, InterfaceC0400ue {
    public final J4 b = new J4();
    public final C0294p2 c;
    public final androidx.lifecycle.a d;
    public final G2 e;
    public C0460xh f;
    public b g;
    public final ExecutorC0145h4 h;
    public final G2 i;
    public final AtomicInteger j;
    public final C0085e4 k;
    public final CopyOnWriteArrayList l;
    public final CopyOnWriteArrayList m;
    public final CopyOnWriteArrayList n;
    public final CopyOnWriteArrayList o;
    public final CopyOnWriteArrayList p;
    public boolean q;
    public boolean r;

    /* JADX WARN: Type inference failed for: r5v0, types: [x.b4] */
    public a() {
        final R0 r0 = (R0) this;
        this.c = new C0294p2(new RunnableC0141h0(4, r0));
        androidx.lifecycle.a aVar = new androidx.lifecycle.a(this);
        this.d = aVar;
        G2 g2 = new G2(this);
        this.e = g2;
        this.g = null;
        ExecutorC0145h4 executorC0145h4 = new ExecutorC0145h4(r0);
        this.h = executorC0145h4;
        this.i = new G2(executorC0145h4, new G8() { // from class: x.b4
            @Override // x.G8
            public final Object a() {
                R0.this.reportFullyDrawn();
                return null;
            }
        });
        this.j = new AtomicInteger();
        this.k = new C0085e4(r0);
        this.l = new CopyOnWriteArrayList();
        this.m = new CopyOnWriteArrayList();
        this.n = new CopyOnWriteArrayList();
        this.o = new CopyOnWriteArrayList();
        this.p = new CopyOnWriteArrayList();
        this.q = false;
        this.r = false;
        aVar.a(new W9() { // from class: androidx.activity.ComponentActivity$2
            @Override // x.W9
            public final void b(Y9 y9, S9 s9) {
                View view;
                if (s9 == S9.ON_STOP) {
                    Window window = R0.this.getWindow();
                    if (window != null) {
                        view = window.peekDecorView();
                    } else {
                        view = null;
                    }
                    if (view != null) {
                        view.cancelPendingInputEvents();
                    }
                }
            }
        });
        aVar.a(new W9() { // from class: androidx.activity.ComponentActivity$3
            @Override // x.W9
            public final void b(Y9 y9, S9 s9) {
                if (s9 == S9.ON_DESTROY) {
                    R0.this.b.b = null;
                    if (!R0.this.isChangingConfigurations()) {
                        R0.this.c().a();
                    }
                    ExecutorC0145h4 executorC0145h42 = R0.this.h;
                    R0 r02 = executorC0145h42.d;
                    r02.getWindow().getDecorView().removeCallbacks(executorC0145h42);
                    r02.getWindow().getDecorView().getViewTreeObserver().removeOnDrawListener(executorC0145h42);
                }
            }
        });
        aVar.a(new W9() { // from class: androidx.activity.ComponentActivity$4
            @Override // x.W9
            public final void b(Y9 y9, S9 s9) {
                R0 r02 = R0.this;
                if (r02.f == null) {
                    C0125g4 c0125g4 = (C0125g4) r02.getLastNonConfigurationInstance();
                    if (c0125g4 != null) {
                        r02.f = c0125g4.a;
                    }
                    if (r02.f == null) {
                        r02.f = new C0460xh();
                    }
                }
                r02.d.f(this);
            }
        });
        g2.a();
        AbstractC0124g3.m(this);
        ((Y0) g2.c).e("android:support:activity-result", new C0045c4(0, r0));
        h(new C0065d4(r0, 0));
    }

    @Override // x.InterfaceC0301p9
    public final Qb a() {
        Qb qb = new Qb();
        Application application = getApplication();
        LinkedHashMap linkedHashMap = qb.a;
        if (application != null) {
            linkedHashMap.put(C0107f6.e, getApplication());
        }
        linkedHashMap.put(AbstractC0124g3.S, this);
        linkedHashMap.put(AbstractC0124g3.T, this);
        if (getIntent() != null && getIntent().getExtras() != null) {
            linkedHashMap.put(AbstractC0124g3.U, getIntent().getExtras());
        }
        return qb;
    }

    @Override // x.InterfaceC0400ue
    public final Y0 b() {
        return (Y0) this.e.c;
    }

    @Override // x.InterfaceC0479yh
    public final C0460xh c() {
        if (getApplication() != null) {
            if (this.f == null) {
                C0125g4 c0125g4 = (C0125g4) getLastNonConfigurationInstance();
                if (c0125g4 != null) {
                    this.f = c0125g4.a;
                }
                if (this.f == null) {
                    this.f = new C0460xh();
                }
            }
            return this.f;
        }
        throw new IllegalStateException("Your activity is not yet attached to the Application instance. You can't request ViewModel before onCreate call.");
    }

    @Override // x.Y9
    public final androidx.lifecycle.a d() {
        return this.d;
    }

    public final void g(D4 d4) {
        this.l.add(d4);
    }

    public final void h(InterfaceC0247mc interfaceC0247mc) {
        J4 j4 = this.b;
        j4.getClass();
        if (j4.b != null) {
            interfaceC0247mc.a();
        }
        j4.a.add(interfaceC0247mc);
    }

    public final b i() {
        if (this.g == null) {
            this.g = new b(new I2(2, this));
            this.d.a(new W9() { // from class: androidx.activity.ComponentActivity$6
                @Override // x.W9
                public final void b(Y9 y9, S9 s9) {
                    if (s9 == S9.ON_CREATE && Build.VERSION.SDK_INT >= 33) {
                        b bVar = a.this.g;
                        OnBackInvokedDispatcher a = AbstractC0105f4.a((a) y9);
                        bVar.getClass();
                        E9.o(a, "invoker");
                        bVar.e = a;
                        bVar.c(bVar.g);
                    }
                }
            });
        }
        return this.g;
    }

    public final void j() {
        View decorView = getWindow().getDecorView();
        E9.o(decorView, "<this>");
        decorView.setTag(R.id.view_tree_lifecycle_owner, this);
        View decorView2 = getWindow().getDecorView();
        E9.o(decorView2, "<this>");
        decorView2.setTag(R.id.view_tree_view_model_store_owner, this);
        View decorView3 = getWindow().getDecorView();
        E9.o(decorView3, "<this>");
        decorView3.setTag(R.id.view_tree_saved_state_registry_owner, this);
        View decorView4 = getWindow().getDecorView();
        E9.o(decorView4, "<this>");
        decorView4.setTag(R.id.view_tree_on_back_pressed_dispatcher_owner, this);
        View decorView5 = getWindow().getDecorView();
        E9.o(decorView5, "<this>");
        decorView5.setTag(R.id.report_drawn, this);
    }

    @Override // android.app.Activity
    public void onActivityResult(int i, int i2, Intent intent) {
        if (!this.k.a(i, i2, intent)) {
            super.onActivityResult(i, i2, intent);
        }
    }

    @Override // android.app.Activity
    public final void onBackPressed() {
        i().b();
    }

    @Override // android.app.Activity, android.content.ComponentCallbacks
    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        Iterator it = this.l.iterator();
        while (it.hasNext()) {
            ((D4) it.next()).a(configuration);
        }
    }

    @Override // x.AbstractActivityC0164i4, android.app.Activity
    public void onCreate(Bundle bundle) {
        this.e.b(bundle);
        J4 j4 = this.b;
        j4.getClass();
        j4.b = this;
        Iterator it = j4.a.iterator();
        while (it.hasNext()) {
            ((InterfaceC0247mc) it.next()).a();
        }
        super.onCreate(bundle);
        int i = Ud.b;
        Sd.b(this);
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public final boolean onCreatePanelMenu(int i, Menu menu) {
        if (i == 0) {
            super.onCreatePanelMenu(i, menu);
            getMenuInflater();
            Iterator it = ((CopyOnWriteArrayList) this.c.d).iterator();
            while (it.hasNext()) {
                ((C0262n8) it.next()).a.j();
            }
            return true;
        }
        return true;
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public boolean onMenuItemSelected(int i, MenuItem menuItem) {
        if (super.onMenuItemSelected(i, menuItem)) {
            return true;
        }
        if (i != 0) {
            return false;
        }
        Iterator it = ((CopyOnWriteArrayList) this.c.d).iterator();
        while (it.hasNext()) {
            if (((C0262n8) it.next()).a.o()) {
                return true;
            }
        }
        return false;
    }

    @Override // android.app.Activity
    public final void onMultiWindowModeChanged(boolean z) {
        if (this.q) {
            return;
        }
        Iterator it = this.o.iterator();
        while (it.hasNext()) {
            ((D4) it.next()).a(new Pb(z));
        }
    }

    @Override // android.app.Activity
    public final void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        Iterator it = this.n.iterator();
        while (it.hasNext()) {
            ((D4) it.next()).a(intent);
        }
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public void onPanelClosed(int i, Menu menu) {
        Iterator it = ((CopyOnWriteArrayList) this.c.d).iterator();
        while (it.hasNext()) {
            ((C0262n8) it.next()).a.p();
        }
        super.onPanelClosed(i, menu);
    }

    @Override // android.app.Activity
    public final void onPictureInPictureModeChanged(boolean z) {
        if (this.r) {
            return;
        }
        Iterator it = this.p.iterator();
        while (it.hasNext()) {
            ((D4) it.next()).a(new Ec(z));
        }
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public final boolean onPreparePanel(int i, View view, Menu menu) {
        if (i == 0) {
            super.onPreparePanel(i, view, menu);
            Iterator it = ((CopyOnWriteArrayList) this.c.d).iterator();
            while (it.hasNext()) {
                ((C0262n8) it.next()).a.s();
            }
            return true;
        }
        return true;
    }

    @Override // android.app.Activity
    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        if (!this.k.a(i, -1, new Intent().putExtra("androidx.activity.result.contract.extra.PERMISSIONS", strArr).putExtra("androidx.activity.result.contract.extra.PERMISSION_GRANT_RESULTS", iArr))) {
            super.onRequestPermissionsResult(i, strArr, iArr);
        }
    }

    /* JADX WARN: Type inference failed for: r1v0, types: [x.g4, java.lang.Object] */
    @Override // android.app.Activity
    public final Object onRetainNonConfigurationInstance() {
        C0125g4 c0125g4;
        C0460xh c0460xh = this.f;
        if (c0460xh == null && (c0125g4 = (C0125g4) getLastNonConfigurationInstance()) != null) {
            c0460xh = c0125g4.a;
        }
        if (c0460xh == null) {
            return null;
        }
        ?? obj = new Object();
        obj.a = c0460xh;
        return obj;
    }

    @Override // x.AbstractActivityC0164i4, android.app.Activity
    public final void onSaveInstanceState(Bundle bundle) {
        androidx.lifecycle.a aVar = this.d;
        if (aVar != null) {
            aVar.g();
        }
        super.onSaveInstanceState(bundle);
        this.e.c(bundle);
    }

    @Override // android.app.Activity, android.content.ComponentCallbacks2
    public final void onTrimMemory(int i) {
        super.onTrimMemory(i);
        Iterator it = this.m.iterator();
        while (it.hasNext()) {
            ((D4) it.next()).a(Integer.valueOf(i));
        }
    }

    @Override // android.app.Activity
    public final void reportFullyDrawn() {
        try {
            if (AbstractC0112fb.u()) {
                AbstractC0112fb.a("reportFullyDrawn() for ComponentActivity");
            }
            super.reportFullyDrawn();
            G2 g2 = this.i;
            synchronized (g2.b) {
                try {
                    g2.a = true;
                    Iterator it = ((ArrayList) g2.c).iterator();
                    while (it.hasNext()) {
                        ((G8) it.next()).a();
                    }
                    ((ArrayList) g2.c).clear();
                } finally {
                }
            }
            Trace.endSection();
        } catch (Throwable th) {
            Trace.endSection();
            throw th;
        }
    }

    @Override // android.app.Activity
    public void setContentView(@SuppressLint({"UnknownNullness", "MissingNullability"}) View view) {
        j();
        View decorView = getWindow().getDecorView();
        ExecutorC0145h4 executorC0145h4 = this.h;
        if (!executorC0145h4.c) {
            executorC0145h4.c = true;
            decorView.getViewTreeObserver().addOnDrawListener(executorC0145h4);
        }
        super.setContentView(view);
    }

    @Override // android.app.Activity
    public final void onMultiWindowModeChanged(boolean z, Configuration configuration) {
        this.q = true;
        try {
            super.onMultiWindowModeChanged(z, configuration);
            this.q = false;
            Iterator it = this.o.iterator();
            while (it.hasNext()) {
                D4 d4 = (D4) it.next();
                E9.o(configuration, "newConfig");
                d4.a(new Pb(z));
            }
        } catch (Throwable th) {
            this.q = false;
            throw th;
        }
    }

    @Override // android.app.Activity
    public final void onPictureInPictureModeChanged(boolean z, Configuration configuration) {
        this.r = true;
        try {
            super.onPictureInPictureModeChanged(z, configuration);
            this.r = false;
            Iterator it = this.p.iterator();
            while (it.hasNext()) {
                D4 d4 = (D4) it.next();
                E9.o(configuration, "newConfig");
                d4.a(new Ec(z));
            }
        } catch (Throwable th) {
            this.r = false;
            throw th;
        }
    }
}
