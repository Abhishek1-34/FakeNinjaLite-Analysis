package androidx.activity;

import x.C0209kc;
import x.C0228lc;
import x.C0243m8;
import x.E9;
import x.InterfaceC0238m3;
import x.S9;
import x.W9;
import x.Y9;

/* loaded from: classes.dex */
final class OnBackPressedDispatcher$LifecycleOnBackPressedCancellable implements W9, InterfaceC0238m3 {
    public final androidx.lifecycle.a a;
    public final C0243m8 b;
    public C0209kc c;
    public final /* synthetic */ b d;

    public OnBackPressedDispatcher$LifecycleOnBackPressedCancellable(b bVar, androidx.lifecycle.a aVar, C0243m8 c0243m8) {
        E9.o(c0243m8, "onBackPressedCallback");
        this.d = bVar;
        this.a = aVar;
        this.b = c0243m8;
        aVar.a(this);
    }

    @Override // x.W9
    public final void b(Y9 y9, S9 s9) {
        if (s9 == S9.ON_START) {
            b bVar = this.d;
            bVar.getClass();
            C0243m8 c0243m8 = this.b;
            E9.o(c0243m8, "onBackPressedCallback");
            bVar.b.addLast(c0243m8);
            C0209kc c0209kc = new C0209kc(bVar, c0243m8);
            c0243m8.b.add(c0209kc);
            bVar.d();
            c0243m8.c = new C0228lc(1, bVar);
            this.c = c0209kc;
            return;
        }
        if (s9 == S9.ON_STOP) {
            C0209kc c0209kc2 = this.c;
            if (c0209kc2 != null) {
                c0209kc2.cancel();
                return;
            }
            return;
        }
        if (s9 == S9.ON_DESTROY) {
            cancel();
        }
    }

    @Override // x.InterfaceC0238m3
    public final void cancel() {
        this.a.f(this);
        this.b.b.remove(this);
        C0209kc c0209kc = this.c;
        if (c0209kc != null) {
            c0209kc.cancel();
        }
        this.c = null;
    }
}
