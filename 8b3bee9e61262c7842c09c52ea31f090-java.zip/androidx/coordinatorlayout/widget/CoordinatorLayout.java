package androidx.coordinatorlayout.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcelable;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.WeakHashMap;
import org.conscrypt.R;
import x.AbstractC0060d;
import x.AbstractC0114fd;
import x.AbstractC0118fh;
import x.AbstractC0158hh;
import x.AbstractC0309ph;
import x.AbstractC0384th;
import x.B;
import x.C0353s5;
import x.Jc;
import x.Kc;
import x.M4;
import x.N4;
import x.O4;
import x.P4;
import x.Pe;
import x.Q4;
import x.R4;
import x.S4;
import x.Vb;
import x.Wb;
import x.Xb;
import x.wi;

/* loaded from: classes.dex */
public class CoordinatorLayout extends ViewGroup implements Vb, Wb {
    public static final String t;
    public static final Class[] u;
    public static final ThreadLocal v;
    public static final S4 w;

    /* renamed from: x, reason: collision with root package name */
    public static final Kc f4x;
    public final ArrayList a;
    public final C0353s5 b;
    public final ArrayList c;
    public final ArrayList d;
    public final int[] e;
    public final int[] f;
    public boolean g;
    public boolean h;
    public final int[] i;
    public View j;
    public View k;
    public Q4 l;
    public boolean m;
    public wi n;
    public boolean o;
    public Drawable p;
    public ViewGroup.OnHierarchyChangeListener q;
    public B r;
    public final Xb s;

    static {
        String str;
        Package r0 = CoordinatorLayout.class.getPackage();
        if (r0 != null) {
            str = r0.getName();
        } else {
            str = null;
        }
        t = str;
        w = new S4(0);
        u = new Class[]{Context.class, AttributeSet.class};
        v = new ThreadLocal();
        f4x = new Kc();
    }

    /* JADX WARN: Type inference failed for: r2v6, types: [x.Xb, java.lang.Object] */
    public CoordinatorLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, R.attr.coordinatorLayoutStyle);
        this.a = new ArrayList();
        this.b = new C0353s5(1);
        this.c = new ArrayList();
        this.d = new ArrayList();
        this.e = new int[2];
        this.f = new int[2];
        this.s = new Object();
        int[] iArr = AbstractC0114fd.a;
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, iArr, R.attr.coordinatorLayoutStyle, 0);
        if (Build.VERSION.SDK_INT >= 29) {
            saveAttributeDataForStyleable(context, iArr, attributeSet, obtainStyledAttributes, R.attr.coordinatorLayoutStyle, 0);
        }
        int resourceId = obtainStyledAttributes.getResourceId(0, 0);
        if (resourceId != 0) {
            Resources resources = context.getResources();
            int[] intArray = resources.getIntArray(resourceId);
            this.i = intArray;
            float f = resources.getDisplayMetrics().density;
            int length = intArray.length;
            for (int i = 0; i < length; i++) {
                this.i[i] = (int) (r2[i] * f);
            }
        }
        this.p = obtainStyledAttributes.getDrawable(1);
        obtainStyledAttributes.recycle();
        w();
        super.setOnHierarchyChangeListener(new O4(this));
        WeakHashMap weakHashMap = AbstractC0309ph.a;
        if (getImportantForAccessibility() == 0) {
            setImportantForAccessibility(1);
        }
    }

    public static Rect g() {
        Rect rect = (Rect) f4x.a();
        if (rect == null) {
            return new Rect();
        }
        return rect;
    }

    public static void l(int i, Rect rect, Rect rect2, P4 p4, int i2, int i3) {
        int width;
        int height;
        int i4 = p4.c;
        if (i4 == 0) {
            i4 = 17;
        }
        int absoluteGravity = Gravity.getAbsoluteGravity(i4, i);
        int i5 = p4.d;
        if ((i5 & 7) == 0) {
            i5 |= 8388611;
        }
        if ((i5 & 112) == 0) {
            i5 |= 48;
        }
        int absoluteGravity2 = Gravity.getAbsoluteGravity(i5, i);
        int i6 = absoluteGravity & 7;
        int i7 = absoluteGravity & 112;
        int i8 = absoluteGravity2 & 7;
        int i9 = absoluteGravity2 & 112;
        if (i8 != 1) {
            if (i8 != 5) {
                width = rect.left;
            } else {
                width = rect.right;
            }
        } else {
            width = rect.left + (rect.width() / 2);
        }
        if (i9 != 16) {
            if (i9 != 80) {
                height = rect.top;
            } else {
                height = rect.bottom;
            }
        } else {
            height = rect.top + (rect.height() / 2);
        }
        if (i6 != 1) {
            if (i6 != 5) {
                width -= i2;
            }
        } else {
            width -= i2 / 2;
        }
        if (i7 != 16) {
            if (i7 != 80) {
                height -= i3;
            }
        } else {
            height -= i3 / 2;
        }
        rect2.set(width, height, i2 + width, i3 + height);
    }

    public static P4 n(View view) {
        P4 p4 = (P4) view.getLayoutParams();
        if (!p4.b) {
            N4 n4 = null;
            for (Class<?> cls = view.getClass(); cls != null; cls = cls.getSuperclass()) {
                n4 = (N4) cls.getAnnotation(N4.class);
                if (n4 != null) {
                    break;
                }
            }
            if (n4 != null) {
                try {
                    M4 m4 = (M4) n4.value().getDeclaredConstructor(null).newInstance(null);
                    M4 m42 = p4.a;
                    if (m42 != m4) {
                        if (m42 != null) {
                            m42.e();
                        }
                        p4.a = m4;
                        p4.b = true;
                        if (m4 != null) {
                            m4.c(p4);
                        }
                    }
                } catch (Exception e) {
                    Log.e("CoordinatorLayout", "Default behavior class " + n4.value().getName() + " could not be instantiated. Did you forget a default constructor?", e);
                }
            }
            p4.b = true;
        }
        return p4;
    }

    public static void u(View view, int i) {
        P4 p4 = (P4) view.getLayoutParams();
        int i2 = p4.i;
        if (i2 != i) {
            WeakHashMap weakHashMap = AbstractC0309ph.a;
            view.offsetLeftAndRight(i - i2);
            p4.i = i;
        }
    }

    public static void v(View view, int i) {
        P4 p4 = (P4) view.getLayoutParams();
        int i2 = p4.j;
        if (i2 != i) {
            WeakHashMap weakHashMap = AbstractC0309ph.a;
            view.offsetTopAndBottom(i - i2);
            p4.j = i;
        }
    }

    @Override // x.Vb
    public final void a(View view, View view2, int i, int i2) {
        Xb xb = this.s;
        if (i2 == 1) {
            xb.b = i;
        } else {
            xb.a = i;
        }
        this.k = view2;
        int childCount = getChildCount();
        for (int i3 = 0; i3 < childCount; i3++) {
            ((P4) getChildAt(i3).getLayoutParams()).getClass();
        }
    }

    @Override // x.Wb
    public final void b(View view, int i, int i2, int i3, int i4, int i5, int[] iArr) {
        M4 m4;
        int min;
        int min2;
        int childCount = getChildCount();
        boolean z = false;
        int i6 = 0;
        int i7 = 0;
        for (int i8 = 0; i8 < childCount; i8++) {
            View childAt = getChildAt(i8);
            if (childAt.getVisibility() != 8) {
                P4 p4 = (P4) childAt.getLayoutParams();
                if (p4.a(i5) && (m4 = p4.a) != null) {
                    int[] iArr2 = this.e;
                    iArr2[0] = 0;
                    iArr2[1] = 0;
                    m4.k(this, childAt, i2, i3, i4, iArr2);
                    if (i3 > 0) {
                        min = Math.max(i6, iArr2[0]);
                    } else {
                        min = Math.min(i6, iArr2[0]);
                    }
                    i6 = min;
                    if (i4 > 0) {
                        min2 = Math.max(i7, iArr2[1]);
                    } else {
                        min2 = Math.min(i7, iArr2[1]);
                    }
                    i7 = min2;
                    z = true;
                }
            }
        }
        iArr[0] = iArr[0] + i6;
        iArr[1] = iArr[1] + i7;
        if (z) {
            p(1);
        }
    }

    @Override // x.Vb
    public final void c(View view, int i, int i2, int i3, int i4, int i5) {
        b(view, i, i2, i3, i4, 0, this.f);
    }

    @Override // android.view.ViewGroup
    public final boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        if ((layoutParams instanceof P4) && super.checkLayoutParams(layoutParams)) {
            return true;
        }
        return false;
    }

    @Override // x.Vb
    public final void d(View view, int i) {
        Xb xb = this.s;
        if (i == 1) {
            xb.b = 0;
        } else {
            xb.a = 0;
        }
        int childCount = getChildCount();
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = getChildAt(i2);
            P4 p4 = (P4) childAt.getLayoutParams();
            if (p4.a(i)) {
                M4 m4 = p4.a;
                if (m4 != null) {
                    m4.p(childAt, view, i);
                }
                if (i != 0) {
                    if (i == 1) {
                        p4.n = false;
                    }
                } else {
                    p4.m = false;
                }
            }
        }
        this.k = null;
    }

    @Override // android.view.ViewGroup
    public final boolean drawChild(Canvas canvas, View view, long j) {
        M4 m4 = ((P4) view.getLayoutParams()).a;
        if (m4 != null) {
            m4.getClass();
        }
        return super.drawChild(canvas, view, j);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void drawableStateChanged() {
        boolean z;
        super.drawableStateChanged();
        int[] drawableState = getDrawableState();
        Drawable drawable = this.p;
        if (drawable != null && drawable.isStateful()) {
            z = drawable.setState(drawableState);
        } else {
            z = false;
        }
        if (z) {
            invalidate();
        }
    }

    @Override // x.Vb
    public final void e(View view, int i, int i2, int[] iArr, int i3) {
        M4 m4;
        int min;
        int min2;
        int childCount = getChildCount();
        boolean z = false;
        int i4 = 0;
        int i5 = 0;
        for (int i6 = 0; i6 < childCount; i6++) {
            View childAt = getChildAt(i6);
            if (childAt.getVisibility() != 8) {
                P4 p4 = (P4) childAt.getLayoutParams();
                if (p4.a(i3) && (m4 = p4.a) != null) {
                    int[] iArr2 = this.e;
                    iArr2[0] = 0;
                    iArr2[1] = 0;
                    m4.j(this, childAt, view, i, i2, iArr2, i3);
                    if (i > 0) {
                        min = Math.max(i4, iArr2[0]);
                    } else {
                        min = Math.min(i4, iArr2[0]);
                    }
                    i4 = min;
                    if (i2 > 0) {
                        min2 = Math.max(i5, iArr2[1]);
                    } else {
                        min2 = Math.min(i5, iArr2[1]);
                    }
                    i5 = min2;
                    z = true;
                }
            }
        }
        iArr[0] = i4;
        iArr[1] = i5;
        if (z) {
            p(1);
        }
    }

    @Override // x.Vb
    public final boolean f(View view, View view2, int i, int i2) {
        int childCount = getChildCount();
        boolean z = false;
        for (int i3 = 0; i3 < childCount; i3++) {
            View childAt = getChildAt(i3);
            if (childAt.getVisibility() != 8) {
                P4 p4 = (P4) childAt.getLayoutParams();
                M4 m4 = p4.a;
                if (m4 != null) {
                    boolean o = m4.o(childAt, i, i2);
                    z |= o;
                    if (i2 != 0) {
                        if (i2 == 1) {
                            p4.n = o;
                        }
                    } else {
                        p4.m = o;
                    }
                } else if (i2 != 0) {
                    if (i2 == 1) {
                        p4.n = false;
                    }
                } else {
                    p4.m = false;
                }
            }
        }
        return z;
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new P4();
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new P4(getContext(), attributeSet);
    }

    public final List<View> getDependencySortedChildren() {
        s();
        return Collections.unmodifiableList(this.a);
    }

    public final wi getLastWindowInsets() {
        return this.n;
    }

    @Override // android.view.ViewGroup
    public int getNestedScrollAxes() {
        Xb xb = this.s;
        return xb.b | xb.a;
    }

    public Drawable getStatusBarBackground() {
        return this.p;
    }

    @Override // android.view.View
    public int getSuggestedMinimumHeight() {
        return Math.max(super.getSuggestedMinimumHeight(), getPaddingBottom() + getPaddingTop());
    }

    @Override // android.view.View
    public int getSuggestedMinimumWidth() {
        return Math.max(super.getSuggestedMinimumWidth(), getPaddingRight() + getPaddingLeft());
    }

    public final void h(P4 p4, Rect rect, int i, int i2) {
        int width = getWidth();
        int height = getHeight();
        int max = Math.max(getPaddingLeft() + ((ViewGroup.MarginLayoutParams) p4).leftMargin, Math.min(rect.left, ((width - getPaddingRight()) - i) - ((ViewGroup.MarginLayoutParams) p4).rightMargin));
        int max2 = Math.max(getPaddingTop() + ((ViewGroup.MarginLayoutParams) p4).topMargin, Math.min(rect.top, ((height - getPaddingBottom()) - i2) - ((ViewGroup.MarginLayoutParams) p4).bottomMargin));
        rect.set(max, max2, i + max, i2 + max2);
    }

    public final void i(View view, Rect rect, boolean z) {
        if (!view.isLayoutRequested() && view.getVisibility() != 8) {
            if (z) {
                k(view, rect);
                return;
            } else {
                rect.set(view.getLeft(), view.getTop(), view.getRight(), view.getBottom());
                return;
            }
        }
        rect.setEmpty();
    }

    public final ArrayList j(View view) {
        Pe pe = (Pe) this.b.b;
        int i = pe.c;
        ArrayList arrayList = null;
        for (int i2 = 0; i2 < i; i2++) {
            ArrayList arrayList2 = (ArrayList) pe.i(i2);
            if (arrayList2 != null && arrayList2.contains(view)) {
                if (arrayList == null) {
                    arrayList = new ArrayList();
                }
                arrayList.add(pe.f(i2));
            }
        }
        ArrayList arrayList3 = this.d;
        arrayList3.clear();
        if (arrayList != null) {
            arrayList3.addAll(arrayList);
        }
        return arrayList3;
    }

    public final void k(View view, Rect rect) {
        ThreadLocal threadLocal = AbstractC0384th.a;
        rect.set(0, 0, view.getWidth(), view.getHeight());
        ThreadLocal threadLocal2 = AbstractC0384th.a;
        Matrix matrix = (Matrix) threadLocal2.get();
        if (matrix == null) {
            matrix = new Matrix();
            threadLocal2.set(matrix);
        } else {
            matrix.reset();
        }
        AbstractC0384th.a(this, view, matrix);
        ThreadLocal threadLocal3 = AbstractC0384th.b;
        RectF rectF = (RectF) threadLocal3.get();
        if (rectF == null) {
            rectF = new RectF();
            threadLocal3.set(rectF);
        }
        rectF.set(rect);
        matrix.mapRect(rectF);
        rect.set((int) (rectF.left + 0.5f), (int) (rectF.top + 0.5f), (int) (rectF.right + 0.5f), (int) (rectF.bottom + 0.5f));
    }

    public final int m(int i) {
        int[] iArr = this.i;
        if (iArr == null) {
            Log.e("CoordinatorLayout", "No keylines defined for " + this + " - attempted index lookup " + i);
            return 0;
        }
        if (i >= 0 && i < iArr.length) {
            return iArr[i];
        }
        Log.e("CoordinatorLayout", "Keyline index " + i + " out of range for " + this);
        return 0;
    }

    public final boolean o(View view, int i, int i2) {
        Kc kc = f4x;
        Rect g = g();
        k(view, g);
        try {
            return g.contains(i, i2);
        } finally {
            g.setEmpty();
            kc.c(g);
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
        t(false);
        if (this.m) {
            if (this.l == null) {
                this.l = new Q4(this);
            }
            getViewTreeObserver().addOnPreDrawListener(this.l);
        }
        if (this.n == null) {
            WeakHashMap weakHashMap = AbstractC0309ph.a;
            if (getFitsSystemWindows()) {
                AbstractC0118fh.c(this);
            }
        }
        this.h = true;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        t(false);
        if (this.m && this.l != null) {
            getViewTreeObserver().removeOnPreDrawListener(this.l);
        }
        View view = this.k;
        if (view != null) {
            d(view, 0);
        }
        this.h = false;
    }

    @Override // android.view.View
    public final void onDraw(Canvas canvas) {
        int i;
        super.onDraw(canvas);
        if (this.o && this.p != null) {
            wi wiVar = this.n;
            if (wiVar != null) {
                i = wiVar.d();
            } else {
                i = 0;
            }
            if (i > 0) {
                this.p.setBounds(0, 0, getWidth(), i);
                this.p.draw(canvas);
            }
        }
    }

    @Override // android.view.ViewGroup
    public final boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            t(true);
        }
        boolean r = r(motionEvent, 0);
        if (actionMasked == 1 || actionMasked == 3) {
            t(true);
        }
        return r;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z, int i, int i2, int i3, int i4) {
        M4 m4;
        WeakHashMap weakHashMap = AbstractC0309ph.a;
        int layoutDirection = getLayoutDirection();
        ArrayList arrayList = this.a;
        int size = arrayList.size();
        for (int i5 = 0; i5 < size; i5++) {
            View view = (View) arrayList.get(i5);
            if (view.getVisibility() != 8 && ((m4 = ((P4) view.getLayoutParams()).a) == null || !m4.g(this, view, layoutDirection))) {
                q(view, layoutDirection);
            }
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:60:0x0186, code lost:
    
        if (r0.h(r32, r20, r25, r8, r26) == false) goto L79;
     */
    /* JADX WARN: Removed duplicated region for block: B:59:0x0163  */
    /* JADX WARN: Removed duplicated region for block: B:64:0x0189  */
    @Override // android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void onMeasure(int i, int i2) {
        boolean z;
        boolean z2;
        boolean z3;
        int i3;
        int i4;
        int i5;
        int i6;
        int i7;
        int i8;
        M4 m4;
        int i9;
        ArrayList arrayList;
        int i10;
        boolean z4;
        int i11;
        int i12;
        int i13;
        int i14;
        int i15;
        int i16;
        boolean z5;
        int max;
        s();
        int childCount = getChildCount();
        int i17 = 0;
        loop0: while (true) {
            if (i17 < childCount) {
                View childAt = getChildAt(i17);
                Pe pe = (Pe) this.b.b;
                int i18 = pe.c;
                for (int i19 = 0; i19 < i18; i19++) {
                    ArrayList arrayList2 = (ArrayList) pe.i(i19);
                    if (arrayList2 != null && arrayList2.contains(childAt)) {
                        z = true;
                        break loop0;
                    }
                }
                i17++;
            } else {
                z = false;
                break;
            }
        }
        if (z != this.m) {
            if (z) {
                if (this.h) {
                    if (this.l == null) {
                        this.l = new Q4(this);
                    }
                    getViewTreeObserver().addOnPreDrawListener(this.l);
                }
                this.m = true;
            } else {
                if (this.h && this.l != null) {
                    getViewTreeObserver().removeOnPreDrawListener(this.l);
                }
                this.m = false;
            }
        }
        int paddingLeft = getPaddingLeft();
        int paddingTop = getPaddingTop();
        int paddingRight = getPaddingRight();
        int paddingBottom = getPaddingBottom();
        WeakHashMap weakHashMap = AbstractC0309ph.a;
        int layoutDirection = getLayoutDirection();
        if (layoutDirection == 1) {
            z2 = true;
        } else {
            z2 = false;
        }
        int mode = View.MeasureSpec.getMode(i);
        int size = View.MeasureSpec.getSize(i);
        int mode2 = View.MeasureSpec.getMode(i2);
        int size2 = View.MeasureSpec.getSize(i2);
        int i20 = paddingLeft + paddingRight;
        int i21 = paddingTop + paddingBottom;
        int suggestedMinimumWidth = getSuggestedMinimumWidth();
        int suggestedMinimumHeight = getSuggestedMinimumHeight();
        if (this.n != null && getFitsSystemWindows()) {
            z3 = true;
        } else {
            z3 = false;
        }
        ArrayList arrayList3 = this.a;
        int size3 = arrayList3.size();
        int i22 = suggestedMinimumWidth;
        int i23 = suggestedMinimumHeight;
        int i24 = 0;
        int i25 = 0;
        while (i25 < size3) {
            View view = (View) arrayList3.get(i25);
            if (view.getVisibility() == 8) {
                i14 = i25;
                i9 = size3;
                arrayList = arrayList3;
                i12 = paddingLeft;
                i15 = paddingRight;
                i10 = layoutDirection;
                z5 = true;
                z4 = false;
            } else {
                P4 p4 = (P4) view.getLayoutParams();
                int i26 = p4.e;
                if (i26 >= 0 && mode != 0) {
                    int m = m(i26);
                    i3 = i24;
                    int i27 = p4.c;
                    if (i27 == 0) {
                        i27 = 8388661;
                    }
                    int absoluteGravity = Gravity.getAbsoluteGravity(i27, layoutDirection) & 7;
                    i4 = i25;
                    if ((absoluteGravity == 3 && !z2) || (absoluteGravity == 5 && z2)) {
                        max = Math.max(0, (size - paddingRight) - m);
                    } else if ((absoluteGravity == 5 && !z2) || (absoluteGravity == 3 && z2)) {
                        max = Math.max(0, m - paddingLeft);
                    }
                    i5 = max;
                    if (!z3 && !view.getFitsSystemWindows()) {
                        int c = this.n.c() + this.n.b();
                        i6 = i23;
                        int a = this.n.a() + this.n.d();
                        i7 = View.MeasureSpec.makeMeasureSpec(size - c, mode);
                        i8 = View.MeasureSpec.makeMeasureSpec(size2 - a, mode2);
                    } else {
                        i6 = i23;
                        i7 = i;
                        i8 = i2;
                    }
                    m4 = p4.a;
                    if (m4 == null) {
                        int i28 = i3;
                        i14 = i4;
                        z4 = false;
                        i12 = paddingLeft;
                        i13 = i28;
                        int i29 = i6;
                        i15 = paddingRight;
                        i16 = i29;
                        i10 = layoutDirection;
                        i11 = i22;
                        i9 = size3;
                        arrayList = arrayList3;
                    } else {
                        i9 = size3;
                        arrayList = arrayList3;
                        i10 = layoutDirection;
                        z4 = false;
                        i11 = i22;
                        int i30 = i4;
                        i12 = paddingLeft;
                        i13 = i3;
                        i14 = i30;
                        int i31 = i6;
                        i15 = paddingRight;
                        i16 = i31;
                    }
                    measureChildWithMargins(view, i7, i5, i8, 0);
                    int max2 = Math.max(i11, view.getMeasuredWidth() + i20 + ((ViewGroup.MarginLayoutParams) p4).leftMargin + ((ViewGroup.MarginLayoutParams) p4).rightMargin);
                    int max3 = Math.max(i16, view.getMeasuredHeight() + i21 + ((ViewGroup.MarginLayoutParams) p4).topMargin + ((ViewGroup.MarginLayoutParams) p4).bottomMargin);
                    i22 = max2;
                    i24 = View.combineMeasuredStates(i13, view.getMeasuredState());
                    i23 = max3;
                    z5 = true;
                } else {
                    i3 = i24;
                    i4 = i25;
                }
                i5 = 0;
                if (!z3) {
                }
                i6 = i23;
                i7 = i;
                i8 = i2;
                m4 = p4.a;
                if (m4 == null) {
                }
                measureChildWithMargins(view, i7, i5, i8, 0);
                int max22 = Math.max(i11, view.getMeasuredWidth() + i20 + ((ViewGroup.MarginLayoutParams) p4).leftMargin + ((ViewGroup.MarginLayoutParams) p4).rightMargin);
                int max32 = Math.max(i16, view.getMeasuredHeight() + i21 + ((ViewGroup.MarginLayoutParams) p4).topMargin + ((ViewGroup.MarginLayoutParams) p4).bottomMargin);
                i22 = max22;
                i24 = View.combineMeasuredStates(i13, view.getMeasuredState());
                i23 = max32;
                z5 = true;
            }
            i25 = i14 + 1;
            paddingLeft = i12;
            paddingRight = i15;
            layoutDirection = i10;
            size3 = i9;
            arrayList3 = arrayList;
        }
        int i32 = i24;
        setMeasuredDimension(View.resolveSizeAndState(i22, i, (-16777216) & i32), View.resolveSizeAndState(i23, i2, i32 << 16));
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onNestedFling(View view, float f, float f2, boolean z) {
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = getChildAt(i);
            if (childAt.getVisibility() != 8) {
                P4 p4 = (P4) childAt.getLayoutParams();
                if (p4.a(0)) {
                    M4 m4 = p4.a;
                }
            }
        }
        return false;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onNestedPreFling(View view, float f, float f2) {
        M4 m4;
        int childCount = getChildCount();
        boolean z = false;
        for (int i = 0; i < childCount; i++) {
            View childAt = getChildAt(i);
            if (childAt.getVisibility() != 8) {
                P4 p4 = (P4) childAt.getLayoutParams();
                if (p4.a(0) && (m4 = p4.a) != null) {
                    z |= m4.i(view);
                }
            }
        }
        return z;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedPreScroll(View view, int i, int i2, int[] iArr) {
        e(view, i, i2, iArr, 0);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedScroll(View view, int i, int i2, int i3, int i4) {
        c(view, i, i2, i3, i4, 0);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedScrollAccepted(View view, View view2, int i) {
        a(view, view2, i, 0);
    }

    @Override // android.view.View
    public final void onRestoreInstanceState(Parcelable parcelable) {
        Parcelable parcelable2;
        if (!(parcelable instanceof R4)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        R4 r4 = (R4) parcelable;
        super.onRestoreInstanceState(r4.a);
        SparseArray sparseArray = r4.c;
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = getChildAt(i);
            int id = childAt.getId();
            M4 m4 = n(childAt).a;
            if (id != -1 && m4 != null && (parcelable2 = (Parcelable) sparseArray.get(id)) != null) {
                m4.m(childAt, parcelable2);
            }
        }
    }

    /* JADX WARN: Type inference failed for: r0v0, types: [android.os.Parcelable, x.d, x.R4] */
    @Override // android.view.View
    public final Parcelable onSaveInstanceState() {
        Parcelable n;
        ?? abstractC0060d = new AbstractC0060d(super.onSaveInstanceState());
        SparseArray sparseArray = new SparseArray();
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = getChildAt(i);
            int id = childAt.getId();
            M4 m4 = ((P4) childAt.getLayoutParams()).a;
            if (id != -1 && m4 != null && (n = m4.n(childAt)) != null) {
                sparseArray.append(id, n);
            }
        }
        abstractC0060d.c = sparseArray;
        return abstractC0060d;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onStartNestedScroll(View view, View view2, int i) {
        return f(view, view2, i, 0);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onStopNestedScroll(View view) {
        d(view, 0);
    }

    /* JADX WARN: Code restructure failed: missing block: B:4:0x0012, code lost:
    
        if (r3 != false) goto L9;
     */
    /* JADX WARN: Removed duplicated region for block: B:10:0x004a  */
    /* JADX WARN: Removed duplicated region for block: B:17:0x0035  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x002f  */
    @Override // android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        boolean z;
        boolean q;
        MotionEvent motionEvent2;
        int actionMasked = motionEvent.getActionMasked();
        if (this.j == null) {
            z = r(motionEvent, 1);
        } else {
            z = false;
        }
        M4 m4 = ((P4) this.j.getLayoutParams()).a;
        if (m4 != null) {
            q = m4.q(this.j, motionEvent);
            motionEvent2 = null;
            if (this.j != null) {
                q |= super.onTouchEvent(motionEvent);
            } else if (z) {
                long uptimeMillis = SystemClock.uptimeMillis();
                motionEvent2 = MotionEvent.obtain(uptimeMillis, uptimeMillis, 3, 0.0f, 0.0f, 0);
                super.onTouchEvent(motionEvent2);
            }
            if (motionEvent2 != null) {
                motionEvent2.recycle();
            }
            if (actionMasked != 1 || actionMasked == 3) {
                t(false);
            }
            return q;
        }
        q = false;
        motionEvent2 = null;
        if (this.j != null) {
        }
        if (motionEvent2 != null) {
        }
        if (actionMasked != 1) {
        }
        t(false);
        return q;
    }

    /* JADX WARN: Removed duplicated region for block: B:100:0x02ae  */
    /* JADX WARN: Removed duplicated region for block: B:108:0x02df  */
    /* JADX WARN: Removed duplicated region for block: B:114:0x004b A[EDGE_INSN: B:114:0x004b->B:9:0x004b BREAK  A[LOOP:2: B:106:0x02db->B:112:0x02f2], SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:115:0x02d4  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void p(int i) {
        int i2;
        Rect rect;
        int i3;
        Rect rect2;
        int i4;
        Rect rect3;
        int i5;
        int i6;
        ArrayList arrayList;
        boolean z;
        int i7;
        int i8;
        int width;
        int i9;
        int i10;
        int i11;
        int height;
        int i12;
        int i13;
        int i14;
        P4 p4;
        int i15;
        Kc kc;
        int i16;
        Rect rect4;
        Rect rect5;
        Rect rect6;
        ArrayList arrayList2;
        int i17;
        boolean z2;
        M4 m4;
        int i18 = i;
        WeakHashMap weakHashMap = AbstractC0309ph.a;
        int layoutDirection = getLayoutDirection();
        ArrayList arrayList3 = this.a;
        int size = arrayList3.size();
        Rect g = g();
        Rect g2 = g();
        Rect g3 = g();
        int i19 = 0;
        while (true) {
            Kc kc2 = f4x;
            if (i19 < size) {
                View view = (View) arrayList3.get(i19);
                P4 p42 = (P4) view.getLayoutParams();
                if (i18 == 0 && view.getVisibility() == 8) {
                    i4 = i18;
                    i3 = layoutDirection;
                    i2 = i19;
                    rect3 = g3;
                    rect = g2;
                    rect2 = g;
                    arrayList = arrayList3;
                    i6 = size;
                } else {
                    int i20 = 0;
                    while (i20 < i19) {
                        if (p42.l == ((View) arrayList3.get(i20))) {
                            P4 p43 = (P4) view.getLayoutParams();
                            if (p43.k != null) {
                                Rect g4 = g();
                                Rect g5 = g();
                                arrayList2 = arrayList3;
                                Rect g6 = g();
                                k(p43.k, g4);
                                i(view, g5, false);
                                i17 = size;
                                int measuredWidth = view.getMeasuredWidth();
                                int measuredHeight = view.getMeasuredHeight();
                                p4 = p42;
                                kc = kc2;
                                i16 = i19;
                                i15 = layoutDirection;
                                rect4 = g3;
                                rect5 = g2;
                                rect6 = g;
                                l(layoutDirection, g4, g6, p43, measuredWidth, measuredHeight);
                                if (g6.left == g5.left && g6.top == g5.top) {
                                    z2 = false;
                                } else {
                                    z2 = true;
                                }
                                h(p43, g6, measuredWidth, measuredHeight);
                                int i21 = g6.left - g5.left;
                                int i22 = g6.top - g5.top;
                                if (i21 != 0) {
                                    WeakHashMap weakHashMap2 = AbstractC0309ph.a;
                                    view.offsetLeftAndRight(i21);
                                }
                                if (i22 != 0) {
                                    WeakHashMap weakHashMap3 = AbstractC0309ph.a;
                                    view.offsetTopAndBottom(i22);
                                }
                                if (z2 && (m4 = p43.a) != null) {
                                    m4.d(this, view, p43.k);
                                }
                                g4.setEmpty();
                                kc.c(g4);
                                g5.setEmpty();
                                kc.c(g5);
                                g6.setEmpty();
                                kc.c(g6);
                                i20++;
                                kc2 = kc;
                                size = i17;
                                arrayList3 = arrayList2;
                                layoutDirection = i15;
                                p42 = p4;
                                i19 = i16;
                                g3 = rect4;
                                g2 = rect5;
                                g = rect6;
                            }
                        }
                        p4 = p42;
                        i15 = layoutDirection;
                        kc = kc2;
                        i16 = i19;
                        rect4 = g3;
                        rect5 = g2;
                        rect6 = g;
                        arrayList2 = arrayList3;
                        i17 = size;
                        i20++;
                        kc2 = kc;
                        size = i17;
                        arrayList3 = arrayList2;
                        layoutDirection = i15;
                        p42 = p4;
                        i19 = i16;
                        g3 = rect4;
                        g2 = rect5;
                        g = rect6;
                    }
                    P4 p44 = p42;
                    int i23 = layoutDirection;
                    Jc jc = kc2;
                    i2 = i19;
                    Rect rect7 = g3;
                    rect = g2;
                    Rect rect8 = g;
                    ArrayList arrayList4 = arrayList3;
                    int i24 = size;
                    i(view, rect, true);
                    if (p44.g != 0 && !rect.isEmpty()) {
                        i3 = i23;
                        int absoluteGravity = Gravity.getAbsoluteGravity(p44.g, i3);
                        int i25 = absoluteGravity & 112;
                        if (i25 != 48) {
                            if (i25 != 80) {
                                rect2 = rect8;
                            } else {
                                rect2 = rect8;
                                rect2.bottom = Math.max(rect2.bottom, getHeight() - rect.top);
                            }
                        } else {
                            rect2 = rect8;
                            rect2.top = Math.max(rect2.top, rect.bottom);
                        }
                        int i26 = absoluteGravity & 7;
                        if (i26 != 3) {
                            if (i26 == 5) {
                                rect2.right = Math.max(rect2.right, getWidth() - rect.left);
                            }
                        } else {
                            rect2.left = Math.max(rect2.left, rect.right);
                        }
                    } else {
                        i3 = i23;
                        rect2 = rect8;
                    }
                    if (p44.h != 0 && view.getVisibility() == 0) {
                        WeakHashMap weakHashMap4 = AbstractC0309ph.a;
                        if (view.isLaidOut() && view.getWidth() > 0 && view.getHeight() > 0) {
                            P4 p45 = (P4) view.getLayoutParams();
                            M4 m42 = p45.a;
                            Rect g7 = g();
                            Rect g8 = g();
                            g8.set(view.getLeft(), view.getTop(), view.getRight(), view.getBottom());
                            if (m42 != null && m42.a(view)) {
                                if (!g8.contains(g7)) {
                                    throw new IllegalArgumentException("Rect should be within the child's bounds. Rect:" + g7.toShortString() + " | Bounds:" + g8.toShortString());
                                }
                            } else {
                                g7.set(g8);
                            }
                            g8.setEmpty();
                            jc.c(g8);
                            if (g7.isEmpty()) {
                                g7.setEmpty();
                                jc.c(g7);
                            } else {
                                int absoluteGravity2 = Gravity.getAbsoluteGravity(p45.h, i3);
                                if ((absoluteGravity2 & 48) == 48 && (i13 = (g7.top - ((ViewGroup.MarginLayoutParams) p45).topMargin) - p45.j) < (i14 = rect2.top)) {
                                    v(view, i14 - i13);
                                    z = true;
                                } else {
                                    z = false;
                                }
                                if ((absoluteGravity2 & 80) == 80 && (height = ((getHeight() - g7.bottom) - ((ViewGroup.MarginLayoutParams) p45).bottomMargin) + p45.j) < (i12 = rect2.bottom)) {
                                    v(view, height - i12);
                                    z = true;
                                }
                                if (!z) {
                                    i7 = 0;
                                    v(view, 0);
                                } else {
                                    i7 = 0;
                                }
                                if ((absoluteGravity2 & 3) == 3 && (i10 = (g7.left - ((ViewGroup.MarginLayoutParams) p45).leftMargin) - p45.i) < (i11 = rect2.left)) {
                                    u(view, i11 - i10);
                                    i8 = 1;
                                } else {
                                    i8 = i7;
                                }
                                if ((absoluteGravity2 & 5) == 5 && (width = ((getWidth() - g7.right) - ((ViewGroup.MarginLayoutParams) p45).rightMargin) + p45.i) < (i9 = rect2.right)) {
                                    u(view, width - i9);
                                    i8 = 1;
                                }
                                if (i8 == 0) {
                                    u(view, i7);
                                }
                                g7.setEmpty();
                                jc.c(g7);
                                i4 = i;
                                if (i4 == 2) {
                                    rect3 = rect7;
                                    rect3.set(((P4) view.getLayoutParams()).o);
                                    if (rect3.equals(rect)) {
                                        i6 = i24;
                                        arrayList = arrayList4;
                                    } else {
                                        ((P4) view.getLayoutParams()).o.set(rect);
                                    }
                                } else {
                                    rect3 = rect7;
                                }
                                i5 = i2 + 1;
                                i6 = i24;
                                while (true) {
                                    arrayList = arrayList4;
                                    if (i5 < i6) {
                                        break;
                                    }
                                    View view2 = (View) arrayList.get(i5);
                                    M4 m43 = ((P4) view2.getLayoutParams()).a;
                                    if (m43 != null) {
                                        m43.b(view2);
                                    }
                                    i5++;
                                    arrayList4 = arrayList;
                                }
                            }
                        }
                    }
                    i4 = i;
                    if (i4 == 2) {
                    }
                    i5 = i2 + 1;
                    i6 = i24;
                    while (true) {
                        arrayList = arrayList4;
                        if (i5 < i6) {
                        }
                        i5++;
                        arrayList4 = arrayList;
                    }
                }
                size = i6;
                i19 = i2 + 1;
                g2 = rect;
                i18 = i4;
                g3 = rect3;
                arrayList3 = arrayList;
                g = rect2;
                layoutDirection = i3;
            } else {
                Rect rect9 = g3;
                Rect rect10 = g2;
                Rect rect11 = g;
                rect11.setEmpty();
                kc2.c(rect11);
                rect10.setEmpty();
                kc2.c(rect10);
                rect9.setEmpty();
                kc2.c(rect9);
                return;
            }
        }
    }

    public final void q(View view, int i) {
        Rect g;
        Rect g2;
        int i2;
        P4 p4 = (P4) view.getLayoutParams();
        View view2 = p4.k;
        if (view2 == null && p4.f != -1) {
            throw new IllegalStateException("An anchor may not be changed after CoordinatorLayout measurement begins before layout is complete.");
        }
        Kc kc = f4x;
        if (view2 != null) {
            g = g();
            g2 = g();
            try {
                k(view2, g);
                P4 p42 = (P4) view.getLayoutParams();
                int measuredWidth = view.getMeasuredWidth();
                int measuredHeight = view.getMeasuredHeight();
                l(i, g, g2, p42, measuredWidth, measuredHeight);
                h(p42, g2, measuredWidth, measuredHeight);
                view.layout(g2.left, g2.top, g2.right, g2.bottom);
                return;
            } finally {
                g.setEmpty();
                kc.c(g);
                g2.setEmpty();
                kc.c(g2);
            }
        }
        int i3 = p4.e;
        if (i3 >= 0) {
            P4 p43 = (P4) view.getLayoutParams();
            int i4 = p43.c;
            if (i4 == 0) {
                i4 = 8388661;
            }
            int absoluteGravity = Gravity.getAbsoluteGravity(i4, i);
            int i5 = absoluteGravity & 7;
            int i6 = absoluteGravity & 112;
            int width = getWidth();
            int height = getHeight();
            int measuredWidth2 = view.getMeasuredWidth();
            int measuredHeight2 = view.getMeasuredHeight();
            if (i == 1) {
                i3 = width - i3;
            }
            int m = m(i3) - measuredWidth2;
            if (i5 != 1) {
                if (i5 == 5) {
                    m += measuredWidth2;
                }
            } else {
                m += measuredWidth2 / 2;
            }
            if (i6 != 16) {
                if (i6 != 80) {
                    i2 = 0;
                } else {
                    i2 = measuredHeight2;
                }
            } else {
                i2 = measuredHeight2 / 2;
            }
            int max = Math.max(getPaddingLeft() + ((ViewGroup.MarginLayoutParams) p43).leftMargin, Math.min(m, ((width - getPaddingRight()) - measuredWidth2) - ((ViewGroup.MarginLayoutParams) p43).rightMargin));
            int max2 = Math.max(getPaddingTop() + ((ViewGroup.MarginLayoutParams) p43).topMargin, Math.min(i2, ((height - getPaddingBottom()) - measuredHeight2) - ((ViewGroup.MarginLayoutParams) p43).bottomMargin));
            view.layout(max, max2, measuredWidth2 + max, measuredHeight2 + max2);
            return;
        }
        P4 p44 = (P4) view.getLayoutParams();
        g = g();
        g.set(getPaddingLeft() + ((ViewGroup.MarginLayoutParams) p44).leftMargin, getPaddingTop() + ((ViewGroup.MarginLayoutParams) p44).topMargin, (getWidth() - getPaddingRight()) - ((ViewGroup.MarginLayoutParams) p44).rightMargin, (getHeight() - getPaddingBottom()) - ((ViewGroup.MarginLayoutParams) p44).bottomMargin);
        if (this.n != null) {
            WeakHashMap weakHashMap = AbstractC0309ph.a;
            if (getFitsSystemWindows() && !view.getFitsSystemWindows()) {
                g.left = this.n.b() + g.left;
                g.top = this.n.d() + g.top;
                g.right -= this.n.c();
                g.bottom -= this.n.a();
            }
        }
        g2 = g();
        int i7 = p44.c;
        if ((i7 & 7) == 0) {
            i7 |= 8388611;
        }
        if ((i7 & 112) == 0) {
            i7 |= 48;
        }
        Gravity.apply(i7, view.getMeasuredWidth(), view.getMeasuredHeight(), g, g2, i);
        view.layout(g2.left, g2.top, g2.right, g2.bottom);
    }

    public final boolean r(MotionEvent motionEvent, int i) {
        int i2;
        int actionMasked = motionEvent.getActionMasked();
        ArrayList arrayList = this.c;
        arrayList.clear();
        boolean isChildrenDrawingOrderEnabled = isChildrenDrawingOrderEnabled();
        int childCount = getChildCount();
        for (int i3 = childCount - 1; i3 >= 0; i3--) {
            if (isChildrenDrawingOrderEnabled) {
                i2 = getChildDrawingOrder(childCount, i3);
            } else {
                i2 = i3;
            }
            arrayList.add(getChildAt(i2));
        }
        S4 s4 = w;
        if (s4 != null) {
            Collections.sort(arrayList, s4);
        }
        int size = arrayList.size();
        MotionEvent motionEvent2 = null;
        boolean z = false;
        for (int i4 = 0; i4 < size; i4++) {
            View view = (View) arrayList.get(i4);
            M4 m4 = ((P4) view.getLayoutParams()).a;
            if (z && actionMasked != 0) {
                if (m4 != null) {
                    if (motionEvent2 == null) {
                        long uptimeMillis = SystemClock.uptimeMillis();
                        motionEvent2 = MotionEvent.obtain(uptimeMillis, uptimeMillis, 3, 0.0f, 0.0f, 0);
                    }
                    if (i != 0) {
                        if (i == 1) {
                            m4.q(view, motionEvent2);
                        }
                    } else {
                        m4.f(this, view, motionEvent2);
                    }
                }
            } else if (!z && m4 != null) {
                if (i != 0) {
                    if (i == 1) {
                        z = m4.q(view, motionEvent);
                    }
                } else {
                    z = m4.f(this, view, motionEvent);
                }
                if (z) {
                    this.j = view;
                }
            }
        }
        arrayList.clear();
        return z;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean requestChildRectangleOnScreen(View view, Rect rect, boolean z) {
        M4 m4 = ((P4) view.getLayoutParams()).a;
        if (m4 != null) {
            m4.l(this, view);
        }
        return super.requestChildRectangleOnScreen(view, rect, z);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void requestDisallowInterceptTouchEvent(boolean z) {
        super.requestDisallowInterceptTouchEvent(z);
        if (z && !this.g) {
            t(false);
            this.g = true;
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:54:0x0144, code lost:
    
        throw new java.lang.IllegalArgumentException("All nodes must be present in the graph before being added as an edge");
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void s() {
        Jc jc;
        ArrayList arrayList = this.a;
        arrayList.clear();
        C0353s5 c0353s5 = this.b;
        Pe pe = (Pe) c0353s5.b;
        int i = pe.c;
        int i2 = 0;
        while (true) {
            jc = (Jc) c0353s5.a;
            if (i2 >= i) {
                break;
            }
            ArrayList arrayList2 = (ArrayList) pe.i(i2);
            if (arrayList2 != null) {
                arrayList2.clear();
                jc.c(arrayList2);
            }
            i2++;
        }
        pe.clear();
        int childCount = getChildCount();
        int i3 = 0;
        loop1: while (true) {
            Pe pe2 = (Pe) c0353s5.b;
            if (i3 < childCount) {
                View childAt = getChildAt(i3);
                P4 n = n(childAt);
                int i4 = n.f;
                if (i4 == -1) {
                    n.l = null;
                    n.k = null;
                } else {
                    View view = n.k;
                    if (view != null && view.getId() == i4) {
                        View view2 = n.k;
                        for (ViewParent parent = view2.getParent(); parent != this; parent = parent.getParent()) {
                            if (parent != null && parent != childAt) {
                                if (parent instanceof View) {
                                    view2 = parent;
                                }
                            } else {
                                n.l = null;
                                n.k = null;
                            }
                        }
                        n.l = view2;
                    }
                    View findViewById = findViewById(i4);
                    n.k = findViewById;
                    if (findViewById != null) {
                        if (findViewById == this) {
                            if (isInEditMode()) {
                                n.l = null;
                                n.k = null;
                            } else {
                                throw new IllegalStateException("View can not be anchored to the the parent CoordinatorLayout");
                            }
                        } else {
                            for (ViewParent parent2 = findViewById.getParent(); parent2 != this && parent2 != null; parent2 = parent2.getParent()) {
                                if (parent2 == childAt) {
                                    if (isInEditMode()) {
                                        n.l = null;
                                        n.k = null;
                                    } else {
                                        throw new IllegalStateException("Anchor must not be a descendant of the anchored view");
                                    }
                                } else {
                                    if (parent2 instanceof View) {
                                        findViewById = parent2;
                                    }
                                }
                            }
                            n.l = findViewById;
                        }
                    } else if (isInEditMode()) {
                        n.l = null;
                        n.k = null;
                    } else {
                        throw new IllegalStateException("Could not find CoordinatorLayout descendant view with id " + getResources().getResourceName(i4) + " to anchor view " + childAt);
                    }
                }
                if (!pe2.containsKey(childAt)) {
                    pe2.put(childAt, null);
                }
                for (int i5 = 0; i5 < childCount; i5++) {
                    if (i5 != i3) {
                        View childAt2 = getChildAt(i5);
                        if (childAt2 != n.l) {
                            WeakHashMap weakHashMap = AbstractC0309ph.a;
                            int layoutDirection = getLayoutDirection();
                            int absoluteGravity = Gravity.getAbsoluteGravity(((P4) childAt2.getLayoutParams()).g, layoutDirection);
                            if (absoluteGravity == 0 || (Gravity.getAbsoluteGravity(n.h, layoutDirection) & absoluteGravity) != absoluteGravity) {
                                M4 m4 = n.a;
                                if (m4 != null) {
                                    m4.b(childAt);
                                }
                            }
                        }
                        if (!pe2.containsKey(childAt2) && !pe2.containsKey(childAt2)) {
                            pe2.put(childAt2, null);
                        }
                        if (!pe2.containsKey(childAt2) || !pe2.containsKey(childAt)) {
                            break loop1;
                        }
                        ArrayList arrayList3 = (ArrayList) pe2.get(childAt2);
                        if (arrayList3 == null) {
                            arrayList3 = (ArrayList) jc.a();
                            if (arrayList3 == null) {
                                arrayList3 = new ArrayList();
                            }
                            pe2.put(childAt2, arrayList3);
                        }
                        arrayList3.add(childAt);
                    }
                }
                i3++;
            } else {
                ArrayList arrayList4 = (ArrayList) c0353s5.c;
                arrayList4.clear();
                HashSet hashSet = (HashSet) c0353s5.d;
                hashSet.clear();
                int i6 = pe2.c;
                for (int i7 = 0; i7 < i6; i7++) {
                    c0353s5.b(pe2.f(i7), arrayList4, hashSet);
                }
                arrayList.addAll(arrayList4);
                Collections.reverse(arrayList);
                return;
            }
        }
    }

    @Override // android.view.View
    public void setFitsSystemWindows(boolean z) {
        super.setFitsSystemWindows(z);
        w();
    }

    @Override // android.view.ViewGroup
    public void setOnHierarchyChangeListener(ViewGroup.OnHierarchyChangeListener onHierarchyChangeListener) {
        this.q = onHierarchyChangeListener;
    }

    public void setStatusBarBackground(Drawable drawable) {
        boolean z;
        Drawable drawable2 = this.p;
        if (drawable2 != drawable) {
            Drawable drawable3 = null;
            if (drawable2 != null) {
                drawable2.setCallback(null);
            }
            if (drawable != null) {
                drawable3 = drawable.mutate();
            }
            this.p = drawable3;
            if (drawable3 != null) {
                if (drawable3.isStateful()) {
                    this.p.setState(getDrawableState());
                }
                Drawable drawable4 = this.p;
                WeakHashMap weakHashMap = AbstractC0309ph.a;
                drawable4.setLayoutDirection(getLayoutDirection());
                Drawable drawable5 = this.p;
                if (getVisibility() == 0) {
                    z = true;
                } else {
                    z = false;
                }
                drawable5.setVisible(z, false);
                this.p.setCallback(this);
            }
            WeakHashMap weakHashMap2 = AbstractC0309ph.a;
            postInvalidateOnAnimation();
        }
    }

    public void setStatusBarBackgroundColor(int i) {
        setStatusBarBackground(new ColorDrawable(i));
    }

    public void setStatusBarBackgroundResource(int i) {
        Drawable drawable;
        if (i != 0) {
            drawable = getContext().getDrawable(i);
        } else {
            drawable = null;
        }
        setStatusBarBackground(drawable);
    }

    @Override // android.view.View
    public void setVisibility(int i) {
        boolean z;
        super.setVisibility(i);
        if (i == 0) {
            z = true;
        } else {
            z = false;
        }
        Drawable drawable = this.p;
        if (drawable != null && drawable.isVisible() != z) {
            this.p.setVisible(z, false);
        }
    }

    public final void t(boolean z) {
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = getChildAt(i);
            M4 m4 = ((P4) childAt.getLayoutParams()).a;
            if (m4 != null) {
                long uptimeMillis = SystemClock.uptimeMillis();
                MotionEvent obtain = MotionEvent.obtain(uptimeMillis, uptimeMillis, 3, 0.0f, 0.0f, 0);
                if (z) {
                    m4.f(this, childAt, obtain);
                } else {
                    m4.q(childAt, obtain);
                }
                obtain.recycle();
            }
        }
        for (int i2 = 0; i2 < childCount; i2++) {
            ((P4) getChildAt(i2).getLayoutParams()).getClass();
        }
        this.j = null;
        this.g = false;
    }

    @Override // android.view.View
    public final boolean verifyDrawable(Drawable drawable) {
        if (!super.verifyDrawable(drawable) && drawable != this.p) {
            return false;
        }
        return true;
    }

    public final void w() {
        WeakHashMap weakHashMap = AbstractC0309ph.a;
        if (getFitsSystemWindows()) {
            if (this.r == null) {
                this.r = new B(10, this);
            }
            AbstractC0158hh.l(this, this.r);
            setSystemUiVisibility(1280);
            return;
        }
        AbstractC0158hh.l(this, null);
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        if (layoutParams instanceof P4) {
            return new P4((P4) layoutParams);
        }
        if (layoutParams instanceof ViewGroup.MarginLayoutParams) {
            return new P4((ViewGroup.MarginLayoutParams) layoutParams);
        }
        return new P4(layoutParams);
    }
}
