package androidx.savedstate;

import android.os.Bundle;
import androidx.lifecycle.SavedStateHandleController;
import androidx.lifecycle.a;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import x.AbstractC0422vh;
import x.C0460xh;
import x.E9;
import x.InterfaceC0362se;
import x.InterfaceC0400ue;
import x.InterfaceC0479yh;
import x.P0;
import x.P9;
import x.S9;
import x.Ue;
import x.W9;
import x.Y0;
import x.Y9;

/* loaded from: classes.dex */
public final class Recreator implements W9 {
    public final InterfaceC0400ue a;

    public Recreator(InterfaceC0400ue interfaceC0400ue) {
        this.a = interfaceC0400ue;
    }

    @Override // x.W9
    public final void b(Y9 y9, S9 s9) {
        Object obj;
        boolean z;
        if (s9 == S9.ON_CREATE) {
            y9.d().f(this);
            Bundle c = this.a.b().c("androidx.savedstate.Restarter");
            if (c == null) {
                return;
            }
            ArrayList<String> stringArrayList = c.getStringArrayList("classes_to_restore");
            if (stringArrayList != null) {
                for (String str : stringArrayList) {
                    try {
                        Class<? extends U> asSubclass = Class.forName(str, false, Recreator.class.getClassLoader()).asSubclass(InterfaceC0362se.class);
                        E9.n(asSubclass, "{\n                Class.…class.java)\n            }");
                        try {
                            Constructor declaredConstructor = asSubclass.getDeclaredConstructor(null);
                            declaredConstructor.setAccessible(true);
                            try {
                                Object newInstance = declaredConstructor.newInstance(null);
                                E9.n(newInstance, "{\n                constr…wInstance()\n            }");
                                InterfaceC0400ue interfaceC0400ue = this.a;
                                if (interfaceC0400ue instanceof InterfaceC0479yh) {
                                    C0460xh c2 = ((InterfaceC0479yh) interfaceC0400ue).c();
                                    Y0 b = interfaceC0400ue.b();
                                    c2.getClass();
                                    Iterator it = new HashSet(c2.a.keySet()).iterator();
                                    while (it.hasNext()) {
                                        String str2 = (String) it.next();
                                        E9.o(str2, "key");
                                        AbstractC0422vh abstractC0422vh = (AbstractC0422vh) c2.a.get(str2);
                                        E9.l(abstractC0422vh);
                                        a d = interfaceC0400ue.d();
                                        E9.o(b, "registry");
                                        E9.o(d, "lifecycle");
                                        HashMap hashMap = abstractC0422vh.a;
                                        if (hashMap == null) {
                                            obj = null;
                                        } else {
                                            synchronized (hashMap) {
                                                obj = abstractC0422vh.a.get("androidx.lifecycle.savedstate.vm.tag");
                                            }
                                        }
                                        SavedStateHandleController savedStateHandleController = (SavedStateHandleController) obj;
                                        if (savedStateHandleController != null && !(z = savedStateHandleController.a)) {
                                            if (z) {
                                                throw new IllegalStateException("Already attached to lifecycleOwner");
                                            }
                                            savedStateHandleController.a = true;
                                            d.a(savedStateHandleController);
                                            throw null;
                                        }
                                    }
                                    if (!new HashSet(c2.a.keySet()).isEmpty()) {
                                        if (b.e) {
                                            P0 p0 = (P0) b.b;
                                            if (p0 == null) {
                                                p0 = new P0(b);
                                            }
                                            b.b = p0;
                                            try {
                                                P9.class.getDeclaredConstructor(null);
                                                P0 p02 = (P0) b.b;
                                                if (p02 != null) {
                                                    ((LinkedHashSet) p02.b).add(P9.class.getName());
                                                }
                                            } catch (NoSuchMethodException e) {
                                                throw new IllegalArgumentException("Class " + P9.class.getSimpleName() + " must have default constructor in order to be automatically recreated", e);
                                            }
                                        } else {
                                            throw new IllegalStateException("Can not perform this action after onSaveInstanceState");
                                        }
                                    }
                                } else {
                                    throw new IllegalStateException("Internal error: OnRecreation should be registered only on components that implement ViewModelStoreOwner");
                                }
                            } catch (Exception e2) {
                                throw new RuntimeException(Ue.h("Failed to instantiate ", str), e2);
                            }
                        } catch (NoSuchMethodException e3) {
                            throw new IllegalStateException("Class " + asSubclass.getSimpleName() + " must have default constructor in order to be automatically recreated", e3);
                        }
                    } catch (ClassNotFoundException e4) {
                        throw new RuntimeException("Class " + str + " wasn't found", e4);
                    }
                }
                return;
            }
            throw new IllegalStateException("Bundle with restored state for the component \"androidx.savedstate.Restarter\" must contain list of strings by the key \"classes_to_restore\"");
        }
        throw new AssertionError("Next event must be ON_CREATE");
    }
}
