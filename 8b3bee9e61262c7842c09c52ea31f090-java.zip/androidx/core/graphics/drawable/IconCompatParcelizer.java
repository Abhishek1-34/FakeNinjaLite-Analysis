package androidx.core.graphics.drawable;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.os.Parcel;
import android.os.Parcelable;
import java.nio.charset.Charset;
import org.conscrypt.ct.CTConstants;
import x.Yg;
import x.Zg;

/* loaded from: classes.dex */
public class IconCompatParcelizer {
    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Failed to find 'out' block for switch in B:23:0x00ac. Please report as an issue. */
    public static IconCompat read(Yg yg) {
        IconCompat iconCompat = new IconCompat();
        int i = iconCompat.a;
        if (yg.e(1)) {
            i = ((Zg) yg).e.readInt();
        }
        iconCompat.a = i;
        byte[] bArr = iconCompat.c;
        if (yg.e(2)) {
            Parcel parcel = ((Zg) yg).e;
            int readInt = parcel.readInt();
            if (readInt < 0) {
                bArr = null;
            } else {
                byte[] bArr2 = new byte[readInt];
                parcel.readByteArray(bArr2);
                bArr = bArr2;
            }
        }
        iconCompat.c = bArr;
        iconCompat.d = yg.f(iconCompat.d, 3);
        int i2 = iconCompat.e;
        if (yg.e(4)) {
            i2 = ((Zg) yg).e.readInt();
        }
        iconCompat.e = i2;
        int i3 = iconCompat.f;
        if (yg.e(5)) {
            i3 = ((Zg) yg).e.readInt();
        }
        iconCompat.f = i3;
        iconCompat.g = (ColorStateList) yg.f(iconCompat.g, 6);
        String str = iconCompat.i;
        if (yg.e(7)) {
            str = ((Zg) yg).e.readString();
        }
        iconCompat.i = str;
        String str2 = iconCompat.j;
        if (yg.e(8)) {
            str2 = ((Zg) yg).e.readString();
        }
        iconCompat.j = str2;
        iconCompat.h = PorterDuff.Mode.valueOf(iconCompat.i);
        switch (iconCompat.a) {
            case -1:
                Parcelable parcelable = iconCompat.d;
                if (parcelable != null) {
                    iconCompat.b = parcelable;
                    return iconCompat;
                }
                throw new IllegalArgumentException("Invalid icon");
            case 0:
            default:
                return iconCompat;
            case 1:
            case 5:
                Parcelable parcelable2 = iconCompat.d;
                if (parcelable2 != null) {
                    iconCompat.b = parcelable2;
                } else {
                    byte[] bArr3 = iconCompat.c;
                    iconCompat.b = bArr3;
                    iconCompat.a = 3;
                    iconCompat.e = 0;
                    iconCompat.f = bArr3.length;
                }
                return iconCompat;
            case 2:
            case 4:
            case 6:
                String str3 = new String(iconCompat.c, Charset.forName("UTF-16"));
                iconCompat.b = str3;
                if (iconCompat.a == 2 && iconCompat.j == null) {
                    iconCompat.j = str3.split(":", -1)[0];
                }
                return iconCompat;
            case CTConstants.CERTIFICATE_LENGTH_BYTES /* 3 */:
                iconCompat.b = iconCompat.c;
                return iconCompat;
        }
    }

    public static void write(IconCompat iconCompat, Yg yg) {
        yg.getClass();
        iconCompat.i = iconCompat.h.name();
        switch (iconCompat.a) {
            case -1:
                iconCompat.d = (Parcelable) iconCompat.b;
                break;
            case 1:
            case 5:
                iconCompat.d = (Parcelable) iconCompat.b;
                break;
            case 2:
                iconCompat.c = ((String) iconCompat.b).getBytes(Charset.forName("UTF-16"));
                break;
            case CTConstants.CERTIFICATE_LENGTH_BYTES /* 3 */:
                iconCompat.c = (byte[]) iconCompat.b;
                break;
            case 4:
            case 6:
                iconCompat.c = iconCompat.b.toString().getBytes(Charset.forName("UTF-16"));
                break;
        }
        int i = iconCompat.a;
        if (-1 != i) {
            yg.h(1);
            ((Zg) yg).e.writeInt(i);
        }
        byte[] bArr = iconCompat.c;
        if (bArr != null) {
            yg.h(2);
            int length = bArr.length;
            Parcel parcel = ((Zg) yg).e;
            parcel.writeInt(length);
            parcel.writeByteArray(bArr);
        }
        Parcelable parcelable = iconCompat.d;
        if (parcelable != null) {
            yg.h(3);
            ((Zg) yg).e.writeParcelable(parcelable, 0);
        }
        int i2 = iconCompat.e;
        if (i2 != 0) {
            yg.h(4);
            ((Zg) yg).e.writeInt(i2);
        }
        int i3 = iconCompat.f;
        if (i3 != 0) {
            yg.h(5);
            ((Zg) yg).e.writeInt(i3);
        }
        ColorStateList colorStateList = iconCompat.g;
        if (colorStateList != null) {
            yg.h(6);
            ((Zg) yg).e.writeParcelable(colorStateList, 0);
        }
        String str = iconCompat.i;
        if (str != null) {
            yg.h(7);
            ((Zg) yg).e.writeString(str);
        }
        String str2 = iconCompat.j;
        if (str2 != null) {
            yg.h(8);
            ((Zg) yg).e.writeString(str2);
        }
    }
}
