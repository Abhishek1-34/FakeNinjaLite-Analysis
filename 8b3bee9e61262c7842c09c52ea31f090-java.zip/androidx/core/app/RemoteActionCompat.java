package androidx.core.app;

import android.app.PendingIntent;
import androidx.core.graphics.drawable.IconCompat;
import x.InterfaceC0018ah;

/* loaded from: classes.dex */
public final class RemoteActionCompat implements InterfaceC0018ah {
    public IconCompat a;
    public CharSequence b;
    public CharSequence c;
    public PendingIntent d;
    public boolean e;
    public boolean f;
}
