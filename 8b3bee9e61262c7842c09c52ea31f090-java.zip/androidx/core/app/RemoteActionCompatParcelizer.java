package androidx.core.app;

import android.app.PendingIntent;
import android.os.Parcel;
import android.text.TextUtils;
import androidx.core.graphics.drawable.IconCompat;
import x.InterfaceC0018ah;
import x.Yg;
import x.Zg;

/* loaded from: classes.dex */
public class RemoteActionCompatParcelizer {
    public static RemoteActionCompat read(Yg yg) {
        RemoteActionCompat remoteActionCompat = new RemoteActionCompat();
        InterfaceC0018ah interfaceC0018ah = remoteActionCompat.a;
        boolean z = true;
        if (yg.e(1)) {
            interfaceC0018ah = yg.g();
        }
        remoteActionCompat.a = (IconCompat) interfaceC0018ah;
        CharSequence charSequence = remoteActionCompat.b;
        if (yg.e(2)) {
            charSequence = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(((Zg) yg).e);
        }
        remoteActionCompat.b = charSequence;
        CharSequence charSequence2 = remoteActionCompat.c;
        if (yg.e(3)) {
            charSequence2 = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(((Zg) yg).e);
        }
        remoteActionCompat.c = charSequence2;
        remoteActionCompat.d = (PendingIntent) yg.f(remoteActionCompat.d, 4);
        boolean z2 = remoteActionCompat.e;
        if (yg.e(5)) {
            if (((Zg) yg).e.readInt() != 0) {
                z2 = true;
            } else {
                z2 = false;
            }
        }
        remoteActionCompat.e = z2;
        boolean z3 = remoteActionCompat.f;
        if (yg.e(6)) {
            if (((Zg) yg).e.readInt() == 0) {
                z = false;
            }
            z3 = z;
        }
        remoteActionCompat.f = z3;
        return remoteActionCompat;
    }

    public static void write(RemoteActionCompat remoteActionCompat, Yg yg) {
        yg.getClass();
        IconCompat iconCompat = remoteActionCompat.a;
        yg.h(1);
        yg.i(iconCompat);
        CharSequence charSequence = remoteActionCompat.b;
        yg.h(2);
        Parcel parcel = ((Zg) yg).e;
        TextUtils.writeToParcel(charSequence, parcel, 0);
        CharSequence charSequence2 = remoteActionCompat.c;
        yg.h(3);
        TextUtils.writeToParcel(charSequence2, parcel, 0);
        PendingIntent pendingIntent = remoteActionCompat.d;
        yg.h(4);
        parcel.writeParcelable(pendingIntent, 0);
        boolean z = remoteActionCompat.e;
        yg.h(5);
        parcel.writeInt(z ? 1 : 0);
        boolean z2 = remoteActionCompat.f;
        yg.h(6);
        parcel.writeInt(z2 ? 1 : 0);
    }
}
