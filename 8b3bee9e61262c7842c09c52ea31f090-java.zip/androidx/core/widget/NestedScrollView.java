package androidx.core.widget;

import android.R;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.os.Build;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.FocusFinder;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.animation.AnimationUtils;
import android.widget.EdgeEffect;
import android.widget.FrameLayout;
import android.widget.OverScroller;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Map;
import java.util.Objects;
import java.util.WeakHashMap;
import x.A;
import x.AbstractC0087e6;
import x.AbstractC0104f3;
import x.AbstractC0158hh;
import x.AbstractC0309ph;
import x.AbstractC0328qh;
import x.B;
import x.E9;
import x.J5;
import x.Ra;
import x.Rb;
import x.Sb;
import x.Tb;
import x.Ub;
import x.Vg;
import x.Wb;
import x.Wg;
import x.Xb;

/* loaded from: classes.dex */
public class NestedScrollView extends FrameLayout implements Wb {
    public static final float B = (float) (Math.log(0.78d) / Math.log(0.9d));
    public static final Ra C = new Ra(3);
    public static final int[] D = {R.attr.fillViewport};
    public final J5 A;
    public final float a;
    public long b;
    public final Rect c;
    public final OverScroller d;
    public final EdgeEffect e;
    public final EdgeEffect f;
    public int g;
    public boolean h;
    public boolean i;
    public View j;
    public boolean k;
    public VelocityTracker l;
    public boolean m;
    public boolean n;
    public final int o;
    public final int p;
    public final int q;
    public int r;
    public final int[] s;
    public final int[] t;
    public int u;
    public int v;
    public Tb w;

    /* renamed from: x, reason: collision with root package name */
    public final Xb f5x;
    public final Ub y;
    public float z;

    /* JADX WARN: Type inference failed for: r7v2, types: [x.Xb, java.lang.Object] */
    public NestedScrollView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, org.conscrypt.R.attr.nestedScrollViewStyle);
        EdgeEffect edgeEffect;
        EdgeEffect edgeEffect2;
        this.c = new Rect();
        this.h = true;
        this.i = false;
        this.j = null;
        this.k = false;
        this.n = true;
        this.r = -1;
        this.s = new int[2];
        this.t = new int[2];
        this.A = new J5(getContext(), new B(22, this));
        int i = Build.VERSION.SDK_INT;
        if (i >= 31) {
            edgeEffect = AbstractC0087e6.a(context, attributeSet);
        } else {
            edgeEffect = new EdgeEffect(context);
        }
        this.e = edgeEffect;
        if (i >= 31) {
            edgeEffect2 = AbstractC0087e6.a(context, attributeSet);
        } else {
            edgeEffect2 = new EdgeEffect(context);
        }
        this.f = edgeEffect2;
        this.a = context.getResources().getDisplayMetrics().density * 160.0f * 386.0878f * 0.84f;
        this.d = new OverScroller(getContext());
        setFocusable(true);
        setDescendantFocusability(262144);
        setWillNotDraw(false);
        ViewConfiguration viewConfiguration = ViewConfiguration.get(getContext());
        this.o = viewConfiguration.getScaledTouchSlop();
        this.p = viewConfiguration.getScaledMinimumFlingVelocity();
        this.q = viewConfiguration.getScaledMaximumFlingVelocity();
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, D, org.conscrypt.R.attr.nestedScrollViewStyle, 0);
        setFillViewport(obtainStyledAttributes.getBoolean(0, false));
        obtainStyledAttributes.recycle();
        this.f5x = new Object();
        this.y = new Ub(this);
        setNestedScrollingEnabled(true);
        AbstractC0309ph.l(this, C);
    }

    public static boolean l(View view, NestedScrollView nestedScrollView) {
        if (view == nestedScrollView) {
            return true;
        }
        Object parent = view.getParent();
        if ((parent instanceof ViewGroup) && l((View) parent, nestedScrollView)) {
            return true;
        }
        return false;
    }

    @Override // x.Vb
    public final void a(View view, View view2, int i, int i2) {
        Xb xb = this.f5x;
        if (i2 == 1) {
            xb.b = i;
        } else {
            xb.a = i;
        }
        this.y.g(2, i2);
    }

    @Override // android.view.ViewGroup
    public final void addView(View view) {
        if (getChildCount() <= 0) {
            super.addView(view);
            return;
        }
        throw new IllegalStateException("ScrollView can host only one direct child");
    }

    @Override // x.Wb
    public final void b(View view, int i, int i2, int i3, int i4, int i5, int[] iArr) {
        n(i4, i5, iArr);
    }

    @Override // x.Vb
    public final void c(View view, int i, int i2, int i3, int i4, int i5) {
        n(i4, i5, null);
    }

    @Override // android.view.View
    public final int computeHorizontalScrollExtent() {
        return super.computeHorizontalScrollExtent();
    }

    @Override // android.view.View
    public final int computeHorizontalScrollOffset() {
        return super.computeHorizontalScrollOffset();
    }

    @Override // android.view.View
    public final int computeHorizontalScrollRange() {
        return super.computeHorizontalScrollRange();
    }

    /* JADX WARN: Removed duplicated region for block: B:15:0x0084  */
    /* JADX WARN: Removed duplicated region for block: B:17:0x0093  */
    /* JADX WARN: Removed duplicated region for block: B:19:0x00b8  */
    /* JADX WARN: Removed duplicated region for block: B:33:0x00f5  */
    /* JADX WARN: Removed duplicated region for block: B:35:0x00f9  */
    @Override // android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void computeScroll() {
        int round;
        int i;
        if (this.d.isFinished()) {
            return;
        }
        this.d.computeScrollOffset();
        int currY = this.d.getCurrY();
        int i2 = currY - this.v;
        int height = getHeight();
        EdgeEffect edgeEffect = this.f;
        EdgeEffect edgeEffect2 = this.e;
        if (i2 > 0 && E9.D(edgeEffect2) != 0.0f) {
            round = Math.round(E9.S(edgeEffect2, ((-i2) * 4.0f) / height, 0.5f) * ((-height) / 4.0f));
            if (round != i2) {
                edgeEffect2.finish();
            }
        } else {
            if (i2 < 0 && E9.D(edgeEffect) != 0.0f) {
                float f = height;
                round = Math.round(E9.S(edgeEffect, (i2 * 4.0f) / f, 0.5f) * (f / 4.0f));
                if (round != i2) {
                    edgeEffect.finish();
                }
            }
            this.v = currY;
            int[] iArr = this.t;
            iArr[1] = 0;
            this.y.c(0, i2, 1, iArr, null);
            i = i2 - iArr[1];
            int scrollRange = getScrollRange();
            if (AbstractC0104f3.a()) {
                Rb.a(this, Math.abs(this.d.getCurrVelocity()));
            }
            if (i != 0) {
                int scrollY = getScrollY();
                p(i, getScrollX(), scrollY, scrollRange);
                int scrollY2 = getScrollY() - scrollY;
                int i3 = i - scrollY2;
                iArr[1] = 0;
                this.y.d(0, scrollY2, 0, i3, this.s, 1, iArr);
                i = i3 - iArr[1];
            }
            if (i != 0) {
                int overScrollMode = getOverScrollMode();
                if (overScrollMode == 0 || (overScrollMode == 1 && scrollRange > 0)) {
                    if (i < 0) {
                        if (edgeEffect2.isFinished()) {
                            edgeEffect2.onAbsorb((int) this.d.getCurrVelocity());
                        }
                    } else if (edgeEffect.isFinished()) {
                        edgeEffect.onAbsorb((int) this.d.getCurrVelocity());
                    }
                }
                this.d.abortAnimation();
                w(1);
            }
            if (this.d.isFinished()) {
                postInvalidateOnAnimation();
                return;
            } else {
                w(1);
                return;
            }
        }
        i2 -= round;
        this.v = currY;
        int[] iArr2 = this.t;
        iArr2[1] = 0;
        this.y.c(0, i2, 1, iArr2, null);
        i = i2 - iArr2[1];
        int scrollRange2 = getScrollRange();
        if (AbstractC0104f3.a()) {
        }
        if (i != 0) {
        }
        if (i != 0) {
        }
        if (this.d.isFinished()) {
        }
    }

    @Override // android.view.View
    public final int computeVerticalScrollExtent() {
        return super.computeVerticalScrollExtent();
    }

    @Override // android.view.View
    public final int computeVerticalScrollOffset() {
        return Math.max(0, super.computeVerticalScrollOffset());
    }

    @Override // android.view.View
    public final int computeVerticalScrollRange() {
        int childCount = getChildCount();
        int height = (getHeight() - getPaddingBottom()) - getPaddingTop();
        if (childCount == 0) {
            return height;
        }
        View childAt = getChildAt(0);
        int bottom = childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin;
        int scrollY = getScrollY();
        int max = Math.max(0, bottom - height);
        if (scrollY < 0) {
            return bottom - scrollY;
        }
        if (scrollY > max) {
            return bottom + (scrollY - max);
        }
        return bottom;
    }

    @Override // x.Vb
    public final void d(View view, int i) {
        Xb xb = this.f5x;
        if (i == 1) {
            xb.b = 0;
        } else {
            xb.a = 0;
        }
        w(i);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final boolean dispatchKeyEvent(KeyEvent keyEvent) {
        if (!super.dispatchKeyEvent(keyEvent) && !i(keyEvent)) {
            return false;
        }
        return true;
    }

    @Override // android.view.View
    public final boolean dispatchNestedFling(float f, float f2, boolean z) {
        return this.y.a(f, f2, z);
    }

    @Override // android.view.View
    public final boolean dispatchNestedPreFling(float f, float f2) {
        return this.y.b(f, f2);
    }

    @Override // android.view.View
    public final boolean dispatchNestedPreScroll(int i, int i2, int[] iArr, int[] iArr2) {
        return this.y.c(i, i2, 0, iArr, iArr2);
    }

    @Override // android.view.View
    public final boolean dispatchNestedScroll(int i, int i2, int i3, int i4, int[] iArr) {
        return this.y.d(i, i2, i3, i4, iArr, 0, null);
    }

    @Override // android.view.View
    public final void draw(Canvas canvas) {
        int i;
        super.draw(canvas);
        int scrollY = getScrollY();
        EdgeEffect edgeEffect = this.e;
        int i2 = 0;
        if (!edgeEffect.isFinished()) {
            int save = canvas.save();
            int width = getWidth();
            int height = getHeight();
            int min = Math.min(0, scrollY);
            if (getClipToPadding()) {
                width -= getPaddingRight() + getPaddingLeft();
                i = getPaddingLeft();
            } else {
                i = 0;
            }
            if (getClipToPadding()) {
                height -= getPaddingBottom() + getPaddingTop();
                min += getPaddingTop();
            }
            canvas.translate(i, min);
            edgeEffect.setSize(width, height);
            if (edgeEffect.draw(canvas)) {
                postInvalidateOnAnimation();
            }
            canvas.restoreToCount(save);
        }
        EdgeEffect edgeEffect2 = this.f;
        if (!edgeEffect2.isFinished()) {
            int save2 = canvas.save();
            int width2 = getWidth();
            int height2 = getHeight();
            int max = Math.max(getScrollRange(), scrollY) + height2;
            if (getClipToPadding()) {
                width2 -= getPaddingRight() + getPaddingLeft();
                i2 = getPaddingLeft();
            }
            if (getClipToPadding()) {
                height2 -= getPaddingBottom() + getPaddingTop();
                max -= getPaddingBottom();
            }
            canvas.translate(i2 - width2, max);
            canvas.rotate(180.0f, width2, 0.0f);
            edgeEffect2.setSize(width2, height2);
            if (edgeEffect2.draw(canvas)) {
                postInvalidateOnAnimation();
            }
            canvas.restoreToCount(save2);
        }
    }

    @Override // x.Vb
    public final void e(View view, int i, int i2, int[] iArr, int i3) {
        this.y.c(i, i2, i3, iArr, null);
    }

    @Override // x.Vb
    public final boolean f(View view, View view2, int i, int i2) {
        return (i & 2) != 0;
    }

    public final boolean g(int i) {
        View findFocus = findFocus();
        if (findFocus == this) {
            findFocus = null;
        }
        View findNextFocus = FocusFinder.getInstance().findNextFocus(this, findFocus, i);
        int maxScrollAmount = getMaxScrollAmount();
        if (findNextFocus != null && m(findNextFocus, maxScrollAmount, getHeight())) {
            Rect rect = this.c;
            findNextFocus.getDrawingRect(rect);
            offsetDescendantRectToMyCoords(findNextFocus, rect);
            s(h(rect), 0, 1, true);
            findNextFocus.requestFocus(i);
        } else {
            if (i == 33 && getScrollY() < maxScrollAmount) {
                maxScrollAmount = getScrollY();
            } else if (i == 130 && getChildCount() > 0) {
                View childAt = getChildAt(0);
                maxScrollAmount = Math.min((childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin) - ((getHeight() + getScrollY()) - getPaddingBottom()), maxScrollAmount);
            }
            if (maxScrollAmount == 0) {
                return false;
            }
            if (i != 130) {
                maxScrollAmount = -maxScrollAmount;
            }
            s(maxScrollAmount, 0, 1, true);
        }
        if (findFocus != null && findFocus.isFocused() && !m(findFocus, 0, getHeight())) {
            int descendantFocusability = getDescendantFocusability();
            setDescendantFocusability(131072);
            requestFocus();
            setDescendantFocusability(descendantFocusability);
        }
        return true;
    }

    @Override // android.view.View
    public float getBottomFadingEdgeStrength() {
        if (getChildCount() == 0) {
            return 0.0f;
        }
        View childAt = getChildAt(0);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
        int verticalFadingEdgeLength = getVerticalFadingEdgeLength();
        int bottom = ((childAt.getBottom() + layoutParams.bottomMargin) - getScrollY()) - (getHeight() - getPaddingBottom());
        if (bottom < verticalFadingEdgeLength) {
            return bottom / verticalFadingEdgeLength;
        }
        return 1.0f;
    }

    public int getMaxScrollAmount() {
        return (int) (getHeight() * 0.5f);
    }

    @Override // android.view.ViewGroup
    public int getNestedScrollAxes() {
        Xb xb = this.f5x;
        return xb.b | xb.a;
    }

    public int getScrollRange() {
        if (getChildCount() <= 0) {
            return 0;
        }
        View childAt = getChildAt(0);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
        return Math.max(0, ((childAt.getHeight() + layoutParams.topMargin) + layoutParams.bottomMargin) - ((getHeight() - getPaddingTop()) - getPaddingBottom()));
    }

    @Override // android.view.View
    public float getTopFadingEdgeStrength() {
        if (getChildCount() == 0) {
            return 0.0f;
        }
        int verticalFadingEdgeLength = getVerticalFadingEdgeLength();
        int scrollY = getScrollY();
        if (scrollY < verticalFadingEdgeLength) {
            return scrollY / verticalFadingEdgeLength;
        }
        return 1.0f;
    }

    public float getVerticalScrollFactorCompat() {
        if (this.z == 0.0f) {
            TypedValue typedValue = new TypedValue();
            Context context = getContext();
            if (context.getTheme().resolveAttribute(R.attr.listPreferredItemHeight, typedValue, true)) {
                this.z = typedValue.getDimension(context.getResources().getDisplayMetrics());
            } else {
                throw new IllegalStateException("Expected theme to define listPreferredItemHeight.");
            }
        }
        return this.z;
    }

    public final int h(Rect rect) {
        int i;
        int i2;
        int i3;
        if (getChildCount() == 0) {
            return 0;
        }
        int height = getHeight();
        int scrollY = getScrollY();
        int i4 = scrollY + height;
        int verticalFadingEdgeLength = getVerticalFadingEdgeLength();
        if (rect.top > 0) {
            scrollY += verticalFadingEdgeLength;
        }
        View childAt = getChildAt(0);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
        if (rect.bottom < childAt.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin) {
            i = i4 - verticalFadingEdgeLength;
        } else {
            i = i4;
        }
        int i5 = rect.bottom;
        if (i5 > i && rect.top > scrollY) {
            if (rect.height() > height) {
                i3 = rect.top - scrollY;
            } else {
                i3 = rect.bottom - i;
            }
            return Math.min(i3, (childAt.getBottom() + layoutParams.bottomMargin) - i4);
        }
        if (rect.top >= scrollY || i5 >= i) {
            return 0;
        }
        if (rect.height() > height) {
            i2 = 0 - (i - rect.bottom);
        } else {
            i2 = 0 - (scrollY - rect.top);
        }
        return Math.max(i2, -getScrollY());
    }

    @Override // android.view.View
    public final boolean hasNestedScrollingParent() {
        return this.y.f(0);
    }

    public final boolean i(KeyEvent keyEvent) {
        this.c.setEmpty();
        int i = 130;
        if (getChildCount() > 0) {
            View childAt = getChildAt(0);
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
            if (childAt.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin > (getHeight() - getPaddingTop()) - getPaddingBottom()) {
                if (keyEvent.getAction() != 0) {
                    return false;
                }
                int keyCode = keyEvent.getKeyCode();
                if (keyCode != 19) {
                    if (keyCode != 20) {
                        if (keyCode != 62) {
                            if (keyCode != 92) {
                                if (keyCode != 93) {
                                    if (keyCode != 122) {
                                        if (keyCode != 123) {
                                            return false;
                                        }
                                        q(130);
                                        return false;
                                    }
                                    q(33);
                                    return false;
                                }
                                return k(130);
                            }
                            return k(33);
                        }
                        if (keyEvent.isShiftPressed()) {
                            i = 33;
                        }
                        q(i);
                        return false;
                    }
                    if (keyEvent.isAltPressed()) {
                        return k(130);
                    }
                    return g(130);
                }
                if (keyEvent.isAltPressed()) {
                    return k(33);
                }
                return g(33);
            }
        }
        if (!isFocused() || keyEvent.getKeyCode() == 4) {
            return false;
        }
        View findFocus = findFocus();
        if (findFocus == this) {
            findFocus = null;
        }
        View findNextFocus = FocusFinder.getInstance().findNextFocus(this, findFocus, 130);
        if (findNextFocus == null || findNextFocus == this || !findNextFocus.requestFocus(130)) {
            return false;
        }
        return true;
    }

    @Override // android.view.View
    public final boolean isNestedScrollingEnabled() {
        return this.y.d;
    }

    public final void j(int i) {
        if (getChildCount() > 0) {
            this.d.fling(getScrollX(), getScrollY(), 0, i, 0, 0, Integer.MIN_VALUE, Integer.MAX_VALUE, 0, 0);
            this.y.g(2, 1);
            this.v = getScrollY();
            postInvalidateOnAnimation();
            if (AbstractC0104f3.a()) {
                Rb.a(this, Math.abs(this.d.getCurrVelocity()));
            }
        }
    }

    public final boolean k(int i) {
        boolean z;
        int childCount;
        if (i == 130) {
            z = true;
        } else {
            z = false;
        }
        int height = getHeight();
        Rect rect = this.c;
        rect.top = 0;
        rect.bottom = height;
        if (z && (childCount = getChildCount()) > 0) {
            View childAt = getChildAt(childCount - 1);
            int paddingBottom = getPaddingBottom() + childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin;
            rect.bottom = paddingBottom;
            rect.top = paddingBottom - height;
        }
        return r(i, rect.top, rect.bottom);
    }

    public final boolean m(View view, int i, int i2) {
        Rect rect = this.c;
        view.getDrawingRect(rect);
        offsetDescendantRectToMyCoords(view, rect);
        if (rect.bottom + i >= getScrollY() && rect.top - i <= getScrollY() + i2) {
            return true;
        }
        return false;
    }

    @Override // android.view.ViewGroup
    public final void measureChild(View view, int i, int i2) {
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        view.measure(ViewGroup.getChildMeasureSpec(i, getPaddingRight() + getPaddingLeft(), layoutParams.width), View.MeasureSpec.makeMeasureSpec(0, 0));
    }

    @Override // android.view.ViewGroup
    public final void measureChildWithMargins(View view, int i, int i2, int i3, int i4) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        view.measure(ViewGroup.getChildMeasureSpec(i, getPaddingRight() + getPaddingLeft() + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + i2, marginLayoutParams.width), View.MeasureSpec.makeMeasureSpec(marginLayoutParams.topMargin + marginLayoutParams.bottomMargin, 0));
    }

    public final void n(int i, int i2, int[] iArr) {
        int scrollY = getScrollY();
        scrollBy(0, i);
        int scrollY2 = getScrollY() - scrollY;
        if (iArr != null) {
            iArr[1] = iArr[1] + scrollY2;
        }
        this.y.d(0, scrollY2, 0, i - scrollY2, null, i2, iArr);
    }

    public final void o(MotionEvent motionEvent) {
        int i;
        int actionIndex = motionEvent.getActionIndex();
        if (motionEvent.getPointerId(actionIndex) == this.r) {
            if (actionIndex == 0) {
                i = 1;
            } else {
                i = 0;
            }
            this.g = (int) motionEvent.getY(i);
            this.r = motionEvent.getPointerId(i);
            VelocityTracker velocityTracker = this.l;
            if (velocityTracker != null) {
                velocityTracker.clear();
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.i = false;
    }

    /* JADX WARN: Removed duplicated region for block: B:131:0x00f1  */
    /* JADX WARN: Removed duplicated region for block: B:134:0x00f7  */
    /* JADX WARN: Removed duplicated region for block: B:58:0x02ad  */
    /* JADX WARN: Removed duplicated region for block: B:88:0x02b5  */
    @Override // android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final boolean onGenericMotionEvent(MotionEvent motionEvent) {
        boolean z;
        float f;
        int i;
        int i2;
        boolean z2;
        char c;
        int i3;
        int i4;
        int scaledMinimumFlingVelocity;
        boolean z3;
        int i5;
        int scaledMaximumFlingVelocity;
        int dimensionPixelSize;
        char c2;
        boolean z4;
        VelocityTracker velocityTracker;
        float f2;
        float f3;
        long j;
        float f4;
        float sqrt;
        int i6;
        VelocityTracker velocityTracker2;
        float[] fArr;
        int i7;
        float f5;
        if (motionEvent.getAction() == 8 && !this.k) {
            if ((motionEvent.getSource() & 2) == 2) {
                z = true;
            } else {
                z = false;
            }
            if (z) {
                i = 9;
                f = motionEvent.getAxisValue(9);
                i2 = (int) motionEvent.getX();
            } else if ((motionEvent.getSource() & 4194304) == 4194304) {
                f = motionEvent.getAxisValue(26);
                i2 = getWidth() / 2;
                i = 26;
            } else {
                f = 0.0f;
                i = 0;
                i2 = 0;
            }
            if (f != 0.0f) {
                int verticalScrollFactorCompat = (int) (getVerticalScrollFactorCompat() * f);
                if ((motionEvent.getSource() & 8194) == 8194) {
                    z2 = true;
                } else {
                    z2 = false;
                }
                s(-verticalScrollFactorCompat, i2, 1, z2);
                if (i == 0) {
                    return true;
                }
                J5 j5 = this.A;
                j5.getClass();
                int source = motionEvent.getSource();
                int deviceId = motionEvent.getDeviceId();
                int i8 = j5.f;
                int[] iArr = j5.h;
                if (i8 == source && j5.g == deviceId && j5.e == i) {
                    c2 = 0;
                    z4 = false;
                } else {
                    Context context = j5.a;
                    ViewConfiguration viewConfiguration = ViewConfiguration.get(context);
                    int deviceId2 = motionEvent.getDeviceId();
                    int source2 = motionEvent.getSource();
                    int i9 = Build.VERSION.SDK_INT;
                    if (i9 >= 34) {
                        Method method = AbstractC0328qh.a;
                        i3 = A.f(viewConfiguration, deviceId2, i, source2);
                    } else {
                        Method method2 = AbstractC0328qh.a;
                        InputDevice device = InputDevice.getDevice(deviceId2);
                        if (device != null && device.getMotionRange(i, source2) != null) {
                            Resources resources = context.getResources();
                            if (source2 == 4194304 && i == 26) {
                                i4 = resources.getIdentifier("config_viewMinRotaryEncoderFlingVelocity", "dimen", "android");
                            } else {
                                i4 = -1;
                            }
                            Objects.requireNonNull(viewConfiguration);
                            if (i4 != -1) {
                                if (i4 != 0) {
                                    scaledMinimumFlingVelocity = resources.getDimensionPixelSize(i4);
                                    if (scaledMinimumFlingVelocity < 0) {
                                        scaledMinimumFlingVelocity = Integer.MAX_VALUE;
                                    }
                                } else {
                                    i3 = Integer.MAX_VALUE;
                                }
                            } else {
                                scaledMinimumFlingVelocity = viewConfiguration.getScaledMinimumFlingVelocity();
                            }
                            i3 = scaledMinimumFlingVelocity;
                        } else {
                            c = 0;
                            i3 = Integer.MAX_VALUE;
                            iArr[c] = i3;
                            int deviceId3 = motionEvent.getDeviceId();
                            int source3 = motionEvent.getSource();
                            if (i9 < 34) {
                                scaledMaximumFlingVelocity = A.e(viewConfiguration, deviceId3, i, source3);
                            } else {
                                InputDevice device2 = InputDevice.getDevice(deviceId3);
                                if (device2 != null && device2.getMotionRange(i, source3) != null) {
                                    z3 = true;
                                } else {
                                    z3 = false;
                                }
                                int i10 = Integer.MIN_VALUE;
                                if (z3) {
                                    Resources resources2 = context.getResources();
                                    if (source3 == 4194304 && i == 26) {
                                        i5 = resources2.getIdentifier("config_viewMaxRotaryEncoderFlingVelocity", "dimen", "android");
                                    } else {
                                        i5 = -1;
                                    }
                                    Objects.requireNonNull(viewConfiguration);
                                    if (i5 != -1) {
                                        if (i5 != 0 && (dimensionPixelSize = resources2.getDimensionPixelSize(i5)) >= 0) {
                                            i10 = dimensionPixelSize;
                                        }
                                    } else {
                                        scaledMaximumFlingVelocity = viewConfiguration.getScaledMaximumFlingVelocity();
                                    }
                                }
                                scaledMaximumFlingVelocity = i10;
                            }
                            iArr[1] = scaledMaximumFlingVelocity;
                            j5.f = source;
                            j5.g = deviceId;
                            j5.e = i;
                            c2 = 0;
                            z4 = true;
                        }
                    }
                    c = 0;
                    iArr[c] = i3;
                    int deviceId32 = motionEvent.getDeviceId();
                    int source32 = motionEvent.getSource();
                    if (i9 < 34) {
                    }
                    iArr[1] = scaledMaximumFlingVelocity;
                    j5.f = source;
                    j5.g = deviceId;
                    j5.e = i;
                    c2 = 0;
                    z4 = true;
                }
                if (iArr[c2] == Integer.MAX_VALUE) {
                    VelocityTracker velocityTracker3 = j5.c;
                    if (velocityTracker3 != null) {
                        velocityTracker3.recycle();
                        j5.c = null;
                    }
                } else {
                    if (j5.c == null) {
                        j5.c = VelocityTracker.obtain();
                    }
                    VelocityTracker velocityTracker4 = j5.c;
                    Map map = Vg.a;
                    velocityTracker4.addMovement(motionEvent);
                    if (Build.VERSION.SDK_INT < 34 && motionEvent.getSource() == 4194304) {
                        Map map2 = Vg.a;
                        if (!map2.containsKey(velocityTracker4)) {
                            map2.put(velocityTracker4, new Wg());
                        }
                        Wg wg = (Wg) map2.get(velocityTracker4);
                        wg.getClass();
                        long eventTime = motionEvent.getEventTime();
                        int i11 = wg.d;
                        long[] jArr = wg.b;
                        if (i11 != 0 && eventTime - jArr[wg.e] > 40) {
                            wg.d = 0;
                            wg.c = 0.0f;
                        }
                        int i12 = (wg.e + 1) % 20;
                        wg.e = i12;
                        int i13 = wg.d;
                        if (i13 != 20) {
                            wg.d = i13 + 1;
                        }
                        wg.a[i12] = motionEvent.getAxisValue(26);
                        jArr[wg.e] = eventTime;
                    }
                    velocityTracker4.computeCurrentVelocity(1000, Float.MAX_VALUE);
                    Wg wg2 = (Wg) Vg.a.get(velocityTracker4);
                    if (wg2 != null) {
                        int i14 = wg2.d;
                        if (i14 >= 2) {
                            int i15 = wg2.e;
                            int i16 = ((i15 + 20) - (i14 - 1)) % 20;
                            long[] jArr2 = wg2.b;
                            long j2 = jArr2[i15];
                            while (true) {
                                j = jArr2[i16];
                                if (j2 - j <= 100) {
                                    break;
                                }
                                wg2.d--;
                                i16 = (i16 + 1) % 20;
                            }
                            int i17 = wg2.d;
                            if (i17 >= 2) {
                                float[] fArr2 = wg2.a;
                                if (i17 == 2) {
                                    int i18 = (i16 + 1) % 20;
                                    long j3 = jArr2[i18];
                                    if (j != j3) {
                                        velocityTracker = velocityTracker4;
                                        i6 = 1000;
                                        sqrt = fArr2[i18] / ((float) (j3 - j));
                                    }
                                } else {
                                    float f6 = 0.0f;
                                    int i19 = 0;
                                    int i20 = 0;
                                    while (true) {
                                        f4 = 1.0f;
                                        if (i19 >= wg2.d - 1) {
                                            break;
                                        }
                                        int i21 = i19 + i16;
                                        long j4 = jArr2[i21 % 20];
                                        int i22 = (i21 + 1) % 20;
                                        if (jArr2[i22] == j4) {
                                            velocityTracker2 = velocityTracker4;
                                            fArr = fArr2;
                                            i7 = 1;
                                        } else {
                                            i20++;
                                            if (f6 < 0.0f) {
                                                f4 = -1.0f;
                                            }
                                            velocityTracker2 = velocityTracker4;
                                            float sqrt2 = f4 * ((float) Math.sqrt(Math.abs(f6) * 2.0f));
                                            float f7 = fArr2[i22];
                                            long j6 = jArr2[i22];
                                            fArr = fArr2;
                                            float f8 = f7 / ((float) (j6 - j4));
                                            float abs = (Math.abs(f8) * (f8 - sqrt2)) + f6;
                                            i7 = 1;
                                            if (i20 == 1) {
                                                abs *= 0.5f;
                                            }
                                            f6 = abs;
                                        }
                                        i19 += i7;
                                        fArr2 = fArr;
                                        velocityTracker4 = velocityTracker2;
                                    }
                                    velocityTracker = velocityTracker4;
                                    if (f6 < 0.0f) {
                                        f4 = -1.0f;
                                    }
                                    sqrt = ((float) Math.sqrt(Math.abs(f6) * 2.0f)) * f4;
                                    i6 = 1000;
                                }
                                f5 = sqrt * i6;
                                wg2.c = f5;
                                if (f5 >= (-Math.abs(Float.MAX_VALUE))) {
                                    wg2.c = -Math.abs(Float.MAX_VALUE);
                                } else if (wg2.c > Math.abs(Float.MAX_VALUE)) {
                                    wg2.c = Math.abs(Float.MAX_VALUE);
                                }
                            }
                        }
                        velocityTracker = velocityTracker4;
                        i6 = 1000;
                        sqrt = 0.0f;
                        f5 = sqrt * i6;
                        wg2.c = f5;
                        if (f5 >= (-Math.abs(Float.MAX_VALUE))) {
                        }
                    } else {
                        velocityTracker = velocityTracker4;
                    }
                    if (Build.VERSION.SDK_INT >= 34) {
                        f2 = A.b(velocityTracker, i);
                    } else {
                        VelocityTracker velocityTracker5 = velocityTracker;
                        if (i == 0) {
                            f2 = velocityTracker5.getXVelocity();
                        } else if (i == 1) {
                            f2 = velocityTracker5.getYVelocity();
                        } else {
                            Wg wg3 = (Wg) Vg.a.get(velocityTracker5);
                            if (wg3 != null && i == 26) {
                                f2 = wg3.c;
                            } else {
                                f2 = 0.0f;
                            }
                        }
                    }
                    NestedScrollView nestedScrollView = (NestedScrollView) j5.b.b;
                    float f9 = f2 * (-nestedScrollView.getVerticalScrollFactorCompat());
                    float signum = Math.signum(f9);
                    if (z4 || (signum != Math.signum(j5.d) && signum != 0.0f)) {
                        nestedScrollView.d.abortAnimation();
                    }
                    if (Math.abs(f9) >= iArr[0]) {
                        float max = Math.max(-r4, Math.min(f9, iArr[1]));
                        if (max == 0.0f) {
                            f3 = 0.0f;
                        } else {
                            nestedScrollView.d.abortAnimation();
                            nestedScrollView.j((int) max);
                            f3 = max;
                        }
                        j5.d = f3;
                    }
                }
                return true;
            }
            return false;
        }
        return false;
    }

    @Override // android.view.ViewGroup
    public final boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        int action = motionEvent.getAction();
        boolean z = true;
        if (action == 2 && this.k) {
            return true;
        }
        int i = action & 255;
        if (i != 0) {
            if (i != 1) {
                if (i != 2) {
                    if (i != 3) {
                        if (i == 6) {
                            o(motionEvent);
                        }
                    }
                } else {
                    int i2 = this.r;
                    if (i2 != -1) {
                        int findPointerIndex = motionEvent.findPointerIndex(i2);
                        if (findPointerIndex == -1) {
                            Log.e("NestedScrollView", "Invalid pointerId=" + i2 + " in onInterceptTouchEvent");
                        } else {
                            int y = (int) motionEvent.getY(findPointerIndex);
                            if (Math.abs(y - this.g) > this.o && (2 & getNestedScrollAxes()) == 0) {
                                this.k = true;
                                this.g = y;
                                if (this.l == null) {
                                    this.l = VelocityTracker.obtain();
                                }
                                this.l.addMovement(motionEvent);
                                this.u = 0;
                                ViewParent parent = getParent();
                                if (parent != null) {
                                    parent.requestDisallowInterceptTouchEvent(true);
                                }
                            }
                        }
                    }
                }
            }
            this.k = false;
            this.r = -1;
            VelocityTracker velocityTracker = this.l;
            if (velocityTracker != null) {
                velocityTracker.recycle();
                this.l = null;
            }
            if (this.d.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange())) {
                postInvalidateOnAnimation();
            }
            w(0);
        } else {
            int y2 = (int) motionEvent.getY();
            int x2 = (int) motionEvent.getX();
            if (getChildCount() > 0) {
                int scrollY = getScrollY();
                View childAt = getChildAt(0);
                if (y2 >= childAt.getTop() - scrollY && y2 < childAt.getBottom() - scrollY && x2 >= childAt.getLeft() && x2 < childAt.getRight()) {
                    this.g = y2;
                    this.r = motionEvent.getPointerId(0);
                    VelocityTracker velocityTracker2 = this.l;
                    if (velocityTracker2 == null) {
                        this.l = VelocityTracker.obtain();
                    } else {
                        velocityTracker2.clear();
                    }
                    this.l.addMovement(motionEvent);
                    this.d.computeScrollOffset();
                    if (!v(motionEvent) && this.d.isFinished()) {
                        z = false;
                    }
                    this.k = z;
                    this.y.g(2, 0);
                }
            }
            if (!v(motionEvent) && this.d.isFinished()) {
                z = false;
            }
            this.k = z;
            VelocityTracker velocityTracker3 = this.l;
            if (velocityTracker3 != null) {
                velocityTracker3.recycle();
                this.l = null;
            }
        }
        return this.k;
    }

    @Override // android.widget.FrameLayout, android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z, int i, int i2, int i3, int i4) {
        int i5;
        super.onLayout(z, i, i2, i3, i4);
        int i6 = 0;
        this.h = false;
        View view = this.j;
        if (view != null && l(view, this)) {
            View view2 = this.j;
            Rect rect = this.c;
            view2.getDrawingRect(rect);
            offsetDescendantRectToMyCoords(view2, rect);
            int h = h(rect);
            if (h != 0) {
                scrollBy(0, h);
            }
        }
        this.j = null;
        if (!this.i) {
            if (this.w != null) {
                scrollTo(getScrollX(), this.w.a);
                this.w = null;
            }
            if (getChildCount() > 0) {
                View childAt = getChildAt(0);
                FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
                i5 = childAt.getMeasuredHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
            } else {
                i5 = 0;
            }
            int paddingTop = ((i4 - i2) - getPaddingTop()) - getPaddingBottom();
            int scrollY = getScrollY();
            if (paddingTop < i5 && scrollY >= 0) {
                i6 = paddingTop + scrollY > i5 ? i5 - paddingTop : scrollY;
            }
            if (i6 != scrollY) {
                scrollTo(getScrollX(), i6);
            }
        }
        scrollTo(getScrollX(), getScrollY());
        this.i = true;
    }

    @Override // android.widget.FrameLayout, android.view.View
    public final void onMeasure(int i, int i2) {
        super.onMeasure(i, i2);
        if (this.m && View.MeasureSpec.getMode(i2) != 0 && getChildCount() > 0) {
            View childAt = getChildAt(0);
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
            int measuredHeight = childAt.getMeasuredHeight();
            int measuredHeight2 = (((getMeasuredHeight() - getPaddingTop()) - getPaddingBottom()) - layoutParams.topMargin) - layoutParams.bottomMargin;
            if (measuredHeight < measuredHeight2) {
                childAt.measure(ViewGroup.getChildMeasureSpec(i, getPaddingRight() + getPaddingLeft() + layoutParams.leftMargin + layoutParams.rightMargin, layoutParams.width), View.MeasureSpec.makeMeasureSpec(measuredHeight2, 1073741824));
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onNestedFling(View view, float f, float f2, boolean z) {
        if (!z) {
            dispatchNestedFling(0.0f, f2, true);
            j((int) f2);
            return true;
        }
        return false;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onNestedPreFling(View view, float f, float f2) {
        return this.y.b(f, f2);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedPreScroll(View view, int i, int i2, int[] iArr) {
        this.y.c(i, i2, 0, iArr, null);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedScroll(View view, int i, int i2, int i3, int i4) {
        n(i4, 0, null);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedScrollAccepted(View view, View view2, int i) {
        a(view, view2, i, 0);
    }

    @Override // android.view.View
    public final void onOverScrolled(int i, int i2, boolean z, boolean z2) {
        super.scrollTo(i, i2);
    }

    @Override // android.view.ViewGroup
    public final boolean onRequestFocusInDescendants(int i, Rect rect) {
        View findNextFocusFromRect;
        if (i == 2) {
            i = 130;
        } else if (i == 1) {
            i = 33;
        }
        if (rect == null) {
            findNextFocusFromRect = FocusFinder.getInstance().findNextFocus(this, null, i);
        } else {
            findNextFocusFromRect = FocusFinder.getInstance().findNextFocusFromRect(this, rect, i);
        }
        if (findNextFocusFromRect == null || !m(findNextFocusFromRect, 0, getHeight())) {
            return false;
        }
        return findNextFocusFromRect.requestFocus(i, rect);
    }

    @Override // android.view.View
    public final void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof Tb)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        Tb tb = (Tb) parcelable;
        super.onRestoreInstanceState(tb.getSuperState());
        this.w = tb;
        requestLayout();
    }

    /* JADX WARN: Type inference failed for: r1v0, types: [android.view.View$BaseSavedState, x.Tb, android.os.Parcelable] */
    @Override // android.view.View
    public final Parcelable onSaveInstanceState() {
        ?? baseSavedState = new View.BaseSavedState(super.onSaveInstanceState());
        baseSavedState.a = getScrollY();
        return baseSavedState;
    }

    @Override // android.view.View
    public final void onScrollChanged(int i, int i2, int i3, int i4) {
        super.onScrollChanged(i, i2, i3, i4);
    }

    @Override // android.view.View
    public final void onSizeChanged(int i, int i2, int i3, int i4) {
        super.onSizeChanged(i, i2, i3, i4);
        View findFocus = findFocus();
        if (findFocus != null && this != findFocus && m(findFocus, 0, i4)) {
            Rect rect = this.c;
            findFocus.getDrawingRect(rect);
            offsetDescendantRectToMyCoords(findFocus, rect);
            int h = h(rect);
            if (h != 0) {
                if (this.n) {
                    u(0, h, false);
                } else {
                    scrollBy(0, h);
                }
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onStartNestedScroll(View view, View view2, int i) {
        return f(view, view2, i, 0);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onStopNestedScroll(View view) {
        d(view, 0);
    }

    @Override // android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        ViewParent parent;
        if (this.l == null) {
            this.l = VelocityTracker.obtain();
        }
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            this.u = 0;
        }
        MotionEvent obtain = MotionEvent.obtain(motionEvent);
        float f = 0.0f;
        obtain.offsetLocation(0.0f, this.u);
        Ub ub = this.y;
        if (actionMasked != 0) {
            EdgeEffect edgeEffect = this.f;
            EdgeEffect edgeEffect2 = this.e;
            if (actionMasked != 1) {
                if (actionMasked != 2) {
                    if (actionMasked != 3) {
                        if (actionMasked != 5) {
                            if (actionMasked == 6) {
                                o(motionEvent);
                                this.g = (int) motionEvent.getY(motionEvent.findPointerIndex(this.r));
                            }
                        } else {
                            int actionIndex = motionEvent.getActionIndex();
                            this.g = (int) motionEvent.getY(actionIndex);
                            this.r = motionEvent.getPointerId(actionIndex);
                        }
                    } else {
                        if (this.k && getChildCount() > 0 && this.d.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange())) {
                            postInvalidateOnAnimation();
                        }
                        this.r = -1;
                        this.k = false;
                        VelocityTracker velocityTracker = this.l;
                        if (velocityTracker != null) {
                            velocityTracker.recycle();
                            this.l = null;
                        }
                        w(0);
                        this.e.onRelease();
                        this.f.onRelease();
                    }
                } else {
                    int findPointerIndex = motionEvent.findPointerIndex(this.r);
                    if (findPointerIndex == -1) {
                        Log.e("NestedScrollView", "Invalid pointerId=" + this.r + " in onTouchEvent");
                    } else {
                        int y = (int) motionEvent.getY(findPointerIndex);
                        int i = this.g - y;
                        float x2 = motionEvent.getX(findPointerIndex) / getWidth();
                        float height = i / getHeight();
                        if (E9.D(edgeEffect2) != 0.0f) {
                            float f2 = -E9.S(edgeEffect2, -height, x2);
                            if (E9.D(edgeEffect2) == 0.0f) {
                                edgeEffect2.onRelease();
                            }
                            f = f2;
                        } else if (E9.D(edgeEffect) != 0.0f) {
                            float S = E9.S(edgeEffect, height, 1.0f - x2);
                            if (E9.D(edgeEffect) == 0.0f) {
                                edgeEffect.onRelease();
                            }
                            f = S;
                        }
                        int round = Math.round(f * getHeight());
                        if (round != 0) {
                            invalidate();
                        }
                        int i2 = i - round;
                        if (!this.k && Math.abs(i2) > this.o) {
                            ViewParent parent2 = getParent();
                            if (parent2 != null) {
                                parent2.requestDisallowInterceptTouchEvent(true);
                            }
                            this.k = true;
                            i2 = i2 > 0 ? i2 - this.o : i2 + this.o;
                        }
                        if (this.k) {
                            int s = s(i2, (int) motionEvent.getX(findPointerIndex), 0, false);
                            this.g = y - s;
                            this.u += s;
                        }
                    }
                }
            } else {
                VelocityTracker velocityTracker2 = this.l;
                velocityTracker2.computeCurrentVelocity(1000, this.q);
                int yVelocity = (int) velocityTracker2.getYVelocity(this.r);
                if (Math.abs(yVelocity) >= this.p) {
                    if (E9.D(edgeEffect2) != 0.0f) {
                        if (t(edgeEffect2, yVelocity)) {
                            edgeEffect2.onAbsorb(yVelocity);
                        } else {
                            j(-yVelocity);
                        }
                    } else if (E9.D(edgeEffect) != 0.0f) {
                        int i3 = -yVelocity;
                        if (t(edgeEffect, i3)) {
                            edgeEffect.onAbsorb(i3);
                        } else {
                            j(i3);
                        }
                    } else {
                        int i4 = -yVelocity;
                        float f3 = i4;
                        if (!ub.b(0.0f, f3)) {
                            dispatchNestedFling(0.0f, f3, true);
                            j(i4);
                        }
                    }
                } else if (this.d.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange())) {
                    postInvalidateOnAnimation();
                }
                this.r = -1;
                this.k = false;
                VelocityTracker velocityTracker3 = this.l;
                if (velocityTracker3 != null) {
                    velocityTracker3.recycle();
                    this.l = null;
                }
                w(0);
                this.e.onRelease();
                this.f.onRelease();
            }
        } else {
            if (getChildCount() == 0) {
                return false;
            }
            if (this.k && (parent = getParent()) != null) {
                parent.requestDisallowInterceptTouchEvent(true);
            }
            if (!this.d.isFinished()) {
                this.d.abortAnimation();
                w(1);
            }
            int y2 = (int) motionEvent.getY();
            int pointerId = motionEvent.getPointerId(0);
            this.g = y2;
            this.r = pointerId;
            ub.g(2, 0);
        }
        VelocityTracker velocityTracker4 = this.l;
        if (velocityTracker4 != null) {
            velocityTracker4.addMovement(obtain);
        }
        obtain.recycle();
        return true;
    }

    public final boolean p(int i, int i2, int i3, int i4) {
        boolean z;
        boolean z2;
        getOverScrollMode();
        super.computeHorizontalScrollRange();
        super.computeHorizontalScrollExtent();
        computeVerticalScrollRange();
        super.computeVerticalScrollExtent();
        int i5 = i3 + i;
        if (i2 > 0 || i2 < 0) {
            i2 = 0;
            z = true;
        } else {
            z = false;
        }
        if (i5 <= i4) {
            if (i5 < 0) {
                i4 = 0;
            } else {
                i4 = i5;
                z2 = false;
                if (z2 && !this.y.f(1)) {
                    this.d.springBack(i2, i4, 0, 0, 0, getScrollRange());
                }
                super.scrollTo(i2, i4);
                if (z && !z2) {
                    return false;
                }
            }
        }
        z2 = true;
        if (z2) {
            this.d.springBack(i2, i4, 0, 0, 0, getScrollRange());
        }
        super.scrollTo(i2, i4);
        return z ? true : true;
    }

    public final void q(int i) {
        boolean z;
        if (i == 130) {
            z = true;
        } else {
            z = false;
        }
        int height = getHeight();
        Rect rect = this.c;
        if (z) {
            rect.top = getScrollY() + height;
            int childCount = getChildCount();
            if (childCount > 0) {
                View childAt = getChildAt(childCount - 1);
                int paddingBottom = getPaddingBottom() + childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin;
                if (rect.top + height > paddingBottom) {
                    rect.top = paddingBottom - height;
                }
            }
        } else {
            int scrollY = getScrollY() - height;
            rect.top = scrollY;
            if (scrollY < 0) {
                rect.top = 0;
            }
        }
        int i2 = rect.top;
        int i3 = height + i2;
        rect.bottom = i3;
        r(i, i2, i3);
    }

    public final boolean r(int i, int i2, int i3) {
        boolean z;
        int i4;
        boolean z2;
        boolean z3;
        boolean z4;
        int height = getHeight();
        int scrollY = getScrollY();
        int i5 = height + scrollY;
        if (i == 33) {
            z = true;
        } else {
            z = false;
        }
        ArrayList<View> focusables = getFocusables(2);
        int size = focusables.size();
        View view = null;
        boolean z5 = false;
        for (int i6 = 0; i6 < size; i6++) {
            View view2 = focusables.get(i6);
            int top = view2.getTop();
            int bottom = view2.getBottom();
            if (i2 < bottom && top < i3) {
                if (i2 < top && bottom < i3) {
                    z3 = true;
                } else {
                    z3 = false;
                }
                if (view == null) {
                    view = view2;
                    z5 = z3;
                } else {
                    if ((z && top < view.getTop()) || (!z && bottom > view.getBottom())) {
                        z4 = true;
                    } else {
                        z4 = false;
                    }
                    if (z5) {
                        if (z3) {
                            if (!z4) {
                            }
                            view = view2;
                        }
                    } else if (z3) {
                        view = view2;
                        z5 = true;
                    } else {
                        if (!z4) {
                        }
                        view = view2;
                    }
                }
            }
        }
        if (view == null) {
            view = this;
        }
        if (i2 >= scrollY && i3 <= i5) {
            z2 = false;
        } else {
            if (z) {
                i4 = i2 - scrollY;
            } else {
                i4 = i3 - i5;
            }
            s(i4, 0, 1, true);
            z2 = true;
        }
        if (view != findFocus()) {
            view.requestFocus(i);
        }
        return z2;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void requestChildFocus(View view, View view2) {
        if (!this.h) {
            Rect rect = this.c;
            view2.getDrawingRect(rect);
            offsetDescendantRectToMyCoords(view2, rect);
            int h = h(rect);
            if (h != 0) {
                scrollBy(0, h);
            }
        } else {
            this.j = view2;
        }
        super.requestChildFocus(view, view2);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean requestChildRectangleOnScreen(View view, Rect rect, boolean z) {
        boolean z2;
        rect.offset(view.getLeft() - view.getScrollX(), view.getTop() - view.getScrollY());
        int h = h(rect);
        if (h != 0) {
            z2 = true;
        } else {
            z2 = false;
        }
        if (z2) {
            if (z) {
                scrollBy(0, h);
            } else {
                u(0, h, false);
            }
        }
        return z2;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void requestDisallowInterceptTouchEvent(boolean z) {
        VelocityTracker velocityTracker;
        if (z && (velocityTracker = this.l) != null) {
            velocityTracker.recycle();
            this.l = null;
        }
        super.requestDisallowInterceptTouchEvent(z);
    }

    @Override // android.view.View, android.view.ViewParent
    public final void requestLayout() {
        this.h = true;
        super.requestLayout();
    }

    public final int s(int i, int i2, int i3, boolean z) {
        int i4;
        int i5;
        boolean z2;
        boolean z3;
        boolean z4;
        VelocityTracker velocityTracker;
        Ub ub = this.y;
        if (i3 == 1) {
            ub.g(2, i3);
        }
        boolean c = this.y.c(0, i, i3, this.t, this.s);
        int[] iArr = this.t;
        int[] iArr2 = this.s;
        if (c) {
            i4 = i - iArr[1];
            i5 = iArr2[1];
        } else {
            i4 = i;
            i5 = 0;
        }
        int scrollY = getScrollY();
        int scrollRange = getScrollRange();
        int overScrollMode = getOverScrollMode();
        if ((overScrollMode == 0 || (overScrollMode == 1 && getScrollRange() > 0)) && !z) {
            z2 = true;
        } else {
            z2 = false;
        }
        if (p(i4, 0, scrollY, scrollRange) && !ub.f(i3)) {
            z3 = true;
        } else {
            z3 = false;
        }
        int scrollY2 = getScrollY() - scrollY;
        iArr[1] = 0;
        this.y.d(0, scrollY2, 0, i4 - scrollY2, this.s, i3, iArr);
        int i6 = i5 + iArr2[1];
        int i7 = i4 - iArr[1];
        int i8 = scrollY + i7;
        EdgeEffect edgeEffect = this.f;
        EdgeEffect edgeEffect2 = this.e;
        if (i8 < 0) {
            if (z2) {
                E9.S(edgeEffect2, (-i7) / getHeight(), i2 / getWidth());
                if (!edgeEffect.isFinished()) {
                    edgeEffect.onRelease();
                }
            }
        } else if (i8 > scrollRange && z2) {
            E9.S(edgeEffect, i7 / getHeight(), 1.0f - (i2 / getWidth()));
            if (!edgeEffect2.isFinished()) {
                edgeEffect2.onRelease();
            }
        }
        if (edgeEffect2.isFinished() && edgeEffect.isFinished()) {
            z4 = z3;
        } else {
            postInvalidateOnAnimation();
            z4 = false;
        }
        if (z4 && i3 == 0 && (velocityTracker = this.l) != null) {
            velocityTracker.clear();
        }
        if (i3 == 1) {
            w(i3);
            edgeEffect2.onRelease();
            edgeEffect.onRelease();
        }
        return i6;
    }

    @Override // android.view.View
    public final void scrollTo(int i, int i2) {
        if (getChildCount() > 0) {
            View childAt = getChildAt(0);
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
            int width = (getWidth() - getPaddingLeft()) - getPaddingRight();
            int width2 = childAt.getWidth() + layoutParams.leftMargin + layoutParams.rightMargin;
            int height = (getHeight() - getPaddingTop()) - getPaddingBottom();
            int height2 = childAt.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
            if (width < width2 && i >= 0) {
                if (width + i > width2) {
                    i = width2 - width;
                }
            } else {
                i = 0;
            }
            if (height < height2 && i2 >= 0) {
                if (height + i2 > height2) {
                    i2 = height2 - height;
                }
            } else {
                i2 = 0;
            }
            if (i != getScrollX() || i2 != getScrollY()) {
                super.scrollTo(i, i2);
            }
        }
    }

    public void setFillViewport(boolean z) {
        if (z != this.m) {
            this.m = z;
            requestLayout();
        }
    }

    @Override // android.view.View
    public void setNestedScrollingEnabled(boolean z) {
        Ub ub = this.y;
        if (ub.d) {
            WeakHashMap weakHashMap = AbstractC0309ph.a;
            AbstractC0158hh.m(ub.c);
        }
        ub.d = z;
    }

    public void setOnScrollChangeListener(Sb sb) {
    }

    public void setSmoothScrollingEnabled(boolean z) {
        this.n = z;
    }

    @Override // android.widget.FrameLayout, android.view.ViewGroup
    public final boolean shouldDelayChildPressedState() {
        return true;
    }

    @Override // android.view.View
    public final boolean startNestedScroll(int i) {
        return this.y.g(i, 0);
    }

    @Override // android.view.View
    public final void stopNestedScroll() {
        w(0);
    }

    public final boolean t(EdgeEffect edgeEffect, int i) {
        if (i > 0) {
            return true;
        }
        float D2 = E9.D(edgeEffect) * getHeight();
        float abs = Math.abs(-i) * 0.35f;
        float f = this.a * 0.015f;
        double log = Math.log(abs / f);
        double d = B;
        if (((float) (Math.exp((d / (d - 1.0d)) * log) * f)) < D2) {
            return true;
        }
        return false;
    }

    public final void u(int i, int i2, boolean z) {
        if (getChildCount() == 0) {
            return;
        }
        if (AnimationUtils.currentAnimationTimeMillis() - this.b > 250) {
            View childAt = getChildAt(0);
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
            int height = childAt.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
            int height2 = (getHeight() - getPaddingTop()) - getPaddingBottom();
            int scrollY = getScrollY();
            this.d.startScroll(getScrollX(), scrollY, 0, Math.max(0, Math.min(i2 + scrollY, Math.max(0, height - height2))) - scrollY, 250);
            if (z) {
                this.y.g(2, 1);
            } else {
                w(1);
            }
            this.v = getScrollY();
            postInvalidateOnAnimation();
        } else {
            if (!this.d.isFinished()) {
                this.d.abortAnimation();
                w(1);
            }
            scrollBy(i, i2);
        }
        this.b = AnimationUtils.currentAnimationTimeMillis();
    }

    public final boolean v(MotionEvent motionEvent) {
        boolean z;
        EdgeEffect edgeEffect = this.e;
        if (E9.D(edgeEffect) != 0.0f) {
            E9.S(edgeEffect, 0.0f, motionEvent.getX() / getWidth());
            z = true;
        } else {
            z = false;
        }
        EdgeEffect edgeEffect2 = this.f;
        if (E9.D(edgeEffect2) != 0.0f) {
            E9.S(edgeEffect2, 0.0f, 1.0f - (motionEvent.getX() / getWidth()));
            return true;
        }
        return z;
    }

    public final void w(int i) {
        this.y.h(i);
    }

    @Override // android.view.ViewGroup
    public final void addView(View view, int i) {
        if (getChildCount() <= 0) {
            super.addView(view, i);
            return;
        }
        throw new IllegalStateException("ScrollView can host only one direct child");
    }

    @Override // android.view.ViewGroup, android.view.ViewManager
    public final void addView(View view, ViewGroup.LayoutParams layoutParams) {
        if (getChildCount() <= 0) {
            super.addView(view, layoutParams);
            return;
        }
        throw new IllegalStateException("ScrollView can host only one direct child");
    }

    @Override // android.view.ViewGroup
    public final void addView(View view, int i, ViewGroup.LayoutParams layoutParams) {
        if (getChildCount() <= 0) {
            super.addView(view, i, layoutParams);
            return;
        }
        throw new IllegalStateException("ScrollView can host only one direct child");
    }
}
