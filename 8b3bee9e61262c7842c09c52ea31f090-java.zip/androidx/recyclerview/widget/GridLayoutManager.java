package androidx.recyclerview.widget;

import android.content.Context;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseIntArray;
import android.view.View;
import android.view.ViewGroup;
import java.util.Arrays;
import java.util.WeakHashMap;
import x.AbstractC0309ph;
import x.AbstractC0475yd;
import x.B;
import x.C;
import x.C0071da;
import x.C0091ea;
import x.C0111fa;
import x.C0130g9;
import x.C0225l9;
import x.C0494zd;
import x.Ed;
import x.F1;
import x.Jd;
import x.Ue;

/* loaded from: classes.dex */
public class GridLayoutManager extends LinearLayoutManager {
    public boolean E;
    public int F;
    public int[] G;
    public View[] H;
    public final SparseIntArray I;
    public final SparseIntArray J;
    public final F1 K;
    public final Rect L;

    public GridLayoutManager(Context context, AttributeSet attributeSet, int i, int i2) {
        super(context, attributeSet, i, i2);
        this.E = false;
        this.F = -1;
        this.I = new SparseIntArray();
        this.J = new SparseIntArray();
        this.K = new F1(13);
        this.L = new Rect();
        l1(AbstractC0475yd.I(context, attributeSet, i, i2).b);
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager
    public final void B0(Jd jd, C0111fa c0111fa, C0130g9 c0130g9) {
        int i;
        int i2 = this.F;
        for (int i3 = 0; i3 < this.F && (i = c0111fa.d) >= 0 && i < jd.b() && i2 > 0; i3++) {
            c0130g9.a(c0111fa.d, Math.max(0, c0111fa.g));
            this.K.getClass();
            i2--;
            c0111fa.d += c0111fa.e;
        }
    }

    @Override // x.AbstractC0475yd
    public final int J(Ed ed, Jd jd) {
        if (this.p == 0) {
            return this.F;
        }
        if (jd.b() < 1) {
            return 0;
        }
        return h1(jd.b() - 1, ed, jd) + 1;
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager
    public final View N0(Ed ed, Jd jd, int i, int i2, int i3) {
        int i4;
        G0();
        int k = this.r.k();
        int g = this.r.g();
        if (i2 > i) {
            i4 = 1;
        } else {
            i4 = -1;
        }
        View view = null;
        View view2 = null;
        while (i != i2) {
            View u = u(i);
            int H = AbstractC0475yd.H(u);
            if (H >= 0 && H < i3 && i1(H, ed, jd) == 0) {
                if (((C0494zd) u.getLayoutParams()).a.i()) {
                    if (view2 == null) {
                        view2 = u;
                    }
                } else {
                    if (this.r.e(u) < g && this.r.b(u) >= k) {
                        return u;
                    }
                    if (view == null) {
                        view = u;
                    }
                }
            }
            i += i4;
        }
        if (view == null) {
            return view2;
        }
        return view;
    }

    /* JADX WARN: Code restructure failed: missing block: B:67:0x00e1, code lost:
    
        if (r13 == r5) goto L55;
     */
    /* JADX WARN: Code restructure failed: missing block: B:78:0x0103, code lost:
    
        if (r13 == r5) goto L79;
     */
    /* JADX WARN: Code restructure failed: missing block: B:88:0x0022, code lost:
    
        if (((java.util.ArrayList) r22.a.d).contains(r3) != false) goto L5;
     */
    /* JADX WARN: Removed duplicated region for block: B:54:0x010b  */
    /* JADX WARN: Removed duplicated region for block: B:56:0x011c  */
    @Override // androidx.recyclerview.widget.LinearLayoutManager, x.AbstractC0475yd
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final View S(View view, int i, Ed ed, Jd jd) {
        View A;
        boolean z;
        int v;
        int i2;
        int i3;
        boolean z2;
        View view2;
        View view3;
        int i4;
        boolean z3;
        boolean z4;
        Ed ed2 = ed;
        Jd jd2 = jd;
        RecyclerView recyclerView = this.b;
        View view4 = null;
        if (recyclerView != null) {
            A = recyclerView.A(view);
            if (A != null) {
            }
        }
        A = null;
        if (A == null) {
            return null;
        }
        C0225l9 c0225l9 = (C0225l9) A.getLayoutParams();
        int i5 = c0225l9.e;
        int i6 = c0225l9.f + i5;
        if (super.S(view, i, ed, jd) == null) {
            return null;
        }
        if (F0(i) == 1) {
            z = true;
        } else {
            z = false;
        }
        if (z != this.u) {
            i3 = v() - 1;
            v = -1;
            i2 = -1;
        } else {
            v = v();
            i2 = 1;
            i3 = 0;
        }
        if (this.p == 1 && S0()) {
            z2 = true;
        } else {
            z2 = false;
        }
        int h1 = h1(i3, ed2, jd2);
        int i7 = -1;
        int i8 = -1;
        int i9 = i2;
        int i10 = 0;
        int i11 = 0;
        int i12 = i3;
        View view5 = null;
        while (i12 != v) {
            int i13 = v;
            int h12 = h1(i12, ed2, jd2);
            View u = u(i12);
            if (u == A) {
                break;
            }
            if (u.hasFocusable() && h12 != h1) {
                if (view4 != null) {
                    break;
                }
                view2 = A;
                view3 = view5;
            } else {
                C0225l9 c0225l92 = (C0225l9) u.getLayoutParams();
                int i14 = c0225l92.e;
                view2 = A;
                int i15 = c0225l92.f + i14;
                if (u.hasFocusable() && i14 == i5 && i15 == i6) {
                    return u;
                }
                if ((u.hasFocusable() && view4 == null) || (!u.hasFocusable() && view5 == null)) {
                    view3 = view5;
                } else {
                    view3 = view5;
                    int min = Math.min(i15, i6) - Math.max(i14, i5);
                    if (u.hasFocusable()) {
                        if (min <= i10) {
                            if (min == i10) {
                                if (i14 > i8) {
                                    z4 = true;
                                } else {
                                    z4 = false;
                                }
                            }
                        }
                    } else if (view4 == null) {
                        i4 = i10;
                        if (!this.c.A(u) || !this.d.A(u)) {
                            if (min <= i11) {
                                if (min == i11) {
                                    if (i14 > i7) {
                                        z3 = true;
                                    } else {
                                        z3 = false;
                                    }
                                }
                            }
                            if (!u.hasFocusable()) {
                                int i16 = c0225l92.e;
                                i10 = Math.min(i15, i6) - Math.max(i14, i5);
                                i8 = i16;
                                view5 = view3;
                                view4 = u;
                            } else {
                                int i17 = c0225l92.e;
                                i11 = Math.min(i15, i6) - Math.max(i14, i5);
                                i7 = i17;
                                i10 = i4;
                                view5 = u;
                            }
                            i12 += i9;
                            ed2 = ed;
                            jd2 = jd;
                            v = i13;
                            A = view2;
                        }
                        i10 = i4;
                        view5 = view3;
                        i12 += i9;
                        ed2 = ed;
                        jd2 = jd;
                        v = i13;
                        A = view2;
                    }
                }
                i4 = i10;
                if (!u.hasFocusable()) {
                }
                i12 += i9;
                ed2 = ed;
                jd2 = jd;
                v = i13;
                A = view2;
            }
            i4 = i10;
            i10 = i4;
            view5 = view3;
            i12 += i9;
            ed2 = ed;
            jd2 = jd;
            v = i13;
            A = view2;
        }
        View view6 = view5;
        if (view4 == null) {
            return view6;
        }
        return view4;
    }

    /* JADX WARN: Code restructure failed: missing block: B:32:0x009f, code lost:
    
        r22.b = true;
     */
    /* JADX WARN: Code restructure failed: missing block: B:33:0x00a1, code lost:
    
        return;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r8v23 */
    /* JADX WARN: Type inference failed for: r8v24, types: [boolean, int] */
    /* JADX WARN: Type inference failed for: r8v32 */
    /* JADX WARN: Type inference failed for: r8v33 */
    /* JADX WARN: Type inference failed for: r8v38 */
    @Override // androidx.recyclerview.widget.LinearLayoutManager
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void T0(Ed ed, Jd jd, C0111fa c0111fa, C0091ea c0091ea) {
        boolean z;
        int i;
        boolean z2;
        int i2;
        int i3;
        int i4;
        int i5;
        int i6;
        int i7;
        int i8;
        int w;
        int i9;
        ?? r8;
        int i10;
        View b;
        int j = this.r.j();
        if (j != 1073741824) {
            z = true;
        } else {
            z = false;
        }
        if (v() > 0) {
            i = this.G[this.F];
        } else {
            i = 0;
        }
        if (z) {
            m1();
        }
        if (c0111fa.e == 1) {
            z2 = true;
        } else {
            z2 = false;
        }
        int i11 = this.F;
        if (!z2) {
            i11 = i1(c0111fa.d, ed, jd) + j1(c0111fa.d, ed, jd);
        }
        int i12 = 0;
        while (i12 < this.F && (i10 = c0111fa.d) >= 0 && i10 < jd.b() && i11 > 0) {
            int i13 = c0111fa.d;
            int j1 = j1(i13, ed, jd);
            if (j1 <= this.F) {
                i11 -= j1;
                if (i11 < 0 || (b = c0111fa.b(ed)) == null) {
                    break;
                }
                this.H[i12] = b;
                i12++;
            } else {
                throw new IllegalArgumentException("Item at position " + i13 + " requires " + j1 + " spans but GridLayoutManager has only " + this.F + " spans.");
            }
        }
        if (z2) {
            i4 = 1;
            i3 = i12;
            i2 = 0;
        } else {
            i2 = i12 - 1;
            i3 = -1;
            i4 = -1;
        }
        int i14 = 0;
        while (i2 != i3) {
            View view = this.H[i2];
            C0225l9 c0225l9 = (C0225l9) view.getLayoutParams();
            int j12 = j1(AbstractC0475yd.H(view), ed, jd);
            c0225l9.f = j12;
            c0225l9.e = i14;
            i14 += j12;
            i2 += i4;
        }
        float f = 0.0f;
        int i15 = 0;
        for (int i16 = 0; i16 < i12; i16++) {
            View view2 = this.H[i16];
            if (c0111fa.k == null) {
                if (z2) {
                    r8 = 0;
                    b(view2, -1, false);
                } else {
                    r8 = 0;
                    b(view2, 0, false);
                }
            } else {
                r8 = 0;
                r8 = 0;
                if (z2) {
                    b(view2, -1, true);
                } else {
                    b(view2, 0, true);
                }
            }
            RecyclerView recyclerView = this.b;
            Rect rect = this.L;
            if (recyclerView == null) {
                rect.set(r8, r8, r8, r8);
            } else {
                rect.set(recyclerView.J(view2));
            }
            k1(view2, j, r8);
            int c = this.r.c(view2);
            if (c > i15) {
                i15 = c;
            }
            float d = (this.r.d(view2) * 1.0f) / ((C0225l9) view2.getLayoutParams()).f;
            if (d > f) {
                f = d;
            }
        }
        if (z) {
            e1(Math.max(Math.round(f * this.F), i));
            i15 = 0;
            for (int i17 = 0; i17 < i12; i17++) {
                View view3 = this.H[i17];
                k1(view3, 1073741824, true);
                int c2 = this.r.c(view3);
                if (c2 > i15) {
                    i15 = c2;
                }
            }
        }
        for (int i18 = 0; i18 < i12; i18++) {
            View view4 = this.H[i18];
            if (this.r.c(view4) != i15) {
                C0225l9 c0225l92 = (C0225l9) view4.getLayoutParams();
                Rect rect2 = c0225l92.b;
                int i19 = rect2.top + rect2.bottom + ((ViewGroup.MarginLayoutParams) c0225l92).topMargin + ((ViewGroup.MarginLayoutParams) c0225l92).bottomMargin;
                int i20 = rect2.left + rect2.right + ((ViewGroup.MarginLayoutParams) c0225l92).leftMargin + ((ViewGroup.MarginLayoutParams) c0225l92).rightMargin;
                int g1 = g1(c0225l92.e, c0225l92.f);
                if (this.p == 1) {
                    i9 = AbstractC0475yd.w(false, g1, 1073741824, i20, ((ViewGroup.MarginLayoutParams) c0225l92).width);
                    w = View.MeasureSpec.makeMeasureSpec(i15 - i19, 1073741824);
                } else {
                    int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(i15 - i20, 1073741824);
                    w = AbstractC0475yd.w(false, g1, 1073741824, i19, ((ViewGroup.MarginLayoutParams) c0225l92).height);
                    i9 = makeMeasureSpec;
                }
                if (w0(view4, i9, w, (C0494zd) view4.getLayoutParams())) {
                    view4.measure(i9, w);
                }
            }
        }
        c0091ea.a = i15;
        if (this.p == 1) {
            if (c0111fa.f == -1) {
                int i21 = c0111fa.b;
                i6 = 0;
                i5 = 0;
                i8 = i21 - i15;
                i7 = i21;
            } else {
                i8 = c0111fa.b;
                i7 = i8 + i15;
                i6 = 0;
                i5 = 0;
            }
        } else {
            if (c0111fa.f == -1) {
                int i22 = c0111fa.b;
                i6 = i22 - i15;
                i5 = i22;
            } else {
                int i23 = c0111fa.b;
                i5 = i23 + i15;
                i6 = i23;
            }
            i7 = 0;
            i8 = 0;
        }
        for (int i24 = 0; i24 < i12; i24++) {
            View view5 = this.H[i24];
            C0225l9 c0225l93 = (C0225l9) view5.getLayoutParams();
            if (this.p == 1) {
                if (S0()) {
                    int E = E() + this.G[this.F - c0225l93.e];
                    i5 = E;
                    i6 = E - this.r.d(view5);
                } else {
                    i6 = E() + this.G[c0225l93.e];
                    i5 = this.r.d(view5) + i6;
                }
            } else {
                int G = G() + this.G[c0225l93.e];
                i8 = G;
                i7 = this.r.d(view5) + G;
            }
            AbstractC0475yd.N(view5, i6, i8, i5, i7);
            if (c0225l93.a.i() || c0225l93.a.l()) {
                c0091ea.c = true;
            }
            c0091ea.d = view5.hasFocusable() | c0091ea.d;
        }
        Arrays.fill(this.H, (Object) null);
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager
    public final void U0(Ed ed, Jd jd, C0071da c0071da, int i) {
        boolean z;
        m1();
        if (jd.b() > 0 && !jd.g) {
            if (i == 1) {
                z = true;
            } else {
                z = false;
            }
            int i1 = i1(c0071da.b, ed, jd);
            if (z) {
                while (i1 > 0) {
                    int i2 = c0071da.b;
                    if (i2 <= 0) {
                        break;
                    }
                    int i3 = i2 - 1;
                    c0071da.b = i3;
                    i1 = i1(i3, ed, jd);
                }
            } else {
                int b = jd.b() - 1;
                int i4 = c0071da.b;
                while (i4 < b) {
                    int i5 = i4 + 1;
                    int i12 = i1(i5, ed, jd);
                    if (i12 <= i1) {
                        break;
                    }
                    i4 = i5;
                    i1 = i12;
                }
                c0071da.b = i4;
            }
        }
        f1();
    }

    @Override // x.AbstractC0475yd
    public final void V(Ed ed, Jd jd, View view, C c) {
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        if (!(layoutParams instanceof C0225l9)) {
            U(view, c);
            return;
        }
        C0225l9 c0225l9 = (C0225l9) layoutParams;
        int h1 = h1(c0225l9.a.b(), ed, jd);
        if (this.p == 0) {
            c.i(B.D(false, c0225l9.e, c0225l9.f, h1, 1));
        } else {
            c.i(B.D(false, h1, 1, c0225l9.e, c0225l9.f));
        }
    }

    @Override // x.AbstractC0475yd
    public final void W(int i, int i2) {
        F1 f1 = this.K;
        f1.z();
        ((SparseIntArray) f1.c).clear();
    }

    @Override // x.AbstractC0475yd
    public final void X() {
        F1 f1 = this.K;
        f1.z();
        ((SparseIntArray) f1.c).clear();
    }

    @Override // x.AbstractC0475yd
    public final void Y(int i, int i2) {
        F1 f1 = this.K;
        f1.z();
        ((SparseIntArray) f1.c).clear();
    }

    @Override // x.AbstractC0475yd
    public final void Z(int i, int i2) {
        F1 f1 = this.K;
        f1.z();
        ((SparseIntArray) f1.c).clear();
    }

    @Override // x.AbstractC0475yd
    public final void a0(int i, int i2) {
        F1 f1 = this.K;
        f1.z();
        ((SparseIntArray) f1.c).clear();
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager
    public final void a1(boolean z) {
        if (!z) {
            super.a1(false);
            return;
        }
        throw new UnsupportedOperationException("GridLayoutManager does not support stack from end. Consider using reverse layout");
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, x.AbstractC0475yd
    public final void b0(Ed ed, Jd jd) {
        boolean z = jd.g;
        SparseIntArray sparseIntArray = this.J;
        SparseIntArray sparseIntArray2 = this.I;
        if (z) {
            int v = v();
            for (int i = 0; i < v; i++) {
                C0225l9 c0225l9 = (C0225l9) u(i).getLayoutParams();
                int b = c0225l9.a.b();
                sparseIntArray2.put(b, c0225l9.f);
                sparseIntArray.put(b, c0225l9.e);
            }
        }
        super.b0(ed, jd);
        sparseIntArray2.clear();
        sparseIntArray.clear();
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, x.AbstractC0475yd
    public final void c0(Jd jd) {
        super.c0(jd);
        this.E = false;
    }

    public final void e1(int i) {
        int i2;
        int[] iArr = this.G;
        int i3 = this.F;
        if (iArr == null || iArr.length != i3 + 1 || iArr[iArr.length - 1] != i) {
            iArr = new int[i3 + 1];
        }
        int i4 = 0;
        iArr[0] = 0;
        int i5 = i / i3;
        int i6 = i % i3;
        int i7 = 0;
        for (int i8 = 1; i8 <= i3; i8++) {
            i4 += i6;
            if (i4 > 0 && i3 - i4 < i6) {
                i2 = i5 + 1;
                i4 -= i3;
            } else {
                i2 = i5;
            }
            i7 += i2;
            iArr[i8] = i7;
        }
        this.G = iArr;
    }

    @Override // x.AbstractC0475yd
    public final boolean f(C0494zd c0494zd) {
        return c0494zd instanceof C0225l9;
    }

    public final void f1() {
        View[] viewArr = this.H;
        if (viewArr == null || viewArr.length != this.F) {
            this.H = new View[this.F];
        }
    }

    public final int g1(int i, int i2) {
        if (this.p == 1 && S0()) {
            int[] iArr = this.G;
            int i3 = this.F;
            return iArr[i3 - i] - iArr[(i3 - i) - i2];
        }
        int[] iArr2 = this.G;
        return iArr2[i2 + i] - iArr2[i];
    }

    public final int h1(int i, Ed ed, Jd jd) {
        boolean z = jd.g;
        F1 f1 = this.K;
        if (!z) {
            int i2 = this.F;
            f1.getClass();
            return F1.y(i, i2);
        }
        int b = ed.b(i);
        if (b == -1) {
            Log.w("GridLayoutManager", "Cannot find span size for pre layout position. " + i);
            return 0;
        }
        int i3 = this.F;
        f1.getClass();
        return F1.y(b, i3);
    }

    public final int i1(int i, Ed ed, Jd jd) {
        boolean z = jd.g;
        F1 f1 = this.K;
        if (!z) {
            int i2 = this.F;
            f1.getClass();
            return i % i2;
        }
        int i3 = this.J.get(i, -1);
        if (i3 != -1) {
            return i3;
        }
        int b = ed.b(i);
        if (b == -1) {
            Log.w("GridLayoutManager", "Cannot find span size for pre layout position. It is not cached, not in the adapter. Pos:" + i);
            return 0;
        }
        int i4 = this.F;
        f1.getClass();
        return b % i4;
    }

    public final int j1(int i, Ed ed, Jd jd) {
        boolean z = jd.g;
        F1 f1 = this.K;
        if (!z) {
            f1.getClass();
            return 1;
        }
        int i2 = this.I.get(i, -1);
        if (i2 != -1) {
            return i2;
        }
        if (ed.b(i) == -1) {
            Log.w("GridLayoutManager", "Cannot find span size for pre layout position. It is not cached, not in the adapter. Pos:" + i);
            return 1;
        }
        f1.getClass();
        return 1;
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, x.AbstractC0475yd
    public final int k(Jd jd) {
        return D0(jd);
    }

    public final void k1(View view, int i, boolean z) {
        int i2;
        int i3;
        boolean u0;
        C0225l9 c0225l9 = (C0225l9) view.getLayoutParams();
        Rect rect = c0225l9.b;
        int i4 = rect.top + rect.bottom + ((ViewGroup.MarginLayoutParams) c0225l9).topMargin + ((ViewGroup.MarginLayoutParams) c0225l9).bottomMargin;
        int i5 = rect.left + rect.right + ((ViewGroup.MarginLayoutParams) c0225l9).leftMargin + ((ViewGroup.MarginLayoutParams) c0225l9).rightMargin;
        int g1 = g1(c0225l9.e, c0225l9.f);
        if (this.p == 1) {
            i3 = AbstractC0475yd.w(false, g1, i, i5, ((ViewGroup.MarginLayoutParams) c0225l9).width);
            i2 = AbstractC0475yd.w(true, this.r.l(), this.m, i4, ((ViewGroup.MarginLayoutParams) c0225l9).height);
        } else {
            int w = AbstractC0475yd.w(false, g1, i, i4, ((ViewGroup.MarginLayoutParams) c0225l9).height);
            int w2 = AbstractC0475yd.w(true, this.r.l(), this.l, i5, ((ViewGroup.MarginLayoutParams) c0225l9).width);
            i2 = w;
            i3 = w2;
        }
        C0494zd c0494zd = (C0494zd) view.getLayoutParams();
        if (z) {
            u0 = w0(view, i3, i2, c0494zd);
        } else {
            u0 = u0(view, i3, i2, c0494zd);
        }
        if (u0) {
            view.measure(i3, i2);
        }
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, x.AbstractC0475yd
    public final int l(Jd jd) {
        return E0(jd);
    }

    public final void l1(int i) {
        if (i == this.F) {
            return;
        }
        this.E = true;
        if (i >= 1) {
            this.F = i;
            this.K.z();
            l0();
            return;
        }
        throw new IllegalArgumentException(Ue.d("Span count should be at least 1. Provided ", i));
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, x.AbstractC0475yd
    public final int m0(int i, Ed ed, Jd jd) {
        m1();
        f1();
        return super.m0(i, ed, jd);
    }

    public final void m1() {
        int D;
        int G;
        if (this.p == 1) {
            D = this.n - F();
            G = E();
        } else {
            D = this.o - D();
            G = G();
        }
        e1(D - G);
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, x.AbstractC0475yd
    public final int n(Jd jd) {
        return D0(jd);
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, x.AbstractC0475yd
    public final int o(Jd jd) {
        return E0(jd);
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, x.AbstractC0475yd
    public final int o0(int i, Ed ed, Jd jd) {
        m1();
        f1();
        return super.o0(i, ed, jd);
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, x.AbstractC0475yd
    public final C0494zd r() {
        if (this.p == 0) {
            return new C0225l9(-2, -1);
        }
        return new C0225l9(-1, -2);
    }

    @Override // x.AbstractC0475yd
    public final void r0(Rect rect, int i, int i2) {
        int g;
        int g2;
        if (this.G == null) {
            super.r0(rect, i, i2);
        }
        int F = F() + E();
        int D = D() + G();
        if (this.p == 1) {
            int height = rect.height() + D;
            RecyclerView recyclerView = this.b;
            WeakHashMap weakHashMap = AbstractC0309ph.a;
            g2 = AbstractC0475yd.g(i2, height, recyclerView.getMinimumHeight());
            int[] iArr = this.G;
            g = AbstractC0475yd.g(i, iArr[iArr.length - 1] + F, this.b.getMinimumWidth());
        } else {
            int width = rect.width() + F;
            RecyclerView recyclerView2 = this.b;
            WeakHashMap weakHashMap2 = AbstractC0309ph.a;
            g = AbstractC0475yd.g(i, width, recyclerView2.getMinimumWidth());
            int[] iArr2 = this.G;
            g2 = AbstractC0475yd.g(i2, iArr2[iArr2.length - 1] + D, this.b.getMinimumHeight());
        }
        this.b.setMeasuredDimension(g, g2);
    }

    /* JADX WARN: Type inference failed for: r0v0, types: [x.l9, x.zd] */
    @Override // x.AbstractC0475yd
    public final C0494zd s(Context context, AttributeSet attributeSet) {
        ?? c0494zd = new C0494zd(context, attributeSet);
        c0494zd.e = -1;
        c0494zd.f = 0;
        return c0494zd;
    }

    /* JADX WARN: Type inference failed for: r0v1, types: [x.l9, x.zd] */
    /* JADX WARN: Type inference failed for: r0v2, types: [x.l9, x.zd] */
    @Override // x.AbstractC0475yd
    public final C0494zd t(ViewGroup.LayoutParams layoutParams) {
        if (layoutParams instanceof ViewGroup.MarginLayoutParams) {
            ?? c0494zd = new C0494zd((ViewGroup.MarginLayoutParams) layoutParams);
            c0494zd.e = -1;
            c0494zd.f = 0;
            return c0494zd;
        }
        ?? c0494zd2 = new C0494zd(layoutParams);
        c0494zd2.e = -1;
        c0494zd2.f = 0;
        return c0494zd2;
    }

    @Override // x.AbstractC0475yd
    public final int x(Ed ed, Jd jd) {
        if (this.p == 1) {
            return this.F;
        }
        if (jd.b() < 1) {
            return 0;
        }
        return h1(jd.b() - 1, ed, jd) + 1;
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, x.AbstractC0475yd
    public final boolean z0() {
        if (this.z == null && !this.E) {
            return true;
        }
        return false;
    }

    public GridLayoutManager(int i) {
        super(1);
        this.E = false;
        this.F = -1;
        this.I = new SparseIntArray();
        this.J = new SparseIntArray();
        this.K = new F1(13);
        this.L = new Rect();
        l1(i);
    }
}
