package androidx.recyclerview.widget;

import android.content.Context;
import android.graphics.PointF;
import android.graphics.Rect;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import java.util.ArrayList;
import java.util.List;
import x.AbstractC0112fb;
import x.AbstractC0203k6;
import x.AbstractC0475yd;
import x.C0071da;
import x.C0091ea;
import x.C0111fa;
import x.C0130g9;
import x.C0131ga;
import x.C0151ha;
import x.C0456xd;
import x.C0494zd;
import x.Ed;
import x.Id;
import x.Jd;
import x.Md;
import x.Ue;

/* loaded from: classes.dex */
public class LinearLayoutManager extends AbstractC0475yd implements Id {
    public final C0071da A;
    public final C0091ea B;
    public final int C;
    public final int[] D;
    public int p;
    public C0111fa q;
    public AbstractC0203k6 r;
    public boolean s;
    public final boolean t;
    public boolean u;
    public boolean v;
    public final boolean w;

    /* renamed from: x, reason: collision with root package name */
    public int f6x;
    public int y;
    public C0131ga z;

    /* JADX WARN: Type inference failed for: r2v1, types: [x.ea, java.lang.Object] */
    public LinearLayoutManager(int i) {
        this.p = 1;
        this.t = false;
        this.u = false;
        this.v = false;
        this.w = true;
        this.f6x = -1;
        this.y = Integer.MIN_VALUE;
        this.z = null;
        this.A = new C0071da();
        this.B = new Object();
        this.C = 2;
        this.D = new int[2];
        Z0(i);
        c(null);
        if (this.t) {
            this.t = false;
            l0();
        }
    }

    public void A0(Jd jd, int[] iArr) {
        int i;
        int i2;
        if (jd.a != -1) {
            i = this.r.l();
        } else {
            i = 0;
        }
        if (this.q.f == -1) {
            i2 = 0;
        } else {
            i2 = i;
            i = 0;
        }
        iArr[0] = i;
        iArr[1] = i2;
    }

    public void B0(Jd jd, C0111fa c0111fa, C0130g9 c0130g9) {
        int i = c0111fa.d;
        if (i >= 0 && i < jd.b()) {
            c0130g9.a(i, Math.max(0, c0111fa.g));
        }
    }

    public final int C0(Jd jd) {
        if (v() == 0) {
            return 0;
        }
        G0();
        AbstractC0203k6 abstractC0203k6 = this.r;
        boolean z = !this.w;
        return AbstractC0112fb.e(jd, abstractC0203k6, J0(z), I0(z), this, this.w);
    }

    public final int D0(Jd jd) {
        if (v() == 0) {
            return 0;
        }
        G0();
        AbstractC0203k6 abstractC0203k6 = this.r;
        boolean z = !this.w;
        return AbstractC0112fb.f(jd, abstractC0203k6, J0(z), I0(z), this, this.w, this.u);
    }

    public final int E0(Jd jd) {
        if (v() == 0) {
            return 0;
        }
        G0();
        AbstractC0203k6 abstractC0203k6 = this.r;
        boolean z = !this.w;
        return AbstractC0112fb.g(jd, abstractC0203k6, J0(z), I0(z), this, this.w);
    }

    public final int F0(int i) {
        if (i != 1) {
            if (i != 2) {
                if (i != 17) {
                    if (i != 33) {
                        if (i != 66) {
                            if (i == 130 && this.p == 1) {
                                return 1;
                            }
                            return Integer.MIN_VALUE;
                        }
                        if (this.p == 0) {
                            return 1;
                        }
                        return Integer.MIN_VALUE;
                    }
                    if (this.p == 1) {
                        return -1;
                    }
                    return Integer.MIN_VALUE;
                }
                if (this.p == 0) {
                    return -1;
                }
                return Integer.MIN_VALUE;
            }
            if (this.p != 1 && S0()) {
                return -1;
            }
            return 1;
        }
        if (this.p == 1 || !S0()) {
            return -1;
        }
        return 1;
    }

    /* JADX WARN: Type inference failed for: r0v1, types: [x.fa, java.lang.Object] */
    public final void G0() {
        if (this.q == null) {
            ?? obj = new Object();
            obj.a = true;
            obj.h = 0;
            obj.i = 0;
            obj.k = null;
            this.q = obj;
        }
    }

    public final int H0(Ed ed, C0111fa c0111fa, Jd jd, boolean z) {
        int i;
        int i2 = c0111fa.c;
        int i3 = c0111fa.g;
        if (i3 != Integer.MIN_VALUE) {
            if (i2 < 0) {
                c0111fa.g = i3 + i2;
            }
            V0(ed, c0111fa);
        }
        int i4 = c0111fa.c + c0111fa.h;
        while (true) {
            if ((!c0111fa.l && i4 <= 0) || (i = c0111fa.d) < 0 || i >= jd.b()) {
                break;
            }
            C0091ea c0091ea = this.B;
            c0091ea.a = 0;
            c0091ea.b = false;
            c0091ea.c = false;
            c0091ea.d = false;
            T0(ed, jd, c0111fa, c0091ea);
            if (!c0091ea.b) {
                int i5 = c0111fa.b;
                int i6 = c0091ea.a;
                c0111fa.b = (c0111fa.f * i6) + i5;
                if (!c0091ea.c || c0111fa.k != null || !jd.g) {
                    c0111fa.c -= i6;
                    i4 -= i6;
                }
                int i7 = c0111fa.g;
                if (i7 != Integer.MIN_VALUE) {
                    int i8 = i7 + i6;
                    c0111fa.g = i8;
                    int i9 = c0111fa.c;
                    if (i9 < 0) {
                        c0111fa.g = i8 + i9;
                    }
                    V0(ed, c0111fa);
                }
                if (z && c0091ea.d) {
                    break;
                }
            } else {
                break;
            }
        }
        return i2 - c0111fa.c;
    }

    public final View I0(boolean z) {
        if (this.u) {
            return M0(0, v(), z);
        }
        return M0(v() - 1, -1, z);
    }

    public final View J0(boolean z) {
        if (this.u) {
            return M0(v() - 1, -1, z);
        }
        return M0(0, v(), z);
    }

    public final int K0() {
        View M0 = M0(v() - 1, -1, false);
        if (M0 == null) {
            return -1;
        }
        return AbstractC0475yd.H(M0);
    }

    @Override // x.AbstractC0475yd
    public final boolean L() {
        return true;
    }

    public final View L0(int i, int i2) {
        int i3;
        int i4;
        G0();
        if (i2 > i || i2 < i) {
            if (this.r.e(u(i)) < this.r.k()) {
                i3 = 16644;
                i4 = 16388;
            } else {
                i3 = 4161;
                i4 = 4097;
            }
            if (this.p == 0) {
                return this.c.v(i, i2, i3, i4);
            }
            return this.d.v(i, i2, i3, i4);
        }
        return u(i);
    }

    public final View M0(int i, int i2, boolean z) {
        int i3;
        G0();
        if (z) {
            i3 = 24579;
        } else {
            i3 = 320;
        }
        if (this.p == 0) {
            return this.c.v(i, i2, i3, 320);
        }
        return this.d.v(i, i2, i3, 320);
    }

    public View N0(Ed ed, Jd jd, int i, int i2, int i3) {
        int i4;
        G0();
        int k = this.r.k();
        int g = this.r.g();
        if (i2 > i) {
            i4 = 1;
        } else {
            i4 = -1;
        }
        View view = null;
        View view2 = null;
        while (i != i2) {
            View u = u(i);
            int H = AbstractC0475yd.H(u);
            if (H >= 0 && H < i3) {
                if (((C0494zd) u.getLayoutParams()).a.i()) {
                    if (view2 == null) {
                        view2 = u;
                    }
                } else {
                    if (this.r.e(u) < g && this.r.b(u) >= k) {
                        return u;
                    }
                    if (view == null) {
                        view = u;
                    }
                }
            }
            i += i4;
        }
        if (view == null) {
            return view2;
        }
        return view;
    }

    public final int O0(int i, Ed ed, Jd jd, boolean z) {
        int g;
        int g2 = this.r.g() - i;
        if (g2 > 0) {
            int i2 = -Y0(-g2, ed, jd);
            int i3 = i + i2;
            if (z && (g = this.r.g() - i3) > 0) {
                this.r.p(g);
                return g + i2;
            }
            return i2;
        }
        return 0;
    }

    public final int P0(int i, Ed ed, Jd jd, boolean z) {
        int k;
        int k2 = i - this.r.k();
        if (k2 > 0) {
            int i2 = -Y0(k2, ed, jd);
            int i3 = i + i2;
            if (z && (k = i3 - this.r.k()) > 0) {
                this.r.p(-k);
                return i2 - k;
            }
            return i2;
        }
        return 0;
    }

    public final View Q0() {
        int v;
        if (this.u) {
            v = 0;
        } else {
            v = v() - 1;
        }
        return u(v);
    }

    @Override // x.AbstractC0475yd
    public final void R(RecyclerView recyclerView) {
    }

    public final View R0() {
        int i;
        if (this.u) {
            i = v() - 1;
        } else {
            i = 0;
        }
        return u(i);
    }

    @Override // x.AbstractC0475yd
    public View S(View view, int i, Ed ed, Jd jd) {
        int F0;
        View L0;
        View Q0;
        X0();
        if (v() == 0 || (F0 = F0(i)) == Integer.MIN_VALUE) {
            return null;
        }
        G0();
        b1(F0, (int) (this.r.l() * 0.33333334f), false, jd);
        C0111fa c0111fa = this.q;
        c0111fa.g = Integer.MIN_VALUE;
        c0111fa.a = false;
        H0(ed, c0111fa, jd, true);
        if (F0 == -1) {
            if (this.u) {
                L0 = L0(v() - 1, -1);
            } else {
                L0 = L0(0, v());
            }
        } else if (this.u) {
            L0 = L0(0, v());
        } else {
            L0 = L0(v() - 1, -1);
        }
        if (F0 == -1) {
            Q0 = R0();
        } else {
            Q0 = Q0();
        }
        if (Q0.hasFocusable()) {
            if (L0 == null) {
                return null;
            }
            return Q0;
        }
        return L0;
    }

    public final boolean S0() {
        if (C() == 1) {
            return true;
        }
        return false;
    }

    @Override // x.AbstractC0475yd
    public final void T(AccessibilityEvent accessibilityEvent) {
        int H;
        super.T(accessibilityEvent);
        if (v() > 0) {
            View M0 = M0(0, v(), false);
            if (M0 == null) {
                H = -1;
            } else {
                H = AbstractC0475yd.H(M0);
            }
            accessibilityEvent.setFromIndex(H);
            accessibilityEvent.setToIndex(K0());
        }
    }

    public void T0(Ed ed, Jd jd, C0111fa c0111fa, C0091ea c0091ea) {
        boolean z;
        int i;
        int i2;
        int i3;
        int i4;
        boolean z2;
        View b = c0111fa.b(ed);
        if (b == null) {
            c0091ea.b = true;
            return;
        }
        C0494zd c0494zd = (C0494zd) b.getLayoutParams();
        if (c0111fa.k == null) {
            boolean z3 = this.u;
            if (c0111fa.f == -1) {
                z2 = true;
            } else {
                z2 = false;
            }
            if (z3 == z2) {
                b(b, -1, false);
            } else {
                b(b, 0, false);
            }
        } else {
            boolean z4 = this.u;
            if (c0111fa.f == -1) {
                z = true;
            } else {
                z = false;
            }
            if (z4 == z) {
                b(b, -1, true);
            } else {
                b(b, 0, true);
            }
        }
        C0494zd c0494zd2 = (C0494zd) b.getLayoutParams();
        Rect J = this.b.J(b);
        int i5 = J.left + J.right;
        int i6 = J.top + J.bottom;
        int w = AbstractC0475yd.w(d(), this.n, this.l, F() + E() + ((ViewGroup.MarginLayoutParams) c0494zd2).leftMargin + ((ViewGroup.MarginLayoutParams) c0494zd2).rightMargin + i5, ((ViewGroup.MarginLayoutParams) c0494zd2).width);
        int w2 = AbstractC0475yd.w(e(), this.o, this.m, D() + G() + ((ViewGroup.MarginLayoutParams) c0494zd2).topMargin + ((ViewGroup.MarginLayoutParams) c0494zd2).bottomMargin + i6, ((ViewGroup.MarginLayoutParams) c0494zd2).height);
        if (u0(b, w, w2, c0494zd2)) {
            b.measure(w, w2);
        }
        c0091ea.a = this.r.c(b);
        if (this.p == 1) {
            if (S0()) {
                i4 = this.n - F();
                i = i4 - this.r.d(b);
            } else {
                i = E();
                i4 = this.r.d(b) + i;
            }
            if (c0111fa.f == -1) {
                i2 = c0111fa.b;
                i3 = i2 - c0091ea.a;
            } else {
                i3 = c0111fa.b;
                i2 = c0091ea.a + i3;
            }
        } else {
            int G = G();
            int d = this.r.d(b) + G;
            if (c0111fa.f == -1) {
                int i7 = c0111fa.b;
                int i8 = i7 - c0091ea.a;
                i4 = i7;
                i2 = d;
                i = i8;
                i3 = G;
            } else {
                int i9 = c0111fa.b;
                int i10 = c0091ea.a + i9;
                i = i9;
                i2 = d;
                i3 = G;
                i4 = i10;
            }
        }
        AbstractC0475yd.N(b, i, i3, i4, i2);
        if (c0494zd.a.i() || c0494zd.a.l()) {
            c0091ea.c = true;
        }
        c0091ea.d = b.hasFocusable();
    }

    public void U0(Ed ed, Jd jd, C0071da c0071da, int i) {
    }

    public final void V0(Ed ed, C0111fa c0111fa) {
        if (c0111fa.a && !c0111fa.l) {
            int i = c0111fa.g;
            int i2 = c0111fa.i;
            if (c0111fa.f == -1) {
                int v = v();
                if (i >= 0) {
                    int f = (this.r.f() - i) + i2;
                    if (this.u) {
                        for (int i3 = 0; i3 < v; i3++) {
                            View u = u(i3);
                            if (this.r.e(u) < f || this.r.o(u) < f) {
                                W0(ed, 0, i3);
                                return;
                            }
                        }
                        return;
                    }
                    int i4 = v - 1;
                    for (int i5 = i4; i5 >= 0; i5--) {
                        View u2 = u(i5);
                        if (this.r.e(u2) < f || this.r.o(u2) < f) {
                            W0(ed, i4, i5);
                            return;
                        }
                    }
                    return;
                }
                return;
            }
            if (i >= 0) {
                int i6 = i - i2;
                int v2 = v();
                if (this.u) {
                    int i7 = v2 - 1;
                    for (int i8 = i7; i8 >= 0; i8--) {
                        View u3 = u(i8);
                        if (this.r.b(u3) > i6 || this.r.n(u3) > i6) {
                            W0(ed, i7, i8);
                            return;
                        }
                    }
                    return;
                }
                for (int i9 = 0; i9 < v2; i9++) {
                    View u4 = u(i9);
                    if (this.r.b(u4) > i6 || this.r.n(u4) > i6) {
                        W0(ed, 0, i9);
                        return;
                    }
                }
            }
        }
    }

    public final void W0(Ed ed, int i, int i2) {
        if (i == i2) {
            return;
        }
        if (i2 > i) {
            for (int i3 = i2 - 1; i3 >= i; i3--) {
                View u = u(i3);
                j0(i3);
                ed.f(u);
            }
            return;
        }
        while (i > i2) {
            View u2 = u(i);
            j0(i);
            ed.f(u2);
            i--;
        }
    }

    public final void X0() {
        if (this.p != 1 && S0()) {
            this.u = !this.t;
        } else {
            this.u = this.t;
        }
    }

    public final int Y0(int i, Ed ed, Jd jd) {
        int i2;
        if (v() == 0 || i == 0) {
            return 0;
        }
        G0();
        this.q.a = true;
        if (i > 0) {
            i2 = 1;
        } else {
            i2 = -1;
        }
        int abs = Math.abs(i);
        b1(i2, abs, true, jd);
        C0111fa c0111fa = this.q;
        int H0 = H0(ed, c0111fa, jd, false) + c0111fa.g;
        if (H0 < 0) {
            return 0;
        }
        if (abs > H0) {
            i = i2 * H0;
        }
        this.r.p(-i);
        this.q.j = i;
        return i;
    }

    public final void Z0(int i) {
        if (i != 0 && i != 1) {
            throw new IllegalArgumentException(Ue.d("invalid orientation:", i));
        }
        c(null);
        if (i != this.p || this.r == null) {
            AbstractC0203k6 a = AbstractC0203k6.a(this, i);
            this.r = a;
            this.A.a = a;
            this.p = i;
            l0();
        }
    }

    @Override // x.Id
    public final PointF a(int i) {
        if (v() == 0) {
            return null;
        }
        boolean z = false;
        int i2 = 1;
        if (i < AbstractC0475yd.H(u(0))) {
            z = true;
        }
        if (z != this.u) {
            i2 = -1;
        }
        if (this.p == 0) {
            return new PointF(i2, 0.0f);
        }
        return new PointF(0.0f, i2);
    }

    public void a1(boolean z) {
        c(null);
        if (this.v == z) {
            return;
        }
        this.v = z;
        l0();
    }

    @Override // x.AbstractC0475yd
    public void b0(Ed ed, Jd jd) {
        View focusedChild;
        int i;
        View focusedChild2;
        View N0;
        int k;
        int i2;
        boolean z;
        boolean z2;
        int e;
        int i3;
        boolean z3;
        int i4;
        int i5;
        List list;
        boolean z4;
        int i6;
        int i7;
        int O0;
        int i8;
        View q;
        int e2;
        int i9;
        int i10;
        int i11 = -1;
        if ((this.z != null || this.f6x != -1) && jd.b() == 0) {
            g0(ed);
            return;
        }
        C0131ga c0131ga = this.z;
        if (c0131ga != null && (i10 = c0131ga.a) >= 0) {
            this.f6x = i10;
        }
        G0();
        this.q.a = false;
        X0();
        RecyclerView recyclerView = this.b;
        if (recyclerView == null || (focusedChild = recyclerView.getFocusedChild()) == null || ((ArrayList) this.a.d).contains(focusedChild)) {
            focusedChild = null;
        }
        C0071da c0071da = this.A;
        if (c0071da.e && this.f6x == -1 && this.z == null) {
            if (focusedChild != null && (this.r.e(focusedChild) >= this.r.g() || this.r.b(focusedChild) <= this.r.k())) {
                c0071da.c(focusedChild, AbstractC0475yd.H(focusedChild));
            }
        } else {
            c0071da.d();
            c0071da.d = this.u ^ this.v;
            if (!jd.g && (i2 = this.f6x) != -1) {
                if (i2 >= 0 && i2 < jd.b()) {
                    int i12 = this.f6x;
                    c0071da.b = i12;
                    C0131ga c0131ga2 = this.z;
                    if (c0131ga2 != null && c0131ga2.a >= 0) {
                        boolean z5 = c0131ga2.c;
                        c0071da.d = z5;
                        if (z5) {
                            c0071da.c = this.r.g() - this.z.b;
                        } else {
                            c0071da.c = this.r.k() + this.z.b;
                        }
                    } else if (this.y == Integer.MIN_VALUE) {
                        View q2 = q(i12);
                        if (q2 != null) {
                            if (this.r.c(q2) > this.r.l()) {
                                c0071da.a();
                            } else if (this.r.e(q2) - this.r.k() < 0) {
                                c0071da.c = this.r.k();
                                c0071da.d = false;
                            } else if (this.r.g() - this.r.b(q2) < 0) {
                                c0071da.c = this.r.g();
                                c0071da.d = true;
                            } else {
                                if (c0071da.d) {
                                    e = this.r.m() + this.r.b(q2);
                                } else {
                                    e = this.r.e(q2);
                                }
                                c0071da.c = e;
                            }
                        } else {
                            if (v() > 0) {
                                if (this.f6x < AbstractC0475yd.H(u(0))) {
                                    z = true;
                                } else {
                                    z = false;
                                }
                                if (z == this.u) {
                                    z2 = true;
                                } else {
                                    z2 = false;
                                }
                                c0071da.d = z2;
                            }
                            c0071da.a();
                        }
                    } else {
                        boolean z6 = this.u;
                        c0071da.d = z6;
                        if (z6) {
                            c0071da.c = this.r.g() - this.y;
                        } else {
                            c0071da.c = this.r.k() + this.y;
                        }
                    }
                    c0071da.e = true;
                } else {
                    this.f6x = -1;
                    this.y = Integer.MIN_VALUE;
                }
            }
            if (v() != 0) {
                RecyclerView recyclerView2 = this.b;
                if (recyclerView2 == null || (focusedChild2 = recyclerView2.getFocusedChild()) == null || ((ArrayList) this.a.d).contains(focusedChild2)) {
                    focusedChild2 = null;
                }
                if (focusedChild2 != null) {
                    C0494zd c0494zd = (C0494zd) focusedChild2.getLayoutParams();
                    if (!c0494zd.a.i() && c0494zd.a.b() >= 0 && c0494zd.a.b() < jd.b()) {
                        c0071da.c(focusedChild2, AbstractC0475yd.H(focusedChild2));
                        c0071da.e = true;
                    }
                }
                if (this.s == this.v) {
                    if (c0071da.d) {
                        if (this.u) {
                            N0 = N0(ed, jd, 0, v(), jd.b());
                        } else {
                            N0 = N0(ed, jd, v() - 1, -1, jd.b());
                        }
                    } else if (this.u) {
                        N0 = N0(ed, jd, v() - 1, -1, jd.b());
                    } else {
                        N0 = N0(ed, jd, 0, v(), jd.b());
                    }
                    if (N0 != null) {
                        c0071da.b(N0, AbstractC0475yd.H(N0));
                        if (!jd.g && z0() && (this.r.e(N0) >= this.r.g() || this.r.b(N0) < this.r.k())) {
                            if (c0071da.d) {
                                k = this.r.g();
                            } else {
                                k = this.r.k();
                            }
                            c0071da.c = k;
                        }
                        c0071da.e = true;
                    }
                }
            }
            c0071da.a();
            if (this.v) {
                i = jd.b() - 1;
            } else {
                i = 0;
            }
            c0071da.b = i;
            c0071da.e = true;
        }
        C0111fa c0111fa = this.q;
        if (c0111fa.j >= 0) {
            i3 = 1;
        } else {
            i3 = -1;
        }
        c0111fa.f = i3;
        int[] iArr = this.D;
        iArr[0] = 0;
        iArr[1] = 0;
        A0(jd, iArr);
        int k2 = this.r.k() + Math.max(0, iArr[0]);
        int h = this.r.h() + Math.max(0, iArr[1]);
        if (jd.g && (i8 = this.f6x) != -1 && this.y != Integer.MIN_VALUE && (q = q(i8)) != null) {
            if (this.u) {
                i9 = this.r.g() - this.r.b(q);
                e2 = this.y;
            } else {
                e2 = this.r.e(q) - this.r.k();
                i9 = this.y;
            }
            int i13 = i9 - e2;
            if (i13 > 0) {
                k2 += i13;
            } else {
                h -= i13;
            }
        }
        if (!c0071da.d ? !this.u : this.u) {
            i11 = 1;
        }
        U0(ed, jd, c0071da, i11);
        p(ed);
        C0111fa c0111fa2 = this.q;
        if (this.r.i() == 0 && this.r.f() == 0) {
            z3 = true;
        } else {
            z3 = false;
        }
        c0111fa2.l = z3;
        this.q.getClass();
        this.q.i = 0;
        if (c0071da.d) {
            d1(c0071da.b, c0071da.c);
            C0111fa c0111fa3 = this.q;
            c0111fa3.h = k2;
            H0(ed, c0111fa3, jd, false);
            C0111fa c0111fa4 = this.q;
            i5 = c0111fa4.b;
            int i14 = c0111fa4.d;
            int i15 = c0111fa4.c;
            if (i15 > 0) {
                h += i15;
            }
            c1(c0071da.b, c0071da.c);
            C0111fa c0111fa5 = this.q;
            c0111fa5.h = h;
            c0111fa5.d += c0111fa5.e;
            H0(ed, c0111fa5, jd, false);
            C0111fa c0111fa6 = this.q;
            i4 = c0111fa6.b;
            int i16 = c0111fa6.c;
            if (i16 > 0) {
                d1(i14, i5);
                C0111fa c0111fa7 = this.q;
                c0111fa7.h = i16;
                H0(ed, c0111fa7, jd, false);
                i5 = this.q.b;
            }
        } else {
            c1(c0071da.b, c0071da.c);
            C0111fa c0111fa8 = this.q;
            c0111fa8.h = h;
            H0(ed, c0111fa8, jd, false);
            C0111fa c0111fa9 = this.q;
            i4 = c0111fa9.b;
            int i17 = c0111fa9.d;
            int i18 = c0111fa9.c;
            if (i18 > 0) {
                k2 += i18;
            }
            d1(c0071da.b, c0071da.c);
            C0111fa c0111fa10 = this.q;
            c0111fa10.h = k2;
            c0111fa10.d += c0111fa10.e;
            H0(ed, c0111fa10, jd, false);
            C0111fa c0111fa11 = this.q;
            i5 = c0111fa11.b;
            int i19 = c0111fa11.c;
            if (i19 > 0) {
                c1(i17, i4);
                C0111fa c0111fa12 = this.q;
                c0111fa12.h = i19;
                H0(ed, c0111fa12, jd, false);
                i4 = this.q.b;
            }
        }
        if (v() > 0) {
            if (this.u ^ this.v) {
                int O02 = O0(i4, ed, jd, true);
                i6 = i5 + O02;
                i7 = i4 + O02;
                O0 = P0(i6, ed, jd, false);
            } else {
                int P0 = P0(i5, ed, jd, true);
                i6 = i5 + P0;
                i7 = i4 + P0;
                O0 = O0(i7, ed, jd, false);
            }
            i5 = i6 + O0;
            i4 = i7 + O0;
        }
        if (jd.k && v() != 0 && !jd.g && z0()) {
            List list2 = ed.d;
            int size = list2.size();
            int H = AbstractC0475yd.H(u(0));
            int i20 = 0;
            int i21 = 0;
            for (int i22 = 0; i22 < size; i22++) {
                Md md = (Md) list2.get(i22);
                if (!md.i()) {
                    if (md.b() < H) {
                        z4 = true;
                    } else {
                        z4 = false;
                    }
                    boolean z7 = this.u;
                    View view = md.a;
                    if (z4 != z7) {
                        i20 += this.r.c(view);
                    } else {
                        i21 += this.r.c(view);
                    }
                }
            }
            this.q.k = list2;
            if (i20 > 0) {
                d1(AbstractC0475yd.H(R0()), i5);
                C0111fa c0111fa13 = this.q;
                c0111fa13.h = i20;
                c0111fa13.c = 0;
                c0111fa13.a(null);
                H0(ed, this.q, jd, false);
            }
            if (i21 > 0) {
                c1(AbstractC0475yd.H(Q0()), i4);
                C0111fa c0111fa14 = this.q;
                c0111fa14.h = i21;
                c0111fa14.c = 0;
                list = null;
                c0111fa14.a(null);
                H0(ed, this.q, jd, false);
            } else {
                list = null;
            }
            this.q.k = list;
        }
        if (!jd.g) {
            AbstractC0203k6 abstractC0203k6 = this.r;
            abstractC0203k6.a = abstractC0203k6.l();
        } else {
            c0071da.d();
        }
        this.s = this.v;
    }

    public final void b1(int i, int i2, boolean z, Jd jd) {
        boolean z2;
        int i3;
        int k;
        C0111fa c0111fa = this.q;
        boolean z3 = false;
        int i4 = 1;
        if (this.r.i() == 0 && this.r.f() == 0) {
            z2 = true;
        } else {
            z2 = false;
        }
        c0111fa.l = z2;
        this.q.f = i;
        int[] iArr = this.D;
        iArr[0] = 0;
        iArr[1] = 0;
        A0(jd, iArr);
        int max = Math.max(0, iArr[0]);
        int max2 = Math.max(0, iArr[1]);
        if (i == 1) {
            z3 = true;
        }
        C0111fa c0111fa2 = this.q;
        if (z3) {
            i3 = max2;
        } else {
            i3 = max;
        }
        c0111fa2.h = i3;
        if (!z3) {
            max = max2;
        }
        c0111fa2.i = max;
        if (z3) {
            c0111fa2.h = this.r.h() + i3;
            View Q0 = Q0();
            C0111fa c0111fa3 = this.q;
            if (this.u) {
                i4 = -1;
            }
            c0111fa3.e = i4;
            int H = AbstractC0475yd.H(Q0);
            C0111fa c0111fa4 = this.q;
            c0111fa3.d = H + c0111fa4.e;
            c0111fa4.b = this.r.b(Q0);
            k = this.r.b(Q0) - this.r.g();
        } else {
            View R0 = R0();
            C0111fa c0111fa5 = this.q;
            c0111fa5.h = this.r.k() + c0111fa5.h;
            C0111fa c0111fa6 = this.q;
            if (!this.u) {
                i4 = -1;
            }
            c0111fa6.e = i4;
            int H2 = AbstractC0475yd.H(R0);
            C0111fa c0111fa7 = this.q;
            c0111fa6.d = H2 + c0111fa7.e;
            c0111fa7.b = this.r.e(R0);
            k = (-this.r.e(R0)) + this.r.k();
        }
        C0111fa c0111fa8 = this.q;
        c0111fa8.c = i2;
        if (z) {
            c0111fa8.c = i2 - k;
        }
        c0111fa8.g = k;
    }

    @Override // x.AbstractC0475yd
    public final void c(String str) {
        if (this.z == null) {
            super.c(str);
        }
    }

    @Override // x.AbstractC0475yd
    public void c0(Jd jd) {
        this.z = null;
        this.f6x = -1;
        this.y = Integer.MIN_VALUE;
        this.A.d();
    }

    public final void c1(int i, int i2) {
        int i3;
        this.q.c = this.r.g() - i2;
        C0111fa c0111fa = this.q;
        if (this.u) {
            i3 = -1;
        } else {
            i3 = 1;
        }
        c0111fa.e = i3;
        c0111fa.d = i;
        c0111fa.f = 1;
        c0111fa.b = i2;
        c0111fa.g = Integer.MIN_VALUE;
    }

    @Override // x.AbstractC0475yd
    public final boolean d() {
        if (this.p == 0) {
            return true;
        }
        return false;
    }

    @Override // x.AbstractC0475yd
    public final void d0(Parcelable parcelable) {
        if (parcelable instanceof C0131ga) {
            this.z = (C0131ga) parcelable;
            l0();
        }
    }

    public final void d1(int i, int i2) {
        int i3;
        this.q.c = i2 - this.r.k();
        C0111fa c0111fa = this.q;
        c0111fa.d = i;
        if (this.u) {
            i3 = 1;
        } else {
            i3 = -1;
        }
        c0111fa.e = i3;
        c0111fa.f = -1;
        c0111fa.b = i2;
        c0111fa.g = Integer.MIN_VALUE;
    }

    @Override // x.AbstractC0475yd
    public final boolean e() {
        if (this.p == 1) {
            return true;
        }
        return false;
    }

    /* JADX WARN: Type inference failed for: r0v1, types: [android.os.Parcelable, x.ga, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r1v9, types: [android.os.Parcelable, x.ga, java.lang.Object] */
    @Override // x.AbstractC0475yd
    public final Parcelable e0() {
        C0131ga c0131ga = this.z;
        if (c0131ga != null) {
            ?? obj = new Object();
            obj.a = c0131ga.a;
            obj.b = c0131ga.b;
            obj.c = c0131ga.c;
            return obj;
        }
        ?? obj2 = new Object();
        if (v() > 0) {
            G0();
            boolean z = this.s ^ this.u;
            obj2.c = z;
            if (z) {
                View Q0 = Q0();
                obj2.b = this.r.g() - this.r.b(Q0);
                obj2.a = AbstractC0475yd.H(Q0);
            } else {
                View R0 = R0();
                obj2.a = AbstractC0475yd.H(R0);
                obj2.b = this.r.e(R0) - this.r.k();
            }
        } else {
            obj2.a = -1;
        }
        return obj2;
    }

    @Override // x.AbstractC0475yd
    public final void h(int i, int i2, Jd jd, C0130g9 c0130g9) {
        int i3;
        if (this.p != 0) {
            i = i2;
        }
        if (v() != 0 && i != 0) {
            G0();
            if (i > 0) {
                i3 = 1;
            } else {
                i3 = -1;
            }
            b1(i3, Math.abs(i), true, jd);
            B0(jd, this.q, c0130g9);
        }
    }

    @Override // x.AbstractC0475yd
    public final void i(int i, C0130g9 c0130g9) {
        boolean z;
        int i2;
        C0131ga c0131ga = this.z;
        int i3 = -1;
        if (c0131ga != null && (i2 = c0131ga.a) >= 0) {
            z = c0131ga.c;
        } else {
            X0();
            z = this.u;
            i2 = this.f6x;
            if (i2 == -1) {
                i2 = z ? i - 1 : 0;
            }
        }
        if (!z) {
            i3 = 1;
        }
        for (int i4 = 0; i4 < this.C && i2 >= 0 && i2 < i; i4++) {
            c0130g9.a(i2, 0);
            i2 += i3;
        }
    }

    @Override // x.AbstractC0475yd
    public final int j(Jd jd) {
        return C0(jd);
    }

    @Override // x.AbstractC0475yd
    public int k(Jd jd) {
        return D0(jd);
    }

    @Override // x.AbstractC0475yd
    public int l(Jd jd) {
        return E0(jd);
    }

    @Override // x.AbstractC0475yd
    public final int m(Jd jd) {
        return C0(jd);
    }

    @Override // x.AbstractC0475yd
    public int m0(int i, Ed ed, Jd jd) {
        if (this.p == 1) {
            return 0;
        }
        return Y0(i, ed, jd);
    }

    @Override // x.AbstractC0475yd
    public int n(Jd jd) {
        return D0(jd);
    }

    @Override // x.AbstractC0475yd
    public final void n0(int i) {
        this.f6x = i;
        this.y = Integer.MIN_VALUE;
        C0131ga c0131ga = this.z;
        if (c0131ga != null) {
            c0131ga.a = -1;
        }
        l0();
    }

    @Override // x.AbstractC0475yd
    public int o(Jd jd) {
        return E0(jd);
    }

    @Override // x.AbstractC0475yd
    public int o0(int i, Ed ed, Jd jd) {
        if (this.p == 0) {
            return 0;
        }
        return Y0(i, ed, jd);
    }

    @Override // x.AbstractC0475yd
    public final View q(int i) {
        int v = v();
        if (v == 0) {
            return null;
        }
        int H = i - AbstractC0475yd.H(u(0));
        if (H >= 0 && H < v) {
            View u = u(H);
            if (AbstractC0475yd.H(u) == i) {
                return u;
            }
        }
        return super.q(i);
    }

    @Override // x.AbstractC0475yd
    public C0494zd r() {
        return new C0494zd(-2, -2);
    }

    @Override // x.AbstractC0475yd
    public final boolean v0() {
        if (this.m == 1073741824 || this.l == 1073741824) {
            return false;
        }
        int v = v();
        for (int i = 0; i < v; i++) {
            ViewGroup.LayoutParams layoutParams = u(i).getLayoutParams();
            if (layoutParams.width < 0 && layoutParams.height < 0) {
                return true;
            }
        }
        return false;
    }

    @Override // x.AbstractC0475yd
    public void x0(RecyclerView recyclerView, int i) {
        C0151ha c0151ha = new C0151ha(recyclerView.getContext());
        c0151ha.a = i;
        y0(c0151ha);
    }

    @Override // x.AbstractC0475yd
    public boolean z0() {
        if (this.z == null && this.s == this.v) {
            return true;
        }
        return false;
    }

    /* JADX WARN: Type inference failed for: r1v2, types: [x.ea, java.lang.Object] */
    public LinearLayoutManager(Context context, AttributeSet attributeSet, int i, int i2) {
        this.p = 1;
        this.t = false;
        this.u = false;
        this.v = false;
        this.w = true;
        this.f6x = -1;
        this.y = Integer.MIN_VALUE;
        this.z = null;
        this.A = new C0071da();
        this.B = new Object();
        this.C = 2;
        this.D = new int[2];
        C0456xd I = AbstractC0475yd.I(context, attributeSet, i, i2);
        Z0(I.a);
        boolean z = I.c;
        c(null);
        if (z != this.t) {
            this.t = z;
            l0();
        }
        a1(I.d);
    }
}
