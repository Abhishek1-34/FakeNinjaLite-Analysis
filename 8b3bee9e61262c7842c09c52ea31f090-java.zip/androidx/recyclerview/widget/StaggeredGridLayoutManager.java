package androidx.recyclerview.widget;

import android.content.Context;
import android.graphics.PointF;
import android.graphics.Rect;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.BitSet;
import java.util.WeakHashMap;
import x.AbstractC0112fb;
import x.AbstractC0203k6;
import x.AbstractC0309ph;
import x.AbstractC0475yd;
import x.B;
import x.C;
import x.C0056cf;
import x.C0076df;
import x.C0096ef;
import x.C0116ff;
import x.C0130g9;
import x.C0151ha;
import x.C0456xd;
import x.C0494zd;
import x.Da;
import x.Ed;
import x.F1;
import x.I2;
import x.Id;
import x.Jd;
import x.N9;

/* loaded from: classes.dex */
public class StaggeredGridLayoutManager extends AbstractC0475yd implements Id {
    public final F1 B;
    public final int C;
    public boolean D;
    public boolean E;
    public C0116ff F;
    public final Rect G;
    public final C0056cf H;
    public final boolean I;
    public int[] J;
    public final I2 K;
    public final int p;
    public final Da[] q;
    public final AbstractC0203k6 r;
    public final AbstractC0203k6 s;
    public final int t;
    public int u;
    public final N9 v;
    public boolean w;
    public final BitSet y;

    /* renamed from: x, reason: collision with root package name */
    public boolean f8x = false;
    public int z = -1;
    public int A = Integer.MIN_VALUE;

    /* JADX WARN: Type inference failed for: r7v3, types: [x.N9, java.lang.Object] */
    public StaggeredGridLayoutManager(Context context, AttributeSet attributeSet, int i, int i2) {
        this.p = -1;
        this.w = false;
        F1 f1 = new F1(16, false);
        this.B = f1;
        this.C = 2;
        this.G = new Rect();
        this.H = new C0056cf(this);
        this.I = true;
        this.K = new I2(10, this);
        C0456xd I = AbstractC0475yd.I(context, attributeSet, i, i2);
        int i3 = I.a;
        if (i3 != 0 && i3 != 1) {
            throw new IllegalArgumentException("invalid orientation.");
        }
        c(null);
        if (i3 != this.t) {
            this.t = i3;
            AbstractC0203k6 abstractC0203k6 = this.r;
            this.r = this.s;
            this.s = abstractC0203k6;
            l0();
        }
        int i4 = I.b;
        c(null);
        if (i4 != this.p) {
            int[] iArr = (int[]) f1.b;
            if (iArr != null) {
                Arrays.fill(iArr, -1);
            }
            f1.c = null;
            l0();
            this.p = i4;
            this.y = new BitSet(this.p);
            this.q = new Da[this.p];
            for (int i5 = 0; i5 < this.p; i5++) {
                this.q[i5] = new Da(this, i5);
            }
            l0();
        }
        boolean z = I.c;
        c(null);
        C0116ff c0116ff = this.F;
        if (c0116ff != null && c0116ff.h != z) {
            c0116ff.h = z;
        }
        this.w = z;
        l0();
        ?? obj = new Object();
        obj.a = true;
        obj.f = 0;
        obj.g = 0;
        this.v = obj;
        this.r = AbstractC0203k6.a(this, this.t);
        this.s = AbstractC0203k6.a(this, 1 - this.t);
    }

    public static int d1(int i, int i2, int i3) {
        if (i2 == 0 && i3 == 0) {
            return i;
        }
        int mode = View.MeasureSpec.getMode(i);
        if (mode != Integer.MIN_VALUE && mode != 1073741824) {
            return i;
        }
        return View.MeasureSpec.makeMeasureSpec(Math.max(0, (View.MeasureSpec.getSize(i) - i2) - i3), mode);
    }

    public final int A0(int i) {
        boolean z;
        if (v() == 0) {
            if (!this.f8x) {
                return -1;
            }
            return 1;
        }
        if (i < K0()) {
            z = true;
        } else {
            z = false;
        }
        if (z != this.f8x) {
            return -1;
        }
        return 1;
    }

    public final boolean B0() {
        int K0;
        if (v() != 0 && this.C != 0 && this.g) {
            if (this.f8x) {
                K0 = L0();
                K0();
            } else {
                K0 = K0();
                L0();
            }
            F1 f1 = this.B;
            if (K0 == 0 && P0() != null) {
                int[] iArr = (int[]) f1.b;
                if (iArr != null) {
                    Arrays.fill(iArr, -1);
                }
                f1.c = null;
                this.f = true;
                l0();
                return true;
            }
        }
        return false;
    }

    public final int C0(Jd jd) {
        if (v() == 0) {
            return 0;
        }
        AbstractC0203k6 abstractC0203k6 = this.r;
        boolean z = !this.I;
        return AbstractC0112fb.e(jd, abstractC0203k6, H0(z), G0(z), this, this.I);
    }

    public final int D0(Jd jd) {
        if (v() == 0) {
            return 0;
        }
        AbstractC0203k6 abstractC0203k6 = this.r;
        boolean z = !this.I;
        return AbstractC0112fb.f(jd, abstractC0203k6, H0(z), G0(z), this, this.I, this.f8x);
    }

    public final int E0(Jd jd) {
        if (v() == 0) {
            return 0;
        }
        AbstractC0203k6 abstractC0203k6 = this.r;
        boolean z = !this.I;
        return AbstractC0112fb.g(jd, abstractC0203k6, H0(z), G0(z), this, this.I);
    }

    /* JADX WARN: Type inference failed for: r6v20 */
    /* JADX WARN: Type inference failed for: r6v3 */
    /* JADX WARN: Type inference failed for: r6v4, types: [boolean, int] */
    public final int F0(Ed ed, N9 n9, Jd jd) {
        int i;
        int k;
        int i2;
        int M0;
        int i3;
        Da da;
        ?? r6;
        int i4;
        int i5;
        int c;
        int k2;
        int c2;
        int i6;
        int i7;
        int i8;
        int i9;
        int i10 = 0;
        int i11 = 1;
        this.y.set(0, this.p, true);
        N9 n92 = this.v;
        if (n92.i) {
            if (n9.e == 1) {
                i = Integer.MAX_VALUE;
            } else {
                i = Integer.MIN_VALUE;
            }
        } else if (n9.e == 1) {
            i = n9.g + n9.b;
        } else {
            i = n9.f - n9.b;
        }
        int i12 = n9.e;
        for (int i13 = 0; i13 < this.p; i13++) {
            if (!((ArrayList) this.q[i13].f).isEmpty()) {
                c1(this.q[i13], i12, i);
            }
        }
        if (this.f8x) {
            k = this.r.g();
        } else {
            k = this.r.k();
        }
        boolean z = false;
        while (true) {
            int i14 = n9.c;
            if (i14 >= 0 && i14 < jd.b()) {
                i2 = i11;
            } else {
                i2 = i10;
            }
            if (i2 == 0 || (!n92.i && this.y.isEmpty())) {
                break;
            }
            View view = ed.i(Long.MAX_VALUE, n9.c).a;
            n9.c += n9.d;
            C0076df c0076df = (C0076df) view.getLayoutParams();
            int b = c0076df.a.b();
            F1 f1 = this.B;
            int[] iArr = (int[]) f1.b;
            if (iArr != null && b < iArr.length) {
                i3 = iArr[b];
            } else {
                i3 = -1;
            }
            if (i3 == -1) {
                if (T0(n9.e)) {
                    i9 = this.p - i11;
                    i8 = -1;
                    i7 = -1;
                } else {
                    i7 = i11;
                    i8 = this.p;
                    i9 = i10;
                }
                Da da2 = null;
                if (n9.e == i11) {
                    int k3 = this.r.k();
                    int i15 = Integer.MAX_VALUE;
                    while (i9 != i8) {
                        Da da3 = this.q[i9];
                        int g = da3.g(k3);
                        if (g < i15) {
                            i15 = g;
                            da2 = da3;
                        }
                        i9 += i7;
                    }
                } else {
                    int g2 = this.r.g();
                    int i16 = Integer.MIN_VALUE;
                    while (i9 != i8) {
                        Da da4 = this.q[i9];
                        int i17 = da4.i(g2);
                        if (i17 > i16) {
                            da2 = da4;
                            i16 = i17;
                        }
                        i9 += i7;
                    }
                }
                da = da2;
                f1.t(b);
                ((int[]) f1.b)[b] = da.e;
            } else {
                da = this.q[i3];
            }
            c0076df.e = da;
            if (n9.e == 1) {
                r6 = 0;
                b(view, -1, false);
            } else {
                r6 = 0;
                b(view, 0, false);
            }
            if (this.t == 1) {
                i4 = 1;
                R0(view, AbstractC0475yd.w(r6, this.u, this.l, r6, ((ViewGroup.MarginLayoutParams) c0076df).width), AbstractC0475yd.w(true, this.o, this.m, D() + G(), ((ViewGroup.MarginLayoutParams) c0076df).height));
            } else {
                i4 = 1;
                R0(view, AbstractC0475yd.w(true, this.n, this.l, F() + E(), ((ViewGroup.MarginLayoutParams) c0076df).width), AbstractC0475yd.w(false, this.u, this.m, 0, ((ViewGroup.MarginLayoutParams) c0076df).height));
            }
            if (n9.e == i4) {
                c = da.g(k);
                i5 = this.r.c(view) + c;
            } else {
                i5 = da.i(k);
                c = i5 - this.r.c(view);
            }
            if (n9.e == 1) {
                Da da5 = c0076df.e;
                da5.getClass();
                C0076df c0076df2 = (C0076df) view.getLayoutParams();
                c0076df2.e = da5;
                ArrayList arrayList = (ArrayList) da5.f;
                arrayList.add(view);
                da5.c = Integer.MIN_VALUE;
                if (arrayList.size() == 1) {
                    da5.b = Integer.MIN_VALUE;
                }
                if (c0076df2.a.i() || c0076df2.a.l()) {
                    da5.d = ((StaggeredGridLayoutManager) da5.g).r.c(view) + da5.d;
                }
            } else {
                Da da6 = c0076df.e;
                da6.getClass();
                C0076df c0076df3 = (C0076df) view.getLayoutParams();
                c0076df3.e = da6;
                ArrayList arrayList2 = (ArrayList) da6.f;
                arrayList2.add(0, view);
                da6.b = Integer.MIN_VALUE;
                if (arrayList2.size() == 1) {
                    da6.c = Integer.MIN_VALUE;
                }
                if (c0076df3.a.i() || c0076df3.a.l()) {
                    da6.d = ((StaggeredGridLayoutManager) da6.g).r.c(view) + da6.d;
                }
            }
            if (Q0() && this.t == 1) {
                c2 = this.s.g() - (((this.p - 1) - da.e) * this.u);
                k2 = c2 - this.s.c(view);
            } else {
                k2 = this.s.k() + (da.e * this.u);
                c2 = this.s.c(view) + k2;
            }
            if (this.t == 1) {
                AbstractC0475yd.N(view, k2, c, c2, i5);
            } else {
                AbstractC0475yd.N(view, c, k2, i5, c2);
            }
            c1(da, n92.e, i);
            V0(ed, n92);
            if (n92.h && view.hasFocusable()) {
                i6 = 0;
                this.y.set(da.e, false);
            } else {
                i6 = 0;
            }
            i10 = i6;
            i11 = 1;
            z = true;
        }
        int i18 = i10;
        if (!z) {
            V0(ed, n92);
        }
        if (n92.e == -1) {
            M0 = this.r.k() - N0(this.r.k());
        } else {
            M0 = M0(this.r.g()) - this.r.g();
        }
        if (M0 > 0) {
            return Math.min(n9.b, M0);
        }
        return i18;
    }

    public final View G0(boolean z) {
        int k = this.r.k();
        int g = this.r.g();
        View view = null;
        for (int v = v() - 1; v >= 0; v--) {
            View u = u(v);
            int e = this.r.e(u);
            int b = this.r.b(u);
            if (b > k && e < g) {
                if (b > g && z) {
                    if (view == null) {
                        view = u;
                    }
                } else {
                    return u;
                }
            }
        }
        return view;
    }

    public final View H0(boolean z) {
        int k = this.r.k();
        int g = this.r.g();
        int v = v();
        View view = null;
        for (int i = 0; i < v; i++) {
            View u = u(i);
            int e = this.r.e(u);
            if (this.r.b(u) > k && e < g) {
                if (e < k && z) {
                    if (view == null) {
                        view = u;
                    }
                } else {
                    return u;
                }
            }
        }
        return view;
    }

    public final void I0(Ed ed, Jd jd, boolean z) {
        int g;
        int M0 = M0(Integer.MIN_VALUE);
        if (M0 != Integer.MIN_VALUE && (g = this.r.g() - M0) > 0) {
            int i = g - (-Z0(-g, ed, jd));
            if (z && i > 0) {
                this.r.p(i);
            }
        }
    }

    @Override // x.AbstractC0475yd
    public final int J(Ed ed, Jd jd) {
        if (this.t == 0) {
            return this.p;
        }
        return super.J(ed, jd);
    }

    public final void J0(Ed ed, Jd jd, boolean z) {
        int k;
        int N0 = N0(Integer.MAX_VALUE);
        if (N0 != Integer.MAX_VALUE && (k = N0 - this.r.k()) > 0) {
            int Z0 = k - Z0(k, ed, jd);
            if (z && Z0 > 0) {
                this.r.p(-Z0);
            }
        }
    }

    public final int K0() {
        if (v() == 0) {
            return 0;
        }
        return AbstractC0475yd.H(u(0));
    }

    @Override // x.AbstractC0475yd
    public final boolean L() {
        if (this.C != 0) {
            return true;
        }
        return false;
    }

    public final int L0() {
        int v = v();
        if (v == 0) {
            return 0;
        }
        return AbstractC0475yd.H(u(v - 1));
    }

    public final int M0(int i) {
        int g = this.q[0].g(i);
        for (int i2 = 1; i2 < this.p; i2++) {
            int g2 = this.q[i2].g(i);
            if (g2 > g) {
                g = g2;
            }
        }
        return g;
    }

    public final int N0(int i) {
        int i2 = this.q[0].i(i);
        for (int i3 = 1; i3 < this.p; i3++) {
            int i4 = this.q[i3].i(i);
            if (i4 < i2) {
                i2 = i4;
            }
        }
        return i2;
    }

    @Override // x.AbstractC0475yd
    public final void O(int i) {
        super.O(i);
        for (int i2 = 0; i2 < this.p; i2++) {
            Da da = this.q[i2];
            int i3 = da.b;
            if (i3 != Integer.MIN_VALUE) {
                da.b = i3 + i;
            }
            int i4 = da.c;
            if (i4 != Integer.MIN_VALUE) {
                da.c = i4 + i;
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:17:0x0093  */
    /* JADX WARN: Removed duplicated region for block: B:18:0x00a1  */
    /* JADX WARN: Removed duplicated region for block: B:19:0x0036  */
    /* JADX WARN: Removed duplicated region for block: B:43:0x00ad  */
    /* JADX WARN: Removed duplicated region for block: B:48:0x00c3 A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:50:0x00c4  */
    /* JADX WARN: Removed duplicated region for block: B:59:0x00be  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void O0(int i, int i2, int i3) {
        int K0;
        int i4;
        int i5;
        F1 f1;
        int[] iArr;
        int L0;
        ArrayList arrayList;
        int i6;
        if (this.f8x) {
            K0 = L0();
        } else {
            K0 = K0();
        }
        if (i3 == 8) {
            if (i < i2) {
                i4 = i2 + 1;
            } else {
                i4 = i + 1;
                i5 = i2;
                f1 = this.B;
                iArr = (int[]) f1.b;
                if (iArr != null && i5 < iArr.length) {
                    arrayList = (ArrayList) f1.c;
                    if (arrayList != null) {
                        C0096ef c0096ef = null;
                        if (arrayList != null) {
                            int size = arrayList.size() - 1;
                            while (true) {
                                if (size < 0) {
                                    break;
                                }
                                C0096ef c0096ef2 = (C0096ef) ((ArrayList) f1.c).get(size);
                                if (c0096ef2.a == i5) {
                                    c0096ef = c0096ef2;
                                    break;
                                }
                                size--;
                            }
                        }
                        if (c0096ef != null) {
                            ((ArrayList) f1.c).remove(c0096ef);
                        }
                        int size2 = ((ArrayList) f1.c).size();
                        int i7 = 0;
                        while (true) {
                            if (i7 < size2) {
                                if (((C0096ef) ((ArrayList) f1.c).get(i7)).a >= i5) {
                                    break;
                                } else {
                                    i7++;
                                }
                            } else {
                                i7 = -1;
                                break;
                            }
                        }
                        if (i7 != -1) {
                            C0096ef c0096ef3 = (C0096ef) ((ArrayList) f1.c).get(i7);
                            ((ArrayList) f1.c).remove(i7);
                            i6 = c0096ef3.a;
                            if (i6 == -1) {
                                int[] iArr2 = (int[]) f1.b;
                                Arrays.fill(iArr2, i5, iArr2.length, -1);
                                int length = ((int[]) f1.b).length;
                            } else {
                                Arrays.fill((int[]) f1.b, i5, i6 + 1, -1);
                            }
                        }
                    }
                    i6 = -1;
                    if (i6 == -1) {
                    }
                }
                if (i3 == 1) {
                    if (i3 != 2) {
                        if (i3 == 8) {
                            f1.D(i, 1);
                            f1.C(i2, 1);
                        }
                    } else {
                        f1.D(i, i2);
                    }
                } else {
                    f1.C(i, i2);
                }
                if (i4 > K0) {
                    return;
                }
                if (this.f8x) {
                    L0 = K0();
                } else {
                    L0 = L0();
                }
                if (i5 <= L0) {
                    l0();
                    return;
                }
                return;
            }
        } else {
            i4 = i + i2;
        }
        i5 = i;
        f1 = this.B;
        iArr = (int[]) f1.b;
        if (iArr != null) {
            arrayList = (ArrayList) f1.c;
            if (arrayList != null) {
            }
            i6 = -1;
            if (i6 == -1) {
            }
        }
        if (i3 == 1) {
        }
        if (i4 > K0) {
        }
    }

    @Override // x.AbstractC0475yd
    public final void P(int i) {
        super.P(i);
        for (int i2 = 0; i2 < this.p; i2++) {
            Da da = this.q[i2];
            int i3 = da.b;
            if (i3 != Integer.MIN_VALUE) {
                da.b = i3 + i;
            }
            int i4 = da.c;
            if (i4 != Integer.MIN_VALUE) {
                da.c = i4 + i;
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:46:0x00fd  */
    /* JADX WARN: Removed duplicated region for block: B:48:0x0102  */
    /* JADX WARN: Removed duplicated region for block: B:50:0x0107 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:52:0x002c A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:54:0x0104  */
    /* JADX WARN: Removed duplicated region for block: B:55:0x00ff  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final View P0() {
        char c;
        boolean z;
        boolean z2;
        int v = v();
        int i = v - 1;
        BitSet bitSet = new BitSet(this.p);
        bitSet.set(0, this.p, true);
        int i2 = -1;
        if (this.t == 1 && Q0()) {
            c = 1;
        } else {
            c = 65535;
        }
        if (this.f8x) {
            v = -1;
        } else {
            i = 0;
        }
        if (i < v) {
            i2 = 1;
        }
        while (i != v) {
            View u = u(i);
            C0076df c0076df = (C0076df) u.getLayoutParams();
            if (bitSet.get(c0076df.e.e)) {
                Da da = c0076df.e;
                if (this.f8x) {
                    int i3 = da.c;
                    if (i3 == Integer.MIN_VALUE) {
                        da.a();
                        i3 = da.c;
                    }
                    if (i3 < this.r.g()) {
                        ArrayList arrayList = (ArrayList) da.f;
                        ((C0076df) ((View) arrayList.get(arrayList.size() - 1)).getLayoutParams()).getClass();
                        return u;
                    }
                    bitSet.clear(c0076df.e.e);
                } else {
                    int i4 = da.b;
                    if (i4 == Integer.MIN_VALUE) {
                        View view = (View) ((ArrayList) da.f).get(0);
                        C0076df c0076df2 = (C0076df) view.getLayoutParams();
                        da.b = ((StaggeredGridLayoutManager) da.g).r.e(view);
                        c0076df2.getClass();
                        i4 = da.b;
                    }
                    if (i4 > this.r.k()) {
                        ((C0076df) ((View) ((ArrayList) da.f).get(0)).getLayoutParams()).getClass();
                        return u;
                    }
                    bitSet.clear(c0076df.e.e);
                }
            }
            i += i2;
            if (i != v) {
                View u2 = u(i);
                if (this.f8x) {
                    int b = this.r.b(u);
                    int b2 = this.r.b(u2);
                    if (b < b2) {
                        return u;
                    }
                    if (b == b2) {
                        if (c0076df.e.e - ((C0076df) u2.getLayoutParams()).e.e >= 0) {
                            z = true;
                        } else {
                            z = false;
                        }
                        if (c >= 0) {
                            z2 = true;
                        } else {
                            z2 = false;
                        }
                        if (z == z2) {
                            return u;
                        }
                    } else {
                        continue;
                    }
                } else {
                    int e = this.r.e(u);
                    int e2 = this.r.e(u2);
                    if (e > e2) {
                        return u;
                    }
                    if (e == e2) {
                        if (c0076df.e.e - ((C0076df) u2.getLayoutParams()).e.e >= 0) {
                        }
                        if (c >= 0) {
                        }
                        if (z == z2) {
                        }
                    } else {
                        continue;
                    }
                }
            }
        }
        return null;
    }

    public final boolean Q0() {
        if (C() == 1) {
            return true;
        }
        return false;
    }

    @Override // x.AbstractC0475yd
    public final void R(RecyclerView recyclerView) {
        RecyclerView recyclerView2 = this.b;
        if (recyclerView2 != null) {
            recyclerView2.removeCallbacks(this.K);
        }
        for (int i = 0; i < this.p; i++) {
            this.q[i].b();
        }
        recyclerView.requestLayout();
    }

    public final void R0(View view, int i, int i2) {
        RecyclerView recyclerView = this.b;
        Rect rect = this.G;
        if (recyclerView == null) {
            rect.set(0, 0, 0, 0);
        } else {
            rect.set(recyclerView.J(view));
        }
        C0076df c0076df = (C0076df) view.getLayoutParams();
        int d1 = d1(i, ((ViewGroup.MarginLayoutParams) c0076df).leftMargin + rect.left, ((ViewGroup.MarginLayoutParams) c0076df).rightMargin + rect.right);
        int d12 = d1(i2, ((ViewGroup.MarginLayoutParams) c0076df).topMargin + rect.top, ((ViewGroup.MarginLayoutParams) c0076df).bottomMargin + rect.bottom);
        if (u0(view, d1, d12, c0076df)) {
            view.measure(d1, d12);
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:112:0x004f, code lost:
    
        if (r8.t == 1) goto L46;
     */
    /* JADX WARN: Code restructure failed: missing block: B:115:0x0054, code lost:
    
        if (r8.t == 0) goto L46;
     */
    /* JADX WARN: Code restructure failed: missing block: B:119:0x0061, code lost:
    
        if (Q0() == false) goto L43;
     */
    /* JADX WARN: Code restructure failed: missing block: B:123:0x006e, code lost:
    
        if (Q0() == false) goto L46;
     */
    @Override // x.AbstractC0475yd
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final View S(View view, int i, Ed ed, Jd jd) {
        View A;
        int i2;
        int K0;
        boolean z;
        boolean z2;
        int d;
        int d2;
        int d3;
        if (v() == 0) {
            return null;
        }
        RecyclerView recyclerView = this.b;
        if (recyclerView == null || (A = recyclerView.A(view)) == null || ((ArrayList) this.a.d).contains(A)) {
            A = null;
        }
        if (A == null) {
            return null;
        }
        Y0();
        if (i != 1) {
            if (i != 2) {
                if (i != 17) {
                    if (i != 33) {
                        if (i == 66) {
                        }
                    }
                    i2 = Integer.MIN_VALUE;
                }
            } else {
                if (this.t != 1) {
                }
                i2 = 1;
            }
        } else {
            if (this.t != 1) {
            }
            i2 = -1;
        }
        if (i2 == Integer.MIN_VALUE) {
            return null;
        }
        C0076df c0076df = (C0076df) A.getLayoutParams();
        c0076df.getClass();
        Da da = c0076df.e;
        if (i2 == 1) {
            K0 = L0();
        } else {
            K0 = K0();
        }
        b1(K0, jd);
        a1(i2);
        N9 n9 = this.v;
        n9.c = n9.d + K0;
        n9.b = (int) (this.r.l() * 0.33333334f);
        n9.h = true;
        n9.a = false;
        F0(ed, n9, jd);
        this.D = this.f8x;
        View h = da.h(K0, i2);
        if (h != null && h != A) {
            return h;
        }
        if (T0(i2)) {
            for (int i3 = this.p - 1; i3 >= 0; i3--) {
                View h2 = this.q[i3].h(K0, i2);
                if (h2 != null && h2 != A) {
                    return h2;
                }
            }
        } else {
            for (int i4 = 0; i4 < this.p; i4++) {
                View h3 = this.q[i4].h(K0, i2);
                if (h3 != null && h3 != A) {
                    return h3;
                }
            }
        }
        boolean z3 = !this.w;
        if (i2 == -1) {
            z = true;
        } else {
            z = false;
        }
        if (z3 == z) {
            z2 = true;
        } else {
            z2 = false;
        }
        if (z2) {
            d = da.c();
        } else {
            d = da.d();
        }
        View q = q(d);
        if (q != null && q != A) {
            return q;
        }
        if (T0(i2)) {
            for (int i5 = this.p - 1; i5 >= 0; i5--) {
                if (i5 != da.e) {
                    if (z2) {
                        d3 = this.q[i5].c();
                    } else {
                        d3 = this.q[i5].d();
                    }
                    View q2 = q(d3);
                    if (q2 != null && q2 != A) {
                        return q2;
                    }
                }
            }
        } else {
            for (int i6 = 0; i6 < this.p; i6++) {
                if (z2) {
                    d2 = this.q[i6].c();
                } else {
                    d2 = this.q[i6].d();
                }
                View q3 = q(d2);
                if (q3 != null && q3 != A) {
                    return q3;
                }
            }
        }
        return null;
    }

    /* JADX WARN: Code restructure failed: missing block: B:257:0x040c, code lost:
    
        if (B0() != false) goto L250;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void S0(Ed ed, Jd jd, boolean z) {
        boolean z2;
        C0116ff c0116ff;
        int i;
        int i2;
        int i3;
        boolean z3;
        int k;
        int K0;
        int k2;
        int k3;
        C0116ff c0116ff2 = this.F;
        C0056cf c0056cf = this.H;
        if ((c0116ff2 != null || this.z != -1) && jd.b() == 0) {
            g0(ed);
            c0056cf.a();
            return;
        }
        boolean z4 = true;
        if (c0056cf.e && this.z == -1 && this.F == null) {
            z2 = false;
        } else {
            z2 = true;
        }
        F1 f1 = this.B;
        StaggeredGridLayoutManager staggeredGridLayoutManager = c0056cf.g;
        if (z2) {
            c0056cf.a();
            C0116ff c0116ff3 = this.F;
            if (c0116ff3 != null) {
                int i4 = c0116ff3.c;
                if (i4 > 0) {
                    if (i4 == this.p) {
                        for (int i5 = 0; i5 < this.p; i5++) {
                            this.q[i5].b();
                            C0116ff c0116ff4 = this.F;
                            int i6 = c0116ff4.d[i5];
                            if (i6 != Integer.MIN_VALUE) {
                                if (c0116ff4.i) {
                                    k3 = this.r.g();
                                } else {
                                    k3 = this.r.k();
                                }
                                i6 += k3;
                            }
                            Da da = this.q[i5];
                            da.b = i6;
                            da.c = i6;
                        }
                    } else {
                        c0116ff3.d = null;
                        c0116ff3.c = 0;
                        c0116ff3.e = 0;
                        c0116ff3.f = null;
                        c0116ff3.g = null;
                        c0116ff3.a = c0116ff3.b;
                    }
                }
                C0116ff c0116ff5 = this.F;
                this.E = c0116ff5.j;
                boolean z5 = c0116ff5.h;
                c(null);
                C0116ff c0116ff6 = this.F;
                if (c0116ff6 != null && c0116ff6.h != z5) {
                    c0116ff6.h = z5;
                }
                this.w = z5;
                l0();
                Y0();
                C0116ff c0116ff7 = this.F;
                int i7 = c0116ff7.a;
                if (i7 != -1) {
                    this.z = i7;
                    c0056cf.c = c0116ff7.i;
                } else {
                    c0056cf.c = this.f8x;
                }
                if (c0116ff7.e > 1) {
                    f1.b = c0116ff7.f;
                    f1.c = c0116ff7.g;
                }
            } else {
                Y0();
                c0056cf.c = this.f8x;
            }
            if (!jd.g && (i3 = this.z) != -1) {
                if (i3 >= 0 && i3 < jd.b()) {
                    C0116ff c0116ff8 = this.F;
                    if (c0116ff8 != null && c0116ff8.a != -1 && c0116ff8.c >= 1) {
                        c0056cf.b = Integer.MIN_VALUE;
                        c0056cf.a = this.z;
                    } else {
                        View q = q(this.z);
                        if (q != null) {
                            if (this.f8x) {
                                K0 = L0();
                            } else {
                                K0 = K0();
                            }
                            c0056cf.a = K0;
                            if (this.A != Integer.MIN_VALUE) {
                                if (c0056cf.c) {
                                    c0056cf.b = (this.r.g() - this.A) - this.r.b(q);
                                } else {
                                    c0056cf.b = (this.r.k() + this.A) - this.r.e(q);
                                }
                            } else if (this.r.c(q) > this.r.l()) {
                                if (c0056cf.c) {
                                    k2 = this.r.g();
                                } else {
                                    k2 = this.r.k();
                                }
                                c0056cf.b = k2;
                            } else {
                                int e = this.r.e(q) - this.r.k();
                                if (e < 0) {
                                    c0056cf.b = -e;
                                } else {
                                    int g = this.r.g() - this.r.b(q);
                                    if (g < 0) {
                                        c0056cf.b = g;
                                    } else {
                                        c0056cf.b = Integer.MIN_VALUE;
                                    }
                                }
                            }
                        } else {
                            int i8 = this.z;
                            c0056cf.a = i8;
                            int i9 = this.A;
                            if (i9 == Integer.MIN_VALUE) {
                                if (A0(i8) == 1) {
                                    z3 = true;
                                } else {
                                    z3 = false;
                                }
                                c0056cf.c = z3;
                                if (z3) {
                                    k = staggeredGridLayoutManager.r.g();
                                } else {
                                    k = staggeredGridLayoutManager.r.k();
                                }
                                c0056cf.b = k;
                            } else if (c0056cf.c) {
                                c0056cf.b = staggeredGridLayoutManager.r.g() - i9;
                            } else {
                                c0056cf.b = staggeredGridLayoutManager.r.k() + i9;
                            }
                            c0056cf.d = true;
                        }
                    }
                    c0056cf.e = true;
                } else {
                    this.z = -1;
                    this.A = Integer.MIN_VALUE;
                }
            }
            if (this.D) {
                int b = jd.b();
                for (int v = v() - 1; v >= 0; v--) {
                    i2 = AbstractC0475yd.H(u(v));
                    if (i2 >= 0 && i2 < b) {
                        break;
                    }
                }
                i2 = 0;
                c0056cf.a = i2;
                c0056cf.b = Integer.MIN_VALUE;
                c0056cf.e = true;
            } else {
                int b2 = jd.b();
                int v2 = v();
                for (int i10 = 0; i10 < v2; i10++) {
                    int H = AbstractC0475yd.H(u(i10));
                    if (H >= 0 && H < b2) {
                        i2 = H;
                        break;
                    }
                }
                i2 = 0;
                c0056cf.a = i2;
                c0056cf.b = Integer.MIN_VALUE;
                c0056cf.e = true;
            }
        }
        if (this.F == null && this.z == -1 && (c0056cf.c != this.D || Q0() != this.E)) {
            int[] iArr = (int[]) f1.b;
            if (iArr != null) {
                Arrays.fill(iArr, -1);
            }
            f1.c = null;
            c0056cf.d = true;
        }
        if (v() > 0 && ((c0116ff = this.F) == null || c0116ff.c < 1)) {
            if (c0056cf.d) {
                for (int i11 = 0; i11 < this.p; i11++) {
                    this.q[i11].b();
                    int i12 = c0056cf.b;
                    if (i12 != Integer.MIN_VALUE) {
                        Da da2 = this.q[i11];
                        da2.b = i12;
                        da2.c = i12;
                    }
                }
            } else if (!z2 && c0056cf.f != null) {
                for (int i13 = 0; i13 < this.p; i13++) {
                    Da da3 = this.q[i13];
                    da3.b();
                    int i14 = c0056cf.f[i13];
                    da3.b = i14;
                    da3.c = i14;
                }
            } else {
                for (int i15 = 0; i15 < this.p; i15++) {
                    Da da4 = this.q[i15];
                    boolean z6 = this.f8x;
                    int i16 = c0056cf.b;
                    if (z6) {
                        i = da4.g(Integer.MIN_VALUE);
                    } else {
                        i = da4.i(Integer.MIN_VALUE);
                    }
                    da4.b();
                    if (i != Integer.MIN_VALUE) {
                        StaggeredGridLayoutManager staggeredGridLayoutManager2 = (StaggeredGridLayoutManager) da4.g;
                        if ((!z6 || i >= staggeredGridLayoutManager2.r.g()) && (z6 || i <= staggeredGridLayoutManager2.r.k())) {
                            if (i16 != Integer.MIN_VALUE) {
                                i += i16;
                            }
                            da4.c = i;
                            da4.b = i;
                        }
                    }
                }
                Da[] daArr = this.q;
                int length = daArr.length;
                int[] iArr2 = c0056cf.f;
                if (iArr2 == null || iArr2.length < length) {
                    c0056cf.f = new int[staggeredGridLayoutManager.q.length];
                }
                for (int i17 = 0; i17 < length; i17++) {
                    c0056cf.f[i17] = daArr[i17].i(Integer.MIN_VALUE);
                }
            }
        }
        p(ed);
        N9 n9 = this.v;
        n9.a = false;
        int l = this.s.l();
        this.u = l / this.p;
        View.MeasureSpec.makeMeasureSpec(l, this.s.i());
        b1(c0056cf.a, jd);
        if (c0056cf.c) {
            a1(-1);
            F0(ed, n9, jd);
            a1(1);
            n9.c = c0056cf.a + n9.d;
            F0(ed, n9, jd);
        } else {
            a1(1);
            F0(ed, n9, jd);
            a1(-1);
            n9.c = c0056cf.a + n9.d;
            F0(ed, n9, jd);
        }
        if (this.s.i() != 1073741824) {
            int v3 = v();
            float f = 0.0f;
            for (int i18 = 0; i18 < v3; i18++) {
                View u = u(i18);
                float c = this.s.c(u);
                if (c >= f) {
                    ((C0076df) u.getLayoutParams()).getClass();
                    f = Math.max(f, c);
                }
            }
            int i19 = this.u;
            int round = Math.round(f * this.p);
            if (this.s.i() == Integer.MIN_VALUE) {
                round = Math.min(round, this.s.l());
            }
            this.u = round / this.p;
            View.MeasureSpec.makeMeasureSpec(round, this.s.i());
            if (this.u != i19) {
                for (int i20 = 0; i20 < v3; i20++) {
                    View u2 = u(i20);
                    C0076df c0076df = (C0076df) u2.getLayoutParams();
                    c0076df.getClass();
                    if (Q0() && this.t == 1) {
                        int i21 = -((this.p - 1) - c0076df.e.e);
                        u2.offsetLeftAndRight((this.u * i21) - (i21 * i19));
                    } else {
                        int i22 = c0076df.e.e;
                        int i23 = this.u * i22;
                        int i24 = i22 * i19;
                        if (this.t == 1) {
                            u2.offsetLeftAndRight(i23 - i24);
                        } else {
                            u2.offsetTopAndBottom(i23 - i24);
                        }
                    }
                }
            }
        }
        if (v() > 0) {
            if (this.f8x) {
                I0(ed, jd, true);
                J0(ed, jd, false);
            } else {
                J0(ed, jd, true);
                I0(ed, jd, false);
            }
        }
        if (z && !jd.g && this.C != 0 && v() > 0 && P0() != null) {
            RecyclerView recyclerView = this.b;
            if (recyclerView != null) {
                recyclerView.removeCallbacks(this.K);
            }
        }
        z4 = false;
        if (jd.g) {
            c0056cf.a();
        }
        this.D = c0056cf.c;
        this.E = Q0();
        if (z4) {
            c0056cf.a();
            S0(ed, jd, false);
        }
    }

    @Override // x.AbstractC0475yd
    public final void T(AccessibilityEvent accessibilityEvent) {
        super.T(accessibilityEvent);
        if (v() > 0) {
            View H0 = H0(false);
            View G0 = G0(false);
            if (H0 != null && G0 != null) {
                int H = AbstractC0475yd.H(H0);
                int H2 = AbstractC0475yd.H(G0);
                if (H < H2) {
                    accessibilityEvent.setFromIndex(H);
                    accessibilityEvent.setToIndex(H2);
                } else {
                    accessibilityEvent.setFromIndex(H2);
                    accessibilityEvent.setToIndex(H);
                }
            }
        }
    }

    public final boolean T0(int i) {
        boolean z;
        boolean z2;
        boolean z3;
        if (this.t == 0) {
            if (i == -1) {
                z3 = true;
            } else {
                z3 = false;
            }
            if (z3 == this.f8x) {
                return false;
            }
            return true;
        }
        if (i == -1) {
            z = true;
        } else {
            z = false;
        }
        if (z == this.f8x) {
            z2 = true;
        } else {
            z2 = false;
        }
        if (z2 != Q0()) {
            return false;
        }
        return true;
    }

    public final void U0(int i, Jd jd) {
        int K0;
        int i2;
        if (i > 0) {
            K0 = L0();
            i2 = 1;
        } else {
            K0 = K0();
            i2 = -1;
        }
        N9 n9 = this.v;
        n9.a = true;
        b1(K0, jd);
        a1(i2);
        n9.c = K0 + n9.d;
        n9.b = Math.abs(i);
    }

    @Override // x.AbstractC0475yd
    public final void V(Ed ed, Jd jd, View view, C c) {
        int i;
        int i2;
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        if (!(layoutParams instanceof C0076df)) {
            U(view, c);
            return;
        }
        C0076df c0076df = (C0076df) layoutParams;
        if (this.t == 0) {
            Da da = c0076df.e;
            if (da == null) {
                i2 = -1;
            } else {
                i2 = da.e;
            }
            c.i(B.D(false, i2, 1, -1, -1));
            return;
        }
        Da da2 = c0076df.e;
        if (da2 == null) {
            i = -1;
        } else {
            i = da2.e;
        }
        c.i(B.D(false, -1, -1, i, 1));
    }

    public final void V0(Ed ed, N9 n9) {
        int min;
        int min2;
        if (n9.a && !n9.i) {
            if (n9.b == 0) {
                if (n9.e == -1) {
                    W0(ed, n9.g);
                    return;
                } else {
                    X0(ed, n9.f);
                    return;
                }
            }
            int i = 1;
            if (n9.e == -1) {
                int i2 = n9.f;
                int i3 = this.q[0].i(i2);
                while (i < this.p) {
                    int i4 = this.q[i].i(i2);
                    if (i4 > i3) {
                        i3 = i4;
                    }
                    i++;
                }
                int i5 = i2 - i3;
                if (i5 < 0) {
                    min2 = n9.g;
                } else {
                    min2 = n9.g - Math.min(i5, n9.b);
                }
                W0(ed, min2);
                return;
            }
            int i6 = n9.g;
            int g = this.q[0].g(i6);
            while (i < this.p) {
                int g2 = this.q[i].g(i6);
                if (g2 < g) {
                    g = g2;
                }
                i++;
            }
            int i7 = g - n9.g;
            if (i7 < 0) {
                min = n9.f;
            } else {
                min = Math.min(i7, n9.b) + n9.f;
            }
            X0(ed, min);
        }
    }

    @Override // x.AbstractC0475yd
    public final void W(int i, int i2) {
        O0(i, i2, 1);
    }

    public final void W0(Ed ed, int i) {
        for (int v = v() - 1; v >= 0; v--) {
            View u = u(v);
            if (this.r.e(u) >= i && this.r.o(u) >= i) {
                C0076df c0076df = (C0076df) u.getLayoutParams();
                c0076df.getClass();
                if (((ArrayList) c0076df.e.f).size() == 1) {
                    return;
                }
                Da da = c0076df.e;
                ArrayList arrayList = (ArrayList) da.f;
                int size = arrayList.size();
                View view = (View) arrayList.remove(size - 1);
                C0076df c0076df2 = (C0076df) view.getLayoutParams();
                c0076df2.e = null;
                if (c0076df2.a.i() || c0076df2.a.l()) {
                    da.d -= ((StaggeredGridLayoutManager) da.g).r.c(view);
                }
                if (size == 1) {
                    da.b = Integer.MIN_VALUE;
                }
                da.c = Integer.MIN_VALUE;
                i0(u, ed);
            } else {
                return;
            }
        }
    }

    @Override // x.AbstractC0475yd
    public final void X() {
        F1 f1 = this.B;
        int[] iArr = (int[]) f1.b;
        if (iArr != null) {
            Arrays.fill(iArr, -1);
        }
        f1.c = null;
        l0();
    }

    public final void X0(Ed ed, int i) {
        while (v() > 0) {
            View u = u(0);
            if (this.r.b(u) <= i && this.r.n(u) <= i) {
                C0076df c0076df = (C0076df) u.getLayoutParams();
                c0076df.getClass();
                if (((ArrayList) c0076df.e.f).size() == 1) {
                    return;
                }
                Da da = c0076df.e;
                ArrayList arrayList = (ArrayList) da.f;
                View view = (View) arrayList.remove(0);
                C0076df c0076df2 = (C0076df) view.getLayoutParams();
                c0076df2.e = null;
                if (arrayList.size() == 0) {
                    da.c = Integer.MIN_VALUE;
                }
                if (c0076df2.a.i() || c0076df2.a.l()) {
                    da.d -= ((StaggeredGridLayoutManager) da.g).r.c(view);
                }
                da.b = Integer.MIN_VALUE;
                i0(u, ed);
            } else {
                return;
            }
        }
    }

    @Override // x.AbstractC0475yd
    public final void Y(int i, int i2) {
        O0(i, i2, 8);
    }

    public final void Y0() {
        if (this.t != 1 && Q0()) {
            this.f8x = !this.w;
        } else {
            this.f8x = this.w;
        }
    }

    @Override // x.AbstractC0475yd
    public final void Z(int i, int i2) {
        O0(i, i2, 2);
    }

    public final int Z0(int i, Ed ed, Jd jd) {
        if (v() == 0 || i == 0) {
            return 0;
        }
        U0(i, jd);
        N9 n9 = this.v;
        int F0 = F0(ed, n9, jd);
        if (n9.b >= F0) {
            if (i < 0) {
                i = -F0;
            } else {
                i = F0;
            }
        }
        this.r.p(-i);
        this.D = this.f8x;
        n9.b = 0;
        V0(ed, n9);
        return i;
    }

    @Override // x.Id
    public final PointF a(int i) {
        int A0 = A0(i);
        PointF pointF = new PointF();
        if (A0 == 0) {
            return null;
        }
        if (this.t == 0) {
            pointF.x = A0;
            pointF.y = 0.0f;
        } else {
            pointF.x = 0.0f;
            pointF.y = A0;
        }
        return pointF;
    }

    @Override // x.AbstractC0475yd
    public final void a0(int i, int i2) {
        O0(i, i2, 4);
    }

    public final void a1(int i) {
        boolean z;
        N9 n9 = this.v;
        n9.e = i;
        boolean z2 = this.f8x;
        int i2 = 1;
        if (i == -1) {
            z = true;
        } else {
            z = false;
        }
        if (z2 != z) {
            i2 = -1;
        }
        n9.d = i2;
    }

    @Override // x.AbstractC0475yd
    public final void b0(Ed ed, Jd jd) {
        S0(ed, jd, true);
    }

    public final void b1(int i, Jd jd) {
        boolean z;
        int i2;
        int i3;
        int i4;
        boolean z2;
        N9 n9 = this.v;
        boolean z3 = false;
        n9.b = 0;
        n9.c = i;
        C0151ha c0151ha = this.e;
        if (c0151ha != null && c0151ha.e) {
            z = true;
        } else {
            z = false;
        }
        if (z && (i4 = jd.a) != -1) {
            boolean z4 = this.f8x;
            if (i4 < i) {
                z2 = true;
            } else {
                z2 = false;
            }
            if (z4 == z2) {
                i2 = this.r.l();
                i3 = 0;
            } else {
                i3 = this.r.l();
                i2 = 0;
            }
        } else {
            i2 = 0;
            i3 = 0;
        }
        RecyclerView recyclerView = this.b;
        if (recyclerView != null && recyclerView.g) {
            n9.f = this.r.k() - i3;
            n9.g = this.r.g() + i2;
        } else {
            n9.g = this.r.f() + i2;
            n9.f = -i3;
        }
        n9.h = false;
        n9.a = true;
        if (this.r.i() == 0 && this.r.f() == 0) {
            z3 = true;
        }
        n9.i = z3;
    }

    @Override // x.AbstractC0475yd
    public final void c(String str) {
        if (this.F == null) {
            super.c(str);
        }
    }

    @Override // x.AbstractC0475yd
    public final void c0(Jd jd) {
        this.z = -1;
        this.A = Integer.MIN_VALUE;
        this.F = null;
        this.H.a();
    }

    public final void c1(Da da, int i, int i2) {
        int i3 = da.d;
        int i4 = da.e;
        if (i == -1) {
            int i5 = da.b;
            if (i5 == Integer.MIN_VALUE) {
                View view = (View) ((ArrayList) da.f).get(0);
                C0076df c0076df = (C0076df) view.getLayoutParams();
                da.b = ((StaggeredGridLayoutManager) da.g).r.e(view);
                c0076df.getClass();
                i5 = da.b;
            }
            if (i5 + i3 <= i2) {
                this.y.set(i4, false);
                return;
            }
            return;
        }
        int i6 = da.c;
        if (i6 == Integer.MIN_VALUE) {
            da.a();
            i6 = da.c;
        }
        if (i6 - i3 >= i2) {
            this.y.set(i4, false);
        }
    }

    @Override // x.AbstractC0475yd
    public final boolean d() {
        if (this.t == 0) {
            return true;
        }
        return false;
    }

    @Override // x.AbstractC0475yd
    public final void d0(Parcelable parcelable) {
        if (parcelable instanceof C0116ff) {
            this.F = (C0116ff) parcelable;
            l0();
        }
    }

    @Override // x.AbstractC0475yd
    public final boolean e() {
        if (this.t == 1) {
            return true;
        }
        return false;
    }

    /* JADX WARN: Type inference failed for: r0v1, types: [x.ff, android.os.Parcelable, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r1v28, types: [x.ff, android.os.Parcelable, java.lang.Object] */
    @Override // x.AbstractC0475yd
    public final Parcelable e0() {
        int K0;
        View H0;
        int i;
        int k;
        int[] iArr;
        C0116ff c0116ff = this.F;
        if (c0116ff != null) {
            ?? obj = new Object();
            obj.c = c0116ff.c;
            obj.a = c0116ff.a;
            obj.b = c0116ff.b;
            obj.d = c0116ff.d;
            obj.e = c0116ff.e;
            obj.f = c0116ff.f;
            obj.h = c0116ff.h;
            obj.i = c0116ff.i;
            obj.j = c0116ff.j;
            obj.g = c0116ff.g;
            return obj;
        }
        ?? obj2 = new Object();
        obj2.h = this.w;
        obj2.i = this.D;
        obj2.j = this.E;
        F1 f1 = this.B;
        if (f1 != null && (iArr = (int[]) f1.b) != null) {
            obj2.f = iArr;
            obj2.e = iArr.length;
            obj2.g = (ArrayList) f1.c;
        } else {
            obj2.e = 0;
        }
        int i2 = -1;
        if (v() > 0) {
            if (this.D) {
                K0 = L0();
            } else {
                K0 = K0();
            }
            obj2.a = K0;
            if (this.f8x) {
                H0 = G0(true);
            } else {
                H0 = H0(true);
            }
            if (H0 != null) {
                i2 = AbstractC0475yd.H(H0);
            }
            obj2.b = i2;
            int i3 = this.p;
            obj2.c = i3;
            obj2.d = new int[i3];
            for (int i4 = 0; i4 < this.p; i4++) {
                if (this.D) {
                    i = this.q[i4].g(Integer.MIN_VALUE);
                    if (i != Integer.MIN_VALUE) {
                        k = this.r.g();
                        i -= k;
                        obj2.d[i4] = i;
                    } else {
                        obj2.d[i4] = i;
                    }
                } else {
                    i = this.q[i4].i(Integer.MIN_VALUE);
                    if (i != Integer.MIN_VALUE) {
                        k = this.r.k();
                        i -= k;
                        obj2.d[i4] = i;
                    } else {
                        obj2.d[i4] = i;
                    }
                }
            }
        } else {
            obj2.a = -1;
            obj2.b = -1;
            obj2.c = 0;
        }
        return obj2;
    }

    @Override // x.AbstractC0475yd
    public final boolean f(C0494zd c0494zd) {
        return c0494zd instanceof C0076df;
    }

    @Override // x.AbstractC0475yd
    public final void f0(int i) {
        if (i == 0) {
            B0();
        }
    }

    @Override // x.AbstractC0475yd
    public final void h(int i, int i2, Jd jd, C0130g9 c0130g9) {
        N9 n9;
        int g;
        int i3;
        if (this.t != 0) {
            i = i2;
        }
        if (v() != 0 && i != 0) {
            U0(i, jd);
            int[] iArr = this.J;
            if (iArr == null || iArr.length < this.p) {
                this.J = new int[this.p];
            }
            int i4 = 0;
            int i5 = 0;
            while (true) {
                int i6 = this.p;
                n9 = this.v;
                if (i4 >= i6) {
                    break;
                }
                if (n9.d == -1) {
                    g = n9.f;
                    i3 = this.q[i4].i(g);
                } else {
                    g = this.q[i4].g(n9.g);
                    i3 = n9.g;
                }
                int i7 = g - i3;
                if (i7 >= 0) {
                    this.J[i5] = i7;
                    i5++;
                }
                i4++;
            }
            Arrays.sort(this.J, 0, i5);
            for (int i8 = 0; i8 < i5; i8++) {
                int i9 = n9.c;
                if (i9 >= 0 && i9 < jd.b()) {
                    c0130g9.a(n9.c, this.J[i8]);
                    n9.c += n9.d;
                } else {
                    return;
                }
            }
        }
    }

    @Override // x.AbstractC0475yd
    public final int j(Jd jd) {
        return C0(jd);
    }

    @Override // x.AbstractC0475yd
    public final int k(Jd jd) {
        return D0(jd);
    }

    @Override // x.AbstractC0475yd
    public final int l(Jd jd) {
        return E0(jd);
    }

    @Override // x.AbstractC0475yd
    public final int m(Jd jd) {
        return C0(jd);
    }

    @Override // x.AbstractC0475yd
    public final int m0(int i, Ed ed, Jd jd) {
        return Z0(i, ed, jd);
    }

    @Override // x.AbstractC0475yd
    public final int n(Jd jd) {
        return D0(jd);
    }

    @Override // x.AbstractC0475yd
    public final void n0(int i) {
        C0116ff c0116ff = this.F;
        if (c0116ff != null && c0116ff.a != i) {
            c0116ff.d = null;
            c0116ff.c = 0;
            c0116ff.a = -1;
            c0116ff.b = -1;
        }
        this.z = i;
        this.A = Integer.MIN_VALUE;
        l0();
    }

    @Override // x.AbstractC0475yd
    public final int o(Jd jd) {
        return E0(jd);
    }

    @Override // x.AbstractC0475yd
    public final int o0(int i, Ed ed, Jd jd) {
        return Z0(i, ed, jd);
    }

    @Override // x.AbstractC0475yd
    public final C0494zd r() {
        if (this.t == 0) {
            return new C0494zd(-2, -1);
        }
        return new C0494zd(-1, -2);
    }

    @Override // x.AbstractC0475yd
    public final void r0(Rect rect, int i, int i2) {
        int g;
        int g2;
        int i3 = this.p;
        int F = F() + E();
        int D = D() + G();
        if (this.t == 1) {
            int height = rect.height() + D;
            RecyclerView recyclerView = this.b;
            WeakHashMap weakHashMap = AbstractC0309ph.a;
            g2 = AbstractC0475yd.g(i2, height, recyclerView.getMinimumHeight());
            g = AbstractC0475yd.g(i, (this.u * i3) + F, this.b.getMinimumWidth());
        } else {
            int width = rect.width() + F;
            RecyclerView recyclerView2 = this.b;
            WeakHashMap weakHashMap2 = AbstractC0309ph.a;
            g = AbstractC0475yd.g(i, width, recyclerView2.getMinimumWidth());
            g2 = AbstractC0475yd.g(i2, (this.u * i3) + D, this.b.getMinimumHeight());
        }
        this.b.setMeasuredDimension(g, g2);
    }

    @Override // x.AbstractC0475yd
    public final C0494zd s(Context context, AttributeSet attributeSet) {
        return new C0494zd(context, attributeSet);
    }

    @Override // x.AbstractC0475yd
    public final C0494zd t(ViewGroup.LayoutParams layoutParams) {
        if (layoutParams instanceof ViewGroup.MarginLayoutParams) {
            return new C0494zd((ViewGroup.MarginLayoutParams) layoutParams);
        }
        return new C0494zd(layoutParams);
    }

    @Override // x.AbstractC0475yd
    public final int x(Ed ed, Jd jd) {
        if (this.t == 1) {
            return this.p;
        }
        return super.x(ed, jd);
    }

    @Override // x.AbstractC0475yd
    public final void x0(RecyclerView recyclerView, int i) {
        C0151ha c0151ha = new C0151ha(recyclerView.getContext());
        c0151ha.a = i;
        y0(c0151ha);
    }

    @Override // x.AbstractC0475yd
    public final boolean z0() {
        if (this.F == null) {
            return true;
        }
        return false;
    }
}
