package androidx.recyclerview.widget;

import android.R;
import android.animation.LayoutTransition;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.PointF;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Build;
import android.os.Parcelable;
import android.os.SystemClock;
import android.os.Trace;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.Display;
import android.view.FocusFinder;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityManager;
import android.view.animation.Interpolator;
import android.widget.EdgeEffect;
import android.widget.OverScroller;
import java.lang.ref.WeakReference;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.WeakHashMap;
import org.conscrypt.BuildConfig;
import x.AbstractC0060d;
import x.AbstractC0067d6;
import x.AbstractC0158hh;
import x.AbstractC0173id;
import x.AbstractC0175ig;
import x.AbstractC0195jh;
import x.AbstractC0203k6;
import x.AbstractC0309ph;
import x.AbstractC0324qd;
import x.AbstractC0328qh;
import x.AbstractC0399ud;
import x.AbstractC0418vd;
import x.AbstractC0475yd;
import x.Ad;
import x.B;
import x.Ba;
import x.Bd;
import x.C0107f6;
import x.C0130g9;
import x.C0151ha;
import x.C0240m5;
import x.C0294p2;
import x.C0299p7;
import x.C0305pd;
import x.C0314q3;
import x.C0367t0;
import x.C0380td;
import x.C0386u0;
import x.C0403uh;
import x.C0455xc;
import x.C0494zd;
import x.Cd;
import x.Dd;
import x.Ed;
import x.F1;
import x.Fd;
import x.G3;
import x.Gd;
import x.I2;
import x.Id;
import x.InterfaceC0361sd;
import x.InterpolatorC0286od;
import x.Jc;
import x.Jd;
import x.K4;
import x.Kd;
import x.Ld;
import x.Md;
import x.Od;
import x.Pe;
import x.RunnableC0169i9;
import x.Ub;
import x.Xb;

/* loaded from: classes.dex */
public class RecyclerView extends ViewGroup {
    public static final int[] s0 = {R.attr.nestedScrollingEnabled};
    public static final Class[] t0;
    public static final InterpolatorC0286od u0;
    public int A;
    public int B;
    public C0380td C;
    public EdgeEffect D;
    public EdgeEffect E;
    public EdgeEffect F;
    public EdgeEffect G;
    public AbstractC0399ud H;
    public int I;
    public int J;
    public VelocityTracker K;
    public int L;
    public int M;
    public int N;
    public int O;
    public int P;
    public Ad Q;
    public final int R;
    public final int S;
    public final float T;
    public final float U;
    public boolean V;
    public final Ld W;
    public final C0107f6 a;
    public RunnableC0169i9 a0;
    public final Ed b;
    public final C0130g9 b0;
    public Gd c;
    public final Jd c0;
    public final C0386u0 d;
    public Bd d0;
    public final C0294p2 e;
    public ArrayList e0;
    public final F1 f;
    public boolean f0;
    public boolean g;
    public boolean g0;
    public final Rect h;
    public final C0305pd h0;
    public final Rect i;
    public boolean i0;
    public final RectF j;
    public Od j0;
    public AbstractC0324qd k;
    public final int[] k0;
    public AbstractC0475yd l;
    public Ub l0;
    public final ArrayList m;
    public final int[] m0;
    public final ArrayList n;
    public final int[] n0;
    public C0299p7 o;
    public final int[] o0;
    public boolean p;
    public final ArrayList p0;
    public boolean q;
    public final I2 q0;
    public boolean r;
    public final C0305pd r0;
    public int s;
    public boolean t;
    public boolean u;
    public boolean v;
    public int w;

    /* renamed from: x, reason: collision with root package name */
    public final AccessibilityManager f7x;
    public boolean y;
    public boolean z;

    static {
        Class cls = Integer.TYPE;
        t0 = new Class[]{Context.class, AttributeSet.class, cls, cls};
        u0 = new InterpolatorC0286od(0);
    }

    public RecyclerView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, org.conscrypt.R.attr.recyclerViewStyle);
    }

    public static RecyclerView D(View view) {
        if (!(view instanceof ViewGroup)) {
            return null;
        }
        if (view instanceof RecyclerView) {
            return (RecyclerView) view;
        }
        ViewGroup viewGroup = (ViewGroup) view;
        int childCount = viewGroup.getChildCount();
        for (int i = 0; i < childCount; i++) {
            RecyclerView D = D(viewGroup.getChildAt(i));
            if (D != null) {
                return D;
            }
        }
        return null;
    }

    public static Md I(View view) {
        if (view == null) {
            return null;
        }
        return ((C0494zd) view.getLayoutParams()).a;
    }

    private Ub getScrollingChildHelper() {
        if (this.l0 == null) {
            this.l0 = new Ub(this);
        }
        return this.l0;
    }

    public static void j(Md md) {
        WeakReference weakReference = md.b;
        if (weakReference != null) {
            View view = (View) weakReference.get();
            while (view != null) {
                if (view == md.a) {
                    return;
                }
                Object parent = view.getParent();
                if (parent instanceof View) {
                    view = (View) parent;
                } else {
                    view = null;
                }
            }
            md.b = null;
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:11:?, code lost:
    
        return r3;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final View A(View view) {
        ViewParent parent = view.getParent();
        while (parent != null && parent != this && (parent instanceof View)) {
            view = parent;
            parent = view.getParent();
        }
        return null;
    }

    /* JADX WARN: Removed duplicated region for block: B:16:0x005e A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:20:0x0061 A[SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final boolean B(MotionEvent motionEvent) {
        int action = motionEvent.getAction();
        ArrayList arrayList = this.n;
        int size = arrayList.size();
        for (int i = 0; i < size; i++) {
            C0299p7 c0299p7 = (C0299p7) arrayList.get(i);
            int i2 = c0299p7.v;
            if (i2 == 1) {
                boolean d = c0299p7.d(motionEvent.getX(), motionEvent.getY());
                boolean c = c0299p7.c(motionEvent.getX(), motionEvent.getY());
                if (motionEvent.getAction() == 0 && (d || c)) {
                    if (c) {
                        c0299p7.w = 1;
                        c0299p7.p = (int) motionEvent.getX();
                    } else if (d) {
                        c0299p7.w = 2;
                        c0299p7.m = (int) motionEvent.getY();
                    }
                    c0299p7.f(2);
                    if (action == 3) {
                        this.o = c0299p7;
                        return true;
                    }
                }
            } else {
                if (i2 != 2) {
                    continue;
                }
                if (action == 3) {
                }
            }
        }
        return false;
    }

    public final void C(int[] iArr) {
        int m = this.e.m();
        if (m == 0) {
            iArr[0] = -1;
            iArr[1] = -1;
            return;
        }
        int i = Integer.MAX_VALUE;
        int i2 = Integer.MIN_VALUE;
        for (int i3 = 0; i3 < m; i3++) {
            Md I = I(this.e.l(i3));
            if (!I.p()) {
                int b = I.b();
                if (b < i) {
                    i = b;
                }
                if (b > i2) {
                    i2 = b;
                }
            }
        }
        iArr[0] = i;
        iArr[1] = i2;
    }

    public final Md E(int i) {
        Md md = null;
        if (this.y) {
            return null;
        }
        int u = this.e.u();
        for (int i2 = 0; i2 < u; i2++) {
            Md I = I(this.e.t(i2));
            if (I != null && !I.i() && F(I) == i) {
                if (((ArrayList) this.e.d).contains(I.a)) {
                    md = I;
                } else {
                    return I;
                }
            }
        }
        return md;
    }

    public final int F(Md md) {
        if (md.d(524) || !md.f()) {
            return -1;
        }
        C0386u0 c0386u0 = this.d;
        int i = md.c;
        ArrayList arrayList = c0386u0.b;
        int size = arrayList.size();
        for (int i2 = 0; i2 < size; i2++) {
            C0367t0 c0367t0 = (C0367t0) arrayList.get(i2);
            int i3 = c0367t0.a;
            if (i3 != 1) {
                if (i3 != 2) {
                    if (i3 == 8) {
                        int i4 = c0367t0.b;
                        if (i4 == i) {
                            i = c0367t0.c;
                        } else {
                            if (i4 < i) {
                                i--;
                            }
                            if (c0367t0.c <= i) {
                                i++;
                            }
                        }
                    }
                } else {
                    int i5 = c0367t0.b;
                    if (i5 <= i) {
                        int i6 = c0367t0.c;
                        if (i5 + i6 > i) {
                            return -1;
                        }
                        i -= i6;
                    } else {
                        continue;
                    }
                }
            } else if (c0367t0.b <= i) {
                i += c0367t0.c;
            }
        }
        return i;
    }

    public final long G(Md md) {
        if (this.k.b) {
            return md.e;
        }
        return md.c;
    }

    public final Md H(View view) {
        ViewParent parent = view.getParent();
        if (parent != null && parent != this) {
            throw new IllegalArgumentException("View " + view + " is not a direct child of " + this);
        }
        return I(view);
    }

    public final Rect J(View view) {
        C0494zd c0494zd = (C0494zd) view.getLayoutParams();
        boolean z = c0494zd.c;
        Rect rect = c0494zd.b;
        if (!z) {
            return rect;
        }
        if (this.c0.g && (c0494zd.a.l() || c0494zd.a.g())) {
            return rect;
        }
        rect.set(0, 0, 0, 0);
        ArrayList arrayList = this.m;
        int size = arrayList.size();
        for (int i = 0; i < size; i++) {
            Rect rect2 = this.h;
            rect2.set(0, 0, 0, 0);
            ((AbstractC0418vd) arrayList.get(i)).getClass();
            ((C0494zd) view.getLayoutParams()).a.getClass();
            rect2.set(0, 0, 0, 0);
            rect.left += rect2.left;
            rect.top += rect2.top;
            rect.right += rect2.right;
            rect.bottom += rect2.bottom;
        }
        c0494zd.c = false;
        return rect;
    }

    public final boolean K() {
        if (this.r && !this.y && !this.d.f()) {
            return false;
        }
        return true;
    }

    public final boolean L() {
        if (this.A > 0) {
            return true;
        }
        return false;
    }

    public final void M(int i) {
        if (this.l == null) {
            return;
        }
        setScrollState(2);
        this.l.n0(i);
        awakenScrollBars();
    }

    public final void N() {
        int u = this.e.u();
        for (int i = 0; i < u; i++) {
            ((C0494zd) this.e.t(i).getLayoutParams()).c = true;
        }
        ArrayList arrayList = this.b.c;
        int size = arrayList.size();
        for (int i2 = 0; i2 < size; i2++) {
            C0494zd c0494zd = (C0494zd) ((Md) arrayList.get(i2)).a.getLayoutParams();
            if (c0494zd != null) {
                c0494zd.c = true;
            }
        }
    }

    public final void O(int i, int i2, boolean z) {
        int i3 = i + i2;
        int u = this.e.u();
        for (int i4 = 0; i4 < u; i4++) {
            Md I = I(this.e.t(i4));
            if (I != null && !I.p()) {
                int i5 = I.c;
                Jd jd = this.c0;
                if (i5 >= i3) {
                    I.m(-i2, z);
                    jd.f = true;
                } else if (i5 >= i) {
                    I.a(8);
                    I.m(-i2, z);
                    I.c = i - 1;
                    jd.f = true;
                }
            }
        }
        Ed ed = this.b;
        ArrayList arrayList = ed.c;
        for (int size = arrayList.size() - 1; size >= 0; size--) {
            Md md = (Md) arrayList.get(size);
            if (md != null) {
                int i6 = md.c;
                if (i6 >= i3) {
                    md.m(-i2, z);
                } else if (i6 >= i) {
                    md.a(8);
                    ed.e(size);
                }
            }
        }
        requestLayout();
    }

    public final void P() {
        this.A++;
    }

    public final void Q(boolean z) {
        int i;
        AccessibilityManager accessibilityManager;
        int i2 = this.A - 1;
        this.A = i2;
        if (i2 < 1) {
            this.A = 0;
            if (z) {
                int i3 = this.w;
                this.w = 0;
                if (i3 != 0 && (accessibilityManager = this.f7x) != null && accessibilityManager.isEnabled()) {
                    AccessibilityEvent obtain = AccessibilityEvent.obtain();
                    obtain.setEventType(2048);
                    obtain.setContentChangeTypes(i3);
                    sendAccessibilityEventUnchecked(obtain);
                }
                ArrayList arrayList = this.p0;
                for (int size = arrayList.size() - 1; size >= 0; size--) {
                    Md md = (Md) arrayList.get(size);
                    if (md.a.getParent() == this && !md.p() && (i = md.q) != -1) {
                        WeakHashMap weakHashMap = AbstractC0309ph.a;
                        md.a.setImportantForAccessibility(i);
                        md.q = -1;
                    }
                }
                arrayList.clear();
            }
        }
    }

    public final void R(MotionEvent motionEvent) {
        int i;
        int actionIndex = motionEvent.getActionIndex();
        if (motionEvent.getPointerId(actionIndex) == this.J) {
            if (actionIndex == 0) {
                i = 1;
            } else {
                i = 0;
            }
            this.J = motionEvent.getPointerId(i);
            int x2 = (int) (motionEvent.getX(i) + 0.5f);
            this.N = x2;
            this.L = x2;
            int y = (int) (motionEvent.getY(i) + 0.5f);
            this.O = y;
            this.M = y;
        }
    }

    public final void S() {
        if (!this.i0 && this.p) {
            WeakHashMap weakHashMap = AbstractC0309ph.a;
            postOnAnimation(this.q0);
            this.i0 = true;
        }
    }

    public final void T(Md md, Xb xb) {
        md.j &= -8193;
        boolean z = this.c0.h;
        F1 f1 = this.f;
        if (z && md.l() && !md.i() && !md.p()) {
            ((Ba) f1.c).d(G(md), md);
        }
        Pe pe = (Pe) f1.b;
        C0403uh c0403uh = (C0403uh) pe.get(md);
        if (c0403uh == null) {
            c0403uh = C0403uh.a();
            pe.put(md, c0403uh);
        }
        c0403uh.b = xb;
        c0403uh.a |= 4;
    }

    public final void U(View view, View view2) {
        View view3;
        boolean z;
        if (view2 != null) {
            view3 = view2;
        } else {
            view3 = view;
        }
        int width = view3.getWidth();
        int height = view3.getHeight();
        Rect rect = this.h;
        rect.set(0, 0, width, height);
        ViewGroup.LayoutParams layoutParams = view3.getLayoutParams();
        if (layoutParams instanceof C0494zd) {
            C0494zd c0494zd = (C0494zd) layoutParams;
            if (!c0494zd.c) {
                int i = rect.left;
                Rect rect2 = c0494zd.b;
                rect.left = i - rect2.left;
                rect.right += rect2.right;
                rect.top -= rect2.top;
                rect.bottom += rect2.bottom;
            }
        }
        if (view2 != null) {
            offsetDescendantRectToMyCoords(view2, rect);
            offsetRectIntoDescendantCoords(view, rect);
        }
        AbstractC0475yd abstractC0475yd = this.l;
        boolean z2 = !this.r;
        if (view2 == null) {
            z = true;
        } else {
            z = false;
        }
        abstractC0475yd.k0(this, view, this.h, z2, z);
    }

    public final void V() {
        VelocityTracker velocityTracker = this.K;
        if (velocityTracker != null) {
            velocityTracker.clear();
        }
        boolean z = false;
        c0(0);
        EdgeEffect edgeEffect = this.D;
        if (edgeEffect != null) {
            edgeEffect.onRelease();
            z = this.D.isFinished();
        }
        EdgeEffect edgeEffect2 = this.E;
        if (edgeEffect2 != null) {
            edgeEffect2.onRelease();
            z |= this.E.isFinished();
        }
        EdgeEffect edgeEffect3 = this.F;
        if (edgeEffect3 != null) {
            edgeEffect3.onRelease();
            z |= this.F.isFinished();
        }
        EdgeEffect edgeEffect4 = this.G;
        if (edgeEffect4 != null) {
            edgeEffect4.onRelease();
            z |= this.G.isFinished();
        }
        if (z) {
            WeakHashMap weakHashMap = AbstractC0309ph.a;
            postInvalidateOnAnimation();
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:22:0x00d4  */
    /* JADX WARN: Removed duplicated region for block: B:25:0x0108  */
    /* JADX WARN: Removed duplicated region for block: B:30:0x00eb  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final boolean W(int i, int i2, MotionEvent motionEvent) {
        int i3;
        int i4;
        int i5;
        int i6;
        boolean z;
        boolean z2;
        m();
        AbstractC0324qd abstractC0324qd = this.k;
        int[] iArr = this.o0;
        if (abstractC0324qd != null) {
            iArr[0] = 0;
            iArr[1] = 0;
            X(i, i2, iArr);
            int i7 = iArr[0];
            int i8 = iArr[1];
            i3 = i7;
            i4 = i8;
            i5 = i - i7;
            i6 = i2 - i8;
        } else {
            i3 = 0;
            i4 = 0;
            i5 = 0;
            i6 = 0;
        }
        if (!this.m.isEmpty()) {
            invalidate();
        }
        iArr[0] = 0;
        iArr[1] = 0;
        s(i3, i4, i5, i6, this.m0, 0, iArr);
        int i9 = iArr[0];
        int i10 = i5 - i9;
        int i11 = iArr[1];
        int i12 = i6 - i11;
        if (i9 == 0 && i11 == 0) {
            z = false;
        } else {
            z = true;
        }
        int i13 = this.N;
        int[] iArr2 = this.m0;
        int i14 = iArr2[0];
        this.N = i13 - i14;
        int i15 = this.O;
        int i16 = iArr2[1];
        this.O = i15 - i16;
        int[] iArr3 = this.n0;
        iArr3[0] = iArr3[0] + i14;
        iArr3[1] = iArr3[1] + i16;
        if (getOverScrollMode() != 2) {
            if (motionEvent != null && (motionEvent.getSource() & 8194) != 8194) {
                float x2 = motionEvent.getX();
                float f = i10;
                float y = motionEvent.getY();
                float f2 = i12;
                if (f < 0.0f) {
                    v();
                    AbstractC0067d6.a(this.D, (-f) / getWidth(), 1.0f - (y / getHeight()));
                } else if (f > 0.0f) {
                    w();
                    AbstractC0067d6.a(this.F, f / getWidth(), y / getHeight());
                } else {
                    z2 = false;
                    if (f2 >= 0.0f) {
                        x();
                        AbstractC0067d6.a(this.E, (-f2) / getHeight(), x2 / getWidth());
                    } else {
                        if (f2 > 0.0f) {
                            u();
                            AbstractC0067d6.a(this.G, f2 / getHeight(), 1.0f - (x2 / getWidth()));
                        }
                        if (!z2 || f != 0.0f || f2 != 0.0f) {
                            WeakHashMap weakHashMap = AbstractC0309ph.a;
                            postInvalidateOnAnimation();
                        }
                    }
                    z2 = true;
                    if (!z2) {
                    }
                    WeakHashMap weakHashMap2 = AbstractC0309ph.a;
                    postInvalidateOnAnimation();
                }
                z2 = true;
                if (f2 >= 0.0f) {
                }
                z2 = true;
                if (!z2) {
                }
                WeakHashMap weakHashMap22 = AbstractC0309ph.a;
                postInvalidateOnAnimation();
            }
            l(i, i2);
        }
        if (i3 != 0 || i4 != 0) {
            t(i3, i4);
        }
        if (!awakenScrollBars()) {
            invalidate();
        }
        if (!z && i3 == 0 && i4 == 0) {
            return false;
        }
        return true;
    }

    public final void X(int i, int i2, int[] iArr) {
        int i3;
        int i4;
        Md md;
        C0294p2 c0294p2 = this.e;
        a0();
        P();
        int i5 = AbstractC0175ig.a;
        Trace.beginSection("RV Scroll");
        Jd jd = this.c0;
        z(jd);
        Ed ed = this.b;
        if (i != 0) {
            i3 = this.l.m0(i, ed, jd);
        } else {
            i3 = 0;
        }
        if (i2 != 0) {
            i4 = this.l.o0(i2, ed, jd);
        } else {
            i4 = 0;
        }
        Trace.endSection();
        int m = c0294p2.m();
        for (int i6 = 0; i6 < m; i6++) {
            View l = c0294p2.l(i6);
            Md H = H(l);
            if (H != null && (md = H.i) != null) {
                int left = l.getLeft();
                int top = l.getTop();
                View view = md.a;
                if (left != view.getLeft() || top != view.getTop()) {
                    view.layout(left, top, view.getWidth() + left, view.getHeight() + top);
                }
            }
        }
        Q(true);
        b0(false);
        if (iArr != null) {
            iArr[0] = i3;
            iArr[1] = i4;
        }
    }

    public final void Y(int i) {
        C0151ha c0151ha;
        if (this.u) {
            return;
        }
        setScrollState(0);
        Ld ld = this.W;
        ld.g.removeCallbacks(ld);
        ld.c.abortAnimation();
        AbstractC0475yd abstractC0475yd = this.l;
        if (abstractC0475yd != null && (c0151ha = abstractC0475yd.e) != null) {
            c0151ha.i();
        }
        AbstractC0475yd abstractC0475yd2 = this.l;
        if (abstractC0475yd2 == null) {
            Log.e("RecyclerView", "Cannot scroll to position a LayoutManager set. Call setLayoutManager with a non-null argument.");
        } else {
            abstractC0475yd2.n0(i);
            awakenScrollBars();
        }
    }

    public final void Z(int i, int i2, boolean z) {
        AbstractC0475yd abstractC0475yd = this.l;
        if (abstractC0475yd == null) {
            Log.e("RecyclerView", "Cannot smooth scroll without a LayoutManager set. Call setLayoutManager with a non-null argument.");
            return;
        }
        if (this.u) {
            return;
        }
        int i3 = 0;
        if (!abstractC0475yd.d()) {
            i = 0;
        }
        if (!this.l.e()) {
            i2 = 0;
        }
        if (i != 0 || i2 != 0) {
            if (z) {
                if (i != 0) {
                    i3 = 1;
                }
                if (i2 != 0) {
                    i3 |= 2;
                }
                getScrollingChildHelper().g(i3, 1);
            }
            this.W.b(i, i2, Integer.MIN_VALUE, null);
        }
    }

    public final void a0() {
        int i = this.s + 1;
        this.s = i;
        if (i == 1 && !this.u) {
            this.t = false;
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void addFocusables(ArrayList arrayList, int i, int i2) {
        AbstractC0475yd abstractC0475yd = this.l;
        if (abstractC0475yd != null) {
            abstractC0475yd.getClass();
        }
        super.addFocusables(arrayList, i, i2);
    }

    public final void b0(boolean z) {
        if (this.s < 1) {
            this.s = 1;
        }
        if (!z && !this.u) {
            this.t = false;
        }
        if (this.s == 1) {
            if (z && this.t && !this.u && this.l != null && this.k != null) {
                o();
            }
            if (!this.u) {
                this.t = false;
            }
        }
        this.s--;
    }

    public final void c0(int i) {
        getScrollingChildHelper().h(i);
    }

    @Override // android.view.ViewGroup
    public final boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        if ((layoutParams instanceof C0494zd) && this.l.f((C0494zd) layoutParams)) {
            return true;
        }
        return false;
    }

    @Override // android.view.View
    public final int computeHorizontalScrollExtent() {
        AbstractC0475yd abstractC0475yd = this.l;
        if (abstractC0475yd == null || !abstractC0475yd.d()) {
            return 0;
        }
        return this.l.j(this.c0);
    }

    @Override // android.view.View
    public final int computeHorizontalScrollOffset() {
        AbstractC0475yd abstractC0475yd = this.l;
        if (abstractC0475yd == null || !abstractC0475yd.d()) {
            return 0;
        }
        return this.l.k(this.c0);
    }

    @Override // android.view.View
    public final int computeHorizontalScrollRange() {
        AbstractC0475yd abstractC0475yd = this.l;
        if (abstractC0475yd == null || !abstractC0475yd.d()) {
            return 0;
        }
        return this.l.l(this.c0);
    }

    @Override // android.view.View
    public final int computeVerticalScrollExtent() {
        AbstractC0475yd abstractC0475yd = this.l;
        if (abstractC0475yd == null || !abstractC0475yd.e()) {
            return 0;
        }
        return this.l.m(this.c0);
    }

    @Override // android.view.View
    public final int computeVerticalScrollOffset() {
        AbstractC0475yd abstractC0475yd = this.l;
        if (abstractC0475yd == null || !abstractC0475yd.e()) {
            return 0;
        }
        return this.l.n(this.c0);
    }

    @Override // android.view.View
    public final int computeVerticalScrollRange() {
        AbstractC0475yd abstractC0475yd = this.l;
        if (abstractC0475yd == null || !abstractC0475yd.e()) {
            return 0;
        }
        return this.l.o(this.c0);
    }

    @Override // android.view.View
    public final boolean dispatchNestedFling(float f, float f2, boolean z) {
        return getScrollingChildHelper().a(f, f2, z);
    }

    @Override // android.view.View
    public final boolean dispatchNestedPreFling(float f, float f2) {
        return getScrollingChildHelper().b(f, f2);
    }

    @Override // android.view.View
    public final boolean dispatchNestedPreScroll(int i, int i2, int[] iArr, int[] iArr2) {
        return getScrollingChildHelper().c(i, i2, 0, iArr, iArr2);
    }

    @Override // android.view.View
    public final boolean dispatchNestedScroll(int i, int i2, int i3, int i4, int[] iArr) {
        return getScrollingChildHelper().d(i, i2, i3, i4, iArr, 0, null);
    }

    @Override // android.view.View
    public final boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        onPopulateAccessibilityEvent(accessibilityEvent);
        return true;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void dispatchRestoreInstanceState(SparseArray sparseArray) {
        dispatchThawSelfOnly(sparseArray);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void dispatchSaveInstanceState(SparseArray sparseArray) {
        dispatchFreezeSelfOnly(sparseArray);
    }

    @Override // android.view.View
    public final void draw(Canvas canvas) {
        boolean z;
        int i;
        boolean z2;
        boolean z3;
        int i2;
        boolean z4 = true;
        super.draw(canvas);
        ArrayList arrayList = this.m;
        int size = arrayList.size();
        boolean z5 = false;
        for (int i3 = 0; i3 < size; i3++) {
            ((AbstractC0418vd) arrayList.get(i3)).b(canvas, this);
        }
        EdgeEffect edgeEffect = this.D;
        if (edgeEffect != null && !edgeEffect.isFinished()) {
            int save = canvas.save();
            if (this.g) {
                i2 = getPaddingBottom();
            } else {
                i2 = 0;
            }
            canvas.rotate(270.0f);
            canvas.translate((-getHeight()) + i2, 0.0f);
            EdgeEffect edgeEffect2 = this.D;
            if (edgeEffect2 != null && edgeEffect2.draw(canvas)) {
                z = true;
            } else {
                z = false;
            }
            canvas.restoreToCount(save);
        } else {
            z = false;
        }
        EdgeEffect edgeEffect3 = this.E;
        if (edgeEffect3 != null && !edgeEffect3.isFinished()) {
            int save2 = canvas.save();
            if (this.g) {
                canvas.translate(getPaddingLeft(), getPaddingTop());
            }
            EdgeEffect edgeEffect4 = this.E;
            if (edgeEffect4 != null && edgeEffect4.draw(canvas)) {
                z3 = true;
            } else {
                z3 = false;
            }
            z |= z3;
            canvas.restoreToCount(save2);
        }
        EdgeEffect edgeEffect5 = this.F;
        if (edgeEffect5 != null && !edgeEffect5.isFinished()) {
            int save3 = canvas.save();
            int width = getWidth();
            if (this.g) {
                i = getPaddingTop();
            } else {
                i = 0;
            }
            canvas.rotate(90.0f);
            canvas.translate(-i, -width);
            EdgeEffect edgeEffect6 = this.F;
            if (edgeEffect6 != null && edgeEffect6.draw(canvas)) {
                z2 = true;
            } else {
                z2 = false;
            }
            z |= z2;
            canvas.restoreToCount(save3);
        }
        EdgeEffect edgeEffect7 = this.G;
        if (edgeEffect7 != null && !edgeEffect7.isFinished()) {
            int save4 = canvas.save();
            canvas.rotate(180.0f);
            if (this.g) {
                canvas.translate(getPaddingRight() + (-getWidth()), getPaddingBottom() + (-getHeight()));
            } else {
                canvas.translate(-getWidth(), -getHeight());
            }
            EdgeEffect edgeEffect8 = this.G;
            if (edgeEffect8 != null && edgeEffect8.draw(canvas)) {
                z5 = true;
            }
            z |= z5;
            canvas.restoreToCount(save4);
        }
        if (z || this.H == null || arrayList.size() <= 0 || !this.H.f()) {
            z4 = z;
        }
        if (z4) {
            WeakHashMap weakHashMap = AbstractC0309ph.a;
            postInvalidateOnAnimation();
        }
    }

    @Override // android.view.ViewGroup
    public final boolean drawChild(Canvas canvas, View view, long j) {
        return super.drawChild(canvas, view, j);
    }

    public final void f(Md md) {
        boolean z;
        View view = md.a;
        if (view.getParent() == this) {
            z = true;
        } else {
            z = false;
        }
        this.b.j(H(view));
        if (md.k()) {
            this.e.g(view, -1, view.getLayoutParams(), true);
            return;
        }
        if (!z) {
            this.e.f(view, -1, true);
            return;
        }
        C0294p2 c0294p2 = this.e;
        int indexOfChild = ((C0305pd) c0294p2.b).a.indexOfChild(view);
        if (indexOfChild >= 0) {
            ((G3) c0294p2.c).h(indexOfChild);
            c0294p2.w(view);
        } else {
            throw new IllegalArgumentException("view is not a child, cannot hide " + view);
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:103:0x018a, code lost:
    
        if ((r5 * r6) < 0) goto L135;
     */
    /* JADX WARN: Code restructure failed: missing block: B:107:0x0192, code lost:
    
        if ((r5 * r6) > 0) goto L135;
     */
    /* JADX WARN: Code restructure failed: missing block: B:94:0x015e, code lost:
    
        if (r7 > 0) goto L136;
     */
    /* JADX WARN: Code restructure failed: missing block: B:97:0x017c, code lost:
    
        if (r5 > 0) goto L136;
     */
    /* JADX WARN: Code restructure failed: missing block: B:98:0x017f, code lost:
    
        if (r7 < 0) goto L136;
     */
    /* JADX WARN: Code restructure failed: missing block: B:99:0x0182, code lost:
    
        if (r5 < 0) goto L136;
     */
    /* JADX WARN: Removed duplicated region for block: B:26:0x005f  */
    /* JADX WARN: Removed duplicated region for block: B:28:0x0064  */
    /* JADX WARN: Removed duplicated region for block: B:31:0x006a  */
    /* JADX WARN: Removed duplicated region for block: B:34:0x0074  */
    /* JADX WARN: Removed duplicated region for block: B:35:0x0076  */
    /* JADX WARN: Removed duplicated region for block: B:36:0x006d  */
    /* JADX WARN: Removed duplicated region for block: B:37:0x0066  */
    /* JADX WARN: Removed duplicated region for block: B:38:0x0061  */
    /* JADX WARN: Removed duplicated region for block: B:40:0x0079  */
    /* JADX WARN: Removed duplicated region for block: B:61:0x0199  */
    /* JADX WARN: Removed duplicated region for block: B:63:? A[RETURN, SYNTHETIC] */
    @Override // android.view.ViewGroup, android.view.ViewParent
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final View focusSearch(View view, int i) {
        boolean z;
        View view2;
        int i2;
        int i3;
        char c;
        boolean z2;
        boolean z3;
        boolean z4;
        int i4;
        int i5;
        this.l.getClass();
        boolean z5 = true;
        if (this.k != null && this.l != null && !L() && !this.u) {
            z = true;
        } else {
            z = false;
        }
        FocusFinder focusFinder = FocusFinder.getInstance();
        Jd jd = this.c0;
        Ed ed = this.b;
        if (z && (i == 2 || i == 1)) {
            if (this.l.e()) {
                if (i == 2) {
                    i5 = 130;
                } else {
                    i5 = 33;
                }
                if (focusFinder.findNextFocus(this, view, i5) == null) {
                    z2 = true;
                    if (!z2 && this.l.d()) {
                        if (this.l.C() != 1) {
                            z3 = true;
                        } else {
                            z3 = false;
                        }
                        if (i != 2) {
                            z4 = true;
                        } else {
                            z4 = false;
                        }
                        if (!(z3 ^ z4)) {
                            i4 = 66;
                        } else {
                            i4 = 17;
                        }
                        if (focusFinder.findNextFocus(this, view, i4) != null) {
                            z2 = true;
                        } else {
                            z2 = false;
                        }
                    }
                    if (z2) {
                        m();
                        if (A(view) == null) {
                            return null;
                        }
                        a0();
                        this.l.S(view, i, ed, jd);
                        b0(false);
                    }
                    view2 = focusFinder.findNextFocus(this, view, i);
                }
            }
            z2 = false;
            if (!z2) {
                if (this.l.C() != 1) {
                }
                if (i != 2) {
                }
                if (!(z3 ^ z4)) {
                }
                if (focusFinder.findNextFocus(this, view, i4) != null) {
                }
            }
            if (z2) {
            }
            view2 = focusFinder.findNextFocus(this, view, i);
        } else {
            View findNextFocus = focusFinder.findNextFocus(this, view, i);
            if (findNextFocus == null && z) {
                m();
                if (A(view) == null) {
                    return null;
                }
                a0();
                view2 = this.l.S(view, i, ed, jd);
                b0(false);
            } else {
                view2 = findNextFocus;
            }
        }
        if (view2 != null && !view2.hasFocusable()) {
            if (getFocusedChild() == null) {
                return super.focusSearch(view, i);
            }
            U(view2, null);
            return view;
        }
        if (view2 != null && view2 != this) {
            if (A(view2) == null) {
                z5 = false;
            } else if (view != null && A(view) != null) {
                int width = view.getWidth();
                int height = view.getHeight();
                Rect rect = this.h;
                rect.set(0, 0, width, height);
                int width2 = view2.getWidth();
                int height2 = view2.getHeight();
                Rect rect2 = this.i;
                rect2.set(0, 0, width2, height2);
                offsetDescendantRectToMyCoords(view, rect);
                offsetDescendantRectToMyCoords(view2, rect2);
                if (this.l.C() == 1) {
                    i2 = -1;
                } else {
                    i2 = 1;
                }
                int i6 = rect.left;
                int i7 = rect2.left;
                if ((i6 < i7 || rect.right <= i7) && rect.right < rect2.right) {
                    i3 = 1;
                } else {
                    int i8 = rect.right;
                    int i9 = rect2.right;
                    if ((i8 > i9 || i6 >= i9) && i6 > i7) {
                        i3 = -1;
                    } else {
                        i3 = 0;
                    }
                }
                int i10 = rect.top;
                int i11 = rect2.top;
                if ((i10 < i11 || rect.bottom <= i11) && rect.bottom < rect2.bottom) {
                    c = 1;
                } else {
                    int i12 = rect.bottom;
                    int i13 = rect2.bottom;
                    if ((i12 > i13 || i10 >= i13) && i10 > i11) {
                        c = 65535;
                    } else {
                        c = 0;
                    }
                }
                if (i != 1) {
                    if (i != 2) {
                        if (i != 17) {
                            if (i != 33) {
                                if (i != 66) {
                                    if (i != 130) {
                                        throw new IllegalArgumentException("Invalid direction: " + i + y());
                                    }
                                }
                            }
                        }
                    } else if (c <= 0) {
                        if (c == 0) {
                        }
                    }
                } else if (c >= 0) {
                    if (c == 0) {
                    }
                }
            }
            if (z5) {
                return super.focusSearch(view, i);
            }
            return view2;
        }
        z5 = false;
        if (z5) {
        }
    }

    public final void g(AbstractC0418vd abstractC0418vd) {
        AbstractC0475yd abstractC0475yd = this.l;
        if (abstractC0475yd != null) {
            abstractC0475yd.c("Cannot add item decoration during a scroll  or layout");
        }
        ArrayList arrayList = this.m;
        if (arrayList.isEmpty()) {
            setWillNotDraw(false);
        }
        arrayList.add(abstractC0418vd);
        N();
        requestLayout();
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateDefaultLayoutParams() {
        AbstractC0475yd abstractC0475yd = this.l;
        if (abstractC0475yd != null) {
            return abstractC0475yd.r();
        }
        throw new IllegalStateException("RecyclerView has no LayoutManager" + y());
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        AbstractC0475yd abstractC0475yd = this.l;
        if (abstractC0475yd != null) {
            return abstractC0475yd.s(getContext(), attributeSet);
        }
        throw new IllegalStateException("RecyclerView has no LayoutManager" + y());
    }

    @Override // android.view.ViewGroup, android.view.View
    public CharSequence getAccessibilityClassName() {
        return "androidx.recyclerview.widget.RecyclerView";
    }

    public AbstractC0324qd getAdapter() {
        return this.k;
    }

    @Override // android.view.View
    public int getBaseline() {
        AbstractC0475yd abstractC0475yd = this.l;
        if (abstractC0475yd != null) {
            abstractC0475yd.getClass();
            return -1;
        }
        return super.getBaseline();
    }

    @Override // android.view.ViewGroup
    public final int getChildDrawingOrder(int i, int i2) {
        return super.getChildDrawingOrder(i, i2);
    }

    @Override // android.view.ViewGroup
    public boolean getClipToPadding() {
        return this.g;
    }

    public Od getCompatAccessibilityDelegate() {
        return this.j0;
    }

    public C0380td getEdgeEffectFactory() {
        return this.C;
    }

    public AbstractC0399ud getItemAnimator() {
        return this.H;
    }

    public int getItemDecorationCount() {
        return this.m.size();
    }

    public AbstractC0475yd getLayoutManager() {
        return this.l;
    }

    public int getMaxFlingVelocity() {
        return this.S;
    }

    public int getMinFlingVelocity() {
        return this.R;
    }

    public long getNanoTime() {
        return System.nanoTime();
    }

    public Ad getOnFlingListener() {
        return this.Q;
    }

    public boolean getPreserveFocusAfterLayout() {
        return this.V;
    }

    public Dd getRecycledViewPool() {
        return this.b.c();
    }

    public int getScrollState() {
        return this.I;
    }

    public final void h(Bd bd) {
        if (this.e0 == null) {
            this.e0 = new ArrayList();
        }
        this.e0.add(bd);
    }

    @Override // android.view.View
    public final boolean hasNestedScrollingParent() {
        return getScrollingChildHelper().f(0);
    }

    public final void i(String str) {
        if (L()) {
            if (str == null) {
                throw new IllegalStateException("Cannot call this method while RecyclerView is computing a layout or scrolling" + y());
            }
            throw new IllegalStateException(str);
        }
        if (this.B > 0) {
            Log.w("RecyclerView", "Cannot call this method in a scroll callback. Scroll callbacks mightbe run during a measure & layout pass where you cannot change theRecyclerView data. Any method call that might change the structureof the RecyclerView or the adapter contents should be postponed tothe next frame.", new IllegalStateException(BuildConfig.FLAVOR + y()));
        }
    }

    @Override // android.view.View
    public final boolean isAttachedToWindow() {
        return this.p;
    }

    @Override // android.view.ViewGroup
    public final boolean isLayoutSuppressed() {
        return this.u;
    }

    @Override // android.view.View
    public final boolean isNestedScrollingEnabled() {
        return getScrollingChildHelper().d;
    }

    public final void k() {
        int u = this.e.u();
        for (int i = 0; i < u; i++) {
            Md I = I(this.e.t(i));
            if (!I.p()) {
                I.d = -1;
                I.g = -1;
            }
        }
        Ed ed = this.b;
        ArrayList arrayList = ed.c;
        int size = arrayList.size();
        for (int i2 = 0; i2 < size; i2++) {
            Md md = (Md) arrayList.get(i2);
            md.d = -1;
            md.g = -1;
        }
        ArrayList arrayList2 = ed.a;
        int size2 = arrayList2.size();
        for (int i3 = 0; i3 < size2; i3++) {
            Md md2 = (Md) arrayList2.get(i3);
            md2.d = -1;
            md2.g = -1;
        }
        ArrayList arrayList3 = ed.b;
        if (arrayList3 != null) {
            int size3 = arrayList3.size();
            for (int i4 = 0; i4 < size3; i4++) {
                Md md3 = (Md) ed.b.get(i4);
                md3.d = -1;
                md3.g = -1;
            }
        }
    }

    public final void l(int i, int i2) {
        boolean z;
        EdgeEffect edgeEffect = this.D;
        if (edgeEffect != null && !edgeEffect.isFinished() && i > 0) {
            this.D.onRelease();
            z = this.D.isFinished();
        } else {
            z = false;
        }
        EdgeEffect edgeEffect2 = this.F;
        if (edgeEffect2 != null && !edgeEffect2.isFinished() && i < 0) {
            this.F.onRelease();
            z |= this.F.isFinished();
        }
        EdgeEffect edgeEffect3 = this.E;
        if (edgeEffect3 != null && !edgeEffect3.isFinished() && i2 > 0) {
            this.E.onRelease();
            z |= this.E.isFinished();
        }
        EdgeEffect edgeEffect4 = this.G;
        if (edgeEffect4 != null && !edgeEffect4.isFinished() && i2 < 0) {
            this.G.onRelease();
            z |= this.G.isFinished();
        }
        if (z) {
            WeakHashMap weakHashMap = AbstractC0309ph.a;
            postInvalidateOnAnimation();
        }
    }

    public final void m() {
        C0386u0 c0386u0 = this.d;
        if (this.r && !this.y) {
            if (!c0386u0.f()) {
                return;
            }
            c0386u0.getClass();
            if (c0386u0.f()) {
                int i = AbstractC0175ig.a;
                Trace.beginSection("RV FullInvalidate");
                o();
                Trace.endSection();
                return;
            }
            return;
        }
        int i2 = AbstractC0175ig.a;
        Trace.beginSection("RV FullInvalidate");
        o();
        Trace.endSection();
    }

    public final void n(int i, int i2) {
        int paddingRight = getPaddingRight() + getPaddingLeft();
        WeakHashMap weakHashMap = AbstractC0309ph.a;
        setMeasuredDimension(AbstractC0475yd.g(i, paddingRight, getMinimumWidth()), AbstractC0475yd.g(i2, getPaddingBottom() + getPaddingTop(), getMinimumHeight()));
    }

    /* JADX WARN: Code restructure failed: missing block: B:149:0x031b, code lost:
    
        if (((java.util.ArrayList) r19.e.d).contains(getFocusedChild()) == false) goto L214;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:177:0x03c5  */
    /* JADX WARN: Type inference failed for: r13v7, types: [x.Xb, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r3v13 */
    /* JADX WARN: Type inference failed for: r3v20 */
    /* JADX WARN: Type inference failed for: r3v21, types: [int] */
    /* JADX WARN: Type inference failed for: r3v24 */
    /* JADX WARN: Type inference failed for: r3v27 */
    /* JADX WARN: Type inference failed for: r3v28 */
    /* JADX WARN: Type inference failed for: r3v29 */
    /* JADX WARN: Type inference failed for: r3v30 */
    /* JADX WARN: Type inference failed for: r9v0, types: [x.F1] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void o() {
        boolean z;
        Md md;
        View findViewById;
        boolean z2;
        Xb xb;
        ?? r3;
        RecyclerView recyclerView;
        boolean g;
        int i;
        int i2;
        if (this.k == null) {
            Log.e("RecyclerView", "No adapter attached; skipping layout");
            return;
        }
        if (this.l == null) {
            Log.e("RecyclerView", "No layout manager attached; skipping layout");
            return;
        }
        Jd jd = this.c0;
        boolean z3 = false;
        jd.i = false;
        int i3 = 1;
        if (jd.d == 1) {
            p();
            this.l.p0(this);
            q();
        } else {
            C0386u0 c0386u0 = this.d;
            if ((c0386u0.c.isEmpty() || c0386u0.b.isEmpty()) && this.l.n == getWidth() && this.l.o == getHeight()) {
                this.l.p0(this);
            } else {
                this.l.p0(this);
                q();
            }
        }
        jd.a(4);
        a0();
        P();
        jd.d = 1;
        boolean z4 = jd.j;
        Ed ed = this.b;
        ?? r9 = this.f;
        if (z4) {
            int m = this.e.m() - 1;
            while (m >= 0) {
                Md I = I(this.e.l(m));
                if (!I.p()) {
                    long G = G(I);
                    this.H.getClass();
                    ?? obj = new Object();
                    obj.a(I);
                    Md md2 = (Md) ((Ba) r9.c).b(G);
                    if (md2 != null && !md2.p()) {
                        Pe pe = (Pe) r9.b;
                        C0403uh c0403uh = (C0403uh) pe.get(md2);
                        if (c0403uh != null && (c0403uh.a & i3) != 0) {
                            i = i3;
                        } else {
                            i = 0;
                        }
                        C0403uh c0403uh2 = (C0403uh) pe.get(I);
                        if (c0403uh2 != null && (c0403uh2.a & i3) != 0) {
                            i2 = i3;
                        } else {
                            i2 = 0;
                        }
                        if (i != 0 && md2 == I) {
                            r9.a(I, obj);
                        } else {
                            Xb J = r9.J(md2, 4);
                            r9.a(I, obj);
                            Xb J2 = r9.J(I, 8);
                            if (J == null) {
                                int m2 = this.e.m();
                                for (int i4 = 0; i4 < m2; i4++) {
                                    Md I2 = I(this.e.l(i4));
                                    if (I2 != I && G(I2) == G) {
                                        AbstractC0324qd abstractC0324qd = this.k;
                                        if (abstractC0324qd != null && abstractC0324qd.b) {
                                            throw new IllegalStateException("Two different ViewHolders have the same stable ID. Stable IDs in your adapter MUST BE unique and SHOULD NOT change.\n ViewHolder 1:" + I2 + " \n View Holder 2:" + I + y());
                                        }
                                        throw new IllegalStateException("Two different ViewHolders have the same change ID. This might happen due to inconsistent Adapter update events or if the LayoutManager lays out the same View multiple times.\n ViewHolder 1:" + I2 + " \n View Holder 2:" + I + y());
                                    }
                                }
                                Log.e("RecyclerView", "Problem while matching changed view holders with the newones. The pre-layout information for the change holder " + md2 + " cannot be found but it is necessary for " + I + y());
                            } else {
                                md2.o(false);
                                if (i != 0) {
                                    f(md2);
                                }
                                if (md2 != I) {
                                    if (i2 != 0) {
                                        f(I);
                                    }
                                    md2.h = I;
                                    f(md2);
                                    ed.j(md2);
                                    I.o(false);
                                    I.i = md2;
                                }
                                if (this.H.a(md2, I, J, J2)) {
                                    S();
                                }
                            }
                        }
                    } else {
                        r9.a(I, obj);
                    }
                }
                m--;
                i3 = 1;
            }
            Pe pe2 = (Pe) r9.b;
            int i5 = pe2.c - 1;
            while (i5 >= 0) {
                Md md3 = (Md) pe2.f(i5);
                C0403uh c0403uh3 = (C0403uh) pe2.g(i5);
                int i6 = c0403uh3.a;
                int i7 = i6 & 3;
                C0305pd c0305pd = this.r0;
                if (i7 == 3) {
                    RecyclerView recyclerView2 = c0305pd.a;
                    recyclerView2.l.i0(md3.a, recyclerView2.b);
                    r3 = z3;
                } else if ((i6 & 1) != 0) {
                    Xb xb2 = c0403uh3.b;
                    if (xb2 == null) {
                        RecyclerView recyclerView3 = c0305pd.a;
                        recyclerView3.l.i0(md3.a, recyclerView3.b);
                        r3 = z3;
                    } else {
                        c0305pd.g(md3, xb2, c0403uh3.c);
                        r3 = z3;
                    }
                } else if ((i6 & 14) == 14) {
                    c0305pd.f(md3, c0403uh3.b, c0403uh3.c);
                    r3 = z3;
                } else if ((i6 & 12) == 12) {
                    Xb xb3 = c0403uh3.b;
                    Xb xb4 = c0403uh3.c;
                    c0305pd.getClass();
                    md3.o(z3);
                    RecyclerView recyclerView4 = c0305pd.a;
                    if (recyclerView4.y) {
                        if (recyclerView4.H.a(md3, md3, xb3, xb4)) {
                            recyclerView4.S();
                        }
                    } else {
                        C0240m5 c0240m5 = (C0240m5) recyclerView4.H;
                        c0240m5.getClass();
                        int i8 = xb3.a;
                        int i9 = xb4.a;
                        if (i8 == i9 && xb3.b == xb4.b) {
                            c0240m5.c(md3);
                            recyclerView = recyclerView4;
                            g = false;
                        } else {
                            recyclerView = recyclerView4;
                            g = c0240m5.g(md3, i8, xb3.b, i9, xb4.b);
                        }
                        if (g) {
                            recyclerView.S();
                        }
                    }
                    r3 = 0;
                } else {
                    if ((i6 & 4) != 0) {
                        xb = null;
                        c0305pd.g(md3, c0403uh3.b, null);
                    } else {
                        xb = null;
                        if ((i6 & 8) != 0) {
                            c0305pd.f(md3, c0403uh3.b, c0403uh3.c);
                        }
                    }
                    r3 = 0;
                    c0403uh3.a = r3;
                    c0403uh3.b = xb;
                    c0403uh3.c = xb;
                    C0403uh.d.c(c0403uh3);
                    i5--;
                    z3 = false;
                }
                xb = null;
                c0403uh3.a = r3;
                c0403uh3.b = xb;
                c0403uh3.c = xb;
                C0403uh.d.c(c0403uh3);
                i5--;
                z3 = false;
            }
        }
        View view = null;
        this.l.h0(ed);
        jd.b = jd.e;
        int i10 = 0;
        this.y = false;
        this.z = false;
        jd.j = false;
        jd.k = false;
        this.l.f = false;
        ArrayList arrayList = ed.b;
        if (arrayList != null) {
            arrayList.clear();
        }
        AbstractC0475yd abstractC0475yd = this.l;
        if (abstractC0475yd.k) {
            abstractC0475yd.j = 0;
            abstractC0475yd.k = false;
            ed.k();
        }
        this.l.c0(jd);
        Q(true);
        b0(false);
        ((Pe) r9.b).clear();
        ((Ba) r9.c).a();
        int[] iArr = this.k0;
        int i11 = iArr[0];
        int i12 = iArr[1];
        C(iArr);
        if (iArr[0] == i11 && iArr[1] == i12) {
            z = false;
        } else {
            z = true;
        }
        if (z) {
            t(0, 0);
        }
        if (this.V && this.k != null && hasFocus() && getDescendantFocusability() != 393216 && (getDescendantFocusability() != 131072 || !isFocused())) {
            if (!isFocused()) {
            }
            long j = jd.m;
            if (j != -1 && (z2 = this.k.b) && z2) {
                int u = this.e.u();
                int i13 = 0;
                md = null;
                while (true) {
                    if (i13 >= u) {
                        break;
                    }
                    Md I3 = I(this.e.t(i13));
                    if (I3 != null && !I3.i() && I3.e == j) {
                        if (((ArrayList) this.e.d).contains(I3.a)) {
                            md = I3;
                        } else {
                            md = I3;
                            break;
                        }
                    }
                    i13++;
                }
            } else {
                md = null;
            }
            if (md != null) {
                ArrayList arrayList2 = (ArrayList) this.e.d;
                View view2 = md.a;
                if (!arrayList2.contains(view2) && view2.hasFocusable()) {
                    view = view2;
                    if (view != null) {
                        int i14 = jd.n;
                        if (i14 != -1 && (findViewById = view.findViewById(i14)) != null && findViewById.isFocusable()) {
                            view = findViewById;
                        }
                        view.requestFocus();
                    }
                }
            }
            if (this.e.m() > 0) {
                int i15 = jd.l;
                if (i15 != -1) {
                    i10 = i15;
                }
                int b = jd.b();
                for (int i16 = i10; i16 < b; i16++) {
                    Md E = E(i16);
                    if (E == null) {
                        break;
                    }
                    View view3 = E.a;
                    if (view3.hasFocusable()) {
                        view = view3;
                        break;
                    }
                }
                int min = Math.min(b, i10) - 1;
                while (true) {
                    if (min < 0) {
                        break;
                    }
                    Md E2 = E(min);
                    if (E2 == null) {
                        break;
                    }
                    View view4 = E2.a;
                    if (view4.hasFocusable()) {
                        view = view4;
                        break;
                    }
                    min--;
                }
            }
            if (view != null) {
            }
        }
        jd.m = -1L;
        jd.l = -1;
        jd.n = -1;
    }

    /* JADX WARN: Code restructure failed: missing block: B:15:0x005a, code lost:
    
        if (r1 >= 30.0f) goto L20;
     */
    /* JADX WARN: Type inference failed for: r1v3, types: [x.i9, java.lang.Object] */
    @Override // android.view.ViewGroup, android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void onAttachedToWindow() {
        boolean z;
        float f;
        super.onAttachedToWindow();
        this.A = 0;
        this.p = true;
        if (this.r && !isLayoutRequested()) {
            z = true;
        } else {
            z = false;
        }
        this.r = z;
        AbstractC0475yd abstractC0475yd = this.l;
        if (abstractC0475yd != null) {
            abstractC0475yd.g = true;
            abstractC0475yd.Q(this);
        }
        this.i0 = false;
        ThreadLocal threadLocal = RunnableC0169i9.e;
        RunnableC0169i9 runnableC0169i9 = (RunnableC0169i9) threadLocal.get();
        this.a0 = runnableC0169i9;
        if (runnableC0169i9 == null) {
            ?? obj = new Object();
            obj.a = new ArrayList();
            obj.d = new ArrayList();
            this.a0 = obj;
            WeakHashMap weakHashMap = AbstractC0309ph.a;
            Display display = getDisplay();
            if (!isInEditMode() && display != null) {
                f = display.getRefreshRate();
            }
            f = 60.0f;
            RunnableC0169i9 runnableC0169i92 = this.a0;
            runnableC0169i92.c = 1.0E9f / f;
            threadLocal.set(runnableC0169i92);
        }
        this.a0.a.add(this);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        C0151ha c0151ha;
        super.onDetachedFromWindow();
        AbstractC0399ud abstractC0399ud = this.H;
        if (abstractC0399ud != null) {
            abstractC0399ud.e();
        }
        setScrollState(0);
        Ld ld = this.W;
        ld.g.removeCallbacks(ld);
        ld.c.abortAnimation();
        AbstractC0475yd abstractC0475yd = this.l;
        if (abstractC0475yd != null && (c0151ha = abstractC0475yd.e) != null) {
            c0151ha.i();
        }
        this.p = false;
        AbstractC0475yd abstractC0475yd2 = this.l;
        if (abstractC0475yd2 != null) {
            abstractC0475yd2.g = false;
            abstractC0475yd2.R(this);
        }
        this.p0.clear();
        removeCallbacks(this.q0);
        this.f.getClass();
        do {
        } while (C0403uh.d.a() != null);
        RunnableC0169i9 runnableC0169i9 = this.a0;
        if (runnableC0169i9 != null) {
            runnableC0169i9.a.remove(this);
            this.a0 = null;
        }
    }

    @Override // android.view.View
    public final void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        ArrayList arrayList = this.m;
        int size = arrayList.size();
        for (int i = 0; i < size; i++) {
            ((AbstractC0418vd) arrayList.get(i)).a(this);
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:20:0x0068  */
    @Override // android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final boolean onGenericMotionEvent(MotionEvent motionEvent) {
        float f;
        float f2;
        if (this.l != null && !this.u && motionEvent.getAction() == 8) {
            if ((motionEvent.getSource() & 2) != 0) {
                if (this.l.e()) {
                    f = -motionEvent.getAxisValue(9);
                } else {
                    f = 0.0f;
                }
                if (this.l.d()) {
                    f2 = motionEvent.getAxisValue(10);
                    if (f == 0.0f || f2 != 0.0f) {
                        W((int) (f2 * this.T), (int) (f * this.U), motionEvent);
                    }
                }
                f2 = 0.0f;
                if (f == 0.0f) {
                }
                W((int) (f2 * this.T), (int) (f * this.U), motionEvent);
            } else {
                if ((motionEvent.getSource() & 4194304) != 0) {
                    float axisValue = motionEvent.getAxisValue(26);
                    if (this.l.e()) {
                        f = -axisValue;
                        f2 = 0.0f;
                        if (f == 0.0f) {
                        }
                        W((int) (f2 * this.T), (int) (f * this.U), motionEvent);
                    } else if (this.l.d()) {
                        f2 = axisValue;
                        f = 0.0f;
                        if (f == 0.0f) {
                        }
                        W((int) (f2 * this.T), (int) (f * this.U), motionEvent);
                    }
                }
                f = 0.0f;
                f2 = 0.0f;
                if (f == 0.0f) {
                }
                W((int) (f2 * this.T), (int) (f * this.U), motionEvent);
            }
        }
        return false;
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // android.view.ViewGroup
    public final boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        boolean z;
        if (this.u) {
            return false;
        }
        this.o = null;
        if (B(motionEvent)) {
            V();
            setScrollState(0);
            return true;
        }
        AbstractC0475yd abstractC0475yd = this.l;
        if (abstractC0475yd == null) {
            return false;
        }
        boolean d = abstractC0475yd.d();
        boolean e = this.l.e();
        if (this.K == null) {
            this.K = VelocityTracker.obtain();
        }
        this.K.addMovement(motionEvent);
        int actionMasked = motionEvent.getActionMasked();
        int actionIndex = motionEvent.getActionIndex();
        if (actionMasked != 0) {
            if (actionMasked != 1) {
                if (actionMasked != 2) {
                    if (actionMasked != 3) {
                        if (actionMasked != 5) {
                            if (actionMasked == 6) {
                                R(motionEvent);
                            }
                        } else {
                            this.J = motionEvent.getPointerId(actionIndex);
                            int x2 = (int) (motionEvent.getX(actionIndex) + 0.5f);
                            this.N = x2;
                            this.L = x2;
                            int y = (int) (motionEvent.getY(actionIndex) + 0.5f);
                            this.O = y;
                            this.M = y;
                        }
                    } else {
                        V();
                        setScrollState(0);
                    }
                } else {
                    int findPointerIndex = motionEvent.findPointerIndex(this.J);
                    if (findPointerIndex < 0) {
                        Log.e("RecyclerView", "Error processing scroll; pointer index for id " + this.J + " not found. Did any MotionEvents get skipped?");
                        return false;
                    }
                    int x3 = (int) (motionEvent.getX(findPointerIndex) + 0.5f);
                    int y2 = (int) (motionEvent.getY(findPointerIndex) + 0.5f);
                    if (this.I != 1) {
                        int i = x3 - this.L;
                        int i2 = y2 - this.M;
                        if (d != 0 && Math.abs(i) > this.P) {
                            this.N = x3;
                            z = true;
                        } else {
                            z = false;
                        }
                        if (e && Math.abs(i2) > this.P) {
                            this.O = y2;
                            z = true;
                        }
                        if (z) {
                            setScrollState(1);
                        }
                    }
                }
            } else {
                this.K.clear();
                c0(0);
            }
        } else {
            if (this.v) {
                this.v = false;
            }
            this.J = motionEvent.getPointerId(0);
            int x4 = (int) (motionEvent.getX() + 0.5f);
            this.N = x4;
            this.L = x4;
            int y3 = (int) (motionEvent.getY() + 0.5f);
            this.O = y3;
            this.M = y3;
            if (this.I == 2) {
                getParent().requestDisallowInterceptTouchEvent(true);
                setScrollState(1);
                c0(1);
            }
            int[] iArr = this.n0;
            iArr[1] = 0;
            iArr[0] = 0;
            int i3 = d;
            if (e) {
                i3 = (d ? 1 : 0) | 2;
            }
            getScrollingChildHelper().g(i3, 0);
        }
        if (this.I != 1) {
            return false;
        }
        return true;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z, int i, int i2, int i3, int i4) {
        int i5 = AbstractC0175ig.a;
        Trace.beginSection("RV OnLayout");
        o();
        Trace.endSection();
        this.r = true;
    }

    @Override // android.view.View
    public final void onMeasure(int i, int i2) {
        AbstractC0475yd abstractC0475yd = this.l;
        if (abstractC0475yd == null) {
            n(i, i2);
            return;
        }
        boolean L = abstractC0475yd.L();
        Jd jd = this.c0;
        if (L) {
            int mode = View.MeasureSpec.getMode(i);
            int mode2 = View.MeasureSpec.getMode(i2);
            this.l.b.n(i, i2);
            if ((mode == 1073741824 && mode2 == 1073741824) || this.k == null) {
                return;
            }
            if (jd.d == 1) {
                p();
            }
            this.l.q0(i, i2);
            jd.i = true;
            q();
            this.l.s0(i, i2);
            if (this.l.v0()) {
                this.l.q0(View.MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 1073741824), View.MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 1073741824));
                jd.i = true;
                q();
                this.l.s0(i, i2);
                return;
            }
            return;
        }
        if (this.q) {
            this.l.b.n(i, i2);
            return;
        }
        if (jd.k) {
            setMeasuredDimension(getMeasuredWidth(), getMeasuredHeight());
            return;
        }
        AbstractC0324qd abstractC0324qd = this.k;
        if (abstractC0324qd != null) {
            jd.e = abstractC0324qd.a();
        } else {
            jd.e = 0;
        }
        a0();
        this.l.b.n(i, i2);
        b0(false);
        jd.g = false;
    }

    @Override // android.view.ViewGroup
    public final boolean onRequestFocusInDescendants(int i, Rect rect) {
        if (L()) {
            return false;
        }
        return super.onRequestFocusInDescendants(i, rect);
    }

    @Override // android.view.View
    public final void onRestoreInstanceState(Parcelable parcelable) {
        Parcelable parcelable2;
        if (!(parcelable instanceof Gd)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        Gd gd = (Gd) parcelable;
        this.c = gd;
        super.onRestoreInstanceState(gd.a);
        AbstractC0475yd abstractC0475yd = this.l;
        if (abstractC0475yd != null && (parcelable2 = this.c.c) != null) {
            abstractC0475yd.d0(parcelable2);
        }
    }

    /* JADX WARN: Type inference failed for: r0v0, types: [android.os.Parcelable, x.Gd, x.d] */
    @Override // android.view.View
    public final Parcelable onSaveInstanceState() {
        ?? abstractC0060d = new AbstractC0060d(super.onSaveInstanceState());
        Gd gd = this.c;
        if (gd != null) {
            abstractC0060d.c = gd.c;
        } else {
            AbstractC0475yd abstractC0475yd = this.l;
            if (abstractC0475yd != null) {
                abstractC0060d.c = abstractC0475yd.e0();
            } else {
                abstractC0060d.c = null;
            }
        }
        return abstractC0060d;
    }

    @Override // android.view.View
    public final void onSizeChanged(int i, int i2, int i3, int i4) {
        super.onSizeChanged(i, i2, i3, i4);
        if (i != i3 || i2 != i4) {
            this.G = null;
            this.E = null;
            this.F = null;
            this.D = null;
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:141:0x0417  */
    /* JADX WARN: Removed duplicated region for block: B:143:0x0423  */
    /* JADX WARN: Removed duplicated region for block: B:149:0x0477  */
    /* JADX WARN: Removed duplicated region for block: B:52:0x01fd  */
    /* JADX WARN: Removed duplicated region for block: B:58:0x0213  */
    /* JADX WARN: Type inference failed for: r7v4, types: [boolean] */
    /* JADX WARN: Type inference failed for: r7v7 */
    @Override // android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        boolean z;
        RecyclerView recyclerView;
        MotionEvent motionEvent2;
        MotionEvent motionEvent3;
        float f;
        float f2;
        boolean z2;
        MotionEvent motionEvent4;
        RecyclerView recyclerView2;
        int minFlingVelocity;
        boolean z3;
        C0314q3 c0314q3;
        AbstractC0203k6 abstractC0203k6;
        boolean z4;
        boolean z5;
        int i;
        int i2;
        PointF a;
        int i3;
        int i4;
        int i5;
        int i6;
        boolean z6;
        int i7 = 0;
        if (this.u || this.v) {
            return false;
        }
        C0299p7 c0299p7 = this.o;
        if (c0299p7 == null) {
            if (motionEvent.getAction() == 0) {
                z = false;
            } else {
                z = B(motionEvent);
            }
        } else {
            if (c0299p7.v != 0) {
                if (motionEvent.getAction() == 0) {
                    boolean d = c0299p7.d(motionEvent.getX(), motionEvent.getY());
                    boolean c = c0299p7.c(motionEvent.getX(), motionEvent.getY());
                    if (d || c) {
                        if (c) {
                            c0299p7.w = 1;
                            c0299p7.p = (int) motionEvent.getX();
                        } else if (d) {
                            c0299p7.w = 2;
                            c0299p7.m = (int) motionEvent.getY();
                        }
                        c0299p7.f(2);
                    }
                } else if (motionEvent.getAction() == 1 && c0299p7.v == 2) {
                    c0299p7.m = 0.0f;
                    c0299p7.p = 0.0f;
                    c0299p7.f(1);
                    c0299p7.w = 0;
                } else if (motionEvent.getAction() == 2 && c0299p7.v == 2) {
                    c0299p7.g();
                    int i8 = c0299p7.w;
                    int i9 = c0299p7.b;
                    if (i8 == 1) {
                        float x2 = motionEvent.getX();
                        int[] iArr = c0299p7.y;
                        iArr[0] = i9;
                        int i10 = c0299p7.q - i9;
                        iArr[1] = i10;
                        float max = Math.max(i9, Math.min(i10, x2));
                        if (Math.abs(c0299p7.o - max) >= 2.0f) {
                            int e = C0299p7.e(c0299p7.p, max, iArr, c0299p7.s.computeHorizontalScrollRange(), c0299p7.s.computeHorizontalScrollOffset(), c0299p7.q);
                            if (e != 0) {
                                c0299p7.s.scrollBy(e, 0);
                            }
                            c0299p7.p = max;
                        }
                    }
                    if (c0299p7.w == 2) {
                        float y = motionEvent.getY();
                        int[] iArr2 = c0299p7.f28x;
                        iArr2[0] = i9;
                        int i11 = c0299p7.r - i9;
                        iArr2[1] = i11;
                        float max2 = Math.max(i9, Math.min(i11, y));
                        if (Math.abs(c0299p7.l - max2) >= 2.0f) {
                            int e2 = C0299p7.e(c0299p7.m, max2, iArr2, c0299p7.s.computeVerticalScrollRange(), c0299p7.s.computeVerticalScrollOffset(), c0299p7.r);
                            if (e2 != 0) {
                                c0299p7.s.scrollBy(0, e2);
                            }
                            c0299p7.m = max2;
                        }
                    }
                }
            }
            int action = motionEvent.getAction();
            if (action == 3 || action == 1) {
                this.o = null;
            }
            z = true;
        }
        if (z) {
            V();
            setScrollState(0);
            return true;
        }
        AbstractC0475yd abstractC0475yd = this.l;
        if (abstractC0475yd == null) {
            return false;
        }
        boolean d2 = abstractC0475yd.d();
        boolean e3 = this.l.e();
        if (this.K == null) {
            this.K = VelocityTracker.obtain();
        }
        int actionMasked = motionEvent.getActionMasked();
        int actionIndex = motionEvent.getActionIndex();
        int[] iArr3 = this.n0;
        if (actionMasked == 0) {
            iArr3[1] = 0;
            iArr3[0] = 0;
        }
        MotionEvent obtain = MotionEvent.obtain(motionEvent);
        obtain.offsetLocation(iArr3[0], iArr3[1]);
        if (actionMasked != 0) {
            if (actionMasked != 1) {
                if (actionMasked != 2) {
                    if (actionMasked != 3) {
                        if (actionMasked != 5) {
                            if (actionMasked == 6) {
                                R(motionEvent);
                            }
                        } else {
                            this.J = motionEvent.getPointerId(actionIndex);
                            int x3 = (int) (motionEvent.getX(actionIndex) + 0.5f);
                            this.N = x3;
                            this.L = x3;
                            int y2 = (int) (motionEvent.getY(actionIndex) + 0.5f);
                            this.O = y2;
                            this.M = y2;
                        }
                    } else {
                        V();
                        setScrollState(0);
                    }
                } else {
                    int findPointerIndex = motionEvent.findPointerIndex(this.J);
                    if (findPointerIndex < 0) {
                        Log.e("RecyclerView", "Error processing scroll; pointer index for id " + this.J + " not found. Did any MotionEvents get skipped?");
                        return false;
                    }
                    int x4 = (int) (motionEvent.getX(findPointerIndex) + 0.5f);
                    int y3 = (int) (motionEvent.getY(findPointerIndex) + 0.5f);
                    int i12 = this.N - x4;
                    int i13 = this.O - y3;
                    if (this.I != 1) {
                        if (d2 != 0) {
                            if (i12 > 0) {
                                i12 = Math.max(0, i12 - this.P);
                            } else {
                                i12 = Math.min(0, i12 + this.P);
                            }
                            if (i12 != 0) {
                                z6 = true;
                                if (e3) {
                                    if (i13 > 0) {
                                        i13 = Math.max(0, i13 - this.P);
                                    } else {
                                        i13 = Math.min(0, i13 + this.P);
                                    }
                                    if (i13 != 0) {
                                        z6 = true;
                                    }
                                }
                                if (z6) {
                                    setScrollState(1);
                                }
                            }
                        }
                        z6 = false;
                        if (e3) {
                        }
                        if (z6) {
                        }
                    }
                    int i14 = i12;
                    int i15 = i13;
                    if (this.I == 1) {
                        int[] iArr4 = this.o0;
                        iArr4[0] = 0;
                        iArr4[1] = 0;
                        if (d2 != 0) {
                            i4 = i14;
                        } else {
                            i4 = 0;
                        }
                        if (e3) {
                            i5 = i15;
                        } else {
                            i5 = 0;
                        }
                        boolean r = r(i4, i5, 0, iArr4, this.m0);
                        int[] iArr5 = this.m0;
                        if (r) {
                            i14 -= iArr4[0];
                            i15 -= iArr4[1];
                            iArr3[0] = iArr3[0] + iArr5[0];
                            iArr3[1] = iArr3[1] + iArr5[1];
                            getParent().requestDisallowInterceptTouchEvent(true);
                        }
                        int i16 = i14;
                        int i17 = i15;
                        this.N = x4 - iArr5[0];
                        this.O = y3 - iArr5[1];
                        if (d2 != 0) {
                            i6 = i16;
                        } else {
                            i6 = 0;
                        }
                        if (e3) {
                            i7 = i17;
                        }
                        if (W(i6, i7, motionEvent)) {
                            getParent().requestDisallowInterceptTouchEvent(true);
                        }
                        RunnableC0169i9 runnableC0169i9 = this.a0;
                        if (runnableC0169i9 != null && (i16 != 0 || i17 != 0)) {
                            runnableC0169i9.a(this, i16, i17);
                        }
                    }
                }
                recyclerView = this;
                motionEvent2 = obtain;
            } else {
                this.K.addMovement(obtain);
                VelocityTracker velocityTracker = this.K;
                int i18 = this.S;
                velocityTracker.computeCurrentVelocity(1000, i18);
                if (d2 != 0) {
                    f = -this.K.getXVelocity(this.J);
                } else {
                    f = 0.0f;
                }
                if (e3) {
                    f2 = -this.K.getYVelocity(this.J);
                } else {
                    f2 = 0.0f;
                }
                if (f == 0.0f && f2 == 0.0f) {
                    recyclerView2 = this;
                    i3 = 0;
                    motionEvent4 = obtain;
                } else {
                    int i19 = (int) f;
                    int i20 = (int) f2;
                    AbstractC0475yd abstractC0475yd2 = this.l;
                    if (abstractC0475yd2 == null) {
                        Log.e("RecyclerView", "Cannot fling without a LayoutManager set. Call setLayoutManager with a non-null argument.");
                    } else if (!this.u) {
                        int d3 = abstractC0475yd2.d();
                        boolean e4 = this.l.e();
                        int i21 = this.R;
                        if (d3 == 0 || Math.abs(i19) < i21) {
                            i19 = 0;
                        }
                        if (!e4 || Math.abs(i20) < i21) {
                            i20 = 0;
                        }
                        if (i19 != 0 || i20 != 0) {
                            float f3 = i19;
                            float f4 = i20;
                            if (!dispatchNestedPreFling(f3, f4)) {
                                if (d3 == 0 && !e4) {
                                    z2 = false;
                                } else {
                                    z2 = true;
                                }
                                dispatchNestedFling(f3, f4, z2);
                                Ad ad = this.Q;
                                if (ad != null) {
                                    C0455xc c0455xc = (C0455xc) ad;
                                    AbstractC0475yd layoutManager = c0455xc.a.getLayoutManager();
                                    if (layoutManager != 0 && c0455xc.a.getAdapter() != null && ((Math.abs(i20) > (minFlingVelocity = c0455xc.a.getMinFlingVelocity()) || Math.abs(i19) > minFlingVelocity) && ((z3 = layoutManager instanceof Id)))) {
                                        if (!z3) {
                                            c0314q3 = null;
                                        } else {
                                            c0314q3 = new C0314q3(c0455xc, c0455xc.a.getContext(), 1);
                                        }
                                        if (c0314q3 != null) {
                                            int B = layoutManager.B();
                                            if (B != 0) {
                                                if (layoutManager.e()) {
                                                    abstractC0203k6 = c0455xc.e(layoutManager);
                                                } else if (layoutManager.d()) {
                                                    abstractC0203k6 = c0455xc.d(layoutManager);
                                                } else {
                                                    abstractC0203k6 = null;
                                                }
                                                if (abstractC0203k6 != null) {
                                                    int v = layoutManager.v();
                                                    motionEvent4 = obtain;
                                                    int i22 = Integer.MIN_VALUE;
                                                    int i23 = Integer.MAX_VALUE;
                                                    int i24 = 0;
                                                    View view = null;
                                                    View view2 = null;
                                                    while (i24 < v) {
                                                        int i25 = v;
                                                        View u = layoutManager.u(i24);
                                                        if (u != null) {
                                                            int b = C0455xc.b(u, abstractC0203k6);
                                                            if (b <= 0 && b > i22) {
                                                                i22 = b;
                                                                view2 = u;
                                                            }
                                                            if (b >= 0 && b < i23) {
                                                                i23 = b;
                                                                view = u;
                                                            }
                                                        }
                                                        i24++;
                                                        v = i25;
                                                    }
                                                    if (!layoutManager.d() ? i20 > 0 : i19 > 0) {
                                                        z4 = true;
                                                    } else {
                                                        z4 = false;
                                                    }
                                                    if (z4 && view != null) {
                                                        i2 = AbstractC0475yd.H(view);
                                                    } else if (!z4 && view2 != null) {
                                                        i2 = AbstractC0475yd.H(view2);
                                                    } else {
                                                        if (z4) {
                                                            view = view2;
                                                        }
                                                        if (view != null) {
                                                            int H = AbstractC0475yd.H(view);
                                                            int B2 = layoutManager.B();
                                                            if (z3 && (a = ((Id) layoutManager).a(B2 - 1)) != null && (a.x < 0.0f || a.y < 0.0f)) {
                                                                z5 = true;
                                                            } else {
                                                                z5 = false;
                                                            }
                                                            if (z5 == z4) {
                                                                i = -1;
                                                            } else {
                                                                i = 1;
                                                            }
                                                            int i26 = i + H;
                                                            if (i26 >= 0 && i26 < B) {
                                                                i2 = i26;
                                                            }
                                                        }
                                                        i2 = -1;
                                                    }
                                                    if (i2 != -1) {
                                                        c0314q3.a = i2;
                                                        layoutManager.y0(c0314q3);
                                                        V();
                                                        motionEvent3 = motionEvent4;
                                                        motionEvent3.recycle();
                                                        return true;
                                                    }
                                                    if (z2) {
                                                        if (e4) {
                                                            d3 = (d3 == true ? 1 : 0) | 2;
                                                        }
                                                        getScrollingChildHelper().g(d3, 1);
                                                        int i27 = -i18;
                                                        int max3 = Math.max(i27, Math.min(i19, i18));
                                                        int max4 = Math.max(i27, Math.min(i20, i18));
                                                        Ld ld = this.W;
                                                        RecyclerView recyclerView3 = ld.g;
                                                        recyclerView3.setScrollState(2);
                                                        ld.b = 0;
                                                        ld.a = 0;
                                                        Interpolator interpolator = ld.d;
                                                        InterpolatorC0286od interpolatorC0286od = u0;
                                                        if (interpolator != interpolatorC0286od) {
                                                            ld.d = interpolatorC0286od;
                                                            ld.c = new OverScroller(recyclerView3.getContext(), interpolatorC0286od);
                                                        }
                                                        ld.c.fling(0, 0, max3, max4, Integer.MIN_VALUE, Integer.MAX_VALUE, Integer.MIN_VALUE, Integer.MAX_VALUE);
                                                        ld.a();
                                                        V();
                                                        motionEvent3 = motionEvent4;
                                                        motionEvent3.recycle();
                                                        return true;
                                                    }
                                                    recyclerView2 = this;
                                                    i3 = 0;
                                                }
                                            }
                                            motionEvent4 = obtain;
                                            i2 = -1;
                                            if (i2 != -1) {
                                            }
                                            if (z2) {
                                            }
                                        }
                                    }
                                }
                                motionEvent4 = obtain;
                                if (z2) {
                                }
                            }
                        }
                    }
                    recyclerView2 = this;
                    motionEvent4 = obtain;
                    i3 = 0;
                }
                recyclerView2.setScrollState(i3);
                V();
                motionEvent3 = motionEvent4;
                motionEvent3.recycle();
                return true;
            }
        } else {
            recyclerView = this;
            motionEvent2 = obtain;
            recyclerView.J = motionEvent.getPointerId(0);
            int x5 = (int) (motionEvent.getX() + 0.5f);
            recyclerView.N = x5;
            recyclerView.L = x5;
            int y4 = (int) (motionEvent.getY() + 0.5f);
            recyclerView.O = y4;
            recyclerView.M = y4;
            int i28 = d2;
            if (e3) {
                i28 = (d2 ? 1 : 0) | 2;
            }
            getScrollingChildHelper().g(i28, 0);
        }
        motionEvent3 = motionEvent2;
        recyclerView.K.addMovement(motionEvent3);
        motionEvent3.recycle();
        return true;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:31:0x00ba  */
    /* JADX WARN: Removed duplicated region for block: B:349:0x03db A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:34:0x00da  */
    /* JADX WARN: Removed duplicated region for block: B:353:0x03bf A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:36:0x00eb  */
    /* JADX WARN: Removed duplicated region for block: B:38:0x00f0  */
    /* JADX WARN: Removed duplicated region for block: B:41:0x0218 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:42:0x00de  */
    /* JADX WARN: Removed duplicated region for block: B:43:0x00bf  */
    /* JADX WARN: Type inference failed for: r7v8, types: [x.Xb, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r8v9, types: [x.Xb, java.lang.Object] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void p() {
        boolean z;
        boolean z2;
        View view;
        int F;
        View view2;
        boolean z3;
        C0403uh c0403uh;
        View A;
        boolean z4;
        int i;
        int i2;
        boolean z5;
        boolean z6;
        char c;
        int i3;
        int i4;
        int i5;
        boolean z7;
        boolean z8;
        C0367t0 g;
        int i6;
        int i7;
        C0367t0 c0367t0;
        Jd jd = this.c0;
        jd.a(1);
        z(jd);
        jd.i = false;
        a0();
        F1 f1 = this.f;
        ((Pe) f1.b).clear();
        Ba ba = (Ba) f1.c;
        ba.a();
        P();
        if (this.y) {
            C0386u0 c0386u0 = this.d;
            c0386u0.i(c0386u0.b);
            c0386u0.i(c0386u0.c);
            if (this.z) {
                this.l.X();
            }
        }
        if (this.H != null && this.l.z0()) {
            C0386u0 c0386u02 = this.d;
            ArrayList arrayList = c0386u02.b;
            B b = c0386u02.e;
            b.getClass();
            while (true) {
                int size = arrayList.size() - 1;
                boolean z9 = false;
                while (true) {
                    i = 8;
                    if (size >= 0) {
                        if (((C0367t0) arrayList.get(size)).a == 8) {
                            if (z9) {
                                break;
                            }
                        } else {
                            z9 = true;
                        }
                        size--;
                    } else {
                        size = -1;
                        break;
                    }
                }
                if (size == -1) {
                    break;
                }
                int i8 = size + 1;
                C0367t0 c0367t02 = (C0367t0) arrayList.get(size);
                C0367t0 c0367t03 = (C0367t0) arrayList.get(i8);
                int i9 = c0367t03.a;
                if (i9 != 1) {
                    C0367t0 c0367t04 = null;
                    C0386u0 c0386u03 = (C0386u0) b.b;
                    if (i9 != 2) {
                        if (i9 == 4) {
                            int i10 = c0367t02.c;
                            int i11 = c0367t03.b;
                            if (i10 < i11) {
                                c0367t03.b = i11 - 1;
                            } else {
                                int i12 = c0367t03.c;
                                if (i10 < i11 + i12) {
                                    c0367t03.c = i12 - 1;
                                    g = c0386u03.g(4, c0367t02.b, 1);
                                    i6 = c0367t02.b;
                                    i7 = c0367t03.b;
                                    if (i6 > i7) {
                                        c0367t03.b = i7 + 1;
                                    } else {
                                        int i13 = i7 + c0367t03.c;
                                        if (i6 < i13) {
                                            int i14 = i13 - i6;
                                            c0367t04 = c0386u03.g(4, i6 + 1, i14);
                                            c0367t03.c -= i14;
                                        }
                                    }
                                    c0367t0 = c0367t04;
                                    arrayList.set(i8, c0367t02);
                                    if (c0367t03.c <= 0) {
                                        arrayList.set(size, c0367t03);
                                    } else {
                                        arrayList.remove(size);
                                        c0386u03.getClass();
                                        c0386u03.a.c(c0367t03);
                                    }
                                    if (g != null) {
                                        arrayList.add(size, g);
                                    }
                                    if (c0367t0 == null) {
                                        arrayList.add(size, c0367t0);
                                    }
                                }
                            }
                            g = null;
                            i6 = c0367t02.b;
                            i7 = c0367t03.b;
                            if (i6 > i7) {
                            }
                            c0367t0 = c0367t04;
                            arrayList.set(i8, c0367t02);
                            if (c0367t03.c <= 0) {
                            }
                            if (g != null) {
                            }
                            if (c0367t0 == null) {
                            }
                        }
                    } else {
                        int i15 = c0367t02.b;
                        int i16 = c0367t02.c;
                        if (i15 < i16) {
                            if (c0367t03.b == i15 && c0367t03.c == i16 - i15) {
                                z7 = false;
                                z8 = true;
                            } else {
                                z7 = false;
                                z8 = false;
                            }
                        } else if (c0367t03.b == i16 + 1 && c0367t03.c == i15 - i16) {
                            z7 = true;
                            z8 = true;
                        } else {
                            z7 = true;
                            z8 = false;
                        }
                        int i17 = c0367t03.b;
                        if (i16 < i17) {
                            c0367t03.b = i17 - 1;
                        } else {
                            int i18 = c0367t03.c;
                            if (i16 < i17 + i18) {
                                c0367t03.c = i18 - 1;
                                c0367t02.a = 2;
                                c0367t02.c = 1;
                                if (c0367t03.c == 0) {
                                    arrayList.remove(i8);
                                    c0386u03.getClass();
                                    c0386u03.a.c(c0367t03);
                                }
                            }
                        }
                        int i19 = c0367t02.b;
                        int i20 = c0367t03.b;
                        if (i19 <= i20) {
                            c0367t03.b = i20 + 1;
                        } else {
                            int i21 = i20 + c0367t03.c;
                            if (i19 < i21) {
                                c0367t04 = c0386u03.g(2, i19 + 1, i21 - i19);
                                c0367t03.c = c0367t02.b - c0367t03.b;
                            }
                        }
                        C0367t0 c0367t05 = c0367t04;
                        if (z8) {
                            arrayList.set(size, c0367t03);
                            arrayList.remove(i8);
                            c0386u03.getClass();
                            c0386u03.a.c(c0367t02);
                        } else {
                            if (z7) {
                                if (c0367t05 != null) {
                                    int i22 = c0367t02.b;
                                    if (i22 > c0367t05.b) {
                                        c0367t02.b = i22 - c0367t05.c;
                                    }
                                    int i23 = c0367t02.c;
                                    if (i23 > c0367t05.b) {
                                        c0367t02.c = i23 - c0367t05.c;
                                    }
                                }
                                int i24 = c0367t02.b;
                                if (i24 > c0367t03.b) {
                                    c0367t02.b = i24 - c0367t03.c;
                                }
                                int i25 = c0367t02.c;
                                if (i25 > c0367t03.b) {
                                    c0367t02.c = i25 - c0367t03.c;
                                }
                            } else {
                                if (c0367t05 != null) {
                                    int i26 = c0367t02.b;
                                    if (i26 >= c0367t05.b) {
                                        c0367t02.b = i26 - c0367t05.c;
                                    }
                                    int i27 = c0367t02.c;
                                    if (i27 >= c0367t05.b) {
                                        c0367t02.c = i27 - c0367t05.c;
                                    }
                                }
                                int i28 = c0367t02.b;
                                if (i28 >= c0367t03.b) {
                                    c0367t02.b = i28 - c0367t03.c;
                                }
                                int i29 = c0367t02.c;
                                if (i29 >= c0367t03.b) {
                                    c0367t02.c = i29 - c0367t03.c;
                                }
                            }
                            arrayList.set(size, c0367t03);
                            if (c0367t02.b != c0367t02.c) {
                                arrayList.set(i8, c0367t02);
                            } else {
                                arrayList.remove(i8);
                            }
                            if (c0367t05 != null) {
                                arrayList.add(size, c0367t05);
                            }
                        }
                    }
                } else {
                    int i30 = c0367t02.c;
                    int i31 = c0367t03.b;
                    if (i30 < i31) {
                        i5 = -1;
                    } else {
                        i5 = 0;
                    }
                    int i32 = c0367t02.b;
                    if (i32 < i31) {
                        i5++;
                    }
                    if (i31 <= i32) {
                        c0367t02.b = i32 + c0367t03.c;
                    }
                    int i33 = c0367t03.b;
                    if (i33 <= i30) {
                        c0367t02.c = i30 + c0367t03.c;
                    }
                    c0367t03.b = i33 + i5;
                    arrayList.set(size, c0367t03);
                    arrayList.set(i8, c0367t02);
                }
            }
            int size2 = arrayList.size();
            int i34 = 0;
            while (i34 < size2) {
                C0367t0 c0367t06 = (C0367t0) arrayList.get(i34);
                int i35 = c0367t06.a;
                if (i35 != 1) {
                    Jc jc = c0386u02.a;
                    C0305pd c0305pd = c0386u02.d;
                    if (i35 != 2) {
                        if (i35 != 4) {
                            if (i35 == i) {
                                c0386u02.h(c0367t06);
                            }
                            i2 = size2;
                        } else {
                            int i36 = c0367t06.b;
                            int i37 = c0367t06.c + i36;
                            int i38 = i36;
                            char c2 = 65535;
                            int i39 = 0;
                            while (i36 < i37) {
                                if (c0305pd.b(i36) != null || c0386u02.a(i36)) {
                                    i3 = size2;
                                    if (c2 == 0) {
                                        c0386u02.c(c0386u02.g(4, i38, i39));
                                        i38 = i36;
                                        i39 = 0;
                                    }
                                    i4 = 1;
                                    c2 = 1;
                                } else {
                                    i3 = size2;
                                    if (c2 == 1) {
                                        c0386u02.h(c0386u02.g(4, i38, i39));
                                        i38 = i36;
                                        i39 = 0;
                                    }
                                    i4 = 1;
                                    c2 = 0;
                                }
                                i39 += i4;
                                i36++;
                                size2 = i3;
                            }
                            i2 = size2;
                            if (i39 != c0367t06.c) {
                                jc.c(c0367t06);
                                c0367t06 = c0386u02.g(4, i38, i39);
                            }
                            if (c2 == 0) {
                                c0386u02.c(c0367t06);
                            } else {
                                c0386u02.h(c0367t06);
                            }
                        }
                    } else {
                        i2 = size2;
                        int i40 = c0367t06.b;
                        int i41 = c0367t06.c + i40;
                        int i42 = i40;
                        int i43 = 0;
                        char c3 = 65535;
                        while (i42 < i41) {
                            if (c0305pd.b(i42) == null && !c0386u02.a(i42)) {
                                if (c3 == 1) {
                                    c0386u02.h(c0386u02.g(2, i40, i43));
                                    z6 = true;
                                } else {
                                    z6 = false;
                                }
                                c = 0;
                            } else {
                                if (c3 == 0) {
                                    c0386u02.c(c0386u02.g(2, i40, i43));
                                    z5 = true;
                                } else {
                                    z5 = false;
                                }
                                z6 = z5;
                                c = 1;
                            }
                            if (z6) {
                                i42 -= i43;
                                i41 -= i43;
                                i43 = 1;
                            } else {
                                i43++;
                            }
                            i42++;
                            c3 = c;
                        }
                        if (i43 != c0367t06.c) {
                            jc.c(c0367t06);
                            c0367t06 = c0386u02.g(2, i40, i43);
                        }
                        if (c3 == 0) {
                            c0386u02.c(c0367t06);
                        } else {
                            c0386u02.h(c0367t06);
                        }
                    }
                } else {
                    i2 = size2;
                    c0386u02.h(c0367t06);
                }
                i34++;
                size2 = i2;
                i = 8;
            }
            arrayList.clear();
        } else {
            this.d.b();
        }
        boolean z10 = true;
        if (!this.f0 && !this.g0) {
            z = false;
        } else {
            z = true;
        }
        if (this.r && this.H != null && (((z4 = this.y) || z || this.l.f) && (!z4 || this.k.b))) {
            z2 = true;
        } else {
            z2 = false;
        }
        Jd jd2 = this.c0;
        jd2.j = z2;
        if (!z2 || !z || this.y || this.H == null || !this.l.z0()) {
            z10 = false;
        }
        jd2.k = z10;
        Md md = null;
        if (this.V && hasFocus() && this.k != null) {
            view = getFocusedChild();
        } else {
            view = null;
        }
        if (view != null && (A = A(view)) != null) {
            md = H(A);
        }
        long j = -1;
        if (md == null) {
            jd.m = -1L;
            jd.l = -1;
            jd.n = -1;
        } else {
            if (this.k.b) {
                j = md.e;
            }
            jd.m = j;
            if (!this.y) {
                if (md.i()) {
                    F = md.d;
                } else {
                    RecyclerView recyclerView = md.r;
                    if (recyclerView != null) {
                        F = recyclerView.F(md);
                    }
                }
                jd.l = F;
                view2 = md.a;
                int id = view2.getId();
                while (!view2.isFocused() && (view2 instanceof ViewGroup) && view2.hasFocus()) {
                    view2 = ((ViewGroup) view2).getFocusedChild();
                    if (view2.getId() == -1) {
                        id = view2.getId();
                    }
                }
                jd.n = id;
            }
            F = -1;
            jd.l = F;
            view2 = md.a;
            int id2 = view2.getId();
            while (!view2.isFocused()) {
                view2 = ((ViewGroup) view2).getFocusedChild();
                if (view2.getId() == -1) {
                }
            }
            jd.n = id2;
        }
        if (jd.j && this.g0) {
            z3 = true;
        } else {
            z3 = false;
        }
        jd.h = z3;
        this.g0 = false;
        this.f0 = false;
        jd.g = jd.k;
        jd.e = this.k.a();
        C(this.k0);
        boolean z11 = jd.j;
        Pe pe = (Pe) f1.b;
        if (z11) {
            int m = this.e.m();
            for (int i44 = 0; i44 < m; i44++) {
                Md I = I(this.e.l(i44));
                if (!I.p() && (!I.g() || this.k.b)) {
                    AbstractC0399ud abstractC0399ud = this.H;
                    AbstractC0399ud.b(I);
                    I.c();
                    abstractC0399ud.getClass();
                    ?? obj = new Object();
                    obj.a(I);
                    C0403uh c0403uh2 = (C0403uh) pe.get(I);
                    if (c0403uh2 == null) {
                        c0403uh2 = C0403uh.a();
                        pe.put(I, c0403uh2);
                    }
                    c0403uh2.b = obj;
                    c0403uh2.a |= 4;
                    if (jd.h && I.l() && !I.i() && !I.p() && !I.g()) {
                        ba.d(G(I), I);
                    }
                }
            }
        }
        if (jd.k) {
            int u = this.e.u();
            for (int i45 = 0; i45 < u; i45++) {
                Md I2 = I(this.e.t(i45));
                if (!I2.p() && I2.d == -1) {
                    I2.d = I2.c;
                }
            }
            boolean z12 = jd.f;
            jd.f = false;
            this.l.b0(this.b, jd);
            jd.f = z12;
            for (int i46 = 0; i46 < this.e.m(); i46++) {
                Md I3 = I(this.e.l(i46));
                if (!I3.p() && ((c0403uh = (C0403uh) pe.get(I3)) == null || (c0403uh.a & 4) == 0)) {
                    AbstractC0399ud.b(I3);
                    boolean d = I3.d(8192);
                    AbstractC0399ud abstractC0399ud2 = this.H;
                    I3.c();
                    abstractC0399ud2.getClass();
                    ?? obj2 = new Object();
                    obj2.a(I3);
                    if (d) {
                        T(I3, obj2);
                    } else {
                        C0403uh c0403uh3 = (C0403uh) pe.get(I3);
                        if (c0403uh3 == null) {
                            c0403uh3 = C0403uh.a();
                            pe.put(I3, c0403uh3);
                        }
                        c0403uh3.a |= 2;
                        c0403uh3.b = obj2;
                    }
                }
            }
            k();
        } else {
            k();
        }
        Q(true);
        b0(false);
        jd.d = 2;
    }

    public final void q() {
        boolean z;
        a0();
        P();
        Jd jd = this.c0;
        jd.a(6);
        this.d.b();
        jd.e = this.k.a();
        jd.c = 0;
        jd.g = false;
        this.l.b0(this.b, jd);
        jd.f = false;
        this.c = null;
        if (jd.j && this.H != null) {
            z = true;
        } else {
            z = false;
        }
        jd.j = z;
        jd.d = 4;
        Q(true);
        b0(false);
    }

    public final boolean r(int i, int i2, int i3, int[] iArr, int[] iArr2) {
        return getScrollingChildHelper().c(i, i2, i3, iArr, iArr2);
    }

    @Override // android.view.ViewGroup
    public final void removeDetachedView(View view, boolean z) {
        Md I = I(view);
        if (I != null) {
            if (I.k()) {
                I.j &= -257;
            } else if (!I.p()) {
                throw new IllegalArgumentException("Called removeDetachedView with a view which is not flagged as tmp detached." + I + y());
            }
        }
        view.clearAnimation();
        I(view);
        super.removeDetachedView(view, z);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void requestChildFocus(View view, View view2) {
        C0151ha c0151ha = this.l.e;
        if ((c0151ha == null || !c0151ha.e) && !L() && view2 != null) {
            U(view, view2);
        }
        super.requestChildFocus(view, view2);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean requestChildRectangleOnScreen(View view, Rect rect, boolean z) {
        return this.l.k0(this, view, rect, z, false);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void requestDisallowInterceptTouchEvent(boolean z) {
        ArrayList arrayList = this.n;
        int size = arrayList.size();
        for (int i = 0; i < size; i++) {
            ((C0299p7) arrayList.get(i)).getClass();
        }
        super.requestDisallowInterceptTouchEvent(z);
    }

    @Override // android.view.View, android.view.ViewParent
    public final void requestLayout() {
        if (this.s == 0 && !this.u) {
            super.requestLayout();
        } else {
            this.t = true;
        }
    }

    public final void s(int i, int i2, int i3, int i4, int[] iArr, int i5, int[] iArr2) {
        getScrollingChildHelper().d(i, i2, i3, i4, iArr, i5, iArr2);
    }

    @Override // android.view.View
    public final void scrollBy(int i, int i2) {
        AbstractC0475yd abstractC0475yd = this.l;
        if (abstractC0475yd == null) {
            Log.e("RecyclerView", "Cannot scroll without a LayoutManager set. Call setLayoutManager with a non-null argument.");
            return;
        }
        if (this.u) {
            return;
        }
        boolean d = abstractC0475yd.d();
        boolean e = this.l.e();
        if (d || e) {
            if (!d) {
                i = 0;
            }
            if (!e) {
                i2 = 0;
            }
            W(i, i2, null);
        }
    }

    @Override // android.view.View
    public final void scrollTo(int i, int i2) {
        Log.w("RecyclerView", "RecyclerView does not support scrolling to an absolute position. Use scrollToPosition instead");
    }

    @Override // android.view.View, android.view.accessibility.AccessibilityEventSource
    public final void sendAccessibilityEventUnchecked(AccessibilityEvent accessibilityEvent) {
        int i;
        if (L()) {
            int i2 = 0;
            if (accessibilityEvent != null) {
                i = accessibilityEvent.getContentChangeTypes();
            } else {
                i = 0;
            }
            if (i != 0) {
                i2 = i;
            }
            this.w |= i2;
            return;
        }
        super.sendAccessibilityEventUnchecked(accessibilityEvent);
    }

    public void setAccessibilityDelegateCompat(Od od) {
        this.j0 = od;
        AbstractC0309ph.l(this, od);
    }

    public void setAdapter(AbstractC0324qd abstractC0324qd) {
        setLayoutFrozen(false);
        AbstractC0324qd abstractC0324qd2 = this.k;
        C0107f6 c0107f6 = this.a;
        if (abstractC0324qd2 != null) {
            abstractC0324qd2.a.unregisterObserver(c0107f6);
            this.k.getClass();
        }
        AbstractC0399ud abstractC0399ud = this.H;
        if (abstractC0399ud != null) {
            abstractC0399ud.e();
        }
        AbstractC0475yd abstractC0475yd = this.l;
        Ed ed = this.b;
        if (abstractC0475yd != null) {
            abstractC0475yd.g0(ed);
            this.l.h0(ed);
        }
        ed.a.clear();
        ed.d();
        C0386u0 c0386u0 = this.d;
        c0386u0.i(c0386u0.b);
        c0386u0.i(c0386u0.c);
        AbstractC0324qd abstractC0324qd3 = this.k;
        this.k = abstractC0324qd;
        if (abstractC0324qd != null) {
            abstractC0324qd.a.registerObserver(c0107f6);
        }
        AbstractC0324qd abstractC0324qd4 = this.k;
        ed.a.clear();
        ed.d();
        Dd c = ed.c();
        if (abstractC0324qd3 != null) {
            c.b--;
        }
        if (c.b == 0) {
            int i = 0;
            while (true) {
                SparseArray sparseArray = c.a;
                if (i >= sparseArray.size()) {
                    break;
                }
                ((Cd) sparseArray.valueAt(i)).a.clear();
                i++;
            }
        }
        if (abstractC0324qd4 != null) {
            c.b++;
        }
        this.c0.f = true;
        this.z |= false;
        this.y = true;
        int u = this.e.u();
        for (int i2 = 0; i2 < u; i2++) {
            Md I = I(this.e.t(i2));
            if (I != null && !I.p()) {
                I.a(6);
            }
        }
        N();
        Ed ed2 = this.b;
        ArrayList arrayList = ed2.c;
        int size = arrayList.size();
        for (int i3 = 0; i3 < size; i3++) {
            Md md = (Md) arrayList.get(i3);
            if (md != null) {
                md.a(6);
                md.a(1024);
            }
        }
        AbstractC0324qd abstractC0324qd5 = ed2.h.k;
        if (abstractC0324qd5 == null || !abstractC0324qd5.b) {
            ed2.d();
        }
        requestLayout();
    }

    public void setChildDrawingOrderCallback(InterfaceC0361sd interfaceC0361sd) {
        if (interfaceC0361sd == null) {
            return;
        }
        setChildrenDrawingOrderEnabled(false);
    }

    @Override // android.view.ViewGroup
    public void setClipToPadding(boolean z) {
        if (z != this.g) {
            this.G = null;
            this.E = null;
            this.F = null;
            this.D = null;
        }
        this.g = z;
        super.setClipToPadding(z);
        if (this.r) {
            requestLayout();
        }
    }

    public void setEdgeEffectFactory(C0380td c0380td) {
        c0380td.getClass();
        this.C = c0380td;
        this.G = null;
        this.E = null;
        this.F = null;
        this.D = null;
    }

    public void setHasFixedSize(boolean z) {
        this.q = z;
    }

    public void setItemAnimator(AbstractC0399ud abstractC0399ud) {
        AbstractC0399ud abstractC0399ud2 = this.H;
        if (abstractC0399ud2 != null) {
            abstractC0399ud2.e();
            this.H.a = null;
        }
        this.H = abstractC0399ud;
        if (abstractC0399ud != null) {
            abstractC0399ud.a = this.h0;
        }
    }

    public void setItemViewCacheSize(int i) {
        Ed ed = this.b;
        ed.e = i;
        ed.k();
    }

    @Deprecated
    public void setLayoutFrozen(boolean z) {
        suppressLayout(z);
    }

    public void setLayoutManager(AbstractC0475yd abstractC0475yd) {
        RecyclerView recyclerView;
        C0151ha c0151ha;
        if (abstractC0475yd == this.l) {
            return;
        }
        setScrollState(0);
        Ld ld = this.W;
        ld.g.removeCallbacks(ld);
        ld.c.abortAnimation();
        AbstractC0475yd abstractC0475yd2 = this.l;
        if (abstractC0475yd2 != null && (c0151ha = abstractC0475yd2.e) != null) {
            c0151ha.i();
        }
        AbstractC0475yd abstractC0475yd3 = this.l;
        Ed ed = this.b;
        if (abstractC0475yd3 != null) {
            AbstractC0399ud abstractC0399ud = this.H;
            if (abstractC0399ud != null) {
                abstractC0399ud.e();
            }
            this.l.g0(ed);
            this.l.h0(ed);
            ed.a.clear();
            ed.d();
            if (this.p) {
                AbstractC0475yd abstractC0475yd4 = this.l;
                abstractC0475yd4.g = false;
                abstractC0475yd4.R(this);
            }
            this.l.t0(null);
            this.l = null;
        } else {
            ed.a.clear();
            ed.d();
        }
        C0294p2 c0294p2 = this.e;
        ((G3) c0294p2.c).g();
        ArrayList arrayList = (ArrayList) c0294p2.d;
        int size = arrayList.size() - 1;
        while (true) {
            recyclerView = ((C0305pd) c0294p2.b).a;
            if (size < 0) {
                break;
            }
            Md I = I((View) arrayList.get(size));
            if (I != null) {
                int i = I.p;
                if (recyclerView.L()) {
                    I.q = i;
                    recyclerView.p0.add(I);
                } else {
                    WeakHashMap weakHashMap = AbstractC0309ph.a;
                    I.a.setImportantForAccessibility(i);
                }
                I.p = 0;
            }
            arrayList.remove(size);
            size--;
        }
        int childCount = recyclerView.getChildCount();
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = recyclerView.getChildAt(i2);
            I(childAt);
            childAt.clearAnimation();
        }
        recyclerView.removeAllViews();
        this.l = abstractC0475yd;
        if (abstractC0475yd != null) {
            if (abstractC0475yd.b == null) {
                abstractC0475yd.t0(this);
                if (this.p) {
                    AbstractC0475yd abstractC0475yd5 = this.l;
                    abstractC0475yd5.g = true;
                    abstractC0475yd5.Q(this);
                }
            } else {
                throw new IllegalArgumentException("LayoutManager " + abstractC0475yd + " is already attached to a RecyclerView:" + abstractC0475yd.b.y());
            }
        }
        ed.k();
        requestLayout();
    }

    @Override // android.view.ViewGroup
    @Deprecated
    public void setLayoutTransition(LayoutTransition layoutTransition) {
        if (layoutTransition == null) {
            super.setLayoutTransition(null);
            return;
        }
        throw new IllegalArgumentException("Providing a LayoutTransition into RecyclerView is not supported. Please use setItemAnimator() instead for animating changes to the items in this RecyclerView");
    }

    @Override // android.view.View
    public void setNestedScrollingEnabled(boolean z) {
        Ub scrollingChildHelper = getScrollingChildHelper();
        if (scrollingChildHelper.d) {
            WeakHashMap weakHashMap = AbstractC0309ph.a;
            AbstractC0158hh.m(scrollingChildHelper.c);
        }
        scrollingChildHelper.d = z;
    }

    public void setOnFlingListener(Ad ad) {
        this.Q = ad;
    }

    @Deprecated
    public void setOnScrollListener(Bd bd) {
        this.d0 = bd;
    }

    public void setPreserveFocusAfterLayout(boolean z) {
        this.V = z;
    }

    public void setRecycledViewPool(Dd dd) {
        Ed ed = this.b;
        if (ed.g != null) {
            r1.b--;
        }
        ed.g = dd;
        if (dd != null && ed.h.getAdapter() != null) {
            ed.g.b++;
        }
    }

    public void setRecyclerListener(Fd fd) {
    }

    public void setScrollState(int i) {
        C0151ha c0151ha;
        if (i == this.I) {
            return;
        }
        this.I = i;
        if (i != 2) {
            Ld ld = this.W;
            ld.g.removeCallbacks(ld);
            ld.c.abortAnimation();
            AbstractC0475yd abstractC0475yd = this.l;
            if (abstractC0475yd != null && (c0151ha = abstractC0475yd.e) != null) {
                c0151ha.i();
            }
        }
        AbstractC0475yd abstractC0475yd2 = this.l;
        if (abstractC0475yd2 != null) {
            abstractC0475yd2.f0(i);
        }
        Bd bd = this.d0;
        if (bd != null) {
            bd.a(this, i);
        }
        ArrayList arrayList = this.e0;
        if (arrayList != null) {
            for (int size = arrayList.size() - 1; size >= 0; size--) {
                ((Bd) this.e0.get(size)).a(this, i);
            }
        }
    }

    public void setScrollingTouchSlop(int i) {
        ViewConfiguration viewConfiguration = ViewConfiguration.get(getContext());
        if (i != 0) {
            if (i != 1) {
                Log.w("RecyclerView", "setScrollingTouchSlop(): bad argument constant " + i + "; using default value");
            } else {
                this.P = viewConfiguration.getScaledPagingTouchSlop();
                return;
            }
        }
        this.P = viewConfiguration.getScaledTouchSlop();
    }

    public void setViewCacheExtension(Kd kd) {
        this.b.getClass();
    }

    @Override // android.view.View
    public final boolean startNestedScroll(int i) {
        return getScrollingChildHelper().g(i, 0);
    }

    @Override // android.view.View
    public final void stopNestedScroll() {
        getScrollingChildHelper().h(0);
    }

    @Override // android.view.ViewGroup
    public final void suppressLayout(boolean z) {
        C0151ha c0151ha;
        if (z != this.u) {
            i("Do not suppressLayout in layout or scroll");
            if (!z) {
                this.u = false;
                if (this.t && this.l != null && this.k != null) {
                    requestLayout();
                }
                this.t = false;
                return;
            }
            long uptimeMillis = SystemClock.uptimeMillis();
            onTouchEvent(MotionEvent.obtain(uptimeMillis, uptimeMillis, 3, 0.0f, 0.0f, 0));
            this.u = true;
            this.v = true;
            setScrollState(0);
            Ld ld = this.W;
            ld.g.removeCallbacks(ld);
            ld.c.abortAnimation();
            AbstractC0475yd abstractC0475yd = this.l;
            if (abstractC0475yd != null && (c0151ha = abstractC0475yd.e) != null) {
                c0151ha.i();
            }
        }
    }

    public final void t(int i, int i2) {
        this.B++;
        int scrollX = getScrollX();
        int scrollY = getScrollY();
        onScrollChanged(scrollX, scrollY, scrollX - i, scrollY - i2);
        Bd bd = this.d0;
        if (bd != null) {
            bd.b(this, i, i2);
        }
        ArrayList arrayList = this.e0;
        if (arrayList != null) {
            for (int size = arrayList.size() - 1; size >= 0; size--) {
                ((Bd) this.e0.get(size)).b(this, i, i2);
            }
        }
        this.B--;
    }

    public final void u() {
        if (this.G != null) {
            return;
        }
        this.C.getClass();
        EdgeEffect edgeEffect = new EdgeEffect(getContext());
        this.G = edgeEffect;
        if (this.g) {
            edgeEffect.setSize((getMeasuredWidth() - getPaddingLeft()) - getPaddingRight(), (getMeasuredHeight() - getPaddingTop()) - getPaddingBottom());
        } else {
            edgeEffect.setSize(getMeasuredWidth(), getMeasuredHeight());
        }
    }

    public final void v() {
        if (this.D != null) {
            return;
        }
        this.C.getClass();
        EdgeEffect edgeEffect = new EdgeEffect(getContext());
        this.D = edgeEffect;
        if (this.g) {
            edgeEffect.setSize((getMeasuredHeight() - getPaddingTop()) - getPaddingBottom(), (getMeasuredWidth() - getPaddingLeft()) - getPaddingRight());
        } else {
            edgeEffect.setSize(getMeasuredHeight(), getMeasuredWidth());
        }
    }

    public final void w() {
        if (this.F != null) {
            return;
        }
        this.C.getClass();
        EdgeEffect edgeEffect = new EdgeEffect(getContext());
        this.F = edgeEffect;
        if (this.g) {
            edgeEffect.setSize((getMeasuredHeight() - getPaddingTop()) - getPaddingBottom(), (getMeasuredWidth() - getPaddingLeft()) - getPaddingRight());
        } else {
            edgeEffect.setSize(getMeasuredHeight(), getMeasuredWidth());
        }
    }

    public final void x() {
        if (this.E != null) {
            return;
        }
        this.C.getClass();
        EdgeEffect edgeEffect = new EdgeEffect(getContext());
        this.E = edgeEffect;
        if (this.g) {
            edgeEffect.setSize((getMeasuredWidth() - getPaddingLeft()) - getPaddingRight(), (getMeasuredHeight() - getPaddingTop()) - getPaddingBottom());
        } else {
            edgeEffect.setSize(getMeasuredWidth(), getMeasuredHeight());
        }
    }

    public final String y() {
        return " " + super.toString() + ", adapter:" + this.k + ", layout:" + this.l + ", context:" + getContext();
    }

    public final void z(Jd jd) {
        if (getScrollState() == 2) {
            OverScroller overScroller = this.W.c;
            overScroller.getFinalX();
            overScroller.getCurrX();
            jd.getClass();
            overScroller.getFinalY();
            overScroller.getCurrY();
            return;
        }
        jd.getClass();
    }

    /* JADX WARN: Removed duplicated region for block: B:55:0x03e4  */
    /* JADX WARN: Type inference failed for: r1v12, types: [java.lang.Object, x.g9] */
    /* JADX WARN: Type inference failed for: r1v13, types: [x.Jd, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r1v8, types: [x.td, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r1v9, types: [x.ud, x.m5, java.lang.Object] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public RecyclerView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        float a;
        float a2;
        TypedArray typedArray;
        char c;
        char c2;
        boolean z;
        int i2;
        ClassLoader classLoader;
        Object[] objArr;
        Constructor constructor;
        this.a = new C0107f6(this, 24);
        this.b = new Ed(this);
        this.f = new F1(18);
        this.h = new Rect();
        this.i = new Rect();
        this.j = new RectF();
        this.m = new ArrayList();
        this.n = new ArrayList();
        this.s = 0;
        this.y = false;
        this.z = false;
        this.A = 0;
        this.B = 0;
        this.C = new Object();
        ?? obj = new Object();
        obj.a = null;
        obj.b = new ArrayList();
        obj.c = 120L;
        obj.d = 120L;
        obj.e = 250L;
        obj.f = 250L;
        obj.g = true;
        obj.h = new ArrayList();
        obj.i = new ArrayList();
        obj.j = new ArrayList();
        obj.k = new ArrayList();
        obj.l = new ArrayList();
        obj.m = new ArrayList();
        obj.n = new ArrayList();
        obj.o = new ArrayList();
        obj.p = new ArrayList();
        obj.q = new ArrayList();
        obj.r = new ArrayList();
        this.H = obj;
        this.I = 0;
        this.J = -1;
        this.T = Float.MIN_VALUE;
        this.U = Float.MIN_VALUE;
        this.V = true;
        this.W = new Ld(this);
        this.b0 = new Object();
        ?? obj2 = new Object();
        obj2.a = -1;
        obj2.b = 0;
        obj2.c = 0;
        obj2.d = 1;
        obj2.e = 0;
        obj2.f = false;
        obj2.g = false;
        obj2.h = false;
        obj2.i = false;
        obj2.j = false;
        obj2.k = false;
        this.c0 = obj2;
        this.f0 = false;
        this.g0 = false;
        C0305pd c0305pd = new C0305pd(this);
        this.h0 = c0305pd;
        this.i0 = false;
        this.k0 = new int[2];
        this.m0 = new int[2];
        this.n0 = new int[2];
        this.o0 = new int[2];
        this.p0 = new ArrayList();
        this.q0 = new I2(8, this);
        this.r0 = new C0305pd(this);
        setScrollContainer(true);
        setFocusableInTouchMode(true);
        ViewConfiguration viewConfiguration = ViewConfiguration.get(context);
        this.P = viewConfiguration.getScaledTouchSlop();
        int i3 = Build.VERSION.SDK_INT;
        if (i3 >= 26) {
            Method method = AbstractC0328qh.a;
            a = K4.c(viewConfiguration);
        } else {
            a = AbstractC0328qh.a(viewConfiguration, context);
        }
        this.T = a;
        if (i3 >= 26) {
            a2 = K4.d(viewConfiguration);
        } else {
            a2 = AbstractC0328qh.a(viewConfiguration, context);
        }
        this.U = a2;
        this.R = viewConfiguration.getScaledMinimumFlingVelocity();
        this.S = viewConfiguration.getScaledMaximumFlingVelocity();
        setWillNotDraw(getOverScrollMode() == 2);
        this.H.a = c0305pd;
        this.d = new C0386u0(new C0305pd(this));
        this.e = new C0294p2(new C0305pd(this));
        WeakHashMap weakHashMap = AbstractC0309ph.a;
        if ((i3 >= 26 ? AbstractC0195jh.a(this) : 0) == 0 && i3 >= 26) {
            AbstractC0195jh.b(this, 8);
        }
        if (getImportantForAccessibility() == 0) {
            setImportantForAccessibility(1);
        }
        this.f7x = (AccessibilityManager) getContext().getSystemService("accessibility");
        setAccessibilityDelegateCompat(new Od(this));
        int[] iArr = AbstractC0173id.a;
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, iArr, i, 0);
        if (i3 >= 29) {
            typedArray = obtainStyledAttributes;
            saveAttributeDataForStyleable(context, iArr, attributeSet, obtainStyledAttributes, i, 0);
        } else {
            typedArray = obtainStyledAttributes;
        }
        String string = typedArray.getString(8);
        if (typedArray.getInt(2, -1) == -1) {
            setDescendantFocusability(262144);
        }
        this.g = typedArray.getBoolean(1, true);
        if (typedArray.getBoolean(3, false)) {
            StateListDrawable stateListDrawable = (StateListDrawable) typedArray.getDrawable(6);
            Drawable drawable = typedArray.getDrawable(7);
            StateListDrawable stateListDrawable2 = (StateListDrawable) typedArray.getDrawable(4);
            Drawable drawable2 = typedArray.getDrawable(5);
            if (stateListDrawable != null && drawable != null && stateListDrawable2 != null && drawable2 != null) {
                Resources resources = getContext().getResources();
                c = 3;
                c2 = 2;
                new C0299p7(this, stateListDrawable, drawable, stateListDrawable2, drawable2, resources.getDimensionPixelSize(org.conscrypt.R.dimen.fastscroll_default_thickness), resources.getDimensionPixelSize(org.conscrypt.R.dimen.fastscroll_minimum_range), resources.getDimensionPixelOffset(org.conscrypt.R.dimen.fastscroll_margin));
            } else {
                throw new IllegalArgumentException("Trying to set fast scroller without both required drawables." + y());
            }
        } else {
            c = 3;
            c2 = 2;
        }
        typedArray.recycle();
        if (string != null) {
            String trim = string.trim();
            if (!trim.isEmpty()) {
                if (trim.charAt(0) == '.') {
                    trim = context.getPackageName() + trim;
                } else if (!trim.contains(".")) {
                    trim = RecyclerView.class.getPackage().getName() + '.' + trim;
                }
                String str = trim;
                try {
                    if (isInEditMode()) {
                        classLoader = getClass().getClassLoader();
                    } else {
                        classLoader = context.getClassLoader();
                    }
                    Class<? extends U> asSubclass = Class.forName(str, false, classLoader).asSubclass(AbstractC0475yd.class);
                    try {
                        constructor = asSubclass.getConstructor(t0);
                        objArr = new Object[4];
                        objArr[0] = context;
                        z = true;
                        try {
                            objArr[1] = attributeSet;
                            objArr[c2] = Integer.valueOf(i);
                            objArr[c] = 0;
                        } catch (NoSuchMethodException e) {
                            e = e;
                            NoSuchMethodException noSuchMethodException = e;
                            objArr = null;
                            try {
                                constructor = asSubclass.getConstructor(null);
                                Object[] objArr2 = objArr;
                                constructor.setAccessible(z);
                                setLayoutManager((AbstractC0475yd) constructor.newInstance(objArr2));
                                i2 = Build.VERSION.SDK_INT;
                                int[] iArr2 = s0;
                                TypedArray obtainStyledAttributes2 = context.obtainStyledAttributes(attributeSet, iArr2, i, 0);
                                if (i2 >= 29) {
                                }
                                boolean z2 = obtainStyledAttributes2.getBoolean(0, z);
                                obtainStyledAttributes2.recycle();
                                setNestedScrollingEnabled(z2);
                            } catch (NoSuchMethodException e2) {
                                e2.initCause(noSuchMethodException);
                                throw new IllegalStateException(attributeSet.getPositionDescription() + ": Error creating LayoutManager " + str, e2);
                            }
                        }
                    } catch (NoSuchMethodException e3) {
                        e = e3;
                        z = true;
                    }
                    Object[] objArr22 = objArr;
                    constructor.setAccessible(z);
                    setLayoutManager((AbstractC0475yd) constructor.newInstance(objArr22));
                    i2 = Build.VERSION.SDK_INT;
                    int[] iArr22 = s0;
                    TypedArray obtainStyledAttributes22 = context.obtainStyledAttributes(attributeSet, iArr22, i, 0);
                    if (i2 >= 29) {
                        saveAttributeDataForStyleable(context, iArr22, attributeSet, obtainStyledAttributes22, i, 0);
                    }
                    boolean z22 = obtainStyledAttributes22.getBoolean(0, z);
                    obtainStyledAttributes22.recycle();
                    setNestedScrollingEnabled(z22);
                } catch (ClassCastException e4) {
                    throw new IllegalStateException(attributeSet.getPositionDescription() + ": Class is not a LayoutManager " + str, e4);
                } catch (ClassNotFoundException e5) {
                    throw new IllegalStateException(attributeSet.getPositionDescription() + ": Unable to find LayoutManager " + str, e5);
                } catch (IllegalAccessException e6) {
                    throw new IllegalStateException(attributeSet.getPositionDescription() + ": Cannot access non-public constructor " + str, e6);
                } catch (InstantiationException e7) {
                    throw new IllegalStateException(attributeSet.getPositionDescription() + ": Could not instantiate the LayoutManager: " + str, e7);
                } catch (InvocationTargetException e8) {
                    throw new IllegalStateException(attributeSet.getPositionDescription() + ": Could not instantiate the LayoutManager: " + str, e8);
                }
            }
        }
        z = true;
        i2 = Build.VERSION.SDK_INT;
        int[] iArr222 = s0;
        TypedArray obtainStyledAttributes222 = context.obtainStyledAttributes(attributeSet, iArr222, i, 0);
        if (i2 >= 29) {
        }
        boolean z222 = obtainStyledAttributes222.getBoolean(0, z);
        obtainStyledAttributes222.recycle();
        setNestedScrollingEnabled(z222);
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        AbstractC0475yd abstractC0475yd = this.l;
        if (abstractC0475yd != null) {
            return abstractC0475yd.t(layoutParams);
        }
        throw new IllegalStateException("RecyclerView has no LayoutManager" + y());
    }
}
