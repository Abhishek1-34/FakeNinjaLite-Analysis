package org.conscrypt;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.AlgorithmParameterSpec;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import org.conscrypt.OpenSSLCipher;

/* loaded from: classes.dex */
public class OpenSSLCipherChaCha20 extends OpenSSLCipher {
    static final /* synthetic */ boolean $assertionsDisabled = false;
    private static final int BLOCK_SIZE_BYTES = 64;
    private static final int NONCE_SIZE_BYTES = 12;
    private int currentBlockConsumedBytes = 0;
    private int blockCounter = 0;

    private void reset() {
        this.blockCounter = 0;
        this.currentBlockConsumedBytes = 0;
    }

    @Override // org.conscrypt.OpenSSLCipher
    public void checkSupportedKeySize(int i) {
        if (i == 32) {
            return;
        }
        throw new InvalidKeyException("Unsupported key size: " + i + " bytes (must be 32)");
    }

    @Override // org.conscrypt.OpenSSLCipher
    public void checkSupportedMode(OpenSSLCipher.Mode mode) {
        if (mode == OpenSSLCipher.Mode.NONE) {
        } else {
            throw new NoSuchAlgorithmException("Mode must be NONE");
        }
    }

    @Override // org.conscrypt.OpenSSLCipher
    public void checkSupportedPadding(OpenSSLCipher.Padding padding) {
        if (padding == OpenSSLCipher.Padding.NOPADDING) {
        } else {
            throw new NoSuchPaddingException("Must be NoPadding");
        }
    }

    @Override // org.conscrypt.OpenSSLCipher
    public int doFinalInternal(byte[] bArr, int i, int i2) {
        reset();
        return 0;
    }

    @Override // org.conscrypt.OpenSSLCipher
    public void engineInitInternal(byte[] bArr, AlgorithmParameterSpec algorithmParameterSpec, SecureRandom secureRandom) {
        if (algorithmParameterSpec instanceof IvParameterSpec) {
            IvParameterSpec ivParameterSpec = (IvParameterSpec) algorithmParameterSpec;
            if (ivParameterSpec.getIV().length == 12) {
                this.iv = ivParameterSpec.getIV();
                return;
            }
            throw new InvalidAlgorithmParameterException("IV must be 12 bytes long");
        }
        if (isEncrypting()) {
            byte[] bArr2 = new byte[12];
            this.iv = bArr2;
            if (secureRandom != null) {
                secureRandom.nextBytes(bArr2);
                return;
            } else {
                NativeCrypto.RAND_bytes(bArr2);
                return;
            }
        }
        throw new InvalidAlgorithmParameterException("IV must be specified when decrypting");
    }

    @Override // org.conscrypt.OpenSSLCipher
    public String getBaseCipherName() {
        return "ChaCha20";
    }

    @Override // org.conscrypt.OpenSSLCipher
    public int getCipherBlockSize() {
        return 0;
    }

    @Override // org.conscrypt.OpenSSLCipher
    public int getOutputSizeForFinal(int i) {
        return i;
    }

    @Override // org.conscrypt.OpenSSLCipher
    public int getOutputSizeForUpdate(int i) {
        return i;
    }

    @Override // org.conscrypt.OpenSSLCipher
    public int updateInternal(byte[] bArr, int i, int i2, byte[] bArr2, int i3, int i4) {
        int i5;
        int i6;
        int i7;
        if (i2 <= bArr2.length - i3) {
            int i8 = this.currentBlockConsumedBytes;
            if (i8 > 0) {
                int min = Math.min(64 - i8, i2);
                byte[] bArr3 = new byte[BLOCK_SIZE_BYTES];
                byte[] bArr4 = new byte[BLOCK_SIZE_BYTES];
                System.arraycopy(bArr, i, bArr3, this.currentBlockConsumedBytes, min);
                NativeCrypto.chacha20_encrypt_decrypt(bArr3, 0, bArr4, 0, BLOCK_SIZE_BYTES, this.encodedKey, this.iv, this.blockCounter);
                System.arraycopy(bArr4, this.currentBlockConsumedBytes, bArr2, i3, min);
                int i9 = this.currentBlockConsumedBytes + min;
                this.currentBlockConsumedBytes = i9;
                if (i9 < BLOCK_SIZE_BYTES) {
                    return min;
                }
                this.currentBlockConsumedBytes = 0;
                int i10 = i + min;
                int i11 = i3 + min;
                int i12 = i2 - min;
                this.blockCounter++;
                i7 = i11;
                i5 = i10;
                i6 = i12;
            } else {
                i5 = i;
                i6 = i2;
                i7 = i3;
            }
            NativeCrypto.chacha20_encrypt_decrypt(bArr, i5, bArr2, i7, i6, this.encodedKey, this.iv, this.blockCounter);
            this.currentBlockConsumedBytes = i6 % BLOCK_SIZE_BYTES;
            this.blockCounter = (i6 / BLOCK_SIZE_BYTES) + this.blockCounter;
            return i2;
        }
        throw new ShortBufferWithoutStackTraceException("Insufficient output space");
    }
}
