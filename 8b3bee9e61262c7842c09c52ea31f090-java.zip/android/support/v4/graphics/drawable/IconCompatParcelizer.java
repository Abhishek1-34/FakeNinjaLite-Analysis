package android.support.v4.graphics.drawable;

import androidx.core.graphics.drawable.IconCompat;
import x.Yg;

/* loaded from: classes.dex */
public final class IconCompatParcelizer extends androidx.core.graphics.drawable.IconCompatParcelizer {
    public static IconCompat read(Yg yg) {
        return androidx.core.graphics.drawable.IconCompatParcelizer.read(yg);
    }

    public static void write(IconCompat iconCompat, Yg yg) {
        androidx.core.graphics.drawable.IconCompatParcelizer.write(iconCompat, yg);
    }
}
