package android.support.v4.app;

import androidx.core.app.RemoteActionCompat;
import x.Yg;

/* loaded from: classes.dex */
public final class RemoteActionCompatParcelizer extends androidx.core.app.RemoteActionCompatParcelizer {
    public static RemoteActionCompat read(Yg yg) {
        return androidx.core.app.RemoteActionCompatParcelizer.read(yg);
    }

    public static void write(RemoteActionCompat remoteActionCompat, Yg yg) {
        androidx.core.app.RemoteActionCompatParcelizer.write(remoteActionCompat, yg);
    }
}
